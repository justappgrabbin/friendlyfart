# Resonance OS App Center Recovered Source

Base: `resonance-os-appcenter-netlify-friendly-source.zip`.

Merged in app-like missing pieces from all uploaded zips without copying bloat.

## Added app windows

- App Center
- App Store
- RAG Console
- Plasmic

## Plasmic placement

Plasmic is mounted inside the App Center namespace:

- `src/components/AppWindows/PlasmicApp.tsx`
- `src/app-center/plasmic/ResonanceShellLayer.ts`
- `public/app-center/plasmic/*`

## Do not zip

- `node_modules/`
- `dist/` except when deploying dist only
- `.git/`
- cache folders

## Build

```bash
npm install   # one time only on your machine if dependencies are missing
npm run build
```

Deploy only `dist/` to Netlify.
