# AXIS + SynthOS + Smart Sandbox Merge v1

This merge uses:

- `Kimi_Agent_Phone OS Build Request (1).zip` as the visible phone OS base.
- `SynthOS_Complete_Architecture (1).zip` as substrate architecture source material.
- The sandbox substrate behavior from `axis-morphnet-smart-substrate-v2-sandbox-source.zip`.

## What changed

1. Replaced the Ingest app with Smart Sandbox Intake:
   - auto-addresses uploads immediately
   - preserves source bundles intact
   - scans zip/file structure inside a sandbox
   - detects roles like frontend/backend/config/knowledge/archive/model/media
   - detects named systems like YOU-N-I-VERSE, Agentic Reality, Trident MCP, Browser, Stellar, Symbiant Circle, Legacy, Grove
   - lets you choose Whole activation or Selected activation

2. Added SynthOS app:
   - shows the SynthOS architecture files
   - mounts the architecture as source material rather than forcing broken TS imports into the app
   - preserves all architecture documents/code in `public/synthos-architecture/`

3. Kept Phone OS base intact:
   - Boot screen
   - desktop/app grid
   - browser
   - builder
   - terminal
   - mesh
   - library
   - federation panel

## What this is

A correct combined base for the full OS, with the real Phone OS surface and a smart sandbox substrate.

## What this is not yet

- full Trident MCP execution
- Supabase cleaner repair
- Neo4j relationship graph
- full MorphNet v6 runtime
