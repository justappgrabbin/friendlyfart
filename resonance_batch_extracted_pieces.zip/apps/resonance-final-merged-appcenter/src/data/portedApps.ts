export type PortedAppKind = 'app' | 'game' | 'agent';

export interface PortedApp {
  id: string;
  source: string;
  type: PortedAppKind;
  name: string;
  icon: string;
  desc: string;
  tags: string[];
  ts: number;
  code: string;
}

export interface DualServerEndpoint {
  id: string;
  name: string;
  method: 'GET' | 'POST';
  path: string;
  desc: string;
  payload?: Record<string, unknown>;
}

export const RENDER_BASE_URL =
  import.meta.env.VITE_SYNTHIS_SERVER_URL || 'https://synthis-server.onrender.com';

export const PORTED_APPS: PortedApp[] = [
  {
    id: 'trident-fibonacci-spiral',
    source: 'TridentApp-Expo.zip',
    type: 'app',
    name: 'Fibonacci Spiral',
    icon: '🌀',
    desc: 'Animated golden spiral with a compact canvas renderer.',
    tags: ['canvas', 'fibonacci', 'geometry', 'ported'],
    ts: Date.now() - 86400000,
    code: `<html><body style="margin:0;background:#0a0a0a;display:flex;flex-direction:column;align-items:center;padding:20px"><h3 style="color:#00ff88;font-family:monospace">Fibonacci Spiral</h3><canvas id="c" width="300" height="260"></canvas><script>const c=document.getElementById('c'),x=c.getContext('2d');x.strokeStyle='#00ff88';x.lineWidth=1.5;function arc(sx,sy,r,a0,a1){x.beginPath();x.arc(sx,sy,r,a0,a1);x.stroke()}let px=150,py=130,r=80;for(let i=0;i<12;i++){arc(px,py,r,Math.PI*(i%2),Math.PI*(i%2+0.5));const a=Math.PI*(i%2+0.5);px+=Math.cos(a)*r;py+=Math.sin(a)*r;r*=0.618}<\/script></body></html>`,
  },
  {
    id: 'trident-pixel-snake',
    source: 'TridentApp-Expo.zip',
    type: 'game',
    name: 'Pixel Snake',
    icon: '🐍',
    desc: 'Classic neon snake with touch-friendly controls.',
    tags: ['game', 'canvas', 'touch', 'ported'],
    ts: Date.now() - 172800000,
    code: `<html><body style="margin:0;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh"><canvas id="s" width="240" height="240" style="border:1px solid #0f0;display:block"></canvas><div style="display:flex;gap:40px;margin-top:16px"><div style="display:flex;flex-direction:column;align-items:center;gap:4px"><button onclick="dir={x:0,y:-1}" style="padding:12px 18px;background:#0f0;border:none;border-radius:6px;font-size:18px;cursor:pointer">▲</button><div style="display:flex;gap:4px"><button onclick="dir={x:-1,y:0}" style="padding:12px 18px;background:#0f0;border:none;border-radius:6px;font-size:18px;cursor:pointer">◀</button><button onclick="dir={x:1,y:0}" style="padding:12px 18px;background:#0f0;border:none;border-radius:6px;font-size:18px;cursor:pointer">▶</button></div><button onclick="dir={x:0,y:1}" style="padding:12px 18px;background:#0f0;border:none;border-radius:6px;font-size:18px;cursor:pointer">▼</button></div></div><script>const cv=document.getElementById('s'),cx=cv.getContext('2d');let snake=[{x:12,y:12}],dir={x:1,y:0},food={x:18,y:6};setInterval(()=>{const h={x:snake[0].x+dir.x,y:snake[0].y+dir.y};if(h.x<0||h.x>23||h.y<0||h.y>23){snake=[{x:12,y:12}];return}snake.unshift(h);if(h.x===food.x&&h.y===food.y){food={x:Math.floor(Math.random()*24),y:Math.floor(Math.random()*24)}}else snake.pop();cx.fillStyle='#000';cx.fillRect(0,0,240,240);cx.fillStyle='#0f0';snake.forEach(s=>cx.fillRect(s.x*10,s.y*10,9,9));cx.fillStyle='#f00';cx.fillRect(food.x*10,food.y*10,9,9)},140)<\/script></body></html>`,
  },
  {
    id: 'trident-weather-poet',
    source: 'TridentApp-Expo.zip',
    type: 'agent',
    name: 'Weather Poet',
    icon: '🌦️',
    desc: 'Tiny weather-to-poetry agent ported from the Expo gallery.',
    tags: ['agent', 'poetry', 'weather', 'ported'],
    ts: Date.now() - 259200000,
    code: `<html><body style="margin:0;background:#1a1a2e;padding:24px;font-family:Georgia,serif;color:#e0e0ff;min-height:100vh"><h2 style="color:#7878ff;margin:0 0 8px">🌦 Weather Poet Agent</h2><p style="color:#888;font-size:13px;margin:0 0 20px">Tap a weather to generate a verse</p><div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:20px"><button onclick="poem('rain')" style="padding:8px 16px;background:rgba(120,120,255,0.2);color:#aaf;border:1px solid rgba(120,120,255,0.4);border-radius:20px;cursor:pointer;font-size:13px">🌧 Rain</button><button onclick="poem('sun')" style="padding:8px 16px;background:rgba(255,200,0,0.15);color:#ffd;border:1px solid rgba(255,200,0,0.3);border-radius:20px;cursor:pointer;font-size:13px">☀️ Sun</button><button onclick="poem('storm')" style="padding:8px 16px;background:rgba(255,80,80,0.15);color:#fcc;border:1px solid rgba(255,80,80,0.3);border-radius:20px;cursor:pointer;font-size:13px">⛈ Storm</button><button onclick="poem('snow')" style="padding:8px 16px;background:rgba(180,220,255,0.15);color:#cef;border:1px solid rgba(180,220,255,0.3);border-radius:20px;cursor:pointer;font-size:13px">❄️ Snow</button></div><div id="p" style="line-height:2;font-style:italic;color:#c8c8ff;font-size:15px;padding:20px;background:rgba(255,255,255,0.04);border-radius:12px;border-left:3px solid #7878ff">Tap a weather above to begin…</div><script>const poems={rain:['The rain descends in silver threads,','Through asphalt dreams and flower beds.','Each drop a whisper, each puddle a mirror,','Of clouds that drift and skies grown clearer.'],sun:['The sun ascends its throne of light,','And chases shadows left from night.','Each golden ray a word of praise,','For all the warmth of summer days.'],storm:['The thunder speaks in ancient tongues,','And lightning fills the sky like lungs.','The world holds breath, then sighs with rain,','As storms remind us: growth needs pain.'],snow:['The snow descends on silent wings,','And softens all the sharper things.','A hush, a veil, a moonlit seam,','The world rewritten as a dream.']};function poem(w){document.getElementById('p').innerHTML=poems[w].join('<br>')}<\/script></body></html>`,
  },
];

export const DUAL_SERVER_ENDPOINTS: DualServerEndpoint[] = [
  { id: 'health', name: 'Health Probe', method: 'GET', path: '/health', desc: 'Render backend liveness probe.' },
  { id: 'rag-query', name: 'RAG Query', method: 'POST', path: '/rag/query', desc: 'Send a prompt into the dual-server RAG endpoint.', payload: { query: 'substrate status', topK: 5 } },
  { id: 'broadcast', name: 'Broadcast', method: 'POST', path: '/broadcast', desc: 'Broadcast a message/event into the dual-server mesh.', payload: { type: 'os_ping', message: 'Resonance OS online' } },
  { id: 'agent-action', name: 'Agent Action', method: 'POST', path: '/agent/action', desc: 'Trigger a backend agent action.', payload: { action: 'inspect', target: 'app-center' } },
];
