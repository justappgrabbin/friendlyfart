import { RENDER_BASE_URL } from '../data/portedApps';

export async function callSynthisEndpoint(path: string, options: RequestInit = {}) {
  const safePath = path.startsWith('/') ? path : `/${path}`;
  const response = await fetch(`${RENDER_BASE_URL}${safePath}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });

  const text = await response.text();
  let body: unknown = text;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    // Keep raw text if backend returns non-JSON.
  }

  if (!response.ok) {
    throw new Error(`${response.status} ${response.statusText}: ${typeof body === 'string' ? body : JSON.stringify(body)}`);
  }

  return body;
}
