
import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import JSZip from "jszip";
import { createClient } from "@supabase/supabase-js";
import {
  Home, Upload, FolderTree, Cpu, Grid3X3, Sparkles, CheckSquare, Square,
  Play, Search, Box, Database, Radio, Eye, Wand2, Paintbrush, ShieldAlert,
  RefreshCw, Settings, UserRound, Network, Store, FileCode2, X
} from "lucide-react";
import "./styles.css";

const RENDER_URL = import.meta.env.VITE_RENDER_SERVER_URL || "";
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || "";
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || "";
const BUCKET = import.meta.env.VITE_SUPABASE_RAW_BUCKET || "raw-files";

const supabase = SUPABASE_URL && SUPABASE_ANON_KEY
  ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

const K = {
  objects: "resonance.axis.objects",
  sandboxes: "resonance.axis.sandboxes",
  events: "resonance.axis.events",
  profile: "resonance.axis.profile",
  activeApp: "resonance.axis.activeApp",
};

const DEFAULT_PROFILE = {
  name: "User",
  humanDesign: "",
  designNotes: "",
  previousInteractions: []
};

const ROLE_MARKERS = {
  archive: [".zip", ".tar", ".gz", ".rar", ".7z"],
  frontend: [".tsx", ".jsx", ".html", ".css", ".scss", ".vue", ".svelte"],
  backend: [".py", ".ts", ".js", ".go", ".rs", ".rb", ".php"],
  config: ["package.json", "vite.config", "next.config", "dockerfile", "docker-compose", "netlify", "supabase", "tsconfig", "tailwind"],
  knowledge: [".pdf", ".docx", ".md", ".txt", ".csv", ".json", ".jsonl"],
  media: [".png", ".jpg", ".jpeg", ".svg", ".webp", ".gif", ".mp4", ".mp3"],
  model: [".onnx", ".pt", ".pth", ".pkl", ".gguf", ".safetensors"],
};

const seedObjects = [
  { name: "YOU-N-I-VERSE", kind: "place", placement: "Home", status: "seeded", purpose: "Agent home and indiverse base" },
  { name: "Agentic Reality", kind: "place", placement: "Peek Tray", status: "seeded", purpose: "Mirrored addressed world" },
  { name: "App Center", kind: "system", placement: "Apps", status: "active", purpose: "Release destination for activated apps" },
  { name: "Morph Substrate", kind: "system", placement: "Substrate", status: "active", purpose: "Structure analysis and morph planning" },
  { name: "Visual Editor", kind: "tool", placement: "App Center", status: "placeholder", purpose: "Future Plasmic-style visual editing" },
];

function load(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}
function save(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
function id() { return crypto.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`; }
function slugify(value) {
  return String(value || "unnamed").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "unnamed";
}
function makeAddress(kind, name, extra = {}) {
  return {
    ontological_address: `axis://${kind}/${slugify(name)}/${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
    kind,
    slug: slugify(name),
    created_at: new Date().toISOString(),
    ...extra
  };
}
function emit(type, payload = {}) {
  const events = load(K.events, []);
  const event = { id: id(), type, payload, at: new Date().toISOString() };
  save(K.events, [event, ...events].slice(0, 500));
  return event;
}
function roleOf(path) {
  const p = path.toLowerCase();
  for (const [role, markers] of Object.entries(ROLE_MARKERS)) {
    if (markers.some(m => p.endsWith(m) || p.includes(m))) return role;
  }
  return "unknown";
}
function specialOf(path) {
  const p = path.toLowerCase();
  if (p.includes("you-n-i") || p.includes("youniverse") || p.includes("ynv")) return "YOU-N-I-VERSE";
  if (p.includes("app-center") || p.includes("appcenter") || p.includes("store") || p.includes("tray")) return "App Center";
  if (p.includes("agentic") || p.includes("reality") || p.includes("arcadia") || p.includes("world")) return "Agentic Reality";
  if (p.includes("trident") || p.includes("mcp")) return "Trident MCP";
  if (p.includes("mobile-mcp")) return "Mobile MCP";
  if (p.includes("plasmic")) return "Visual Editor / Plasmic";
  if (p.includes("browser")) return "Browser";
  if (p.includes("stellar") || p.includes("proximology")) return "Stellar Proximology";
  if (p.includes("symbiant") || p.includes("resonance") || p.includes("circle")) return "Symbiant Circle";
  if (p.includes("legacy") || p.includes("house")) return "Legacy Builder";
  if (p.includes("human") && p.includes("design")) return "Human Design";
  return "";
}
function inferPurpose(summary, declaredPurpose) {
  if (declaredPurpose?.trim()) return { purpose: declaredPurpose.trim(), confidence: 0.94, basis: "declared_by_user" };
  const specials = summary.special_roles || [];
  if (specials.length === 1) return { purpose: specials[0], confidence: 0.86, basis: "special_role_detected" };
  if (specials.length > 1) return { purpose: "multi-system ecosystem", confidence: 0.78, basis: "multiple_special_roles" };
  if (summary.role_counts.frontend && summary.role_counts.backend) return { purpose: "full-stack app ecosystem", confidence: 0.76, basis: "frontend_backend_structure" };
  if (summary.role_counts.frontend) return { purpose: "frontend app or shell", confidence: 0.68, basis: "frontend_structure" };
  if (summary.role_counts.knowledge) return { purpose: "knowledge/source library", confidence: 0.66, basis: "knowledge_files" };
  if (summary.role_counts.model) return { purpose: "model/runtime artifact", confidence: 0.70, basis: "model_files" };
  return { purpose: "unknown intention seed", confidence: 0.35, basis: "insufficient_structure" };
}
function placementFor(intent) {
  const p = intent.purpose.toLowerCase();
  if (p.includes("app") || p.includes("shell") || p.includes("you-n-i") || p.includes("symbiant") || p.includes("browser")) return "App Center";
  if (p.includes("backend") || p.includes("mcp") || p.includes("trident") || p.includes("mobile")) return "Render / Trident";
  if (p.includes("knowledge") || p.includes("stellar") || p.includes("human design")) return "Library / Stellar";
  if (p.includes("reality") || p.includes("world") || p.includes("legacy")) return "Agentic Reality";
  return "Agent Review";
}
function buildMorphPlan({ sandbox, intent, userProfile, mode }) {
  const missing = [];
  if (!supabase) missing.push("Supabase client is not configured. Raw file upload will remain local-plan only.");
  if (!RENDER_URL) missing.push("Render URL is not configured. Regeneration will be an activation plan only.");
  if (!userProfile?.humanDesign && mode === "adaptive") missing.push("Human Design profile is empty. Adaptive mode can only use notes/history.");
  return {
    id: id(),
    sandbox_address: sandbox.ontological_address,
    source_name: sandbox.source_name,
    morph_mode: mode,
    interpreted_purpose: intent.purpose,
    confidence: intent.confidence,
    placement: placementFor(intent),
    considers: {
      structure: true,
      previous_interactions: true,
      human_design: Boolean(userProfile?.humanDesign),
      visual_editing: true
    },
    actions: [
      "preserve raw upload",
      "assign ontological address",
      "send raw file to Supabase when configured",
      "analyze structure inside sandbox",
      mode === "adaptive" ? "render custom user-fitted version" : "regenerate supported identical-system version",
      "agent review before release",
      "release executable/mountable artifact to App Center"
    ],
    missing,
    status: "planned",
    created_at: new Date().toISOString()
  };
}
async function uploadRawToSupabase(file, sourceAddress) {
  if (!supabase) return { ok: false, skipped: true, reason: "missing_supabase_env" };
  const safeName = `${sourceAddress.slug}/${Date.now()}-${file.name}`;
  const { data, error } = await supabase.storage.from(BUCKET).upload(safeName, file, { upsert: false });
  if (error) {
    emit("supabase.raw_upload.failed", { message: error.message, bucket: BUCKET });
    return { ok: false, error: error.message, bucket: BUCKET };
  }
  emit("supabase.raw_upload.ok", { bucket: BUCKET, path: data.path });
  return { ok: true, bucket: BUCKET, path: data.path };
}
async function callRender(path, payload) {
  if (!RENDER_URL) {
    emit("render.skipped", { path, reason: "missing_render_url" });
    return { ok: false, skipped: true };
  }
  const response = await fetch(`${RENDER_URL}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await response.json().catch(() => ({}));
  emit("render.response", { path, status: response.status, data });
  return data;
}
async function createSandbox(file, declaredPurpose, note, userProfile) {
  const sourceAddress = makeAddress("source", file.name);
  const sandboxAddress = makeAddress("sandbox", file.name);
  const rawUpload = await uploadRawToSupabase(file, sourceAddress);
  const isZip = file.name.toLowerCase().endsWith(".zip") || file.type.includes("zip");
  let entries = [];

  if (isZip) {
    try {
      const zip = await JSZip.loadAsync(file);
      zip.forEach((path, entry) => {
        if (!entry.dir) entries.push({
          path,
          role: roleOf(path),
          special_role: specialOf(path),
          size: entry._data?.uncompressedSize || 0,
          selected: false
        });
      });
    } catch (err) {
      entries.push({ path: file.name, role: "archive", special_role: "", size: file.size || 0, selected: false, error: String(err.message || err) });
    }
  } else {
    entries.push({ path: file.name, role: roleOf(file.name), special_role: specialOf(file.name), size: file.size || 0, selected: false });
  }

  const role_counts = entries.reduce((acc, e) => {
    acc[e.role] = (acc[e.role] || 0) + 1;
    return acc;
  }, {});
  const special_roles = [...new Set(entries.map(e => e.special_role).filter(Boolean))];
  const summary = {
    file_count: entries.length,
    role_counts,
    special_roles,
    dominant_role: Object.entries(role_counts).sort((a,b) => b[1] - a[1])[0]?.[0] || "unknown",
    nested_archives: role_counts.archive || 0,
    top_dirs: [...new Set(entries.map(e => e.path.split("/")[0]))].slice(0, 30)
  };
  const intent = inferPurpose(summary, declaredPurpose);
  const plan = buildMorphPlan({ sandbox: { ...sandboxAddress, source_name: file.name }, intent, userProfile, mode: "supported-copy" });

  const sandbox = {
    ...sandboxAddress,
    source_address: sourceAddress.ontological_address,
    source_name: file.name,
    source_preserved: true,
    raw_supabase: rawUpload,
    declared_purpose: declaredPurpose || "",
    note: note || "",
    status: "sandboxed-not-released",
    summary,
    entries,
    intent,
    morph_plan: plan,
    app_center_release: null
  };

  const sandboxes = load(K.sandboxes, []);
  save(K.sandboxes, [sandbox, ...sandboxes].slice(0, 100));

  const objects = load(K.objects, []);
  save(K.objects, [{
    ...sourceAddress,
    name: file.name,
    status: "sandboxed",
    kind: "uploaded-ecosystem",
    placement: "Sandbox",
    sandbox_address: sandbox.ontological_address,
    raw_supabase: rawUpload,
    reality_presence: true
  }, ...objects].slice(0, 700));

  emit("sandbox.created", { sandbox_address: sandbox.ontological_address, source_address: sourceAddress.ontological_address, raw_supabase: rawUpload });
  callRender("/intake/sandbox", { sandbox, user_profile: userProfile }).catch(err => emit("render.error", { message: err.message }));
  return sandbox;
}
function updateSandbox(sandbox) {
  const sandboxes = load(K.sandboxes, []);
  save(K.sandboxes, sandboxes.map(s => s.ontological_address === sandbox.ontological_address ? sandbox : s));
}
function releaseToAppCenter(sandbox, mode, userProfile) {
  const intent = sandbox.intent || inferPurpose(sandbox.summary, sandbox.declared_purpose);
  const plan = buildMorphPlan({ sandbox, intent, userProfile, mode });
  const release = {
    ...makeAddress("app", sandbox.source_name),
    name: sandbox.source_name.replace(/\.(zip|html|pdf|txt|json)$/i, ""),
    source_sandbox: sandbox.ontological_address,
    interpreted_purpose: intent.purpose,
    morph_mode: mode,
    status: plan.missing.length ? "queued-needs-infrastructure" : "released-local",
    placement: "App Center",
    executable_kind: "mount-plan",
    plan,
    reality_presence: true
  };
  const objects = load(K.objects, []);
  save(K.objects, [release, ...objects].slice(0, 700));
  const updated = { ...sandbox, status: "released-to-app-center", app_center_release: release, morph_plan: plan };
  updateSandbox(updated);
  emit("appcenter.release.created", { release, missing: plan.missing });
  callRender("/morph/regenerate", { sandbox: updated, release, user_profile: userProfile }).catch(err => emit("render.error", { message: err.message }));
  return release;
}

function Panel({ children, className = "" }) { return <section className={`panel ${className}`}>{children}</section>; }

function Header({ vitality, setVitality }) {
  return <header>
    <div className="header-left">
      <div className={`led ${vitality}`}></div>
      <span className="os-title">⬡ Resonance OS</span>
    </div>
    <div className="header-right">
      <select className="vitality-select" value={vitality} onChange={e => setVitality(e.target.value)}>
        <option value="dormant">DORMANT</option>
        <option value="observing">OBSERVING</option>
        <option value="active">ACTIVE</option>
        <option value="resonant">RESONANT</option>
      </select>
    </div>
  </header>;
}

function HomeScreen({ state }) {
  return <main>
    <div className="wallpaper">
      <div className="wallpaper-glyph">⬡ ⬡ ⬡</div>
      <div className="wallpaper-title">Resonance OS</div>
      <div className="wallpaper-sub">PHONE SHELL · MORPH SUBSTRATE · APP CENTER</div>
    </div>
    <div className="home-stack">
      <Panel>
        <h2>YOU-N-I-VERSE Base</h2>
        <p>Files become addressed ecosystems. The raw file is preserved, sandboxed, optionally morphed, then released to App Center.</p>
        <div className="info-box"><strong>{state.objects.length}</strong> addressed objects · <strong>{state.sandboxes.length}</strong> sandboxes · <strong>{state.events.length}</strong> events</div>
      </Panel>
    </div>
  </main>;
}

function IngestScreen({ refresh, userProfile }) {
  const [files, setFiles] = useState([]);
  const [purpose, setPurpose] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    try {
      const selected = Array.from(files || []);
      if (!selected.length) selected.push(new File([note || ""], "blank-intention.txt", { type: "text/plain" }));
      for (const file of selected) await createSandbox(file, purpose, note, userProfile);
      setFiles([]); setPurpose(""); setNote("");
      refresh();
    } finally {
      setBusy(false);
    }
  }

  return <Window title="Universal File Ingester">
    <Panel>
      <label className="upload-zone">
        <div className="upload-zone-icon">◈</div>
        <p>{files.length ? `${files.length} file(s) selected` : "Select any file, zip, PDF, HTML, model, app, or blank seed"}</p>
        <input type="file" multiple onChange={e => setFiles(e.target.files)} />
      </label>
      <input value={purpose} onChange={e => setPurpose(e.target.value)} placeholder="Optional intended purpose" />
      <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Optional user/design context, previous interaction clue, or build request" />
      <button className="action-btn primary" onClick={run} disabled={busy}>{busy ? "Scanning..." : "Auto-address + Store Raw + Sandbox"}</button>
    </Panel>
    <Panel>
      <h2>Pipeline</h2>
      <p>File → ontological address → Supabase raw storage when configured → sandbox scan → purpose inference → morph plan → release to App Center.</p>
    </Panel>
  </Window>;
}

function SandboxScreen({ state, refresh, userProfile }) {
  const [active, setActive] = useState("");
  const [query, setQuery] = useState("");
  const sandbox = state.sandboxes.find(s => s.ontological_address === active) || state.sandboxes[0];

  useEffect(() => {
    if (!active && state.sandboxes[0]) setActive(state.sandboxes[0].ontological_address);
  }, [state.sandboxes.length]);

  function toggle(path) {
    const updated = {
      ...sandbox,
      entries: sandbox.entries.map(e => e.path === path ? { ...e, selected: !e.selected } : e),
      status: "selection-in-progress"
    };
    updateSandbox(updated);
    emit("sandbox.selection.updated", { sandbox: sandbox.ontological_address, path });
    refresh();
  }

  const entries = (sandbox?.entries || []).filter(e => !query || `${e.path} ${e.role} ${e.special_role}`.toLowerCase().includes(query.toLowerCase())).slice(0, 500);
  const selectedCount = sandbox?.entries?.filter(e => e.selected).length || 0;

  return <Window title="Sandbox Inspector">
    {!sandbox ? <Panel><p>No sandbox yet. Use Ingest first.</p></Panel> : <>
      <select value={sandbox.ontological_address} onChange={e => setActive(e.target.value)}>
        {state.sandboxes.map(s => <option key={s.ontological_address} value={s.ontological_address}>{s.source_name}</option>)}
      </select>
      <Panel>
        <h2>{sandbox.source_name}</h2>
        <div className="info-box">
          <strong>Address:</strong> {sandbox.ontological_address}<br/>
          <strong>Purpose:</strong> {sandbox.intent?.purpose} ({Math.round((sandbox.intent?.confidence || 0) * 100)}%)<br/>
          <strong>Raw file:</strong> {sandbox.raw_supabase?.ok ? `Supabase: ${sandbox.raw_supabase.path}` : `not uploaded (${sandbox.raw_supabase?.reason || sandbox.raw_supabase?.error || "unknown"})`}
        </div>
        <div className="chips">
          <span>{sandbox.summary.file_count} files</span>
          <span>{sandbox.summary.dominant_role}</span>
          <span>{sandbox.summary.nested_archives} nested archives</span>
          {(sandbox.summary.special_roles || []).map(role => <span key={role}>{role}</span>)}
        </div>
        <div className="actions-row">
          <button className="action-btn" onClick={() => { releaseToAppCenter(sandbox, "supported-copy", userProfile); refresh(); }}><RefreshCw size={15}/> Supported Copy</button>
          <button className="action-btn" onClick={() => { releaseToAppCenter(sandbox, "adaptive", userProfile); refresh(); }}><Wand2 size={15}/> Adaptive Render</button>
          <button className="action-btn" disabled={!selectedCount} onClick={() => { releaseToAppCenter({ ...sandbox, selected_count: selectedCount }, "selected-pieces", userProfile); refresh(); }}><CheckSquare size={15}/> Selected ({selectedCount})</button>
        </div>
        {sandbox.morph_plan?.missing?.length > 0 && <div className="warning"><ShieldAlert size={16}/>{sandbox.morph_plan.missing.join(" ")}</div>}
      </Panel>
      <div className="search"><Search size={16}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="filter files / roles" /></div>
      <div className="file-list">
        {entries.map(e => <button className={`file-row ${e.selected ? "selected" : ""}`} key={e.path} onClick={() => toggle(e.path)}>
          {e.selected ? <CheckSquare size={16}/> : <Square size={16}/>}
          <span>{e.path}</span>
          <small>{e.role}{e.special_role ? ` · ${e.special_role}` : ""}</small>
        </button>)}
      </div>
    </>}
  </Window>;
}

function AppCenter({ state, openApp }) {
  const apps = state.objects.filter(o => o.placement === "App Center" || o.kind === "app" || o.executable_kind === "mount-plan");
  const baseApps = state.objects.filter(o => ["YOU-N-I-VERSE", "Agentic Reality", "App Center", "Morph Substrate", "Visual Editor"].includes(o.name));
  const visible = [...apps, ...baseApps].filter((v, i, arr) => arr.findIndex(x => x.ontological_address === v.ontological_address || x.name === v.name) === i);

  return <Window title="App Center">
    <div className="app-grid">
      {visible.map(app => <button className="app-card" key={app.ontological_address || app.name} onClick={() => openApp(app)}>
        <div className="app-symbol">{app.name?.includes("Visual") ? "✎" : app.name?.includes("Agentic") ? "⬡" : app.name?.includes("Morph") ? "◈" : "◎"}</div>
        <strong>{app.name}</strong>
        <small>{app.status || app.purpose || app.placement}</small>
      </button>)}
    </div>
  </Window>;
}

function SubstrateScreen({ state }) {
  return <Window title="Substrate Status">
    <div className="mesh-layer">
      <div className="mesh-layer-title">Runtime Wiring</div>
      <div className="info-box">
        <strong>Supabase:</strong> {supabase ? "configured" : "not configured"}<br/>
        <strong>Render:</strong> {RENDER_URL || "not configured"}<br/>
        <strong>Raw bucket:</strong> {BUCKET}<br/>
        <strong>Mobile MCP:</strong> integration target, not bundled<br/>
        <strong>Plasmic:</strong> visual editor target, not bundled
      </div>
    </div>
    <div className="mesh-layer">
      <div className="mesh-layer-title">Events</div>
      <div className="agent-terminal">
        {state.events.length ? state.events.map(e => <div className="terminal-line" key={e.id}>› {e.type} · {new Date(e.at).toLocaleTimeString()}</div>) : <div className="terminal-line">› no events yet</div>}
        <span className="blink"/>
      </div>
    </div>
  </Window>;
}

function ProfileScreen({ userProfile, setUserProfile }) {
  function setField(field, value) {
    const next = { ...userProfile, [field]: value };
    setUserProfile(next);
    save(K.profile, next);
    emit("profile.updated", { field });
  }
  return <Window title="User Design Profile">
    <Panel>
      <h2>Adaptive Context</h2>
      <p>This is what adaptive morph plans are allowed to consider.</p>
      <input value={userProfile.name} onChange={e => setField("name", e.target.value)} placeholder="Name / agent label" />
      <textarea value={userProfile.humanDesign} onChange={e => setField("humanDesign", e.target.value)} placeholder="Human Design notes / gates / profile / authority / etc." />
      <textarea value={userProfile.designNotes} onChange={e => setField("designNotes", e.target.value)} placeholder="Design preferences and previous interaction patterns" />
    </Panel>
  </Window>;
}

function Window({ title, children }) {
  return <main>
    <div className="window">
      <div className="window-titlebar"><div className="window-title">{title}</div></div>
      <div className="window-body">{children}</div>
    </div>
  </main>;
}

function RealityTray({ state }) {
  const [open, setOpen] = useState(false);
  const latest = state.objects[0];
  return <div className="reality-tray">
    <button className="reality-tab" onClick={() => setOpen(!open)}><Sparkles size={15}/> Agentic Reality · {latest?.name || "waiting"}</button>
    {open && <div className="reality-body">
      <h3>Peek Tray</h3>
      <p>Every addressed thing appears here. Sandboxes are construction zones until released.</p>
      {state.objects.slice(0, 8).map(o => <div className="reality-object" key={o.ontological_address || o.name}>
        <Box size={15}/>
        <div><strong>{o.name}</strong><small>{o.placement || o.kind} · {o.status || "registered"}</small></div>
      </div>)}
    </div>}
  </div>;
}

function FullAppModal({ app, close }) {
  if (!app) return null;
  return <div className="modal">
    <div className="modal-card">
      <button className="close" onClick={close}><X size={18}/></button>
      <h2>{app.name}</h2>
      <div className="info-box">
        <strong>Address:</strong> {app.ontological_address || "seeded-app"}<br/>
        <strong>Status:</strong> {app.status || "mount point"}<br/>
        <strong>Placement:</strong> {app.placement || "App Center"}
      </div>
      <p>This is a mount point. If this came from a sandbox release, its morph plan is stored with the release object.</p>
      {app.plan?.missing?.length > 0 && <div className="warning"><ShieldAlert size={16}/>{app.plan.missing.join(" ")}</div>}
    </div>
  </div>;
}

function App() {
  const [tab, setTab] = useState("home");
  const [vitality, setVitality] = useState("observing");
  const [profile, setProfile] = useState(load(K.profile, DEFAULT_PROFILE));
  const [openedApp, setOpenedApp] = useState(null);
  const [state, setState] = useState({
    objects: load(K.objects, []),
    sandboxes: load(K.sandboxes, []),
    events: load(K.events, [])
  });

  const refresh = () => setState({
    objects: load(K.objects, []),
    sandboxes: load(K.sandboxes, []),
    events: load(K.events, [])
  });

  useEffect(() => {
    if (!load(K.objects, []).length) {
      const seeded = seedObjects.map(o => ({ ...makeAddress(o.kind, o.name), ...o, reality_presence: true }));
      save(K.objects, seeded);
      emit("system.seeded", { count: seeded.length });
      refresh();
    }
  }, []);

  useEffect(() => {
    const t = setInterval(refresh, 1000);
    return () => clearInterval(t);
  }, []);

  return <div className="os">
    <Header vitality={vitality} setVitality={setVitality} />
    {tab === "home" && <HomeScreen state={state}/>}
    {tab === "ingest" && <IngestScreen refresh={refresh} userProfile={profile}/>}
    {tab === "sandbox" && <SandboxScreen state={state} refresh={refresh} userProfile={profile}/>}
    {tab === "apps" && <AppCenter state={state} openApp={setOpenedApp}/>}
    {tab === "substrate" && <SubstrateScreen state={state}/>}
    {tab === "profile" && <ProfileScreen userProfile={profile} setUserProfile={setProfile}/>}
    <RealityTray state={state}/>
    <nav>
      <button className="dock-btn" onClick={() => setTab("home")}><div className="dock-icon">⌂</div><span className="dock-label">Home</span></button>
      <button className="dock-btn" onClick={() => setTab("ingest")}><div className="dock-icon">⊞</div><span className="dock-label">Ingest</span></button>
      <button className="dock-btn" onClick={() => setTab("sandbox")}><div className="dock-icon">◈</div><span className="dock-label">Sandbox</span></button>
      <button className="dock-btn" onClick={() => setTab("apps")}><div className="dock-icon">◎</div><span className="dock-label">Apps</span></button>
      <button className="dock-btn" onClick={() => setTab("substrate")}><div className="dock-icon">⬡</div><span className="dock-label">Substrate</span></button>
      <button className="dock-btn" onClick={() => setTab("profile")}><div className="dock-icon">☊</div><span className="dock-label">Design</span></button>
    </nav>
    <FullAppModal app={openedApp} close={() => setOpenedApp(null)}/>
  </div>;
}

createRoot(document.getElementById("root")).render(<App/>);
