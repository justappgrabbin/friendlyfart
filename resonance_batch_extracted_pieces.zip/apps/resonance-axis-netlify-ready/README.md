# Resonance AXIS Netlify Ready

This package replaces the shell/App Center direction with the uploaded Resonance OS and Resonance App Center concepts.

## Netlify

Build command:

```bash
npm run build
```

Publish directory:

```text
dist
```

## Environment variables

```env
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
VITE_RENDER_SERVER_URL=https://synthia-server.onrender.com
VITE_SUPABASE_RAW_BUCKET=raw-files
```

## What it does

- Phone-friendly Resonance OS shell
- Universal file ingester
- Ontological address assignment
- Sandbox structural analysis
- App Center release plans
- Supabase raw-file upload attempt when configured
- Adaptive vs supported-copy morph plan
- User design/human-design notes panel
- Visual editor placeholder/mount point
- No silent deletion: missing pieces are reported in BUILD_REPORT.json and in runtime warnings
