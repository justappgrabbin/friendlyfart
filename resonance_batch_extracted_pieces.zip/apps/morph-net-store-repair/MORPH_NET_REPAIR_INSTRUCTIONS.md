# Morph Net Repair Payload

## Goal
Repair only the build/type layer for the OS app. Do not remove app panels, routes, store fields, donor capsules, or UI components.

## Primary target
The custom Zustand-derived store and its consumers:
- `src/store/useOSStore.ts`
- `src/types/os.ts`
- all `useOSStore((s) => ...)` selectors across `src/**`

## Current build failures to repair
1. `Cannot find module 'zustand'` from `src/store/useOSStore.ts`.
   - Either add/restore the dependency, or replace with the custom local Zustand-base implementation if present.
   - Keep the public API name `useOSStore` unless absolutely impossible.

2. Many `Parameter 's' implicitly has an 'any' type` errors in selectors.
   - Fix by properly typing the store hook and store state.
   - Preferred outcome: components do not need manual `(s: OSState)` annotations everywhere because the hook inference works.

3. `Cannot find module 'react-router'` from `src/main.tsx`.
   - Use the installed router package if present, usually `react-router-dom`, or remove router dependency if the app shell does not need it.

4. `Cannot find module 'kimi-plugin-inspect-react'` from `vite.config.ts`.
   - Make this plugin optional, remove it, or guard it behind environment availability.
   - Do not make the production build require a missing dev plugin.

5. Unknown/object errors in UI files such as `FairyApp.tsx`, `Topbar.tsx`, `WindowManager.tsx`.
   - Repair types. Do not delete features.

## Non-removal rule
No silent removals. If a feature/file is stubbed, renamed, disabled, or replaced, write it into `MORPH_NET_CHANGELOG.md`.

## Expected output
Return the repaired app folder with:
- `npm run build` passing, or
- a clear `MORPH_NET_CHANGELOG.md` listing remaining errors and why.

## Keep intact
- App Center
- App Store
- Browser panel
- Dual Server / RAG console
- Render endpoint default: `https://synthis-server.onrender.com`
- PeekAgentBoo placeholder/future panel references, if present
