# Resonance Batch Extracted Pieces

Curated extraction from the uploaded ZIP batch.

## Top-level placement

- `apps/` — visible app/source surfaces
- `services/synthia-server/` — backend/server/synthos pieces
- `core/runtime/` — remount/runtime layers
- `packages/` — reusable runtime layers
- `labs/` — Stellar/SynthOS documentation and research material
- `deployments/` — Netlify/dist bundles
- `archive/` — duplicate notes and misc preservation

## Important

`node_modules` was excluded. Run install commands in each app before building.
