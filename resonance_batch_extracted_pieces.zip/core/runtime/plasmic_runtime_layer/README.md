# Plasmic Runtime Layer

Purpose:
- Plasmic is OPTIONAL.
- The substrate can morph automatically through message passing.
- Plasmic is only for human-directed editing/refinement.

## Runtime Flow

upload
→ ontological addressing
→ Supabase preservation
→ sandbox
→ node classification
→ message passing
→ graph emergence
→ morph queue
→ optional plasmic editing
→ release candidate
→ App Center mount

## Important

The morph engine should NOT physically mutate the live substrate directly.

Instead:
- nodes communicate capabilities
- compatibility emerges through message passing
- renderer mediates state transitions
- graph structures emerge naturally

## App Center Stats

Every mounted object/app should expose:
- lineage
- health
- runtime telemetry
- morph count
- interaction score
- graph relationships
- dependencies
- memory footprint