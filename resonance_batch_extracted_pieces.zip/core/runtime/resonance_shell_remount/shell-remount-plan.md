# Resonance Shell Remount Pass

Goal:
Replace visible PhoneOS shell surfaces with Resonance shell language
WITHOUT replacing the runtime/substrate underneath.

## Runtime Philosophy

Runtime stays stable.
Shell remains swappable.

## Replaced Surfaces

- launcher/home
- dock
- app center
- ingest tray
- sandbox panels
- telemetry panels
- morph queue displays

## Preserved Runtime

- object registry
- message passing
- substrate logic
- ontological addressing
- persistence
- sandbox flow

## Visual Direction

- purple resonance palette
- glass substrate surfaces
- holographic telemetry
- graph-oriented displays
- living app registry aesthetic