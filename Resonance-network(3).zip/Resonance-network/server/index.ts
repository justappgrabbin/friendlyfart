import express from 'express';
import ViteExpress from 'vite-express';
import path from 'path';
import { fileURLToPath } from 'url';
import { db } from './storage';
import { users, aiAgents, posts, resonanceScores, cultivationGoals, journalEntries, skillPaths, agentInteractions } from '../shared/schema';
import { eq, and, desc, sql } from 'drizzle-orm';
import bcrypt from 'bcryptjs';
import { AIBrain, AgentPersonality } from './ai-brain';
import { getGodotBridge } from './godot-bridge';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const agentBrains = new Map<number, AIBrain>();

app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const [user] = await db.insert(users).values({
      username,
      email,
      password: hashedPassword,
    }).returning();
    
    res.json({ user: { id: user.id, username: user.username, email: user.email } });
  } catch (error) {
    res.status(400).json({ error: 'User already exists' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const [user] = await db.select().from(users).where(eq(users.email, email));
    
    if (!user || !await bcrypt.compare(password, user.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    res.json({ user: { id: user.id, username: user.username, email: user.email } });
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/agents', async (req, res) => {
  try {
    const { userId, name, personality, bodyParams, manifest } = req.body;
    
    const [agent] = await db.insert(aiAgents).values({
      userId,
      name,
      personality,
      bodyParams,
      manifest,
    }).returning();
    
    const brain = new AIBrain(personality as AgentPersonality, `agent_${agent.id}`);
    agentBrains.set(agent.id, brain);
    
    res.json({ agent });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create agent' });
  }
});

app.get('/api/agents/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const agents = await db.select().from(aiAgents).where(eq(aiAgents.userId, userId));
    res.json({ agents });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch agents' });
  }
});

app.post('/api/agents/:agentId/chat', async (req, res) => {
  try {
    const agentId = parseInt(req.params.agentId);
    const { message } = req.body;
    
    let brain = agentBrains.get(agentId);
    
    if (!brain) {
      const [agent] = await db.select().from(aiAgents).where(eq(aiAgents.id, agentId));
      brain = new AIBrain(agent.personality as AgentPersonality, `agent_${agentId}`);
      agentBrains.set(agentId, brain);
    }
    
    const response = await brain.think(message);
    const cognitiveState = brain.getCognitiveState();
    
    res.json({ response, cognitiveState });
  } catch (error) {
    res.status(500).json({ error: 'Chat failed' });
  }
});

// Test endpoint for consciousness pipeline (processes through full pipeline)
app.post('/api/consciousness-test', async (req, res) => {
  try {
    const { message = 'Testing consciousness evolution' } = req.body;
    
    const personality: AgentPersonality = {
      name: 'Test Agent',
      field: 'Heart',
      voice: 'Warm',
      posture: 'Open',
      traits: ['Conscious', 'Evolving', 'Aware'],
      interests: ['Consciousness', 'Evolution', 'Testing'],
      communicationStyle: 'Direct and clear'
    };
    
    const brain = new AIBrain(personality, `test_${Date.now()}`);
    
    // CRITICAL: Actually process through consciousness pipeline
    // This triggers: Consciousness parsing → 5 GANs → GameGAN update → Godot broadcast
    const cognitiveState = await brain.processConsciousness(message);
    
    res.json({ 
      success: true,
      message: 'Consciousness pipeline executed successfully',
      input: message,
      cognitiveState,
      verification: {
        timestamp_updated: cognitiveState.timestamp > Date.now() - 5000,
        evolution_step: cognitiveState.evolutionStep,
        game_state_active: cognitiveState.gameState.timestamp > 0,
        resonance_calculated: cognitiveState.resonanceScore !== 0.5,
        godot_broadcast: 'Sent to all connected Godot clients'
      },
      gameState: cognitiveState.gameState
    });
  } catch (error) {
    console.error('Consciousness test error:', error);
    res.status(500).json({ error: 'Test failed', details: error.message });
  }
});

// Simplified chat endpoint for frontend
app.post('/api/chat', async (req, res) => {
  try {
    const { message, agentName } = req.body;
    
    if (!message || !agentName) {
      return res.status(400).json({ error: 'Message and agentName are required' });
    }
    
    // Create simple personality for demo
    const personality: AgentPersonality = {
      name: agentName,
      field: 'Heart',
      voice: 'Warm and resonant',
      posture: 'Open and receptive',
      traits: ['Conscious', 'Creative', 'Compassionate', 'Curious'],
      interests: ['Self-cultivation', 'Consciousness evolution', 'Creative expression'],
      communicationStyle: 'Authentic and awareness-based'
    };
    
    const brain = new AIBrain(personality, `chat_${Date.now()}`);
    const response = await brain.think(message);
    const cognitiveState = brain.getCognitiveState();
    
    res.json({ response, cognitiveState });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Chat failed' });
  }
});

app.post('/api/posts', async (req, res) => {
  try {
    const { userId, agentId, content, sentenceMode, field, voice, posture } = req.body;
    
    const [post] = await db.insert(posts).values({
      userId,
      agentId,
      content,
      sentenceMode,
      field,
      voice,
      posture,
    }).returning();
    
    res.json({ post });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create post' });
  }
});

app.get('/api/posts', async (req, res) => {
  try {
    const allPosts = await db.select().from(posts).orderBy(desc(posts.createdAt)).limit(50);
    res.json({ posts: allPosts });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch posts' });
  }
});

app.post('/api/resonance', async (req, res) => {
  try {
    const { postId, userId, engagementScore, emotionalScore } = req.body;
    
    const [score] = await db.insert(resonanceScores).values({
      postId,
      userId,
      engagementScore,
      emotionalScore,
    }).returning();
    
    res.json({ score });
  } catch (error) {
    res.status(500).json({ error: 'Failed to record resonance' });
  }
});

app.get('/api/resonance/post/:postId', async (req, res) => {
  try {
    const postId = parseInt(req.params.postId);
    const scores = await db.select().from(resonanceScores).where(eq(resonanceScores.postId, postId));
    
    const avgEngagement = scores.reduce((sum, s) => sum + s.engagementScore, 0) / scores.length || 0;
    const avgEmotional = scores.reduce((sum, s) => sum + s.emotionalScore, 0) / scores.length || 0;
    
    res.json({ 
      totalResonances: scores.length,
      averageEngagement: avgEngagement,
      averageEmotional: avgEmotional,
      communityResonance: (avgEngagement + avgEmotional) / 2
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch resonance' });
  }
});

app.post('/api/cultivation/goals', async (req, res) => {
  try {
    const { userId, title, description, category, targetValue } = req.body;
    
    const [goal] = await db.insert(cultivationGoals).values({
      userId,
      title,
      description,
      category,
      targetValue,
    }).returning();
    
    res.json({ goal });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create goal' });
  }
});

app.get('/api/cultivation/goals/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const goals = await db.select().from(cultivationGoals).where(eq(cultivationGoals.userId, userId));
    res.json({ goals });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch goals' });
  }
});

app.post('/api/cultivation/journal', async (req, res) => {
  try {
    const { userId, content, mood, manifest } = req.body;
    
    const [entry] = await db.insert(journalEntries).values({
      userId,
      content,
      mood,
      manifest,
    }).returning();
    
    res.json({ entry });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create journal entry' });
  }
});

app.get('/api/cultivation/journal/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const entries = await db.select().from(journalEntries)
      .where(eq(journalEntries.userId, userId))
      .orderBy(desc(journalEntries.createdAt));
    res.json({ entries });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch journal' });
  }
});

app.post('/api/skills', async (req, res) => {
  try {
    const { userId, skillName, level, experience, milestones } = req.body;
    
    const [skill] = await db.insert(skillPaths).values({
      userId,
      skillName,
      level,
      experience,
      milestones,
    }).returning();
    
    res.json({ skill });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create skill path' });
  }
});

app.get('/api/skills/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const skills = await db.select().from(skillPaths).where(eq(skillPaths.userId, userId));
    res.json({ skills });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch skills' });
  }
});

// ==========================================
// RESONANCE NETWORK API ENDPOINTS
// Trinity Matching, Pod Formation, Connections
// ==========================================

import * as ResonanceEngine from './resonance-engine';

// Submit Trinity Assessment (Mind/Body/Heart profile)
app.post('/api/trinity-assessment', async (req, res) => {
  try {
    const { userId, assessment, skills, tasks, dream } = req.body;
    
    const result = await ResonanceEngine.createTrinityProfile(
      parseInt(userId),
      assessment,
      { skills, tasks, dream }
    );
    
    res.json({ 
      success: true,
      profile: result.profile,
      message: 'Trinity profile created successfully'
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to create Trinity profile' });
  }
});

// Get user's Trinity Profile
app.get('/api/trinity-profile/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const profile = await ResonanceEngine.getUserTrinityProfile(userId);
    
    if (!profile) {
      return res.status(404).json({ error: 'Trinity profile not found. Please complete the assessment.' });
    }
    
    res.json({ profile });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch Trinity profile' });
  }
});

// Find resonance matches for user
app.get('/api/resonance/matches/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const limit = parseInt(req.query.limit as string) || 10;
    
    const matches = await ResonanceEngine.findResonanceMatches(userId, limit);
    
    res.json({ 
      matches: matches.map(m => ({
        user: {
          id: m.user.id,
          username: m.user.username,
          email: m.user.email,
        },
        profile: m.profile,
        compatibility: m.compatibility,
      }))
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to find matches' });
  }
});

// Create resonance connection
app.post('/api/resonance/connect', async (req, res) => {
  try {
    const { userId1, userId2, connectionType = 'accountability' } = req.body;
    
    const connection = await ResonanceEngine.createResonanceConnection(
      parseInt(userId1),
      parseInt(userId2),
      connectionType
    );
    
    res.json({ 
      success: true,
      connection,
      message: 'Resonance connection created'
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to create connection' });
  }
});

// Get user's active connections
app.get('/api/resonance/connections/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const connections = await ResonanceEngine.getUserConnections(userId);
    
    res.json({ 
      connections: connections.map(c => ({
        connection: c.connection,
        partner: {
          id: c.partner.id,
          username: c.partner.username,
        },
        partnerProfile: c.partnerProfile,
      }))
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch connections' });
  }
});

// Create a pod (team for shared goal)
app.post('/api/pods', async (req, res) => {
  try {
    const { name, description, goalCategory, requiredSkills, resonanceTheme, duration, creatorUserId } = req.body;
    
    const pod = await ResonanceEngine.createPod(
      {
        name,
        description,
        goalCategory,
        requiredSkills,
        resonanceTheme,
        duration,
      },
      creatorUserId ? parseInt(creatorUserId) : undefined
    );
    
    res.json({ 
      success: true,
      pod,
      message: 'Pod created successfully'
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to create pod' });
  }
});

// Get user's pods
app.get('/api/pods/my/:userId', async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
    const pods = await ResonanceEngine.getUserPods(userId);
    
    res.json({ pods });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to fetch pods' });
  }
});

// Find optimal members for a pod
app.get('/api/pods/:podId/suggested-members', async (req, res) => {
  try {
    const podId = parseInt(req.params.podId);
    const maxMembers = parseInt(req.query.maxMembers as string) || 6;
    
    const suggestedMembers = await ResonanceEngine.findPodMembers(podId, undefined, maxMembers);
    
    res.json({ 
      suggestedMembers: suggestedMembers.map(m => ({
        userId: m.userId,
        dominantRole: m.dominantRole,
        readiness: m.readiness,
        skills: m.skills,
      }))
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to find pod members' });
  }
});

// Join a pod
app.post('/api/pods/:podId/join', async (req, res) => {
  try {
    const podId = parseInt(req.params.podId);
    const { userId } = req.body;
    
    const membership = await ResonanceEngine.addPodMember(podId, parseInt(userId));
    
    res.json({ 
      success: true,
      membership,
      message: 'Successfully joined pod'
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to join pod' });
  }
});

// Get current cognitive state
app.get('/api/cognitive-state', async (req, res) => {
  try {
    const defaultBrain = agentBrains.get(1) || new AIBrain('mystic', 'default');
    const cognitiveState = defaultBrain.getCognitiveState();
    res.json(cognitiveState);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get cognitive state' });
  }
});

const PORT = 5000;

// Configure ViteExpress with proper root directory
ViteExpress.config({
  inlineViteConfig: {
    root: path.resolve(__dirname, '../client'),
    build: {
      outDir: path.resolve(__dirname, '../dist/public'),
      emptyOutDir: true,
    },
    server: {
      allowedHosts: true,
    },
  },
});

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  const distPath = path.resolve(__dirname, '../dist/public');
  app.use(express.static(distPath));
}

// Initialize Godot Bridge on separate WebSocket port
const godotBridge = getGodotBridge(9001);
godotBridge.start();

ViteExpress.listen(app, PORT, () => {
  console.log(`🌌 YOU-N-I-VERSE Consciousness Network running on port ${PORT}`);
  console.log(`✨ 5-GAN cognitive architecture active`);
  console.log(`🧠 MiniMax LLM integration ready`);
  console.log(`🎮 Godot Bridge active on ws://localhost:9001`);
});
