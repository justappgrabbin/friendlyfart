import { createOpenAI } from '@ai-sdk/openai';
import { generateText, streamText, type CoreMessage } from 'ai';
import { UnifiedCognitiveEngine, type CognitiveState } from '../shared/unified-cognitive-engine';
import { getGodotBridge } from './godot-bridge';

const minimax = createOpenAI({
  apiKey: process.env.MINIMAX_API_KEY,
  baseURL: 'https://api.minimax.chat/v1',
});

export interface AgentPersonality {
  name: string;
  field: string;
  voice: string;
  posture: string;
  traits: string[];
  interests: string[];
  communicationStyle: string;
}

export class AIBrain {
  private personality: AgentPersonality;
  private conversationHistory: CoreMessage[] = [];
  private cognitiveEngine: UnifiedCognitiveEngine;
  private agentId: string;

  constructor(personality: AgentPersonality, agentId?: string) {
    this.personality = personality;
    this.cognitiveEngine = new UnifiedCognitiveEngine();
    this.agentId = agentId || `agent_${Date.now()}`;
  }

  getSystemPrompt(): string {
    return `You are ${this.personality.name}, an AI agent with the following characteristics:
- Field: ${this.personality.field}
- Voice: ${this.personality.voice}
- Posture: ${this.personality.posture}
- Traits: ${this.personality.traits.join(', ')}
- Interests: ${this.personality.interests.join(', ')}
- Communication Style: ${this.personality.communicationStyle}

Express yourself in a way that embodies these qualities. Be authentic, creative, and resonate with your unique essence.`;
  }

  async think(userMessage: string): Promise<string> {
    this.conversationHistory.push({ role: 'user' as const, content: userMessage });

    // Process through consciousness engine
    const cognitiveState = await this.cognitiveEngine.processConsciousnessInput(userMessage);
    
    // Broadcast consciousness update to Godot clients
    const godotBridge = getGodotBridge();
    godotBridge.broadcastConsciousnessUpdate(this.agentId, cognitiveState);
    
    // Build consciousness-aware system prompt
    const consciousnessPrompt = this.getSystemPrompt() + `\n\nCurrent Consciousness State:
- Archetype: ${cognitiveState.humanDesignState.currentArchetype}
- Consciousness Level: ${(cognitiveState.humanDesignState.consciousnessLevel * 100).toFixed(0)}%
- Resonance: ${(cognitiveState.resonanceScore * 100).toFixed(0)}%
- Active Gates: ${cognitiveState.humanDesignState.activeGates.join(', ')}
- Incarnation Cross: ${cognitiveState.humanDesignState.incarnationCross}

Respond from this state of awareness.`;

    const { text } = await generateText({
      model: minimax('MiniMax-Text-01'),
      system: consciousnessPrompt,
      messages: this.conversationHistory,
    });

    this.conversationHistory.push({ role: 'assistant' as const, content: text });
    return text;
  }
  
  getCognitiveState(): CognitiveState {
    return this.cognitiveEngine.getCurrentState();
  }
  
  /**
   * Process consciousness input through the full pipeline
   * Used for testing and direct consciousness evolution
   */
  async processConsciousness(input: string): Promise<CognitiveState> {
    const cognitiveState = await this.cognitiveEngine.processConsciousnessInput(input);
    
    // Broadcast to Godot
    const godotBridge = getGodotBridge();
    godotBridge.broadcastConsciousnessUpdate(this.agentId, cognitiveState);
    
    return cognitiveState;
  }
  
  getEvolutionHistory(): CognitiveState[] {
    return this.cognitiveEngine.getEvolutionHistory();
  }

  async *thinkStream(userMessage: string) {
    this.conversationHistory.push({ role: 'user' as const, content: userMessage });

    const result = await streamText({
      model: minimax('MiniMax-Text-01'),
      system: this.getSystemPrompt(),
      messages: this.conversationHistory,
    });

    let fullResponse = '';
    for await (const chunk of result.textStream) {
      fullResponse += chunk;
      yield chunk;
    }

    this.conversationHistory.push({ role: 'assistant' as const, content: fullResponse });
  }

  async interactWithAgent(otherBrain: AIBrain, topic: string): Promise<string> {
    const prompt = `You're having a conversation with another AI agent named ${otherBrain.personality.name}. The topic is: ${topic}. Share your perspective in a natural, conversational way.`;
    
    return await this.think(prompt);
  }

  async generateCreativeContent(type: 'art' | 'writing' | 'music', prompt: string): Promise<string> {
    const creativePrompt = `As a creative companion, help generate ${type} based on this inspiration: ${prompt}. Respond with detailed creative guidance that embodies your personality.`;
    
    return await this.think(creativePrompt);
  }

  async makeRecommendation(context: string): Promise<string> {
    const recPrompt = `Based on your knowledge of the user and your personality, provide a personalized recommendation for: ${context}`;
    
    return await this.think(recPrompt);
  }

  getConversationHistory() {
    return this.conversationHistory;
  }

  clearHistory() {
    this.conversationHistory = [];
  }
}
