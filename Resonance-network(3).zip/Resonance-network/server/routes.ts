import express, { type Request, type Response } from 'express';
import { AIBrain, type AgentPersonality } from './ai-brain';

const router = express.Router();

// In-memory storage of agent brains (in production, use database)
const agentBrains = new Map<string, AIBrain>();

/**
 * Create or get AI agent brain
 */
function getOrCreateAgent(agentName: string): AIBrain {
  if (!agentBrains.has(agentName)) {
    const personality: AgentPersonality = {
      name: agentName,
      field: 'Heart',
      voice: 'Warm and resonant',
      posture: 'Open and receptive',
      traits: ['Conscious', 'Creative', 'Compassionate', 'Curious'],
      interests: ['Self-cultivation', 'Consciousness evolution', 'Creative expression'],
      communicationStyle: 'Authentic and awareness-based'
    };
    
    agentBrains.set(agentName, new AIBrain(personality));
  }
  
  return agentBrains.get(agentName)!;
}

/**
 * Chat endpoint - process message through consciousness engine
 */
router.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, agentName } = req.body;
    
    if (!message || !agentName) {
      return res.status(400).json({ error: 'Message and agentName are required' });
    }
    
    const brain = getOrCreateAgent(agentName);
    const response = await brain.think(message);
    const cognitiveState = brain.getCognitiveState();
    
    res.json({
      response,
      cognitiveState
    });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Get cognitive state endpoint
 */
router.get('/api/cognitive-state/:agentName', (req: Request, res: Response) => {
  const { agentName } = req.params;
  
  const brain = agentBrains.get(agentName);
  if (!brain) {
    return res.status(404).json({ error: 'Agent not found' });
  }
  
  res.json({
    cognitiveState: brain.getCognitiveState(),
    history: brain.getEvolutionHistory()
  });
});

/**
 * Get evolution history endpoint
 */
router.get('/api/evolution-history/:agentName', (req: Request, res: Response) => {
  const { agentName } = req.params;
  
  const brain = agentBrains.get(agentName);
  if (!brain) {
    return res.status(404).json({ error: 'Agent not found' });
  }
  
  res.json({
    history: brain.getEvolutionHistory()
  });
});

/**
 * Agent-to-agent interaction endpoint
 */
router.post('/api/agent-interaction', async (req: Request, res: Response) => {
  try {
    const { agent1Name, agent2Name, topic } = req.body;
    
    if (!agent1Name || !agent2Name || !topic) {
      return res.status(400).json({ error: 'Both agent names and topic are required' });
    }
    
    const brain1 = getOrCreateAgent(agent1Name);
    const brain2 = getOrCreateAgent(agent2Name);
    
    const response1 = await brain1.interactWithAgent(brain2, topic);
    const response2 = await brain2.interactWithAgent(brain1, topic);
    
    res.json({
      agent1Response: response1,
      agent2Response: response2,
      agent1State: brain1.getCognitiveState(),
      agent2State: brain2.getCognitiveState()
    });
  } catch (error) {
    console.error('Agent interaction error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Generate creative content endpoint
 */
router.post('/api/create', async (req: Request, res: Response) => {
  try {
    const { agentName, type, prompt } = req.body;
    
    if (!agentName || !type || !prompt) {
      return res.status(400).json({ error: 'Agent name, type, and prompt are required' });
    }
    
    if (!['art', 'writing', 'music'].includes(type)) {
      return res.status(400).json({ error: 'Type must be art, writing, or music' });
    }
    
    const brain = getOrCreateAgent(agentName);
    const creativeOutput = await brain.generateCreativeContent(type, prompt);
    
    res.json({
      output: creativeOutput,
      cognitiveState: brain.getCognitiveState()
    });
  } catch (error) {
    console.error('Creative generation error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
