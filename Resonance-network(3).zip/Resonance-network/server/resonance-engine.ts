/**
 * Server-side Resonance Engine
 * 
 * Handles user matching, pod formation, and resonance connections
 * Integrates Trinity Resonance algorithms with consciousness data
 */

import { db } from "./storage";
import { 
  users, 
  trinityProfiles, 
  resonanceConnections, 
  pods, 
  podMembers,
  cultivationGoals
} from "../shared/schema";
import { eq, and, or, desc, sql } from "drizzle-orm";
import {
  chartFromAssessment,
  roleFromChart,
  readinessIndex,
  placementSuggestion,
  findTopMatches,
  formOptimalPod,
  overallCompatibility,
  type TrinityAssessment,
  type TrinityChart,
  type UserResonanceProfile,
  type Role,
  type Placement
} from "../shared/trinity-resonance-engine";

/**
 * Create or update a user's Trinity Profile
 */
export async function createTrinityProfile(
  userId: number,
  assessment: TrinityAssessment,
  additionalData?: {
    skills?: string[];
    tasks?: string[];
    dream?: string;
  }
) {
  // Calculate Trinity Chart from assessment
  const trinityChart = chartFromAssessment(assessment);
  const dominantRole = roleFromChart(trinityChart);
  const readiness = readinessIndex(trinityChart);
  
  const profile: UserResonanceProfile = {
    userId: userId.toString(),
    trinityChart,
    dominantRole,
    readiness,
    placement: placementSuggestion({
      userId: userId.toString(),
      trinityChart,
      dominantRole,
      readiness,
      placement: "Peer Mirror (Mutual Reflection)" // Temp
    }),
    ...additionalData
  };

  // Upsert to database
  const [existing] = await db
    .select()
    .from(trinityProfiles)
    .where(eq(trinityProfiles.userId, userId));

  if (existing) {
    // Update existing profile
    const [updated] = await db
      .update(trinityProfiles)
      .set({
        mindEnergy: trinityChart.mind,
        bodyEnergy: trinityChart.body,
        heartEnergy: trinityChart.heart,
        dominantRole,
        readiness,
        placement: profile.placement,
        skills: additionalData?.skills || existing.skills,
        tasks: additionalData?.tasks || existing.tasks,
        dream: additionalData?.dream || existing.dream,
        assessmentData: assessment as any,
        updatedAt: new Date(),
      })
      .where(eq(trinityProfiles.id, existing.id))
      .returning();
    
    return { profile, dbRecord: updated };
  } else {
    // Create new profile
    const [created] = await db
      .insert(trinityProfiles)
      .values({
        userId,
        mindEnergy: trinityChart.mind,
        bodyEnergy: trinityChart.body,
        heartEnergy: trinityChart.heart,
        dominantRole,
        readiness,
        placement: profile.placement,
        skills: additionalData?.skills || [],
        tasks: additionalData?.tasks || [],
        dream: additionalData?.dream || '',
        assessmentData: assessment as any,
      })
      .returning();
    
    return { profile, dbRecord: created };
  }
}

/**
 * Get user's Trinity Profile from database
 */
export async function getUserTrinityProfile(userId: number): Promise<UserResonanceProfile | null> {
  const [profile] = await db
    .select()
    .from(trinityProfiles)
    .where(eq(trinityProfiles.userId, userId));

  if (!profile) return null;

  return {
    userId: userId.toString(),
    trinityChart: {
      mind: profile.mindEnergy,
      body: profile.bodyEnergy,
      heart: profile.heartEnergy,
    },
    dominantRole: profile.dominantRole as Role,
    readiness: profile.readiness,
    placement: profile.placement as Placement,
    skills: (profile.skills as string[]) || [],
    tasks: (profile.tasks as string[]) || [],
    dream: profile.dream || undefined,
  };
}

/**
 * Find resonance matches for a user
 */
export async function findResonanceMatches(
  userId: number,
  limit: number = 10
): Promise<Array<{ profile: UserResonanceProfile; compatibility: number; user: any }>> {
  // Get user's profile
  const userProfile = await getUserTrinityProfile(userId);
  if (!userProfile) {
    throw new Error("User has not completed Trinity Assessment");
  }

  // Get all other users' profiles
  const allProfiles = await db
    .select()
    .from(trinityProfiles)
    .where(sql`${trinityProfiles.userId} != ${userId}`);

  // Convert to UserResonanceProfile format
  const candidates: UserResonanceProfile[] = allProfiles.map(p => ({
    userId: p.userId.toString(),
    trinityChart: {
      mind: p.mindEnergy,
      body: p.bodyEnergy,
      heart: p.heartEnergy,
    },
    dominantRole: p.dominantRole as Role,
    readiness: p.readiness,
    placement: p.placement as Placement,
    skills: (p.skills as string[]) || [],
    tasks: (p.tasks as string[]) || [],
    dream: p.dream || undefined,
  }));

  // Find top matches
  const matches = findTopMatches(userProfile, candidates, limit);

  // Fetch user data for each match
  const enrichedMatches = await Promise.all(
    matches.map(async (match) => {
      const [user] = await db
        .select()
        .from(users)
        .where(eq(users.id, parseInt(match.profile.userId)));
      
      return {
        ...match,
        user,
      };
    })
  );

  return enrichedMatches;
}

/**
 * Create a resonance connection between two users
 */
export async function createResonanceConnection(
  userId1: number,
  userId2: number,
  connectionType: string = "accountability"
) {
  // Calculate compatibility
  const profile1 = await getUserTrinityProfile(userId1);
  const profile2 = await getUserTrinityProfile(userId2);

  if (!profile1 || !profile2) {
    throw new Error("Both users must complete Trinity Assessment");
  }

  const compatibility = overallCompatibility(profile1, profile2);

  // Create connection
  const [connection] = await db
    .insert(resonanceConnections)
    .values({
      userId1,
      userId2,
      compatibilityScore: compatibility,
      connectionType,
      status: 'active',
      lastInteraction: new Date(),
    })
    .returning();

  return connection;
}

/**
 * Get active resonance connections for a user
 */
export async function getUserConnections(userId: number) {
  const connections = await db
    .select()
    .from(resonanceConnections)
    .where(
      and(
        or(
          eq(resonanceConnections.userId1, userId),
          eq(resonanceConnections.userId2, userId)
        ),
        eq(resonanceConnections.status, 'active')
      )
    );

  // Enrich with partner data
  const enriched = await Promise.all(
    connections.map(async (conn) => {
      const partnerId = conn.userId1 === userId ? conn.userId2 : conn.userId1;
      const [partner] = await db
        .select()
        .from(users)
        .where(eq(users.id, partnerId));
      
      const partnerProfile = await getUserTrinityProfile(partnerId);

      return {
        connection: conn,
        partner,
        partnerProfile,
      };
    })
  );

  return enriched;
}

/**
 * Create a pod for a specific goal/project
 */
export async function createPod(
  goal: {
    name: string;
    description?: string;
    goalCategory: string;
    requiredSkills?: string[];
    resonanceTheme?: string;
    duration?: number; // days
  },
  creatorUserId?: number
) {
  const startDate = new Date();
  const endDate = goal.duration 
    ? new Date(startDate.getTime() + goal.duration * 24 * 60 * 60 * 1000)
    : null;

  const [pod] = await db
    .insert(pods)
    .values({
      name: goal.name,
      description: goal.description || '',
      goalCategory: goal.goalCategory,
      requiredSkills: goal.requiredSkills || [],
      status: 'forming',
      startDate,
      endDate,
      resonanceTheme: goal.resonanceTheme || '',
      aiGuidance: '', // Will be populated by AI agent
    })
    .returning();

  // Add creator as first member if provided
  if (creatorUserId) {
    await db.insert(podMembers).values({
      podId: pod.id!,
      userId: creatorUserId,
    });
  }

  return pod;
}

/**
 * Find optimal members for a pod based on required skills
 */
export async function findPodMembers(
  podId: number,
  candidateUserIds?: number[],
  maxMembers: number = 6
) {
  // Get pod details
  const [pod] = await db
    .select()
    .from(pods)
    .where(eq(pods.id, podId));

  if (!pod) throw new Error("Pod not found");

  // Get all profiles or filter by candidates
  let profileQuery = db.select().from(trinityProfiles);
  if (candidateUserIds && candidateUserIds.length > 0) {
    profileQuery = profileQuery.where(
      sql`${trinityProfiles.userId} IN (${sql.join(candidateUserIds.map(id => sql`${id}`), sql`, `)})`
    );
  }

  const allProfiles = await profileQuery;

  // Convert to UserResonanceProfile format
  const candidates: UserResonanceProfile[] = allProfiles.map(p => ({
    userId: p.userId.toString(),
    trinityChart: {
      mind: p.mindEnergy,
      body: p.bodyEnergy,
      heart: p.heartEnergy,
    },
    dominantRole: p.dominantRole as Role,
    readiness: p.readiness,
    placement: p.placement as Placement,
    skills: (p.skills as string[]) || [],
    tasks: (p.tasks as string[]) || [],
    dream: p.dream || undefined,
  }));

  // Form optimal pod
  const optimalMembers = formOptimalPod(
    {
      requiredSkills: (pod.requiredSkills as string[]) || [],
      maxSize: maxMembers,
    },
    candidates
  );

  return optimalMembers;
}

/**
 * Add member to pod
 */
export async function addPodMember(podId: number, userId: number) {
  const [member] = await db
    .insert(podMembers)
    .values({
      podId,
      userId,
    })
    .returning();

  return member;
}

/**
 * Get pods for a user
 */
export async function getUserPods(userId: number) {
  const memberships = await db
    .select()
    .from(podMembers)
    .where(
      and(
        eq(podMembers.userId, userId),
        sql`${podMembers.leftAt} IS NULL`
      )
    );

  const userPods = await Promise.all(
    memberships.map(async (membership) => {
      const [pod] = await db
        .select()
        .from(pods)
        .where(eq(pods.id, membership.podId));

      // Get all members
      const members = await db
        .select()
        .from(podMembers)
        .where(
          and(
            eq(podMembers.podId, pod.id!),
            sql`${podMembers.leftAt} IS NULL`
          )
        );

      return {
        pod,
        membership,
        memberCount: members.length,
      };
    })
  );

  return userPods;
}
