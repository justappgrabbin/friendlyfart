import { HumanAgentParams } from './HumanAgent';

export const defaultBodyPreset: HumanAgentParams = {
  height: 1,
  shoulders: 1.1,
  chest: 1.25,
  waist: 0.85,
  hips: 1.4,
  uArm: 1.15,
  fArm: 1.05,
  thigh: 1.35,
  calf: 1.15,
  curve: 0.8,
  tilt: 0.15,
  speed: 0.6,
  breath: 0.5
};

export const adayaBodyPreset: HumanAgentParams = {
  height: 1.02,
  shoulders: 1.15,
  chest: 1.35,
  waist: 0.78,
  hips: 1.45,
  curve: 0.95,
  tilt: 0.12,
  uArm: 1.1,
  fArm: 1.0,
  thigh: 1.3,
  calf: 1.1,
  breath: 0.55,
  speed: 0.65
};

export const bodyPresets: Record<string, HumanAgentParams> = {
  default: defaultBodyPreset,
  adaya: adayaBodyPreset,
};
