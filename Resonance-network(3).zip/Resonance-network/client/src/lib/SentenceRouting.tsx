import React, { useState } from 'react';

export function generateSentence(parserOutput: any, mode = 'metaphysical') {
  const { manifest } = parserOutput;
  const field = manifest.field || 'radiant-nostalgic';
  const voice = manifest.voice || 'grounded';
  const posture = manifest.posture || 'relaxed';

  const modes: Record<string, string> = {
    metaphysical: `Through ${field.replace('-', ' ')}, I ${voice} in ${posture} form.`,
    scientific: `${field.replace('-', ' ')} corresponds to variable photon density and ${voice} resonance across molecular space.`,
    poetic: `I breathe ${field.replace('-', ' ')}, becoming ${voice} and ${posture}.`,
    synthia: `{field:${field},voice:${voice},posture:${posture}}`,
    symbolic: `⚛️ ${field} | 🗣️ ${voice} | 💫 ${posture}`
  };

  return modes[mode] || modes.metaphysical;
}

export function speakSentence(sentence: string, voiceType = 'default') {
  if (typeof window === 'undefined' || !window.speechSynthesis) return;
  const utter = new SpeechSynthesisUtterance(sentence);
  utter.lang = 'en-US';
  utter.pitch = voiceType === 'soft' ? 1.2 : 1.0;
  utter.rate = voiceType === 'fast' ? 1.3 : 1.0;
  utter.volume = 1.0;
  window.speechSynthesis.speak(utter);
}

interface SentenceRouterProps {
  parserOutput: any;
  mode?: string;
}

export function SentenceRouter({ parserOutput, mode = 'metaphysical' }: SentenceRouterProps) {
  const [sentence, setSentence] = useState('');

  React.useEffect(() => {
    const newSentence = generateSentence(parserOutput, mode);
    setSentence(newSentence);
  }, [parserOutput, mode]);

  return (
    <div className="p-3 bg-gray-900 text-gray-100 rounded-lg shadow-md max-w-md">
      <p className="text-sm italic mb-2">{sentence}</p>
      <button
        onClick={() => speakSentence(sentence)}
        className="px-3 py-1 text-xs bg-blue-500 hover:bg-blue-600 text-white rounded transition-colors"
      >
        🔊 Speak
      </button>
    </div>
  );
}
