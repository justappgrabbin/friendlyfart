import * as THREE from 'three';

export interface HumanAgentParams {
  height: number;
  shoulders: number;
  chest: number;
  waist: number;
  hips: number;
  uArm: number;
  fArm: number;
  thigh: number;
  calf: number;
  curve: number;
  tilt: number;
  speed: number;
  breath: number;
}

export function createHumanAgent() {
  const group = new THREE.Group();
  const material = new THREE.MeshStandardMaterial({
    color: 0xdddddd,
    metalness: 0.05,
    roughness: 0.45
  });

  const parts: Record<string, THREE.Mesh> = {};
  
  const cap = (rt: number, rb: number, h: number) => {
    const g = new THREE.CapsuleGeometry(rt, Math.max(0, h - rt - rb), 20, 12);
    if (rt !== rb) g.scale(rt/rb, 1, rt/rb);
    return new THREE.Mesh(g, material);
  };

  parts.torso = cap(0.22, 0.30, 0.65);
  parts.torso.position.y = 1.1;
  group.add(parts.torso);

  parts.pelvis = new THREE.Mesh(new THREE.SphereGeometry(0.22, 20, 14), material);
  parts.pelvis.position.y = 0.85;
  group.add(parts.pelvis);

  parts.neck = cap(0.09, 0.09, 0.12);
  parts.neck.position.set(0, 1.35, 0);
  group.add(parts.neck);

  parts.head = new THREE.Mesh(new THREE.SphereGeometry(0.15, 26, 18), material);
  parts.head.position.set(0, 1.48, 0);
  group.add(parts.head);

  const sW = 0.34, hipW = 0.26;

  parts.uArmL = cap(0.09, 0.08, 0.28);
  parts.uArmL.position.set(-sW, 1.28, 0);
  group.add(parts.uArmL);

  parts.fArmL = cap(0.08, 0.07, 0.26);
  parts.fArmL.position.set(-sW, 1.06, 0);
  group.add(parts.fArmL);

  parts.uArmR = parts.uArmL.clone();
  parts.uArmR.position.set(+sW, 1.28, 0);
  group.add(parts.uArmR);

  parts.fArmR = parts.fArmL.clone();
  parts.fArmR.position.set(+sW, 1.06, 0);
  group.add(parts.fArmR);

  parts.thighL = cap(0.12, 0.10, 0.38);
  parts.thighL.position.set(-hipW, 0.73, 0);
  group.add(parts.thighL);

  parts.calfL = cap(0.10, 0.08, 0.38);
  parts.calfL.position.set(-hipW, 0.45, 0);
  group.add(parts.calfL);

  parts.thighR = parts.thighL.clone();
  parts.thighR.position.set(+hipW, 0.73, 0);
  group.add(parts.thighR);

  parts.calfR = parts.calfL.clone();
  parts.calfR.position.set(+hipW, 0.45, 0);
  group.add(parts.calfR);

  parts.handL = new THREE.Mesh(new THREE.SphereGeometry(0.07, 18, 12), material);
  parts.handL.position.set(-sW, 0.90, 0.02);
  group.add(parts.handL);

  parts.handR = parts.handL.clone();
  parts.handR.position.set(+sW, 0.90, 0.02);
  group.add(parts.handR);

  parts.footL = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.06, 0.29), material);
  parts.footL.position.set(-hipW, 0.20, 0.12);
  group.add(parts.footL);

  parts.footR = parts.footL.clone();
  parts.footR.position.set(+hipW, 0.20, 0.12);
  group.add(parts.footR);

  const P: HumanAgentParams = {
    height: 1,
    shoulders: 1.1,
    chest: 1.25,
    waist: 0.85,
    hips: 1.4,
    uArm: 1.15,
    fArm: 1.05,
    thigh: 1.35,
    calf: 1.15,
    curve: 0.8,
    tilt: 0.15,
    speed: 0.6,
    breath: 0.5
  };

  function apply() {
    group.scale.setScalar(P.height);
    
    parts.uArmL.position.x = -0.34 * P.shoulders;
    parts.uArmR.position.x = 0.34 * P.shoulders;
    const shoulderRot = THREE.MathUtils.degToRad((P.shoulders - 1) * 8);
    parts.uArmL.rotation.z = shoulderRot;
    parts.uArmR.rotation.z = -shoulderRot;

    const chestX = P.chest * (1 + 0.35 * P.curve);
    const waistX = P.waist * (1 - 0.25 * P.curve);
    const hipX = P.hips * (1 + 0.45 * P.curve);
    parts.torso.scale.set(chestX, parts.torso.scale.y, 1);
    parts.pelvis.scale.set(hipX, 1, hipX);
    parts.pelvis.position.y = 0.85 + 0.02 * (P.curve - 0.5);

    parts.thighL.scale.x = parts.thighR.scale.x = P.thigh;
    parts.calfL.scale.x = parts.calfR.scale.x = P.calf;
    parts.uArmL.scale.x = parts.uArmR.scale.x = P.uArm;
    parts.fArmL.scale.x = parts.fArmR.scale.x = P.fArm;

    parts.pelvis.rotation.z = P.tilt;
    parts.torso.rotation.z = P.tilt * 0.35;
    parts.neck.rotation.z = P.tilt * 0.15;

    const footY = 0.20 * P.height;
    parts.footL.position.y = parts.footR.position.y = footY;
  }

  const _tmp = new THREE.Vector3();
  function lockFeetToGround() {
    const targetY = 0.20 * P.height;
    parts.footL.getWorldPosition(_tmp);
    const dy = _tmp.y - targetY;
    if (Math.abs(dy) > 1e-4) group.position.y -= dy;
  }

  function tick(t: number) {
    const baseBreath = THREE.MathUtils.lerp(1.0, 1.06, P.breath);
    const breathY = baseBreath * (0.98 + 0.02 * Math.sin(t * 1.1));
    parts.torso.scale.y = breathY;
    parts.neck.position.y = 1.35 + 0.005 * P.breath * Math.sin(t * 0.7);
    parts.head.position.y = 1.48 + 0.006 * P.breath * Math.sin(t * 0.7);

    group.rotation.y = 0.05 * Math.sin(t * 0.5 * P.speed);
    group.position.x = Math.max(-0.25, Math.min(0.25, (0.05 + 0.05 * P.curve) * Math.sin(t * 0.8 * P.speed)));

    lockFeetToGround();
  }

  apply();
  return { object: group, parts, params: P, apply, tick };
}
