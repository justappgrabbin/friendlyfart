import { useState } from 'react';
import AuthScreen from './components/AuthScreen';
import TrinityAssessment from './components/TrinityAssessment';
import ResonanceMatching from './components/ResonanceMatching';
import PodCreation from './components/PodCreation';

type Screen = 'auth' | 'assessment' | 'matching' | 'pod-creation';

interface User {
  id: number;
  username: string;
  email: string;
}

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('auth');
  const [user, setUser] = useState<User | null>(null);

  const handleAuth = (authenticatedUser: User) => {
    setUser(authenticatedUser);
    setCurrentScreen('assessment');
  };

  const handleAssessmentComplete = () => {
    setCurrentScreen('matching');
  };

  const handleCreatePod = () => {
    setCurrentScreen('pod-creation');
  };

  const handleBackToMatching = () => {
    setCurrentScreen('matching');
  };

  return (
    <>
      {currentScreen === 'auth' && <AuthScreen onAuth={handleAuth} />}
      
      {currentScreen === 'assessment' && user && (
        <TrinityAssessment userId={user.id} onComplete={handleAssessmentComplete} />
      )}
      
      {currentScreen === 'matching' && user && (
        <ResonanceMatching 
          userId={user.id} 
          username={user.username}
          onCreatePod={handleCreatePod}
        />
      )}
      
      {currentScreen === 'pod-creation' && user && (
        <PodCreation userId={user.id} onBack={handleBackToMatching} />
      )}
    </>
  );
}

export default App;
