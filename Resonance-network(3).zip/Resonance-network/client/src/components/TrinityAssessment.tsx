import { useState } from 'react';

interface TrinityAssessmentProps {
  userId: number;
  onComplete: () => void;
}

export default function TrinityAssessment({ userId, onComplete }: TrinityAssessmentProps) {
  const [assessment, setAssessment] = useState({
    clarity: 5,
    adaptability: 5,
    discipline: 5,
    vitality: 5,
    compassion: 5,
    connection: 5,
  });
  const [skills, setSkills] = useState('');
  const [tasks, setTasks] = useState('');
  const [dream, setDream] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const questions = [
    { key: 'clarity', label: 'Mental Clarity & Focus', category: 'Mind' },
    { key: 'adaptability', label: 'Mental Flexibility & Adaptability', category: 'Mind' },
    { key: 'discipline', label: 'Physical Discipline & Consistency', category: 'Body' },
    { key: 'vitality', label: 'Physical Energy & Vitality', category: 'Body' },
    { key: 'compassion', label: 'Emotional Depth & Compassion', category: 'Heart' },
    { key: 'connection', label: 'Relational Capacity & Connection', category: 'Heart' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/trinity-assessment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          assessment,
          skills: skills.split(',').map(s => s.trim()).filter(Boolean),
          tasks: tasks.split(',').map(t => t.trim()).filter(Boolean),
          dream,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Assessment failed');
      }

      onComplete();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-blue-900 p-6">
      <div className="max-w-3xl mx-auto">
        <div className="bg-black/50 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-purple-500/30">
          <h1 className="text-4xl font-bold text-white mb-2 consciousness-glow">
            Trinity Assessment
          </h1>
          <p className="text-purple-300 mb-8">
            Measure your Mind, Body, and Heart energies to find your optimal resonance matches
          </p>

          <form onSubmit={handleSubmit} className="space-y-8">
            {questions.map((q) => (
              <div key={q.key}>
                <div className="flex justify-between items-center mb-3">
                  <label className="text-white font-medium">{q.label}</label>
                  <span className="text-purple-400 text-sm">{q.category}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-purple-300 text-sm">Low</span>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={assessment[q.key as keyof typeof assessment]}
                    onChange={(e) =>
                      setAssessment({ ...assessment, [q.key]: parseInt(e.target.value) })
                    }
                    className="flex-1 accent-purple-500"
                  />
                  <span className="text-purple-300 text-sm">High</span>
                  <span className="text-white font-bold w-8 text-center">
                    {assessment[q.key as keyof typeof assessment]}
                  </span>
                </div>
              </div>
            ))}

            <div>
              <label className="block text-purple-200 mb-2">
                Your Skills (comma-separated)
              </label>
              <input
                type="text"
                value={skills}
                onChange={(e) => setSkills(e.target.value)}
                placeholder="e.g., Meditation, Yoga, Writing"
                className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
              />
            </div>

            <div>
              <label className="block text-purple-200 mb-2">
                Current Focus Areas (comma-separated)
              </label>
              <input
                type="text"
                value={tasks}
                onChange={(e) => setTasks(e.target.value)}
                placeholder="e.g., Health, Career, Relationships"
                className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
              />
            </div>

            <div>
              <label className="block text-purple-200 mb-2">
                Your Dream or Purpose
              </label>
              <textarea
                value={dream}
                onChange={(e) => setDream(e.target.value)}
                placeholder="What is your highest aspiration?"
                rows={3}
                className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
                required
              />
            </div>

            {error && (
              <div className="bg-red-500/20 border border-red-500 text-red-200 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-semibold py-3 px-6 rounded-lg transition disabled:opacity-50"
            >
              {loading ? 'Calculating...' : 'Complete Assessment'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
