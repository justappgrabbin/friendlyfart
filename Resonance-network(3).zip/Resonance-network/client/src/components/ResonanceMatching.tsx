import { useState, useEffect } from 'react';

interface User {
  id: number;
  username: string;
  email: string;
}

interface TrinityProfile {
  trinityChart: { mind: number; body: number; heart: number };
  dominantRole: string;
  readiness: number;
  placement: string;
  skills: string[];
  dream: string;
}

interface Match {
  user: User;
  profile: TrinityProfile;
  compatibility: number;
}

interface ResonanceMatchingProps {
  userId: number;
  username: string;
  onCreatePod: () => void;
}

export default function ResonanceMatching({ userId, username, onCreatePod }: ResonanceMatchingProps) {
  const [matches, setMatches] = useState<Match[]>([]);
  const [profile, setProfile] = useState<TrinityProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [connecting, setConnecting] = useState<number | null>(null);

  useEffect(() => {
    loadProfile();
    loadMatches();
  }, [userId]);

  const loadProfile = async () => {
    try {
      const response = await fetch(`/api/trinity-profile/${userId}`);
      const data = await response.json();
      if (response.ok) {
        setProfile(data.profile);
      }
    } catch (err) {
      console.error('Failed to load profile:', err);
    }
  };

  const loadMatches = async () => {
    try {
      const response = await fetch(`/api/resonance/matches/${userId}`);
      const data = await response.json();
      setMatches(data.matches || []);
    } catch (err) {
      console.error('Failed to load matches:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async (matchUserId: number) => {
    setConnecting(matchUserId);
    try {
      await fetch('/api/resonance/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId1: userId,
          userId2: matchUserId,
          connectionType: 'accountability',
        }),
      });
      alert('Connection created!');
    } catch (err) {
      console.error('Failed to connect:', err);
    } finally {
      setConnecting(null);
    }
  };

  const getRoleColor = (role: string) => {
    const colors: Record<string, string> = {
      Catalyst: 'text-yellow-400',
      Generator: 'text-blue-400',
      Amplifier: 'text-purple-400',
      Anchor: 'text-green-400',
      Harmonizer: 'text-pink-400',
    };
    return colors[role] || 'text-white';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-blue-900 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="bg-black/50 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-purple-500/30 mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2 consciousness-glow">
                Resonance Network
              </h1>
              <p className="text-purple-300">
                Welcome, {username} • {profile?.dominantRole || 'Loading...'}
              </p>
            </div>
            <button
              onClick={onCreatePod}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-semibold py-3 px-6 rounded-lg transition"
            >
              Create Pod
            </button>
          </div>

          {profile && (
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/30">
                <div className="text-purple-300 text-sm mb-1">Mind Energy</div>
                <div className="text-2xl font-bold text-white">{profile.trinityChart.mind}%</div>
              </div>
              <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/30">
                <div className="text-purple-300 text-sm mb-1">Body Energy</div>
                <div className="text-2xl font-bold text-white">{profile.trinityChart.body}%</div>
              </div>
              <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/30">
                <div className="text-purple-300 text-sm mb-1">Heart Energy</div>
                <div className="text-2xl font-bold text-white">{profile.trinityChart.heart}%</div>
              </div>
            </div>
          )}
        </div>

        <h2 className="text-2xl font-bold text-white mb-4">Your Matches</h2>

        {loading ? (
          <div className="text-center text-purple-300 py-12">Loading matches...</div>
        ) : matches.length === 0 ? (
          <div className="bg-black/50 backdrop-blur-lg rounded-2xl p-12 text-center border border-purple-500/30">
            <p className="text-purple-300 text-lg">No matches yet. Complete your assessment to find resonance partners!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {matches.map((match) => (
              <div
                key={match.user.id}
                className="bg-black/50 backdrop-blur-lg rounded-2xl p-6 shadow-2xl border border-purple-500/30"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white">{match.user.username}</h3>
                    <p className={`text-sm font-semibold ${getRoleColor(match.profile.dominantRole)}`}>
                      {match.profile.dominantRole}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-purple-400">{match.compatibility}%</div>
                    <div className="text-xs text-purple-300">Compatibility</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="bg-purple-900/20 rounded p-2">
                    <div className="text-xs text-purple-300">Mind</div>
                    <div className="text-sm font-bold text-white">{match.profile.trinityChart.mind}%</div>
                  </div>
                  <div className="bg-purple-900/20 rounded p-2">
                    <div className="text-xs text-purple-300">Body</div>
                    <div className="text-sm font-bold text-white">{match.profile.trinityChart.body}%</div>
                  </div>
                  <div className="bg-purple-900/20 rounded p-2">
                    <div className="text-xs text-purple-300">Heart</div>
                    <div className="text-sm font-bold text-white">{match.profile.trinityChart.heart}%</div>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-xs text-purple-300 mb-1">Skills</div>
                  <div className="flex flex-wrap gap-1">
                    {match.profile.skills.map((skill, i) => (
                      <span
                        key={i}
                        className="text-xs bg-purple-600/30 text-purple-200 px-2 py-1 rounded"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mb-4">
                  <div className="text-xs text-purple-300 mb-1">Dream</div>
                  <p className="text-sm text-white">{match.profile.dream}</p>
                </div>

                <button
                  onClick={() => handleConnect(match.user.id)}
                  disabled={connecting === match.user.id}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-semibold py-2 px-4 rounded-lg transition disabled:opacity-50"
                >
                  {connecting === match.user.id ? 'Connecting...' : 'Connect'}
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
