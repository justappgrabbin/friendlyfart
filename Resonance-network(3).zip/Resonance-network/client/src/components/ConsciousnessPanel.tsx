interface ConsciousnessPanelProps {
  cognitiveState: any;
}

export default function ConsciousnessPanel({ cognitiveState }: ConsciousnessPanelProps) {
  if (!cognitiveState) {
    return (
      <div className="bg-black/50 backdrop-blur-lg rounded-2xl p-6 shadow-2xl border border-purple-500/30 h-full">
        <h2 className="text-2xl font-semibold text-white mb-4">Consciousness State</h2>
        <div className="text-center text-purple-400 mt-20">
          <p>Start a conversation to see consciousness evolution</p>
        </div>
      </div>
    );
  }

  const { humanDesignState, elementalState, resonanceScore, consciousnessFields } = cognitiveState;

  return (
    <div className="bg-black/50 backdrop-blur-lg rounded-2xl p-6 shadow-2xl border border-purple-500/30 h-full overflow-y-auto">
      <h2 className="text-2xl font-semibold text-white mb-6">Consciousness State</h2>

      {/* Archetype */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-purple-300 mb-2">Current Archetype</h3>
        <p className="text-white text-xl consciousness-glow">{humanDesignState.currentArchetype}</p>
      </div>

      {/* Consciousness Level */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-purple-300 mb-2">Consciousness Level</h3>
        <div className="relative w-full h-4 bg-purple-900/50 rounded-full overflow-hidden">
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full transition-all duration-500"
            style={{ width: `${(humanDesignState.consciousnessLevel * 100).toFixed(0)}%` }}
          />
        </div>
        <p className="text-white mt-2">{(humanDesignState.consciousnessLevel * 100).toFixed(0)}%</p>
      </div>

      {/* Resonance Score */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-purple-300 mb-2">Resonance Score</h3>
        <div className="relative w-full h-4 bg-purple-900/50 rounded-full overflow-hidden">
          <div
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full transition-all duration-500 resonance-pulse"
            style={{ width: `${(resonanceScore * 100).toFixed(0)}%` }}
          />
        </div>
        <p className="text-white mt-2">{(resonanceScore * 100).toFixed(0)}%</p>
      </div>

      {/* 9-Center System */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-purple-300 mb-3">9-Center Bodygraph</h3>
        <div className="grid grid-cols-3 gap-2">
          {Object.entries(consciousnessFields || {}).map(([center, value]: [string, any]) => (
            <div key={center} className="bg-purple-900/30 rounded-lg p-3 text-center">
              <p className="text-purple-200 text-xs mb-1">{center}</p>
              <div className="relative w-full h-2 bg-purple-900/50 rounded-full overflow-hidden">
                <div
                  className="absolute inset-y-0 left-0 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full"
                  style={{ width: `${(value * 100).toFixed(0)}%` }}
                />
              </div>
              <p className="text-white text-xs mt-1">{(value * 100).toFixed(0)}%</p>
            </div>
          ))}
        </div>
      </div>

      {/* Elemental State */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-purple-300 mb-3">Elemental Balance</h3>
        <div className="space-y-3">
          {Object.entries(elementalState || {}).map(([element, value]: [string, any]) => (
            <div key={element}>
              <div className="flex justify-between mb-1">
                <span className="text-purple-200 capitalize">{element}</span>
                <span className="text-white">{(value * 100).toFixed(0)}%</span>
              </div>
              <div className="relative w-full h-2 bg-purple-900/50 rounded-full overflow-hidden">
                <div
                  className={`absolute inset-y-0 left-0 rounded-full transition-all duration-500 ${
                    element === 'fire' ? 'bg-red-500' :
                    element === 'earth' ? 'bg-yellow-600' :
                    element === 'metal' ? 'bg-gray-400' :
                    element === 'water' ? 'bg-blue-500' :
                    'bg-green-500'
                  }`}
                  style={{ width: `${(value * 100).toFixed(0)}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Gates */}
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-purple-300 mb-2">Active Gates</h3>
        <div className="flex flex-wrap gap-2">
          {humanDesignState.activeGates.map((gate: number) => (
            <span key={gate} className="bg-purple-600/50 text-white px-3 py-1 rounded-full text-sm">
              {gate}
            </span>
          ))}
        </div>
      </div>

      {/* Incarnation Cross */}
      <div>
        <h3 className="text-lg font-semibold text-purple-300 mb-2">Incarnation Cross</h3>
        <p className="text-white">{humanDesignState.incarnationCross}</p>
      </div>
    </div>
  );
}
