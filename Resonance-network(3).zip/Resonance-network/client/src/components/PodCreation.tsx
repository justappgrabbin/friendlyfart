import { useState } from 'react';

interface PodCreationProps {
  userId: number;
  onBack: () => void;
}

export default function PodCreation({ userId, onBack }: PodCreationProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [goalCategory, setGoalCategory] = useState('Health');
  const [requiredSkills, setRequiredSkills] = useState('');
  const [resonanceTheme, setResonanceTheme] = useState('');
  const [duration, setDuration] = useState('30');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const categories = ['Health', 'Career', 'Relationships', 'Spiritual', 'Creative', 'Learning'];
  const durations = ['30', '60', '90', 'ongoing'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/pods', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          description,
          goalCategory,
          requiredSkills: requiredSkills.split(',').map(s => s.trim()).filter(Boolean),
          resonanceTheme,
          duration,
          creatorUserId: userId,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to create pod');
      }

      setSuccess(true);
      setTimeout(() => onBack(), 2000);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-blue-900 p-6">
      <div className="max-w-3xl mx-auto">
        <div className="bg-black/50 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-purple-500/30">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-4xl font-bold text-white consciousness-glow">
              Create Pod
            </h1>
            <button
              onClick={onBack}
              className="text-purple-300 hover:text-white transition"
            >
              ← Back
            </button>
          </div>

          <p className="text-purple-300 mb-8">
            Form a small team (2-6 members) around a shared goal
          </p>

          {success ? (
            <div className="bg-green-500/20 border border-green-500 text-green-200 px-4 py-3 rounded-lg text-center">
              Pod created successfully! Redirecting...
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-purple-200 mb-2">Pod Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g., Morning Meditation Circle"
                  className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
                  required
                />
              </div>

              <div>
                <label className="block text-purple-200 mb-2">Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="What is this pod's purpose?"
                  rows={3}
                  className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
                  required
                />
              </div>

              <div>
                <label className="block text-purple-200 mb-2">Goal Category</label>
                <select
                  value={goalCategory}
                  onChange={(e) => setGoalCategory(e.target.value)}
                  className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-purple-200 mb-2">
                  Required Skills (comma-separated)
                </label>
                <input
                  type="text"
                  value={requiredSkills}
                  onChange={(e) => setRequiredSkills(e.target.value)}
                  placeholder="e.g., Meditation, Journaling"
                  className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
                />
              </div>

              <div>
                <label className="block text-purple-200 mb-2">Resonance Theme</label>
                <input
                  type="text"
                  value={resonanceTheme}
                  onChange={(e) => setResonanceTheme(e.target.value)}
                  placeholder="e.g., Inner Peace, Creative Expression"
                  className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
                  required
                />
              </div>

              <div>
                <label className="block text-purple-200 mb-2">Duration</label>
                <select
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  className="w-full px-4 py-3 bg-purple-900/30 border border-purple-500/50 rounded-lg text-white focus:outline-none focus:border-purple-400"
                >
                  {durations.map((dur) => (
                    <option key={dur} value={dur}>
                      {dur === 'ongoing' ? 'Ongoing' : `${dur} days`}
                    </option>
                  ))}
                </select>
              </div>

              {error && (
                <div className="bg-red-500/20 border border-red-500 text-red-200 px-4 py-3 rounded-lg">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-semibold py-3 px-6 rounded-lg transition disabled:opacity-50"
              >
                {loading ? 'Creating...' : 'Create Pod'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
