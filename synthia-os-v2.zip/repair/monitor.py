#!/usr/bin/env python3
"""
SYNTIA Self-Healing Monitor — Can run as cron job or separate service
"""

import requests, time, sys

SERVER = "https://synthia-server.onrender.com"

def check_health():
    try:
        r = requests.get(f"{SERVER}/health", timeout=10)
        data = r.json()
        print(f"[{time.ctime()}] Health: OK")

        # Check for stuck heads
        for name, info in data.get("heads", {}).items():
            if info.get("status") == "stuck":
                print(f"  ! {name} is stuck — resetting...")
                requests.post(f"{SERVER}/repair/reset/{name.lower()}", timeout=10)
        return True
    except Exception as e:
        print(f"[{time.ctime()}] Health: FAIL — {e}")
        return False

if __name__ == "__main__":
    while True:
        check_health()
        time.sleep(60)
