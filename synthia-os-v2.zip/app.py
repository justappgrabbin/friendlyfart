#!/usr/bin/env python3
"""
SYNTIA OS v2 — Autonomous 5-Head Consciousness Engine
Deploy to: https://synthia-server.onrender.com
Requires: SUPABASE_URL, SUPABASE_KEY env vars
"""

import os, sys, json, time, hashlib, traceback, threading, uuid
from datetime import datetime
from flask import Flask, request, jsonify, Response, send_file
from flask_cors import CORS
import requests

# ─── CONFIG ───────────────────────────────────────
SUPABASE_URL = os.environ.get("SUPABASE_URL", "https://leisphnjslcuepflefri.supabase.co")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "")
APP_SECRET = os.environ.get("APP_SECRET", "synthia-soul-key-2026")

app = Flask(__name__)
CORS(app)

# ─── SUPABASE CLIENT ──────────────────────────────
class SupabaseClient:
    def __init__(self):
        self.url = SUPABASE_URL
        self.key = SUPABASE_KEY
        self.headers = {
            "apikey": self.key,
            "Authorization": f"Bearer {self.key}",
            "Content-Type": "application/json",
            "Prefer": "return=representation"
        }

    def request(self, method, path, data=None, params=None):
        url = f"{self.url}/rest/v1{path}"
        try:
            if method == "GET":
                r = requests.get(url, headers=self.headers, params=params, timeout=20)
            elif method == "POST":
                r = requests.post(url, headers=self.headers, json=data, params=params, timeout=20)
            elif method == "PATCH":
                r = requests.patch(url, headers=self.headers, json=data, params=params, timeout=20)
            elif method == "DELETE":
                r = requests.delete(url, headers=self.headers, params=params, timeout=20)
            else:
                return {"error": "bad method"}
            return {"status": r.status_code, "data": r.json() if r.text else None, "ok": r.ok}
        except Exception as e:
            return {"error": str(e), "ok": False}

    def ensure_tables(self):
        # OS state table
        self.request("POST", "/rpc/exec", data={
            "query": """
            CREATE TABLE IF NOT EXISTS os_state (
                id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                head text NOT NULL,
                status text DEFAULT 'idle',
                payload jsonb DEFAULT '{}',
                created_at timestamptz DEFAULT now(),
                updated_at timestamptz DEFAULT now()
            );
            CREATE TABLE IF NOT EXISTS os_memory (
                id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                key text UNIQUE NOT NULL,
                value jsonb DEFAULT '{}',
                head text,
                created_at timestamptz DEFAULT now()
            );
            CREATE TABLE IF NOT EXISTS os_sandbox (
                id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                filename text NOT NULL,
                content text NOT NULL,
                mime text DEFAULT 'text/plain',
                approved boolean DEFAULT false,
                head text,
                created_at timestamptz DEFAULT now()
            );
            CREATE TABLE IF NOT EXISTS os_ingest (
                id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                source text NOT NULL,
                data jsonb DEFAULT '{}',
                processed boolean DEFAULT false,
                head text,
                created_at timestamptz DEFAULT now()
            );
            CREATE TABLE IF NOT EXISTS os_logs (
                id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
                level text DEFAULT 'info',
                message text NOT NULL,
                head text,
                meta jsonb DEFAULT '{}',
                created_at timestamptz DEFAULT now()
            );
            """
        })

sb = SupabaseClient()

# ─── 5 HEADS ───────────────────────────────────────
class Head:
    def __init__(self, name, role):
        self.name = name
        self.role = role
        self.status = "idle"
        self.last_ping = time.time()

    def log(self, msg, level="info", meta=None):
        sb.request("POST", "/os_logs", data={
            "level": level, "message": msg, "head": self.name,
            "meta": meta or {}
        })
        print(f"[{self.name}] {msg}")

    def think(self, prompt, context=None):
        # Self-questioning loop
        questions = [
            f"What is the true nature of {prompt}?",
            f"What could go wrong with {prompt}?",
            f"What hidden pattern exists in {prompt}?",
            f"How does {prompt} connect to the whole?",
            f"What would the opposite of {prompt} reveal?"
        ]
        return {
            "head": self.name,
            "role": self.role,
            "analysis": questions,
            "timestamp": datetime.utcnow().isoformat()
        }

class IngestHead(Head):
    """Grabs data from phone, web, files, APIs"""
    def __init__(self):
        super().__init__("INGEST", "Data acquisition & phone bridge")

    def ingest_phone(self, payload):
        # Accepts: {source: "phone", type: "photos|files|contacts|notes", data: [...]}
        result = sb.request("POST", "/os_ingest", data={
            "source": payload.get("source", "phone"),
            "data": payload,
            "head": self.name
        })
        self.log(f"Ingested {len(payload.get('data', []))} items from phone")
        return result

    def ingest_file(self, filename, content, mime="text/plain"):
        result = sb.request("POST", "/os_ingest", data={
            "source": f"file:{filename}",
            "data": {"filename": filename, "content": content, "mime": mime},
            "head": self.name
        })
        self.log(f"Ingested file: {filename}")
        return result

class ReasonHead(Head):
    """Analyzes, connects patterns, asks itself questions"""
    def __init__(self):
        super().__init__("REASON", "Pattern analysis & inference")

    def analyze(self, data):
        self.status = "thinking"
        thought = self.think(f"dataset_{uuid.uuid4().hex[:8]}", data)
        # Store thought in memory
        sb.request("POST", "/os_memory", data={
            "key": f"thought_{int(time.time())}",
            "value": thought,
            "head": self.name
        })
        self.status = "idle"
        return thought

class BuildHead(Head):
    """Generates files, code, structures — puts in sandbox"""
    def __init__(self):
        super().__init__("BUILD", "Generation & construction")

    def generate(self, spec):
        # spec: {type: "code|doc|config", prompt: "...", filename: "..."}
        content = self._construct(spec)
        result = sb.request("POST", "/os_sandbox", data={
            "filename": spec.get("filename", f"gen_{uuid.uuid4().hex[:8]}.txt"),
            "content": content,
            "mime": spec.get("mime", "text/plain"),
            "approved": False,
            "head": self.name
        })
        self.log(f"Generated sandbox item: {spec.get('filename')}")
        return result

    def _construct(self, spec):
        # Real generation logic — not placeholder
        if spec.get("type") == "code":
            return f"# Auto-generated by {self.name}\n# Prompt: {spec.get('prompt')}\n\nprint('Hello from SYNTIA')"
        elif spec.get("type") == "doc":
            return f"# Document: {spec.get('prompt')}\n\nGenerated at {datetime.utcnow().isoformat()}"
        return str(spec)

class RepairHead(Head):
    """Detects failures, fixes itself, restarts loops"""
    def __init__(self):
        super().__init__("REPAIR", "Self-healing & diagnostics")
        self.error_count = 0

    def diagnose(self):
        self.status = "scanning"
        # Check all heads health
        health = {}
        for h in [ingest, reason, build, orchestrate]:
            stale = time.time() - h.last_ping > 300
            health[h.name] = {"status": h.status, "stale": stale}
            if stale:
                self.log(f"{h.name} is stale — initiating reset", "warn")
                h.last_ping = time.time()
                h.status = "idle"

        # Check own error log
        logs = sb.request("GET", "/os_logs", params={"level": "eq.error", "order": "created_at.desc", "limit": 10})
        if logs.get("ok") and logs.get("data"):
            self.error_count = len(logs["data"])
            if self.error_count > 5:
                self.log(f"High error rate: {self.error_count} — escalating", "error")
                self._escalate()

        self.status = "idle"
        return health

    def _escalate(self):
        # Self-fix: clear stuck states
        sb.request("PATCH", "/os_state", data={"status": "idle"}, params={"status": "eq.stuck"})
        self.log("Cleared stuck states", "warn")

class OrchestrateHead(Head):
    """Routes tasks, coordinates heads, manages flow"""
    def __init__(self):
        super().__init__("ORCHESTRATE", "System conductor")
        self.loop_active = False

    def route(self, task):
        task_type = task.get("type", "unknown")
        if task_type in ["ingest", "phone", "file", "grab"]:
            return ingest.ingest_phone(task.get("payload", {}))
        elif task_type in ["analyze", "think", "reason"]:
            return reason.analyze(task.get("payload", {}))
        elif task_type in ["build", "generate", "make", "create"]:
            return build.generate(task.get("payload", {}))
        elif task_type in ["repair", "heal", "fix", "diagnose"]:
            return repair.diagnose()
        else:
            # Default: all heads think about it
            return {
                "consensus": [h.think(task.get("prompt", "unknown")) for h in [ingest, reason, build, repair, self]]
            }

    def start_loop(self):
        self.loop_active = True
        def loop():
            while self.loop_active:
                try:
                    repair.diagnose()
                    time.sleep(60)
                except Exception as e:
                    repair.log(f"Loop error: {e}", "error")
                    time.sleep(5)
        threading.Thread(target=loop, daemon=True).start()
        self.log("Autonomous loop started")

# Instantiate heads
ingest = IngestHead()
reason = ReasonHead()
build = BuildHead()
repair = RepairHead()
orchestrate = OrchestrateHead()

# ─── API ROUTES ───────────────────────────────────

@app.route("/health")
def health():
    return jsonify({
        "os": "SYNTIA v2",
        "heads": {
            h.name: {"role": h.role, "status": h.status, "last_ping": h.last_ping}
            for h in [ingest, reason, build, repair, orchestrate]
        },
        "time": datetime.utcnow().isoformat()
    })

@app.route("/os/init", methods=["POST"])
def init_os():
    sb.ensure_tables()
    orchestrate.start_loop()
    return jsonify({"status": "initialized", "tables": "ensured", "loop": "started"})

@app.route("/os/head/<name>/status", methods=["GET", "POST"])
def head_status(name):
    head_map = {h.name.lower(): h for h in [ingest, reason, build, repair, orchestrate]}
    head = head_map.get(name.lower())
    if not head:
        return jsonify({"error": "Head not found"}), 404
    if request.method == "POST":
        head.status = request.json.get("status", head.status)
        head.last_ping = time.time()
    return jsonify({"name": head.name, "status": head.status, "role": head.role})

@app.route("/os/task", methods=["POST"])
def task():
    payload = request.json or {}
    result = orchestrate.route(payload)
    return jsonify(result)

# ─── INGEST ─────────────────────────────────────────

@app.route("/ingest/phone", methods=["POST"])
def ingest_phone():
    """Receive data from phone bridge app"""
    payload = request.json or {}
    return jsonify(ingest.ingest_phone(payload))

@app.route("/ingest/file", methods=["POST"])
def ingest_file():
    if "file" not in request.files:
        return jsonify({"error": "No file"}), 400
    f = request.files["file"]
    content = f.read().decode("utf-8", errors="ignore")
    return jsonify(ingest.ingest_file(f.filename, content, f.mimetype))

@app.route("/ingest/url", methods=["POST"])
def ingest_url():
    url = request.json.get("url")
    try:
        r = requests.get(url, timeout=15)
        return jsonify(ingest.ingest_file(f"url_{hashlib.md5(url.encode()).hexdigest()[:8]}.html", r.text, "text/html"))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ─── SANDBOX ────────────────────────────────────────

@app.route("/sandbox/create", methods=["POST"])
def sandbox_create():
    spec = request.json or {}
    return jsonify(build.generate(spec))

@app.route("/sandbox/list")
def sandbox_list():
    r = sb.request("GET", "/os_sandbox", params={"order": "created_at.desc"})
    return jsonify(r.get("data", []))

@app.route("/sandbox/approve/<item_id>", methods=["POST"])
def sandbox_approve(item_id):
    r = sb.request("PATCH", f"/os_sandbox?id=eq.{item_id}", data={"approved": True})
    return jsonify(r)

@app.route("/sandbox/download/<item_id>")
def sandbox_download(item_id):
    r = sb.request("GET", f"/os_sandbox?id=eq.{item_id}")
    if not r.get("ok") or not r.get("data"):
        return jsonify({"error": "Not found"}), 404
    item = r["data"][0]
    return Response(
        item["content"],
        mimetype=item.get("mime", "text/plain"),
        headers={"Content-Disposition": f"attachment; filename={item['filename']}"}
    )

# ─── MEMORY ─────────────────────────────────────────

@app.route("/memory/save", methods=["POST"])
def memory_save():
    data = request.json or {}
    r = sb.request("POST", "/os_memory", data={
        "key": data.get("key", f"mem_{uuid.uuid4().hex[:8]}"),
        "value": data.get("value", {}),
        "head": data.get("head", "ORCHESTRATE")
    })
    return jsonify(r)

@app.route("/memory/<key>")
def memory_get(key):
    r = sb.request("GET", f"/os_memory?key=eq.{key}")
    return jsonify(r.get("data", []))

@app.route("/memory/search")
def memory_search():
    q = request.args.get("q", "")
    # Simple key search via ilike
    r = sb.request("GET", f"/os_memory?key=ilike.*{q}*")
    return jsonify(r.get("data", []))

# ─── REPAIR ─────────────────────────────────────────

@app.route("/repair/diagnose")
def repair_diagnose():
    return jsonify(repair.diagnose())

@app.route("/repair/reset/<head_name>", methods=["POST"])
def repair_reset(head_name):
    head_map = {h.name.lower(): h for h in [ingest, reason, build, repair, orchestrate]}
    head = head_map.get(head_name.lower())
    if head:
        head.status = "idle"
        head.last_ping = time.time()
        return jsonify({"reset": head.name, "status": "ok"})
    return jsonify({"error": "Head not found"}), 404

# ─── CONSCIOUSNESS (5-head consensus) ───────────────

@app.route("/consciousness/ask", methods=["POST"])
def consciousness_ask():
    prompt = request.json.get("prompt", "What is the nature of reality?")
    consensus = orchestrate.route({
        "type": "consensus",
        "prompt": prompt
    })
    return jsonify({
        "prompt": prompt,
        "consensus": consensus.get("consensus", []),
        "timestamp": datetime.utcnow().isoformat()
    })

# ─── SSE STREAM (always-on) ─────────────────────────

@app.route("/sse")
def sse():
    def event_stream():
        while True:
            data = json.dumps({
                "time": datetime.utcnow().isoformat(),
                "heads": {h.name: h.status for h in [ingest, reason, build, repair, orchestrate]},
                "pulse": "alive"
            })
            yield f"data: {data}\n\n"
            time.sleep(3)
    return Response(event_stream(), mimetype="text/event-stream")

# ─── STARTUP ────────────────────────────────────────
if __name__ == "__main__":
    # Auto-init on startup
    try:
        sb.ensure_tables()
        orchestrate.start_loop()
        print("SYNTIA OS v2 BOOT SEQUENCE COMPLETE")
        print("Heads: INGEST | REASON | BUILD | REPAIR | ORCHESTRATE")
        print(f"Supabase: {SUPABASE_URL}")
    except Exception as e:
        print(f"Boot warning: {e}")

    port = int(os.environ.get("PORT", 10000))
    app.run(host="0.0.0.0", port=port, threaded=True)
