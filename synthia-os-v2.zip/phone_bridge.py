#!/usr/bin/env python3
"""
SYNTIA Phone Bridge — Run on your phone (Termux/Pydroid)
Scans phone storage and pushes to your SYNTIA OS server
"""

import os, sys, json, requests

SERVER = "https://synthia-server.onrender.com"

# Auto-detect common phone paths
PHONE_PATHS = [
    "/sdcard/DCIM/Camera",      # Photos
    "/sdcard/Download",          # Downloads
    "/sdcard/Documents",         # Docs
    "/storage/emulated/0/DCIM",
    "/storage/emulated/0/Download",
]

def scan_and_push(path, file_types=(".jpg", ".png", ".pdf", ".txt", ".json", ".md")):
    files = []
    if os.path.exists(path):
        for root, dirs, filenames in os.walk(path):
            for fname in filenames:
                if fname.lower().endswith(file_types):
                    fpath = os.path.join(root, fname)
                    try:
                        with open(fpath, "rb") as f:
                            content = f.read().decode("utf-8", errors="ignore")[:50000]  # Limit size
                        files.append({"name": fname, "path": fpath, "content": content})
                    except:
                        files.append({"name": fname, "path": fpath, "content": "[binary]"})

    if files:
        resp = requests.post(f"{SERVER}/ingest/phone", json={
            "source": "phone",
            "type": "auto_scan",
            "data": files,
            "device_path": path
        }, timeout=30)
        print(f"Pushed {len(files)} files from {path} — Status: {resp.status_code}")
        return resp.json()
    return {"pushed": 0}

if __name__ == "__main__":
    print("SYNTIA Phone Bridge starting...")
    for p in PHONE_PATHS:
        scan_and_push(p)
    print("Done. Your data is now in SYNTIA.")
