# SYNTIA OS v2 — Autonomous 5-Head Engine

## Deploy to Render

1. Go to https://dashboard.render.com → your `synthia-server` service
2. Upload this code (Git push or manual deploy)
3. In Render dashboard → Environment, add:
   - `SUPABASE_KEY` = `sb_publishable_r875ycY951IHyew2SwXEmg_qMOgv9AW`
4. Deploy

## API Endpoints

| Endpoint | Method | What it does |
|----------|--------|-------------|
| `/health` | GET | All 5 heads status |
| `/os/init` | POST | Ensure DB tables, start loop |
| `/os/task` | POST | Route any task to correct head |
| `/ingest/phone` | POST | Push phone data into OS |
| `/ingest/file` | POST | Upload file |
| `/ingest/url` | POST | Scrape URL into OS |
| `/sandbox/create` | POST | Generate new file (needs approval) |
| `/sandbox/list` | GET | View generated files |
| `/sandbox/approve/<id>` | POST | Approve file for use |
| `/sandbox/download/<id>` | GET | Download approved file |
| `/memory/save` | POST | Store memory |
| `/memory/<key>` | GET | Retrieve memory |
| `/repair/diagnose` | GET | Self-diagnostic scan |
| `/consciousness/ask` | POST | All 5 heads answer together |
| `/sse` | GET | Live stream of OS state |

## Phone Bridge

Run `phone_bridge.py` on your phone (Termux, Pydroid, or Pythonista).
It scans your photos/downloads/docs and pushes them to SYNTIA.

## 5 Heads

- **INGEST** — Grabs data from phone, files, URLs
- **REASON** — Analyzes patterns, asks itself questions
- **BUILD** — Generates files/code, puts in sandbox
- **REPAIR** — Detects failures, fixes stuck states
- **ORCHESTRATE** — Routes tasks, runs autonomous loop

## Self-Healing

The REPAIR head runs every 60s. If any head is stuck for >5min, it resets.
If error rate >5, it escalates and clears all stuck states.
