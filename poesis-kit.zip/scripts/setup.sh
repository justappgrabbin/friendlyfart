#!/bin/bash
# Easy As Poesis — One-Command Setup
# Run: chmod +x scripts/setup.sh && ./scripts/setup.sh

set -e

echo "🌱 Easy As Poesis — Setup"
echo "=========================="

python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $python_version"

echo "Creating virtual environment..."
python3 -m venv .venv
source .venv/bin/activate

echo "Installing dependencies..."
pip install --upgrade pip
pip install -e ".[dev,web]"

echo "Running tests..."
pytest tests/ -v || echo "Tests not yet written — that's okay!"

echo "Installing CLI..."
pip install -e .

echo ""
echo "✅ Setup complete!"
echo ""
echo "Quick start:"
echo "  poesis build my-app --desc 'My first app' --stack react --stack fastapi --feature auth"
echo "  poesis demo"
echo "  poesis research 'autopoietic systems'"
echo ""
echo "Or run examples:"
echo "  python examples/01_hello_poesis.py"
echo "  python examples/02_build_app.py"
echo "  python examples/03_research_loop.py"
