"""Tests for Orchestrator."""
import pytest
from poesis.orchestrator.agent import PoesisOrchestrator, AppSpec, BuildPlan

class TestOrchestrator:
    def test_init(self):
        orch = PoesisOrchestrator(workspace="./test-orch")
        status = orch.get_status()
        assert status["current_spec"] is None
        assert "brain_stats" in status

    def test_orchestrate(self):
        orch = PoesisOrchestrator(workspace="./test-orch2")
        spec = AppSpec(name="test-app", description="A test app", tech_stack=["python"], features=["test"])
        plan = orch.orchestrate(spec)
        assert isinstance(plan, BuildPlan)
        assert plan.app_name == "test-app"
        assert len(plan.steps) > 0

    def test_app_spec(self):
        spec = AppSpec(name="my-app", description="My app", tech_stack=["react", "fastapi"], features=["auth", "chat"])
        assert spec.name == "my-app"
        assert len(spec.tech_stack) == 2
