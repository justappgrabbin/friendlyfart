"""Tests for Self-Building Neural Network."""
import numpy as np
import pytest
from poesis.core.sbnn import SBNN, Neuron, Synapse

class TestSBNN:
    def test_init(self):
        net = SBNN(input_dim=4, output_dim=2, max_neurons=50)
        assert len(net.neurons) == 6
        assert len(net.layers[0]) == 4
        assert len(net.layers[4]) == 2

    def test_forward(self):
        net = SBNN(input_dim=4, output_dim=2)
        outputs = net.forward(np.array([1, 0, 0, 0]))
        assert len(outputs) == 2
        assert all(-1 <= o <= 1 for o in outputs)

    def test_synaptogenesis(self):
        net = SBNN(input_dim=4, output_dim=2, max_neurons=20)
        initial = len(net.neurons)
        net.synaptogenesis(np.array([5, 5, 5, 5]))
        assert len(net.neurons) >= initial

    def test_train_step(self):
        net = SBNN(input_dim=4, output_dim=2)
        error = net.train_step(np.array([1, 0, 0, 0]), np.array([1, 0]))
        assert isinstance(error, float)
        assert error >= 0

    def test_serialization(self):
        net = SBNN(input_dim=4, output_dim=2)
        data = net.to_dict()
        restored = SBNN.from_dict(data)
        assert restored.input_dim == net.input_dim
        assert len(restored.neurons) == len(net.neurons)

    def test_prune(self):
        net = SBNN(input_dim=4, output_dim=2, max_neurons=20)
        for _ in range(10):
            net.synaptogenesis(np.array([1, 1, 1, 1]))
        initial = len(net.synapses)
        net.prune()
        assert len(net.synapses) <= initial
