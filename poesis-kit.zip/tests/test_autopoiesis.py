"""Tests for Autopoiesis Engine."""
import pytest
from poesis.core.autopoiesis import AutopoiesisEngine, Promise, BlockReport, WorkLog

class TestAutopoiesis:
    def test_promise_lifecycle(self):
        engine = AutopoiesisEngine(workspace_dir="./.test_poesis")
        result = engine.be_autopoietic(mode="promise", task="Test task", max_iterations=5)
        assert result["status"] == "promised"
        assert "promise_id" in result
        status = engine.be_autopoietic(mode="status")
        assert status["status"] == "promised"
        assert not engine.can_exit()
        done = engine.be_autopoietic(mode="done")
        assert done["status"] == "done"
        assert engine.can_exit()

    def test_block_report(self):
        engine = AutopoiesisEngine(workspace_dir="./.test_poesis2")
        engine.be_autopoietic(mode="promise", task="Blocked task")
        blocked = engine.be_autopoietic(mode="blocked", task="Need API key")
        assert blocked["status"] == "blocked"
        assert engine.can_exit()

    def test_iterate(self):
        engine = AutopoiesisEngine(workspace_dir="./.test_poesis3")
        engine.be_autopoietic(mode="promise", task="Iterate task")
        result = engine.iterate(lambda: {"success": True, "result": "done", "done": True, "action": "test"})
        assert result["status"] in ["working", "done"]

    def test_stats(self):
        engine = AutopoiesisEngine(workspace_dir="./.test_poesis4")
        engine.be_autopoietic(mode="promise", task="Stats task")
        engine.be_autopoietic(mode="done")
        stats = engine.get_work_stats()
        assert stats["total_promises"] >= 1
