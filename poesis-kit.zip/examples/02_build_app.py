#!/usr/bin/env python3
"""Example 2: Build a Full Stack App."""
from poesis.orchestrator.agent import PoesisOrchestrator, AppSpec

def main():
    print("=" * 60)
    print("  EXAMPLE 2: Build a Full Stack App")
    print("=" * 60)
    orch = PoesisOrchestrator(workspace="./myapp-output")
    spec = AppSpec(name="my-awesome-app", description="A real-time chat app with AI assistant",
                  tech_stack=["react", "fastapi", "supabase"],
                  features=["auth", "chat", "ai-assistant", "realtime"],
                  constraints={"deploy": "render", "budget": "free"},
                  research_queries=["react 19 server components 2026", "fastapi supabase integration", "realtime chat architecture patterns"])
    plan = orch.orchestrate(spec)
    print(f"\n{'='*60}")
    print(f"  BUILD COMPLETE")
    print(f"{'='*60}")
    print(f"  App: {plan.app_name}")
    print(f"  Files: {len(plan.generated_files)}")
    print(f"  Specialists: {plan.specialists_needed}")
    print(f"  Output: ./myapp-output/")
    print(f"\n  Next steps:")
    print(f"    cd myapp-output")
    print(f"    pip install -e .")
    print(f"    uvicorn api.main:app --reload")

if __name__ == "__main__":
    main()
