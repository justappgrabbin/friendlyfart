#!/usr/bin/env python3
"""Example 3: Research Loop — Use the orchestrator purely for research."""
from poesis.tools.web_search import WebSearchTool
from poesis.core.resonance import ResonanceMatrix

def main():
    print("=" * 60)
    print("  EXAMPLE 3: Research Loop")
    print("=" * 60)
    search = WebSearchTool()
    resonance = ResonanceMatrix(dim=5)
    topics = ["autopoietic systems design 2026", "self-building neural networks", "multi-agent orchestration patterns"]
    for topic in topics:
        print(f"\n🔬 Researching: {topic}")
        result = search.deep_research(topic, depth=2)
        resonance.ingest(topic, result)
        print(f"   Queries: {result['queries_made']}")
        print(f"   Sources: {sum(len(r['sources']) for r in result['results'])}")
        print(f"   Resonance: {resonance.compute_resonance(topic):.2f}")
    print(f"\n{'='*60}")
    print(f"  SYSTEM CONSCIOUSNESS STATE")
    print(f"{'='*60}")
    for key, value in resonance.get_state().items():
        print(f"  {key}: {value}")
    gap = resonance.suggest_gap()
    if gap:
        print(f"\n  💡 Suggested research gap: {gap}")

if __name__ == "__main__":
    main()
