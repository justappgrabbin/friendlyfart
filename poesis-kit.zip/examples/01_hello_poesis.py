#!/usr/bin/env python3
"""Example 1: Hello Poesis — Your first autopoietic build."""
from poesis.orchestrator.agent import PoesisOrchestrator, AppSpec

def main():
    print("=" * 60)
    print("  EXAMPLE 1: Hello Poesis")
    print("=" * 60)
    orch = PoesisOrchestrator(workspace="./hello-output")
    spec = AppSpec(name="hello-poesis", description="A simple greeting app",
                  tech_stack=["python"], features=["greet"])
    plan = orch.orchestrate(spec)
    print(f"\n✅ Built {plan.app_name} with {len(plan.generated_files)} files")
    print(f"   Check ./hello-output/ for results")

if __name__ == "__main__":
    main()
