"""
Easy As Poesis — Autopoietic App Builder

A self-building, self-maintaining agent system that:
  • Researches best practices for your stack
  • Plans your architecture
  • Builds each component via specialist agents
  • Validates everything
  • Ships to GitHub

Based on:
  - SBNN (Self-Building Neural Networks) — Iacca et al. 2023
  - ASAN (Autopoietic Specialist-Agent Network) — Variable-Fox 2025
  - Autopoiesis-MCP — sancovp 2025
  - Plurigrid Protocol — plurigrid/ontology
  - Consciousness Matrix — GitHub Community Discussion #165775
"""

__version__ = "0.1.0"
__author__ = "Poesis Builder"

from poesis.core.sbnn import SBNN, Neuron, Synapse
from poesis.core.autopoiesis import AutopoiesisEngine, Promise, BlockReport, WorkLog
from poesis.orchestrator.agent import PoesisOrchestrator, AppSpec, BuildPlan

__all__ = [
    "SBNN", "Neuron", "Synapse",
    "AutopoiesisEngine", "Promise", "BlockReport", "WorkLog",
    "PoesisOrchestrator", "AppSpec", "BuildPlan",
]
