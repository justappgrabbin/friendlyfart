"""Memory and persistence modules."""
