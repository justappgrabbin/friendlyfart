"""Configuration schemas and validation."""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any

class SBNNConfig(BaseModel):
    input_dim: int = 20
    output_dim: int = 10
    max_neurons: int = 200
    growth_rate: float = 0.1
    prune_rate: float = 0.05
    hebbian_lr: float = 0.01

class AutopoiesisConfig(BaseModel):
    max_iterations: int = 100
    completion_criteria: str = "Production-ready. Deploy-and-forget quality."
    workspace_dir: str = "./.poesis"

class OrchestratorConfig(BaseModel):
    model_provider: str = "openai"
    workspace: str = "./poesis-output"

class ResearchConfig(BaseModel):
    search_engine: str = "duckduckgo"
    max_results: int = 5
    cache_ttl: int = 3600

class PoesisConfig(BaseModel):
    sbnn: SBNNConfig = Field(default_factory=SBNNConfig)
    autopoiesis: AutopoiesisConfig = Field(default_factory=AutopoiesisConfig)
    orchestrator: OrchestratorConfig = Field(default_factory=OrchestratorConfig)
    research: ResearchConfig = Field(default_factory=ResearchConfig)
