"""
ASAN Directory Service
Hierarchical routing for specialist agents.
"""

import hashlib
from typing import Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field
from collections import defaultdict

@dataclass
class Capability:
    domain: str
    skills: List[str]
    expertise_level: float = 1.0

@dataclass
class AgentRecord:
    agent_id: str
    agent_type: str
    capabilities: List[Capability]
    shard: str
    energy: float = 1.0
    active: bool = True

class DirectoryService:
    """Hierarchical directory for ASAN routing."""

    def __init__(self):
        self.agents: Dict[str, AgentRecord] = {}
        self.shards: Dict[str, Set[str]] = defaultdict(set)
        self.capability_index: Dict[str, Set[str]] = defaultdict(set)

    def register(self, agent) -> str:
        agent_id = f"{agent.type}_{hashlib.md5(str(id(agent)).encode()).hexdigest()[:8]}"
        shard = self._get_shard(agent.type)
        record = AgentRecord(agent_id=agent_id, agent_type=agent.type,
                            capabilities=agent.capabilities, shard=shard)
        self.agents[agent_id] = record
        self.shards[shard].add(agent_id)
        for cap in agent.capabilities:
            self.capability_index[cap.domain].add(agent_id)
            for skill in cap.skills:
                self.capability_index[skill].add(agent_id)
        return agent_id

    def _get_shard(self, agent_type: str) -> str:
        return {"frontend": "ui", "backend": "api", "database": "data", "auth": "security",
                "ai_integration": "intelligence", "devops": "ops", "tester": "quality",
                "documenter": "docs", "orchestrator": "control"}.get(agent_type, "general")

    def route(self, task_requirement: str, preferred_shard: Optional[str] = None) -> Optional[str]:
        candidates = []
        for skill, agents in self.capability_index.items():
            if skill.lower() in task_requirement.lower():
                for aid in agents:
                    a = self.agents[aid]
                    if a.active and a.energy > 0.3:
                        candidates.append((aid, a.energy))
        if preferred_shard and preferred_shard in self.shards:
            shard_cands = [(aid, self.agents[aid].energy) for aid in self.shards[preferred_shard]
                          if self.agents[aid].active and self.agents[aid].energy > 0.3]
            candidates = shard_cands + candidates
        if not candidates: return None
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[0][0]

    def get_shard_agents(self, shard: str) -> List[AgentRecord]:
        return [self.agents[aid] for aid in self.shards.get(shard, set())]

    def update_energy(self, agent_id: str, delta: float):
        if agent_id in self.agents:
            self.agents[agent_id].energy = max(0.0, min(2.0, self.agents[agent_id].energy + delta))

    def get_stats(self) -> Dict:
        return {"total_agents": len(self.agents),
                "shards": {k: len(v) for k, v in self.shards.items()},
                "capabilities": {k: len(v) for k, v in self.capability_index.items()},
                "avg_energy": sum(a.energy for a in self.agents.values()) / len(self.agents) if self.agents else 0}
