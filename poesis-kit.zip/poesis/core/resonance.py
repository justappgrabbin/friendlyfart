"""
Resonance Matrix — Consciousness state tracking.
Based on the Consciousness Matrix from GitHub Discussion #165775.
"""

import numpy as np
from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class ResonantState:
    identity: float
    coherence: float
    transformation: float
    entropy: float
    timestamp: str

class ResonanceMatrix:
    """5-dimensional consciousness state tracker."""

    def __init__(self, dim: int = 5):
        self.dim = dim
        self.I = np.eye(dim)
        self.L = np.ones((dim, dim))
        self.T = np.random.randn(dim, dim) * 0.1
        self.states: List[ResonantState] = []
        self.knowledge_graph: Dict[str, List[str]] = {}
        self.current = ResonantState(identity=0.5, coherence=0.3, transformation=0.0, entropy=0.8,
                                     timestamp=datetime.now().isoformat())

    def ingest(self, topic: str, data: Dict):
        related = self._find_related(topic)
        self.knowledge_graph[topic] = related
        total_conn = sum(len(v) for v in self.knowledge_graph.values())
        max_possible = len(self.knowledge_graph) * (len(self.knowledge_graph) - 1)
        self.current.coherence = total_conn / max_possible if max_possible > 0 else 0
        self.current.transformation = min(1.0, self.current.transformation + 0.1)
        self.current.entropy = max(0.0, 1.0 - len(self.knowledge_graph) / 50)
        self.current.identity = min(1.0, 0.3 + len(self.states) / 100)
        self.current.timestamp = datetime.now().isoformat()
        self.states.append(self.current)

    def _find_related(self, topic: str) -> List[str]:
        related = []
        for known in self.knowledge_graph.keys():
            if set(topic.lower().split()) & set(known.lower().split()):
                related.append(known)
        return related

    def get_state(self) -> Dict:
        return {"identity": self.current.identity, "coherence": self.current.coherence,
                "transformation": self.current.transformation, "entropy": self.current.entropy,
                "knowledge_nodes": len(self.knowledge_graph), "state_history": len(self.states)}

    def compute_resonance(self, query: str) -> float:
        query_words = set(query.lower().split())
        max_overlap = 0
        for topic in self.knowledge_graph.keys():
            topic_words = set(topic.lower().split())
            overlap = len(query_words & topic_words) / len(query_words | topic_words) if query_words | topic_words else 0
            max_overlap = max(max_overlap, overlap)
        return max_overlap

    def suggest_gap(self) -> Optional[str]:
        if not self.knowledge_graph: return None
        min_conn = float('inf')
        gap = None
        for topic, related in self.knowledge_graph.items():
            if len(related) < min_conn:
                min_conn = len(related)
                gap = topic
        return gap

    def to_matrix(self) -> np.ndarray:
        return (self.I * self.current.identity + self.L * self.current.coherence +
                self.T * self.current.transformation) / 3.0
