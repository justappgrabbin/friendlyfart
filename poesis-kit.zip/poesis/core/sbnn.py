"""
Self-Building Neural Network (SBNN)
Based on: Iacca et al. 2023 — Synaptogenesis + Hebbian Learning + Pruning

The network BUILDS ITSELF during task execution:
  1. Neurons grow and connect (synaptogenesis)
  2. Connections strengthen via Hebbian learning
  3. Weak connections are pruned (like a developing brain)
  4. The structure adapts to the task at hand
"""

import numpy as np
import random
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass, field

@dataclass
class Neuron:
    """A neuron with state, activation history, and metabolic energy."""
    id: int
    layer: int
    activation: float = 0.0
    bias: float = 0.0
    energy: float = 1.0
    age: int = 0
    synapses: List['Synapse'] = field(default_factory=list)

    def activate(self, inputs: np.ndarray, weights: np.ndarray) -> float:
        raw = np.dot(inputs, weights) + self.bias
        self.activation = float(np.tanh(raw * self.energy))
        self.age += 1
        return self.activation

    def prune_check(self, threshold: float = 0.1) -> bool:
        return self.energy < threshold or (self.age > 1000 and abs(self.activation) < 0.01)

@dataclass
class Synapse:
    """A connection between neurons with Hebbian plasticity."""
    source: int
    target: int
    weight: float = 0.0
    strength: float = 0.0
    age: int = 0
    active: bool = True

    def hebbian_update(self, pre_activation: float, post_activation: float,
                     lr: float = 0.01, decay: float = 0.001):
        correlation = pre_activation * post_activation
        self.strength += lr * correlation - decay * self.strength
        self.weight = float(np.tanh(self.strength) * 2.0)
        self.age += 1
        if abs(self.strength) < 0.01 and self.age > 50:
            self.active = False
            return False
        return True

class SBNN:
    """Self-Building Neural Network. Architecture evolves during execution."""

    def __init__(self, input_dim: int = 10, output_dim: int = 4,
                 max_neurons: int = 500, growth_rate: float = 0.1,
                 prune_rate: float = 0.05, hebbian_lr: float = 0.01):
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.max_neurons = max_neurons
        self.growth_rate = growth_rate
        self.prune_rate = prune_rate
        self.hebbian_lr = hebbian_lr
        self.neurons: Dict[int, Neuron] = {}
        self.synapses: Dict[Tuple[int, int], Synapse] = {}
        self.next_neuron_id = 0
        self.layers: List[List[int]] = [[] for _ in range(5)]
        self.task_history: List[Dict] = []
        self.generation = 0
        self._init_minimal()

    def _init_minimal(self):
        for i in range(self.input_dim):
            n = self._create_neuron(layer=0)
            self.layers[0].append(n.id)
        for i in range(self.output_dim):
            n = self._create_neuron(layer=4)
            self.layers[4].append(n.id)

    def _create_neuron(self, layer: int) -> Neuron:
        nid = self.next_neuron_id
        self.next_neuron_id += 1
        neuron = Neuron(id=nid, layer=layer,
                       bias=float(np.random.randn() * 0.1), energy=1.0)
        self.neurons[nid] = neuron
        return neuron

    def _create_synapse(self, source: int, target: int) -> Optional[Synapse]:
        if source == target or (source, target) in self.synapses:
            return None
        syn = Synapse(source=source, target=target,
                     weight=float(np.random.randn() * 0.1), strength=0.0)
        self.synapses[(source, target)] = syn
        self.neurons[source].synapses.append(syn)
        return syn

    def synaptogenesis(self, task_signal: np.ndarray):
        signal_energy = float(np.linalg.norm(task_signal))
        if signal_energy > 2.0 and len(self.neurons) < self.max_neurons:
            hidden_layer = random.randint(1, 3)
            new_neuron = self._create_neuron(layer=hidden_layer)
            self.layers[hidden_layer].append(new_neuron.id)
            if hidden_layer > 0 and self.layers[hidden_layer - 1]:
                for sid in random.sample(self.layers[hidden_layer - 1], min(3, len(self.layers[hidden_layer - 1]))):
                    self._create_synapse(sid, new_neuron.id)
            if hidden_layer < 4 and self.layers[hidden_layer + 1]:
                for tid in random.sample(self.layers[hidden_layer + 1], min(3, len(self.layers[hidden_layer + 1]))):
                    self._create_synapse(new_neuron.id, tid)
        if random.random() < self.growth_rate:
            all_n = list(self.neurons.keys())
            if len(all_n) >= 2:
                s, t = random.sample(all_n, 2)
                if self.neurons[s].layer < self.neurons[t].layer:
                    self._create_synapse(s, t)

    def forward(self, inputs: np.ndarray) -> np.ndarray:
        assert len(inputs) == self.input_dim
        for i, nid in enumerate(self.layers[0]):
            self.neurons[nid].activation = float(inputs[i])
        for layer_idx in range(1, 5):
            for nid in self.layers[layer_idx]:
                neuron = self.neurons[nid]
                active_inputs, active_weights = [], []
                for syn in neuron.synapses:
                    if syn.active and syn.target == nid:
                        src = self.neurons.get(syn.source)
                        if src:
                            active_inputs.append(src.activation)
                            active_weights.append(syn.weight)
                if active_inputs:
                    neuron.activate(np.array(active_inputs), np.array(active_weights))
                    for syn in neuron.synapses:
                        if syn.active and syn.target == nid:
                            src = self.neurons.get(syn.source)
                            if src:
                                syn.hebbian_update(src.activation, neuron.activation, lr=self.hebbian_lr)
        return np.array([self.neurons[nid].activation for nid in self.layers[4]])

    def prune(self):
        pruned_syn, pruned_neu = 0, 0
        for key, syn in list(self.synapses.items()):
            if not syn.active:
                del self.synapses[key]
                pruned_syn += 1
        for nid, neuron in list(self.neurons.items()):
            if neuron.prune_check():
                pruned_neu += 1
                for layer in self.layers:
                    if nid in layer: layer.remove(nid)
                for syn in list(neuron.synapses):
                    if (syn.source, syn.target) in self.synapses:
                        del self.synapses[(syn.source, syn.target)]
                del self.neurons[nid]
        return pruned_syn, pruned_neu

    def train_step(self, inputs: np.ndarray, target: np.ndarray, reward: float = 1.0):
        outputs = self.forward(inputs)
        error = float(np.mean((outputs - target) ** 2))
        self.synaptogenesis(np.array([error] * self.input_dim))
        for neuron in self.neurons.values():
            if neuron.layer > 0:
                neuron.energy = float(np.clip(neuron.energy + reward * abs(neuron.activation) * 0.1 - 0.01, 0.0, 2.0))
        if self.generation % 10 == 0:
            self.prune()
        self.generation += 1
        self.task_history.append({'generation': self.generation, 'error': error,
                                  'neurons': len(self.neurons), 'synapses': len(self.synapses)})
        return error

    def get_stats(self) -> Dict:
        return {'neurons': len(self.neurons), 'synapses': len(self.synapses),
                'generation': self.generation,
                'layer_sizes': [len(l) for l in self.layers],
                'avg_energy': float(np.mean([n.energy for n in self.neurons.values()])) if self.neurons else 0}

    def to_dict(self) -> Dict:
        return {'input_dim': self.input_dim, 'output_dim': self.output_dim,
                'max_neurons': self.max_neurons, 'generation': self.generation,
                'neurons': [{'id': n.id, 'layer': n.layer, 'bias': n.bias,
                            'energy': n.energy, 'age': n.age} for n in self.neurons.values()],
                'synapses': [{'source': s.source, 'target': s.target, 'weight': s.weight,
                             'strength': s.strength, 'active': s.active} for s in self.synapses.values()],
                'layers': self.layers, 'history': self.task_history[-100:]}

    @classmethod
    def from_dict(cls, data: Dict) -> 'SBNN':
        net = cls(input_dim=data['input_dim'], output_dim=data['output_dim'],
                 max_neurons=data['max_neurons'])
        net.generation = data['generation']
        for nd in data['neurons']:
            n = Neuron(**nd)
            net.neurons[n.id] = n
            net.layers[n.layer].append(n.id)
            net.next_neuron_id = max(net.next_neuron_id, n.id + 1)
        for sd in data['synapses']:
            s = Synapse(**sd)
            net.synapses[(s.source, s.target)] = s
            if s.source in net.neurons:
                net.neurons[s.source].synapses.append(s)
        net.task_history = data.get('history', [])
        return net

def demo_sbnn():
    print("\n" + "="*70)
    print("  SBNN DEMO: Self-Building Neural Network")
    print("="*70)
    net = SBNN(input_dim=4, output_dim=2, max_neurons=100)
    print(f"\nInitial: {net.get_stats()}")
    patterns = [(np.array([1,0,0,0]), np.array([1,0])), (np.array([0,1,0,0]), np.array([0,1])),
                (np.array([0,0,1,0]), np.array([1,1])), (np.array([0,0,0,1]), np.array([0,0]))]
    for epoch in range(50):
        total_err = sum(net.train_step(i, t, 1.0) for i, t in patterns)
        if epoch % 10 == 0:
            s = net.get_stats()
            print(f"  Epoch {epoch}: err={total_err/4:.4f}, neurons={s['neurons']}, synapses={s['synapses']}")
    print(f"\nFinal: {net.get_stats()}")
    print(f"\nTest [0.5,0.5,0,0] → {net.forward(np.array([0.5,0.5,0,0]))}")

if __name__ == "__main__":
    demo_sbnn()
