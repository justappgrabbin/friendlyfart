"""
Autopoiesis Engine
Based on: sancovp/autopoiesis-mcp — Self-maintaining work loops

The agent controls its own loop:
  1. Agent commits a PROMISE → loop starts
  2. Agent works on the task
  3. Agent can't exit until genuinely complete or blocked
  4. Loop continues until <promise>DONE</promise> or block report
"""

import json
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path

class LoopState(Enum):
    IDLE = "idle"
    PROMISED = "promised"
    WORKING = "working"
    BLOCKED = "blocked"
    DONE = "done"

@dataclass
class Promise:
    id: str
    task: str
    created_at: str
    state: str = "active"
    iterations: int = 0
    max_iterations: int = 100
    block_reason: Optional[str] = None
    completion_criteria: str = ""
    def to_dict(self) -> Dict: return asdict(self)

@dataclass
class BlockReport:
    promise_id: str
    reason: str
    attempted_solutions: List[str]
    external_needs: List[str]
    timestamp: str
    def to_dict(self) -> Dict: return asdict(self)

@dataclass
class WorkLog:
    promise_id: str
    actions: List[Dict] = field(default_factory=list)
    thoughts: List[str] = field(default_factory=list)
    artifacts_created: List[str] = field(default_factory=list)
    tests_run: List[str] = field(default_factory=list)
    errors_encountered: List[str] = field(default_factory=list)
    def add_action(self, action: str, result: str, success: bool = True):
        self.actions.append({'action': action, 'result': result, 'success': success,
                            'timestamp': datetime.now().isoformat()})
    def to_dict(self) -> Dict: return asdict(self)

class AutopoiesisEngine:
    """Self-maintaining work loop engine. Agent cannot exit until done or blocked."""

    def __init__(self, workspace_dir: str = "./.poesis", max_iterations: int = 100,
                 completion_criteria: str = "Production-ready. Deploy-and-forget quality."):
        self.workspace = Path(workspace_dir)
        self.workspace.mkdir(exist_ok=True)
        self.promises_dir = self.workspace / "promises"
        self.blocks_dir = self.workspace / "blocks"
        self.logs_dir = self.workspace / "logs"
        self.artifacts_dir = self.workspace / "artifacts"
        for d in [self.promises_dir, self.blocks_dir, self.logs_dir, self.artifacts_dir]:
            d.mkdir(exist_ok=True)
        self.max_iterations = max_iterations
        self.completion_criteria = completion_criteria
        self.current_promise: Optional[Promise] = None
        self.current_log: Optional[WorkLog] = None
        self.state = LoopState.IDLE
        self.tools: Dict[str, Callable] = {}

    def register_tool(self, name: str, func: Callable):
        self.tools[name] = func

    def be_autopoietic(self, mode: str, task: str = "", completion_criteria: str = "",
                       max_iterations: int = 100) -> Dict:
        if mode == "promise": return self._start_promise(task, completion_criteria, max_iterations)
        elif mode == "blocked": return self._write_block_report(task)
        elif mode == "done": return self._mark_done()
        elif mode == "status": return self._get_status()
        else: return {"error": f"Unknown mode: {mode}"}

    def _start_promise(self, task: str, criteria: str, max_iter: int) -> Dict:
        promise_id = f"promise_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.current_promise = Promise(id=promise_id, task=task,
            created_at=datetime.now().isoformat(),
            completion_criteria=criteria or self.completion_criteria, max_iterations=max_iter)
        self.current_log = WorkLog(promise_id=promise_id)
        self.state = LoopState.PROMISED
        promise_file = self.promises_dir / f"{promise_id}.json"
        with open(promise_file, 'w') as f: json.dump(self.current_promise.to_dict(), f, indent=2)
        return {"status": "promised", "promise_id": promise_id, "task": task,
                "message": "Loop started. Cannot exit until <promise>DONE</promise> or blocked."}

    def _write_block_report(self, reason: str) -> Dict:
        if not self.current_promise: return {"error": "No active promise"}
        report = BlockReport(promise_id=self.current_promise.id, reason=reason,
            attempted_solutions=[a['action'] for a in self.current_log.actions if not a.get('success', True)],
            external_needs=["User clarification needed"], timestamp=datetime.now().isoformat())
        block_file = self.blocks_dir / f"{self.current_promise.id}.json"
        with open(block_file, 'w') as f: json.dump(report.to_dict(), f, indent=2)
        self.state = LoopState.BLOCKED
        log_file = self.logs_dir / f"{self.current_promise.id}.json"
        with open(log_file, 'w') as f: json.dump(self.current_log.to_dict(), f, indent=2)
        return {"status": "blocked", "promise_id": self.current_promise.id, "reason": reason,
                "message": "Block report written. Loop can exit."}

    def _mark_done(self) -> Dict:
        if not self.current_promise: return {"error": "No active promise"}
        self.current_promise.state = "completed"
        self.state = LoopState.DONE
        promise_file = self.promises_dir / f"{self.current_promise.id}.json"
        with open(promise_file, 'w') as f: json.dump(self.current_promise.to_dict(), f, indent=2)
        log_file = self.logs_dir / f"{self.current_promise.id}.json"
        with open(log_file, 'w') as f: json.dump(self.current_log.to_dict(), f, indent=2)
        return {"status": "done", "promise_id": self.current_promise.id,
                "iterations": self.current_promise.iterations, "message": "<promise>DONE</promise>"}

    def _get_status(self) -> Dict:
        if not self.current_promise: return {"status": "idle", "message": "No active promise"}
        return {"status": self.state.value, "promise_id": self.current_promise.id,
                "task": self.current_promise.task, "iterations": self.current_promise.iterations,
                "max_iterations": self.current_promise.max_iterations,
                "completion_criteria": self.current_promise.completion_criteria}

    def iterate(self, action_func: Callable[[], Dict]) -> Dict:
        if self.state not in [LoopState.PROMISED, LoopState.WORKING]:
            return {"error": "No active promise. Call be_autopoietic('promise') first."}
        self.state = LoopState.WORKING
        self.current_promise.iterations += 1
        if self.current_promise.iterations >= self.current_promise.max_iterations:
            return self._write_block_report("Max iterations reached")
        try:
            result = action_func()
            self.current_log.add_action(action=result.get('action', 'work'),
                                       result=str(result.get('result', '')),
                                       success=result.get('success', True))
            if result.get('done', False): return self._mark_done()
            return {"status": "working", "iteration": self.current_promise.iterations, "result": result}
        except Exception as e:
            self.current_log.errors_encountered.append(str(e))
            self.current_log.add_action(action="error", result=str(e), success=False)
            return {"status": "error", "error": str(e), "iteration": self.current_promise.iterations}

    def can_exit(self) -> bool:
        if not self.current_promise: return True
        if (self.blocks_dir / f"{self.current_promise.id}.json").exists(): return True
        if self.state == LoopState.DONE: return True
        return False

    def get_promise_history(self) -> List[Dict]:
        history = []
        for f in sorted(self.promises_dir.glob("*.json")):
            with open(f) as fh: history.append(json.load(fh))
        return history

    def get_work_stats(self) -> Dict:
        promises = self.get_promise_history()
        completed = sum(1 for p in promises if p.get('state') == 'completed')
        blocked = len(list(self.blocks_dir.glob("*.json")))
        total_iter = sum(p.get('iterations', 0) for p in promises)
        return {"total_promises": len(promises), "completed": completed, "blocked": blocked,
                "total_iterations": total_iter, "success_rate": completed / len(promises) if promises else 0}

def demo_autopoiesis():
    print("\n" + "="*70)
    print("  AUTOPOIESIS DEMO: Self-Maintaining Work Loop")
    print("="*70)
    engine = AutopoiesisEngine(workspace_dir="./.poesis_demo")
    result = engine.be_autopoietic(mode="promise", task="Build React component",
        completion_criteria="Component tested and production-ready", max_iterations=5)
    print(f"\nStarted: {result['promise_id']}")
    steps = [
        {"action": "scaffold", "result": "Created ProfileCard.jsx", "done": False, "success": True},
        {"action": "add_props", "result": "Props added", "done": False, "success": True},
        {"action": "style", "result": "CSS done", "done": False, "success": True},
        {"action": "test", "result": "3 tests passing", "done": False, "success": True},
        {"action": "docs", "result": "README updated", "done": True, "success": True},
    ]
    for step in steps:
        r = engine.iterate(lambda s=step: s)
        print(f"  Iter {r.get('iteration', '?')}: {step['action']} → {step['result']}")
        if r['status'] == 'done':
            print(f"\n✅ {r['message']}")
            break
    print(f"\nStats: {engine.get_work_stats()}")
    print(f"Can exit? {engine.can_exit()}")

if __name__ == "__main__":
    demo_autopoiesis()
