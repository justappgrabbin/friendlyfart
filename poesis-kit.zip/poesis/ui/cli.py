"""
Poesis CLI v2
Command-line interface for the orchestrator.
"""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from typing import Optional, List
from pathlib import Path

from poesis.orchestrator.agent import PoesisOrchestrator, AppSpec

app = typer.Typer(help="Easy As Poesis — Autopoietic App Builder")
console = Console()

@app.command()
def build(
    name: str = typer.Argument(..., help="App name"),
    description: str = typer.Option(..., "--desc", "-d", help="App description"),
    stack: List[str] = typer.Option([], "--stack", "-s", help="Tech stack (repeatable)"),
    features: List[str] = typer.Option([], "--feature", "-f", help="Features (repeatable)"),
    output: str = typer.Option("./poesis-output", "--output", "-o", help="Output directory"),
    github_org: str = typer.Option("yourusername", "--github-org", "-g", help="GitHub org/username"),
    create_repo: bool = typer.Option(True, "--create-repo/--no-create-repo", help="Create GitHub repo"),
    private: bool = typer.Option(False, "--private", "-p", help="Private repo"),
    research: bool = typer.Option(True, "--research/--no-research", help="Enable research phase"),
):
    """Build an app with the autopoietic orchestrator."""

    console.print(Panel.fit(
        f"[bold cyan]Easy As Poesis[/bold cyan]\n"
        f"Building: [bold]{name}[/bold]",
        title="🌱 Autopoietic Builder",
        border_style="green"
    ))

    spec = AppSpec(
        name=name,
        description=description,
        tech_stack=stack,
        features=features
    )

    orchestrator = PoesisOrchestrator(
        workspace=output,
        github_org=github_org
    )

    plan = orchestrator.orchestrate(
        spec,
        create_github_repo=create_repo,
        repo_private=private
    )

    # Summary
    table = Table(title="Build Summary")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("App Name", plan.app_name)
    table.add_row("Files Created", str(len(plan.generated_files)))
    table.add_row("Specialists Used", ", ".join(plan.specialists_needed))
    table.add_row("Research Queries", str(len(plan.research_results)))
    table.add_row("Output Directory", output)

    console.print(table)
    console.print(f"\n[bold green]✅ Build complete![/bold green] Check {output}/ for your app.")

@app.command()
def status(
    workspace: str = typer.Option("./poesis-output", "--workspace", "-w")
):
    """Check orchestrator status."""
    orchestrator = PoesisOrchestrator(workspace=workspace)
    status = orchestrator.get_status()

    console.print(Panel.fit(
        f"Brain: {status['brain_stats']}\n"
        f"Resonance: {status['resonance_state']}\n"
        f"Specialists: {', '.join(status['specialists_active'])}\n"
        f"Builds: {status['build_history']}\n"
        f"State: {status['state']}",
        title="📊 System Status",
        border_style="blue"
    ))

@app.command()
def research(
    query: str = typer.Argument(..., help="Research query"),
    depth: int = typer.Option(1, "--depth", "-d", help="Research depth")
):
    """Run a research query."""
    from poesis.tools.web_search import WebSearchTool

    tool = WebSearchTool()
    result = tool.deep_research(query, depth=depth)

    console.print(Panel.fit(
        f"[bold]{result['topic']}[/bold]\n\n"
        f"Queries: {result['queries_made']}\n"
        f"Synthesis: {result['synthesis']}",
        title="🔬 Research Results",
        border_style="magenta"
    ))

    for r in result['results']:
        console.print(f"\n[bold]{r['query']}[/bold]")
        for source in r['sources'][:3]:
            console.print(f"  • {source['title']} ({source['relevance']:.2f})")

@app.command()
def suggest(
    suggestion: str = typer.Argument(..., help="Improvement suggestion"),
    impact: str = typer.Option("", "--impact", "-i", help="Expected impact")
):
    """Submit a suggestion to the Suggestion Tournament (ASAN)."""
    orchestrator = PoesisOrchestrator()
    result = orchestrator.suggest_improvement(suggestion, impact)
    console.print(Panel.fit(
        f"[bold]{result['message']}[/bold]\n"
        f"Proposal ID: {result['proposal_id']}",
        title="💡 Suggestion Tournament",
        border_style="yellow"
    ))

@app.command()
def demo():
    """Run the full demo."""
    console.print(Panel.fit(
        "[bold yellow]Running full Poesis demo...[/bold yellow]",
        border_style="yellow"
    ))

    from poesis.core.sbnn import demo_sbnn
    from poesis.core.autopoiesis import demo_autopoiesis

    demo_sbnn()
    demo_autopoiesis()

    console.print("\n[bold green]✅ Demo complete![/bold green]")

@app.command()
def save(
    workspace: str = typer.Option("./poesis-output", "--workspace", "-w"),
    path: Optional[str] = typer.Option(None, "--path", help="Save path")
):
    """Save orchestrator state."""
    orchestrator = PoesisOrchestrator(workspace=workspace)
    save_path = orchestrator.save_state(path)
    console.print(f"[bold green]✅ State saved to {save_path}[/bold green]")

@app.command()
def load(
    path: str = typer.Argument(..., help="State file path")
):
    """Load orchestrator state."""
    orchestrator = PoesisOrchestrator.load_state(path)
    status = orchestrator.get_status()
    console.print(Panel.fit(
        f"Loaded state with {status['build_history']} builds\n"
        f"Specialists: {status['specialists_active']}\n"
        f"Constitution: {status['state']['constitution']}",
        title="📂 State Loaded",
        border_style="blue"
    ))

def main():
    app()

if __name__ == "__main__":
    main()
