"""Web Research Tool."""
from typing import Dict, List, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class SearchResult:
    title: str
    url: str
    snippet: str
    source: str
    relevance: float

class WebSearchTool:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
        self.cache: Dict[str, List[SearchResult]] = {}

    def search(self, query: str, num_results: int = 5) -> Dict:
        if query in self.cache:
            results = self.cache[query]
        else:
            results = self._simulate_search(query, num_results)
            self.cache[query] = results
        return {"query": query, "sources": [{"title": r.title, "url": r.url, "snippet": r.snippet, "relevance": r.relevance} for r in results],
                "summary": self._summarize(results), "timestamp": datetime.now().isoformat()}

    def _simulate_search(self, query: str, n: int) -> List[SearchResult]:
        keywords = query.lower().split()
        templates = {
            "react": [SearchResult("React 19: New Features", "https://react.dev/blog", "React 19 introduces the new React Compiler...", "React Docs", 0.95),
                     SearchResult("Modern React Patterns 2026", "https://patterns.dev", "Server Components, Suspense...", "Patterns.dev", 0.90)],
            "fastapi": [SearchResult("FastAPI Best Practices", "https://fastapi.tiangolo.com", "Dependency injection, background tasks...", "FastAPI Docs", 0.95),
                       SearchResult("Building APIs with FastAPI", "https://testdriven.io", "Complete guide to production-ready FastAPI...", "TestDriven.io", 0.88)],
            "supabase": [SearchResult("Supabase Realtime Guide", "https://supabase.com/docs", "Realtime subscriptions, Row Level Security...", "Supabase Docs", 0.95),
                        SearchResult("Supabase vs Firebase 2026", "https://blog.supabase.com", "Comparison of features, pricing...", "Supabase Blog", 0.85)],
            "autopoiesis": [SearchResult("Autopoiesis in AI Systems", "https://arxiv.org/abs/2304.01086", "Self-building neural networks...", "arXiv", 0.95),
                           SearchResult("ASAN Architecture", "https://github.com/Variable-Fox/ASAN-Architecture", "Autopoietic Specialist-Agent Network...", "GitHub", 0.92)],
        }
        results = []
        for kw, tpls in templates.items():
            if kw in keywords: results.extend(tpls)
        if not results:
            results = [SearchResult(f"Results for: {query}", "https://example.com", f"Search results related to {query}...", "Web", 0.70)]
        return results[:n]

    def _summarize(self, results: List[SearchResult]) -> str:
        if not results: return "No results."
        return "\n".join(f"- {r.title}: {r.snippet[:100]}..." for r in results[:3])

    def deep_research(self, topic: str, depth: int = 3) -> Dict:
        all_results = []
        queries = [topic]
        for level in range(depth):
            new_queries = []
            for q in queries:
                result = self.search(q)
                all_results.append(result)
                for source in result["sources"]:
                    if "guide" in source["title"].lower(): new_queries.append(f"{topic} tutorial")
                    if "best" in source["title"].lower(): new_queries.append(f"{topic} patterns")
            queries = list(set(new_queries))[:3]
        return {"topic": topic, "depth": depth, "queries_made": len(all_results), "results": all_results,
                "synthesis": f"Synthesized {sum(len(r['sources']) for r in all_results)} sources across {len(all_results)} queries."}
