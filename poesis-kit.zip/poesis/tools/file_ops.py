"""File Operations Tool."""
from typing import Dict, List, Optional
from pathlib import Path

class FileOpsTool:
    def read(self, path: str) -> Optional[str]:
        try:
            with open(path, 'r') as f: return f.read()
        except Exception as e:
            print(f"Read failed: {e}")
            return None

    def write(self, path: str, content: str) -> bool:
        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w') as f: f.write(content)
            return True
        except Exception as e:
            print(f"Write failed: {e}")
            return False

    def exists(self, path: str) -> bool:
        return Path(path).exists()

    def list_dir(self, path: str) -> List[str]:
        try: return [str(p) for p in Path(path).iterdir()]
        except Exception: return []

    def ensure_dir(self, path: str) -> bool:
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            return True
        except Exception: return False
