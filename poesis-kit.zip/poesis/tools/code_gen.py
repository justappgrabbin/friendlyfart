"""Code Generation Tool."""
from typing import Dict, List
from pathlib import Path
from jinja2 import Template

class CodeGenTool:
    def __init__(self):
        self.templates: Dict[str, str] = {}
        self._load_defaults()

    def _load_defaults(self):
        # React component template
        self.templates["react_component"] = """import React from 'react';
import './{{ name }}.css';
function {{ name }}({% for prop in props %}{{ prop }}{% if not loop.last %}, {% endif %}{% endfor %}) {
  return (<div className="{{ name|lower }}">{% for prop in props %}<p>{{ prop }}: { {{ prop }} }</p>{% endfor %}</div>);
}
export default {{ name }};
"""
        # FastAPI route template
        self.templates["fastapi_route"] = """from fastapi import APIRouter, HTTPException
from typing import List, Optional
router = APIRouter(prefix="/{{ prefix }}", tags=["{{ name }}"])
@router.get("/")
async def list_{{ name|lower }}(): return {"message": "List of {{ name }}"}
@router.get("/{item_id}")
async def get_{{ name|lower }}(item_id: str): return {"id": item_id, "name": "{{ name }}"}
@router.post("/")
async def create_{{ name|lower }}(data: dict): return {"created": True, "data": data}
"""
        # Python class template
        self.templates["python_class"] = """class {{ name }}:
    \"\"\"{{ description }}\"\"\"
    def __init__(self{% for param in params %}, {{ param.name }}: {{ param.type }}{% endfor %}):
        {% for param in params %}self.{{ param.name }} = {{ param.name }}
        {% endfor %}
    def __repr__(self):
        return f"{{ name }}({% for param in params %}self.{{ param.name }}{% if not loop.last %}, {% endif %}{% endfor %})"
"""

    def generate(self, template_name: str, context: Dict) -> str:
        if template_name not in self.templates:
            return f"# Template '{template_name}' not found"
        return Template(self.templates[template_name]).render(**context)

    def add_template(self, name: str, template_str: str):
        self.templates[name] = template_str

    def generate_file(self, template_name: str, context: Dict, output_path: Path) -> bool:
        try:
            code = self.generate(template_name, context)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, 'w') as f:
                f.write(code)
            return True
        except Exception as e:
            print(f"Error: {e}")
            return False
