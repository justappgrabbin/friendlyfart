"""
Git Operations Tool
Handles GitHub repo creation, setup, and operations.
"""

import subprocess
import os
from typing import Dict, List, Optional
from pathlib import Path

class GitOpsTool:
    """Git operations with full GitHub CLI integration."""

    def __init__(self, github_token: Optional[str] = None):
        self.github_token = github_token or os.getenv("GITHUB_TOKEN")

    def _fix_safe_directory(self, path: str):
        """Fix dubious ownership by adding to safe.directory."""
        try:
            repo_path = Path(path).resolve()
            # Try system-wide first (works in containers)
            subprocess.run(
                ["git", "config", "--system", "--add", "safe.directory", str(repo_path)],
                capture_output=True, check=False
            )
            # Also try global
            subprocess.run(
                ["git", "config", "--global", "--add", "safe.directory", str(repo_path)],
                capture_output=True, check=False
            )
        except Exception:
            pass

    def _run_git(self, cmd: List[str], cwd: str, check: bool = True) -> subprocess.CompletedProcess:
        """Run git command with safe.directory fix on failure."""
        try:
            return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, check=check)
        except subprocess.CalledProcessError as e:
            if "dubious ownership" in e.stderr or "detected dubious" in e.stderr:
                self._fix_safe_directory(cwd)
                return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, check=check)
            raise

    def init_repo(self, path: str) -> bool:
        """Initialize a git repository with main as default branch."""
        try:
            repo_path = Path(path)
            git_dir = repo_path / ".git"

            # Check if already a git repo
            if git_dir.exists():
                self._fix_safe_directory(path)
                return True

            # Initialize with main branch (works on git 2.28+)
            result = subprocess.run(
                ["git", "init", "--initial-branch=main"],
                cwd=path, capture_output=True, text=True
            )

            if result.returncode != 0:
                # Fallback for older git versions
                subprocess.run(["git", "init"], cwd=path, check=True, capture_output=True)
                subprocess.run(["git", "checkout", "-b", "main"], cwd=path, capture_output=True)

            # Fix safe.directory BEFORE any other git commands
            self._fix_safe_directory(path)

            # Configure git user (required for commits)
            subprocess.run(["git", "config", "user.email", "poesis@autopoietic.dev"], cwd=path, check=True, capture_output=True)
            subprocess.run(["git", "config", "user.name", "Poesis Builder"], cwd=path, check=True, capture_output=True)

            return True
        except subprocess.CalledProcessError as e:
            print(f"Git init failed: {e}")
            return False

    def add_file(self, path: str) -> bool:
        """Stage a file."""
        try:
            file_path = Path(path)
            repo_path = file_path.parent

            # Find the git root
            while not (repo_path / ".git").exists():
                repo_path = repo_path.parent
                if repo_path == repo_path.parent:
                    return False

            self._fix_safe_directory(str(repo_path))

            rel_path = file_path.relative_to(repo_path)
            subprocess.run(["git", "add", str(rel_path)], cwd=repo_path, check=True, capture_output=True)
            return True
        except Exception as e:
            print(f"Git add failed: {e}")
            return False

    def commit(self, message: str, path: str = ".") -> bool:
        """Commit staged changes."""
        try:
            self._fix_safe_directory(path)

            # Check if there are changes to commit
            status = subprocess.run(["git", "status", "--porcelain"], cwd=path, capture_output=True, text=True)
            if not status.stdout.strip():
                return True  # Nothing to commit

            subprocess.run(["git", "commit", "-m", message], cwd=path, check=True, capture_output=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Git commit failed: {e}")
            return False

    def create_github_repo(self, repo_name: str, path: str, 
                          org: Optional[str] = None,
                          description: str = "",
                          private: bool = False,
                          push: bool = True) -> Dict:
        """
        Create a GitHub repository using gh CLI and push local code.

        Requires: gh CLI installed and authenticated (gh auth login)
        """
        result = {"success": False, "repo_url": None, "error": None}

        # Check if gh is installed
        try:
            gh_version = subprocess.run(["gh", "--version"], capture_output=True, text=True, check=True)
            print(f"  GitHub CLI: {gh_version.stdout.strip().split(chr(10))[0]}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            result["error"] = "GitHub CLI (gh) not found. Install: https://cli.github.com"
            return result

        # Check authentication
        try:
            auth_status = subprocess.run(["gh", "auth", "status"], capture_output=True, text=True, check=True)
            print(f"  Auth: ✓ Logged in")
        except subprocess.CalledProcessError:
            result["error"] = "Not authenticated. Run: gh auth login"
            return result

        # Build repo name with org if provided
        full_repo_name = f"{org}/{repo_name}" if org else repo_name

        # Create repo
        try:
            cmd = [
                "gh", "repo", "create", full_repo_name,
                "--source", path,
                "--" + ("private" if private else "public")
            ]
            if push:
                cmd.append("--push")
            if description:
                cmd.extend(["--description", description])

            create_result = subprocess.run(cmd, capture_output=True, text=True, check=True)

            # Extract repo URL from output
            lines = create_result.stdout.strip().split(chr(10))
            repo_url = None
            for line in lines:
                if "github.com" in line:
                    repo_url = line.strip()
                    break

            if not repo_url:
                repo_url = f"https://github.com/{full_repo_name}"

            result["success"] = True
            result["repo_url"] = repo_url
            print(f"  ✅ Created: {repo_url}")

        except subprocess.CalledProcessError as e:
            if "already exists" in e.stderr:
                result["error"] = f"Repository {full_repo_name} already exists"
                result["repo_url"] = f"https://github.com/{full_repo_name}"
            else:
                result["error"] = f"Failed to create repo: {e.stderr}"

        return result

    def setup_github_actions(self, path: str, workflow_content: str) -> bool:
        """Setup GitHub Actions workflow."""
        try:
            workflow_dir = Path(path) / ".github" / "workflows"
            workflow_dir.mkdir(parents=True, exist_ok=True)
            with open(workflow_dir / "autopoiesis.yml", 'w') as f:
                f.write(workflow_content)
            return True
        except Exception as e:
            print(f"Setup failed: {e}")
            return False

    def trigger_workflow(self, repo: str, workflow: str = "autopoiesis.yml", 
                        ref: str = "main", inputs: Optional[Dict] = None) -> Dict:
        """Trigger a GitHub Actions workflow dispatch."""
        try:
            cmd = ["gh", "workflow", "run", workflow, "--repo", repo, "--ref", ref]
            if inputs:
                for key, value in inputs.items():
                    cmd.extend(["-f", f"{key}={value}"])

            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            return {"success": True, "output": result.stdout}
        except subprocess.CalledProcessError as e:
            return {"success": False, "error": e.stderr}
