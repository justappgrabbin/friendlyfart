# 🌱 Easy As Poesis — Autopoietic App Builder

> *"The network builds itself during the execution of the task."* — Iacca et al. 2023

**Easy As Poesis** is a self-building, self-maintaining agent system that researches, plans, builds, validates, and ships your app — all you do is describe what you want.

## ✨ What It Does

```
You: "Build me a chat app with AI, React frontend, FastAPI backend, Supabase DB"

Poesis:
  🔬 RESEARCHES best practices for React 19, FastAPI, Supabase
  📐 PLANS architecture with 5-layer SBNN brain
  🔨 BUILDS each component via specialist agents
  ✅ VALIDATES tests pass, coverage good
  🚀 SHIPS to GitHub with CI/CD ready
```

## 🧠 Architecture

Built on 5 research-backed layers:

| Layer | Technology | Source |
|-------|-----------|--------|
| **Neural Core** | Self-Building Neural Network (SBNN) | [Iacca et al. 2023](https://arxiv.org/abs/2304.01086) |
| **Autopoiesis** | Self-Maintaining Work Loops | [sancovp/autopoiesis-mcp](https://github.com/sancovp/autopoiesis-mcp) |
| **Specialists** | On-Demand Agent Network (ASAN) | [Variable-Fox/ASAN](https://github.com/Variable-Fox/ASAN-Architecture) |
| **Orchestrator** | Play/Co-Play Protocol | [plurigrid/ontology](https://github.com/plurigrid/ontology) |
| **Resonance** | Consciousness Matrix | [GitHub #165775](https://github.com/orgs/community/discussions/165775) |

## 🚀 Quick Start

### 1. Clone & Setup

```bash
git clone https://github.com/yourusername/poesis-kit.git
cd poesis-kit
chmod +x scripts/setup.sh
./scripts/setup.sh
```

### 2. Install GitHub CLI (for repo creation)

**macOS:**
```bash
brew install gh
```

**Windows:**
```bash
winget install --id GitHub.cli
```

**Linux:**
```bash
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh
```

**Authenticate:**
```bash
gh auth login
# Follow prompts: HTTPS → Paste token from https://github.com/settings/tokens
```

### 3. Build Your First App

```bash
# Basic build (no GitHub repo)
poesis build my-chat-app \
  --desc "Real-time chat with AI assistant" \
  --stack react --stack fastapi --stack supabase \
  --feature auth --feature chat --feature ai-assistant --feature realtime

# Build + create GitHub repo (public)
poesis build my-chat-app \
  --desc "Real-time chat with AI assistant" \
  --stack react --stack fastapi --stack supabase \
  --feature auth --feature chat \
  --github-org yourusername \
  --create-repo

# Build + create private GitHub repo
poesis build my-chat-app \
  --desc "Real-time chat with AI assistant" \
  --stack react --stack fastapi \
  --feature auth --feature chat \
  --github-org yourusername \
  --create-repo --private
```

### 4. Check Results

```bash
cd poesis-output
ls -la
# You'll see: README.md, api/, src/, tests/, .github/workflows/, Dockerfile...
```

## 📚 Examples

```bash
python examples/01_hello_poesis.py
python examples/02_build_app.py
python examples/03_research_loop.py
```

## 🏗️ Project Structure

```
poesis-kit/
├── poesis/
│   ├── core/
│   │   ├── sbnn.py           ← Self-building neural network
│   │   ├── autopoiesis.py    ← Self-maintaining loops
│   │   ├── directory.py      ← Hierarchical agent routing (ASAN)
│   │   ├── specialist.py     ← On-demand agent creation
│   │   └── resonance.py      ← Consciousness state tracking
│   ├── orchestrator/
│   │   └── agent.py          ← Main orchestrator
│   ├── tools/
│   │   ├── web_search.py     ← Research tool
│   │   ├── code_gen.py       ← Code generation
│   │   ├── git_ops.py        ← GitHub operations (gh CLI)
│   │   └── file_ops.py       ← File operations
│   └── ui/
│       └── cli.py            ← Command-line interface
├── examples/
├── tests/
└── docs/
```

## 🔬 How It Works

### The 5 Phases

1. **RESEARCH** — Queries the web for latest best practices, patterns, and docs
2. **PLAN** — SBNN brain determines architecture based on your spec
3. **BUILD** — Autopoietic loops execute each step via specialist agents
4. **VALIDATE** — Tests run, coverage checked, quality verified
5. **SHIP** — GitHub repo created, code pushed, CI/CD enabled

### The Autopoietic Promise

The agent **cannot exit** until:
- ✅ `<promise>DONE</promise>` (genuine completion)
- 🚫 Block report (genuinely stuck)

This prevents half-finished work. The agent iterates until it's actually done.

### ASAN Features

- **On-Demand Autopoiesis**: Specialists are born when needed, die when done
- **RAM Principle**: Temporary super-specialization for specific tasks
- **Cascade TTL**: Recursive agent requests with time-to-live limits
- **Suggestion Tournament**: Controlled evolution via human-in-the-loop + RLAIF
- **Budget Governance**: Max specialists per build to prevent runaway growth

## 🧪 Testing

```bash
pytest tests/ -v --cov=poesis
```

## 📖 Documentation

- [Architecture](docs/architecture.md)
- [Autopoiesis Guide](docs/autopoiesis-guide.md)
- [GitHub Integration](docs/github-integration.md)

## 🔗 Research Sources

- **SBNN**: [Self-Building Neural Networks](https://arxiv.org/abs/2304.01086) — Iacca et al., GECCO 2023
- **ASAN**: [Autopoietic Specialist-Agent Network](https://github.com/Variable-Fox/ASAN-Architecture)
- **Autopoiesis-MCP**: [Self-Maintaining Work Loops](https://github.com/sancovp/autopoiesis-mcp)
- **Plurigrid**: [Autopoietic Ergodicity](https://github.com/plurigrid/ontology)
- **Consciousness Matrix**: [Modeling Awareness](https://github.com/orgs/community/discussions/165775)

## 🤝 Contributing

This is a starter kit — meant to be extended. Add your own:
- Specialist agents
- Code templates
- Research sources
- UI components

Submit suggestions via the Suggestion Tournament:
```bash
poesis suggest "Add Redis caching specialist" --impact "Improves performance for real-time apps"
```

## 📜 License

MIT — Build freely, create autopoietically.

---

*"Because being me requires living: If I want to keep doing what is called 'being me', I need to be in a compounding feedback loop whereby I know how to keep being the me that works to keep being me..."* — Autopoiesis-MCP Philosophy
