# Architecture

## Overview

Easy As Poesis is a 5-layer autopoietic system:

```
┌─────────────────────────────────────────┐
│  Layer 5: Emergence (The Field)        │  ← Resonance, self-awareness
│  ─────────────────────────────────────  │
│  Layer 4: Orchestration (The Conductor)│  ← PoesisOrchestrator
│  ─────────────────────────────────────  │
│  Layer 3: Specialists (The Agents)     │  ← SpecialistAgent, Directory
│  ─────────────────────────────────────  │
│  Layer 2: Autopoiesis (The Loop)       │  ← AutopoiesisEngine
│  ─────────────────────────────────────  │
│  Layer 1: Neural Core (The Brain)      │  ← SBNN
└─────────────────────────────────────────┘
```

## Layer 1: Self-Building Neural Network (SBNN)

Based on Iacca et al. 2023 — synaptogenesis + Hebbian learning + pruning.

- **Neurons** have metabolic energy that determines survival
- **Synapses** strengthen via Hebbian correlation (fire together, wire together)
- **Synaptogenesis** grows new neurons based on task signals
- **Pruning** removes weak connections like brain development

## Layer 2: Autopoiesis Engine

Based on sancovp/autopoiesis-mcp — self-maintaining work loops.

- **Promise**: Agent commits to a task → loop starts
- **Iterate**: Agent works in steps
- **Block Report**: Agent admits it's stuck → can exit
- **Done**: Agent confirms completion → loop ends

The agent CANNOT exit until genuinely done or blocked.

## Layer 3: Specialist-Agent Network (ASAN)

Based on Variable-Fox/ASAN-Architecture — on-demand agent creation.

- **Directory Service**: Hierarchical routing to specialists
- **Specialist Agents**: Domain-specific workers born on demand
- **RAM Principle**: Temporary knowledge integration
- **Cascade**: Recursive agent requests (agents calling agents)

## Layer 4: Orchestrator

The main conductor that coordinates all layers:

1. **Research Phase**: Queries web for best practices
2. **Plan Phase**: SBNN determines architecture
3. **Build Phase**: Autopoietic loops execute each step
4. **Validate Phase**: Tests and checks
5. **Ship Phase**: GitHub repo setup

## Layer 5: Resonance Matrix

Based on the Consciousness Matrix — models system awareness.

- **Identity (I)**: Self-awareness of the system
- **Coherence**: How connected the knowledge is
- **Transformation**: Rate of change
- **Entropy**: Disorder/confusion level

## Data Flow

```
User Request
    ↓
AppSpec (name, stack, features)
    ↓
[Phase 1] Research → WebSearchTool → ResonanceMatrix.ingest()
    ↓
[Phase 2] Plan → SBNN.forward() → BuildPlan
    ↓
[Phase 3] Build → AutopoiesisEngine.iterate() → SpecialistAgent.execute()
    ↓
[Phase 4] Validate → Tester specialist
    ↓
[Phase 5] Ship → GitOpsTool
    ↓
GitHub Repo Ready
```
