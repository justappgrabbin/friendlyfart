# Autopoiesis Guide

## What is Autopoiesis?

Autopoiesis (from Greek: "auto" = self, "poiesis" = creation) means **self-creation**.

In this system, it means:
- The agent **creates itself** through work
- The agent **maintains itself** through loops
- The agent **cannot exit** until genuinely complete

## The Promise Loop

```
┌─────────────┐     promise      ┌─────────────┐
│   IDLE      │ ───────────────→ │  PROMISED   │
└─────────────┘                  └─────────────┘
                                      │
                                      │ iterate
                                      ↓
                                ┌─────────────┐
                                │  WORKING    │ ←───┐
                                └─────────────┘     │
                                      │             │
                    ┌─────────────────┼─────────────────┐
                    │                 │                 │
                    ↓                 ↓                 ↓
              ┌─────────┐      ┌─────────┐       ┌─────────┐
              │  DONE   │      │ BLOCKED │       │ iterate │
              └─────────┘      └─────────┘       └────┬────┘
                                                      │
                                                      └──────→ (back to WORKING)
```

## What "DONE" Means

✗ NOT "I made a file"  
✗ NOT "I completed my checklist"  
✗ NOT "I tried my best"  
✓ Production-ready. Deploy-and-forget quality.  
✓ Real-world working. If it's code, it's tested, documented, complete.  
✓ A human could ship this TODAY and never touch it again.

## What "BLOCKED" Means

✗ NOT "I'm tired of iterating"  
✗ NOT "This seems hard"  
✗ NOT "I want to exit"  
✓ "I need the user to set up Twitter because it costs money"  
✓ "I need credentials I don't have access to"  
✓ "The requirement is ambiguous and I need clarification"

## Using the CLI

### Start a build
```bash
poesis build my-app \
  --desc "A chat app with AI" \
  --stack react --stack fastapi --stack supabase \
  --feature auth --feature chat --feature ai-assistant
```

### Check status
```bash
poesis status
```

### Research a topic
```bash
poesis research "autopoietic neural networks"
```

### Run demo
```bash
poesis demo
```

## Writing Custom Specialists

```python
from poesis.core.specialist import SpecialistAgent, SpecialistConfig

my_specialist = SpecialistAgent(
    type="my_domain",
    config=SpecialistConfig(
        type="my_domain",
        system_prompt="You are a specialist in...",
        tools=["code_gen", "file_ops"]
    )
)
```

## Extending the System

### Add a new tool
```python
from poesis.orchestrator.agent import PoesisOrchestrator
orch = PoesisOrchestrator()
orch.tools["my_tool"] = MyTool()
```

### Add a new template
```python
from poesis.tools.code_gen import CodeGenTool
code_gen = CodeGenTool()
code_gen.add_template("my_template", "...jinja2 template...")
```
