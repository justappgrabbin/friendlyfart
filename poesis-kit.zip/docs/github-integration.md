# GitHub Integration Guide

## Overview

Easy As Poesis can automatically create GitHub repositories, push your code, and enable CI/CD workflows. This guide covers setup and usage.

## Prerequisites

### 1. Install GitHub CLI (gh)

**macOS:**
```bash
brew install gh
```

**Windows:**
```bash
winget install --id GitHub.cli
```

**Linux (Debian/Ubuntu):**
```bash
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh
```

**Linux (Fedora/CentOS/RHEL):**
```bash
sudo dnf install gh
```

**Verify installation:**
```bash
gh --version
```

### 2. Authenticate with GitHub

```bash
gh auth login
```

Follow the prompts:
1. **What account do you want to log into?** → GitHub.com
2. **What is your preferred protocol for Git operations on this host?** → HTTPS
3. **Authenticate Git with your GitHub credentials?** → Yes
4. **How would you like to authenticate?** → Paste an authentication token

**Get a token:**
1. Go to https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Select scopes: `repo`, `workflow`, `read:org`
4. Generate and copy the token
5. Paste it into the CLI prompt

**Verify authentication:**
```bash
gh auth status
```

## Usage

### Basic Build (No GitHub)

```bash
poesis build my-app \
  --desc "My awesome app" \
  --stack react --stack fastapi \
  --feature auth
```

This creates files locally in `./poesis-output/` but does NOT create a GitHub repo.

### Build + Create Public GitHub Repo

```bash
poesis build my-app \
  --desc "My awesome app" \
  --stack react --stack fastapi \
  --feature auth \
  --github-org yourusername \
  --create-repo
```

This:
1. Builds the app locally
2. Creates a public repo at `github.com/yourusername/my-app`
3. Pushes all code to the repo
4. Enables the autopoietic CI/CD workflow

### Build + Create Private GitHub Repo

```bash
poesis build my-app \
  --desc "My awesome app" \
  --stack react --stack fastapi \
  --feature auth \
  --github-org yourusername \
  --create-repo \
  --private
```

### Using Environment Variables

Set defaults so you don't need flags every time:

```bash
export GITHUB_ORG="yourusername"
export GITHUB_TOKEN="your-token-here"  # Optional: for API operations
```

Then build without flags:
```bash
poesis build my-app --desc "My app" --stack react --feature auth
```

## What Gets Created on GitHub

When you use `--create-repo`, the following happens:

1. **Repository created** with:
   - Name matching your app name
   - Description: "Built with Easy As Poesis — {app_name}"
   - Public or private based on `--private` flag

2. **Code pushed** to `main` branch with:
   - All generated files (README, code, tests, docs)
   - `.gitignore` configured
   - Initial commit: "feat: autopoietic build complete — Easy As Poesis"

3. **GitHub Actions workflow** enabled:
   - File: `.github/workflows/autopoiesis.yml`
   - Triggers: push to main, pull requests
   - Jobs: test (pytest), lint (ruff), type-check (mypy)
   - Matrix: Python 3.10, 3.11, 3.12

## Manual Push (if gh CLI not available)

If you can't install gh CLI, you can still push manually:

```bash
cd poesis-output

# 1. Create repo on GitHub.com manually
# 2. Add remote
git remote add origin https://github.com/yourusername/my-app.git

# 3. Push
git push -u origin main
```

## Troubleshooting

### "gh: command not found"
Install GitHub CLI first (see Prerequisites).

### "Not authenticated"
Run `gh auth login` and follow the prompts.

### "Repository already exists"
The repo name conflicts with an existing repo. Choose a different name or delete the existing repo.

### "Permission denied"
Your token doesn't have `repo` scope. Generate a new token at https://github.com/settings/tokens with `repo` and `workflow` scopes.

### "Could not resolve host"
Check your internet connection. GitHub CLI requires internet access.

## Advanced: Triggering Workflows

After pushing, you can trigger the CI workflow manually:

```bash
gh workflow run autopoiesis.yml --repo yourusername/my-app
```

Or via the Poesis orchestrator:

```python
from poesis.tools.git_ops import GitOpsTool

git = GitOpsTool()
git.trigger_workflow("yourusername/my-app", workflow="autopoiesis.yml")
```

## Security Notes

- Never commit your `GITHUB_TOKEN` to the repo
- Use GitHub Secrets for CI/CD (already configured in the workflow)
- The default `SECRET_KEY` in auth.py is a placeholder — change it in production
- The autopoietic workflow runs on GitHub's infrastructure, not your local machine
