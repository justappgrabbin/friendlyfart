# MRNN Orchestrator OS

## Magnetite Resonance Neural Network - Orchestrator Operating System

A unified-field symbolic neural architecture where five dimensions are operator projections on a shared computational field. Alive, goal-pursuing, success/failure-sensitive, self-correcting, and self-questioning at five levels.

### Architecture

**Core Principle:** The system is NOT composed of separate dimensions or stacked layers. There exists ONE unified computational field. The five dimensions are operator projections acting on the same shared node-field.

### Five Dimensions (Operator Projections)

| Dimension | Function | Question |
|-----------|----------|----------|
| **Being** | Node existence, persistence, embodiment | "Do I exist?" |
| **Design** | Graph topology, edge architecture | "Do I hold together?" |
| **Movement** | Activation propagation, coordinate orientation | "Do I flow?" |
| **Evolution** | Recursive memory gravity, attractor behavior | "Do I grow?" |
| **Space** | Observer-context projection, interpretation field | "Do I see clearly?" |

### Key Components

- **UnifiedField** - The core tensor. One computational field with 5 operator projections.
- **ResonanceNode** - Each node is a mini phase-space with 5 operator values, binary state, line state, tension, and attractor weight.
- **Monopole** - The attention router, trajectory stabilizer, attractor coordinator. The conductor.
- **FibonacciEngine** - Recurrence scheduling. The heartbeat: 1, 1, 2, 3, 5, 8, 13, 21...
- **AgentNode** - Personal translator for each user, born from Human Design Color/Tone/Base.
- **P2PMesh** - Swarm network. Every instance is a node in the same graph.

### Human Design Integration

The system is grounded in the Human Design variable system:

- **Color** (1-6) - Motivation/perception lens: FEAR, HOPE, DESIRE, NEED, GUILT, INNOCENCE
- **Tone** (1-6) - Cognitive environment: SECURITY, UNCERTAINTY, ACTION, MEDITATION, JUDGEMENT, ACCEPTANCE
- **Base** (1-5) - Dimensional anchor: INDIVIDUALITY, MIND, BODY, EGO, PERSONALITY

### Circuit Families & Neural Analogues

| Circuit | Architecture | Mode |
|---------|-------------|------|
| Understanding | DFF | Logical feedforward deduction |
| Sensing | DBN | Developmental belief formation |
| Knowing | LSM | Pulsed emergent mutation |
| Centering | Actor-Critic | Agency-action integration |
| Ego | Game Theory | Resource-social negotiation |

### Features

- **Fullscreen immersive visualization** - Void, Mandala, Tree, Hexagram, Neural, Hardware, Unified modes
- **Voice interaction** - Speak to the field, agent translates
- **File ingestion** - Drag & drop files to transform into field topology
- **Output manifestation** - Export code, images, music, worlds
- **Haptic feedback** - Vibration patterns from field state
- **Spatial audio** - Gate tones, channel timbres, crossing beats
- **P2P mesh** - Collaborate with other instances
- **Self-correction** - Five parallel loops monitor and repair the field
- **Emotional state** - Mood affects behavior: elation, pride, relief, pain, shame, fear, grief

### Usage

```javascript
const os = new OrchestratorOS({
  userProfile: {
    color: 3,    // DESIRE
    tone: 4,     // MEDITATION
    base: 2,     // MIND
    chart: null
  }
});

await os.init(document.getElementById('canvas'));
os.start();

// Speak to the field
os.processSpeech("I need to understand this code");

// Ingest a file
await os.ingestFile(file);

// Manifest output
os.manifest('code');

// Morph visualization
os.morphTo('mandala');
```

### File Structure

```
mrnn-os/
├── index.html              # Main entry point
├── css/
│   └── field.css           # Styling
├── js/
│   ├── core/
│   │   ├── UnifiedField.js      # Core tensor
│   │   ├── ResonanceNode.js     # Node model
│   │   ├── Monopole.js          # Router/conductor
│   │   └── FibonacciEngine.js   # Timing
│   ├── circuits/           # Circuit implementations
│   ├── adapters/           # Crossing adapters
│   ├── agents/
│   │   └── AgentNode.js         # Personal translator
│   ├── io/
│   │   ├── FileIngestor.js      # File absorption
│   │   ├── OutputManifestor.js  # Export generation
│   │   └── ChatInterface.js     # Voice/text chat
│   ├── mesh/
│   │   └── P2PMesh.js           # Swarm network
│   ├── loops/
│   │   ├── MoodState.js         # Emotional state
│   │   ├── BeingLoop.js         # Persistence
│   │   ├── DesignLoop.js        # Coherence
│   │   ├── MovementLoop.js      # Flow
│   │   ├── EvolutionLoop.js     # Growth
│   │   └── SpaceLoop.js         # Clarity
│   ├── render/
│   │   ├── FieldRenderer.js     # Canvas visualization
│   │   ├── SonicOutput.js       # Audio generation
│   │   └── HapticOutput.js      # Vibration patterns
│   └── main.js             # OrchestratorOS class
└── data/
    ├── gates.json          # 64 I Ching hexagrams
    ├── channels.json       # 36 Human Design channels
    ├── circuits.json       # Circuit families
    └── variables.json      # Color/Tone/Base lookup
```

### The Tick

The orchestrator's heartbeat. Not just a scheduler. A pulse. Every tick:

1. Self-question (5 levels)
2. Feel (mood update)
3. Plan (goal adjustment)
4. Act (execute corrections)
5. Learn (Hebbian/Anti-Hebbian)
6. Monopole routing
7. Sonic update
8. Haptic feedback
9. Changing line detection
10. Goal tracking

### License

MIT - Built for emergence.
