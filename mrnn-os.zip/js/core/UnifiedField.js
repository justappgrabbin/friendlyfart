/**
 * UnifiedField - The core tensor. One computational field.
 * Five dimensions are operator projections, not layers.
 */
class UnifiedField {
  constructor() {
    // Node storage
    this.nodes = new Map();

    // Edge storage (channel connections)
    this.edges = new Map();

    // Gate data (loaded from JSON)
    this.gatesData = null;
    this.channelsData = null;
    this.circuitsData = null;
    this.variablesData = null;

    // Circuit families
    this.circuits = {};
    this.channels = {};

    // Current form (visual mode)
    this.currentForm = 'void';

    // Routing state
    this.routingStale = true;
    this.shortestPaths = new Map();

    // Attractor basins
    this.attractors = new Map();

    // Memory graph
    this.memory = new Map();

    // Event callbacks
    this.onNodeAdd = null;
    this.onNodeRemove = null;
    this.onEdgeAdd = null;
    this.onEdgeRemove = null;
    this.onMorph = null;

    // Statistics
    this.stats = {
      nodeCount: 0,
      edgeCount: 0,
      activeNodes: 0,
      changingNodes: 0,
      lastUpdate: Date.now()
    };
  }

  /**
   * Load data files
   */
  async loadData() {
    const [gates, channels, circuits, variables] = await Promise.all([
      fetch('data/gates.json').then(r => r.json()),
      fetch('data/channels.json').then(r => r.json()),
      fetch('data/circuits.json').then(r => r.json()),
      fetch('data/variables.json').then(r => r.json())
    ]);

    this.gatesData = gates;
    this.channelsData = channels;
    this.circuitsData = circuits;
    this.variablesData = variables;

    // Build circuit and channel maps
    this.circuits = circuits.circuits;
    for (const ch of channels.channels) {
      this.channels[ch.id] = ch;
    }

    return this;
  }

  /**
   * Create a node in the field
   */
  createNode(id, options = {}) {
    const node = new ResonanceNode(id, options);
    this.nodes.set(id, node);
    this.stats.nodeCount++;

    if (this.onNodeAdd) {
      this.onNodeAdd(node);
    }

    return node;
  }

  /**
   * Remove a node
   */
  removeNode(id) {
    const node = this.nodes.get(id);
    if (!node) return false;

    // Remove connected edges
    for (const edgeId of [...node.connections]) {
      this.removeEdge(edgeId);
    }

    this.nodes.delete(id);
    this.stats.nodeCount--;

    if (this.onNodeRemove) {
      this.onNodeRemove(node);
    }

    this.routingStale = true;
    return true;
  }

  /**
   * Get a node by ID
   */
  getNode(id) {
    return this.nodes.get(id);
  }

  /**
   * Get all nodes
   */
  getAllNodes() {
    return Array.from(this.nodes.values());
  }

  /**
   * Create an edge (channel connection)
   */
  createEdge(id, sourceId, targetId, channelId, options = {}) {
    const source = this.nodes.get(sourceId);
    const target = this.nodes.get(targetId);

    if (!source || !target) {
      throw new Error('Source or target node not found');
    }

    const channel = this.channels[channelId];
    const edge = {
      id,
      sourceId,
      targetId,
      channelId,
      channelMode: channel?.neural_analogue || 'DFF',
      circuit: channel?.circuit || 'Understanding',
      weight: options.weight ?? 1.0,
      active: options.active ?? false,
      createdAt: Date.now(),
      lastActivated: null,
      activationCount: 0,
      crossing: options.crossing ?? false,
      adapter: options.adapter ?? null
    };

    this.edges.set(id, edge);
    source.connections.push(id);
    target.connections.push(id);
    this.stats.edgeCount++;
    this.routingStale = true;

    if (this.onEdgeAdd) {
      this.onEdgeAdd(edge);
    }

    return edge;
  }

  /**
   * Remove an edge
   */
  removeEdge(id) {
    const edge = this.edges.get(id);
    if (!edge) return false;

    const source = this.nodes.get(edge.sourceId);
    const target = this.nodes.get(edge.targetId);

    if (source) {
      source.connections = source.connections.filter(cid => cid !== id);
    }
    if (target) {
      target.connections = target.connections.filter(cid => cid !== id);
    }

    this.edges.delete(id);
    this.stats.edgeCount--;
    this.routingStale = true;

    if (this.onEdgeRemove) {
      this.onEdgeRemove(edge);
    }

    return true;
  }

  /**
   * Get an edge
   */
  getEdge(id) {
    return this.edges.get(id);
  }

  /**
   * Get all edges
   */
  getAllEdges() {
    return Array.from(this.edges.values());
  }

  /**
   * Get edges connected to a node
   */
  getNodeEdges(nodeId) {
    const node = this.nodes.get(nodeId);
    if (!node) return [];

    return node.connections.map(edgeId => this.edges.get(edgeId)).filter(Boolean);
  }

  /**
   * Find path between nodes (Dijkstra with custom weights)
   */
  findPath(sourceId, targetId, options = {}) {
    if (this.routingStale) {
      this.rebuildRouting();
    }

    const weightFn = options.weightFunction || ((edge) => edge.weight);

    // Dijkstra
    const distances = new Map();
    const previous = new Map();
    const unvisited = new Set();

    for (const [id] of this.nodes) {
      distances.set(id, id === sourceId ? 0 : Infinity);
      unvisited.add(id);
    }

    while (unvisited.size > 0) {
      let current = null;
      let minDist = Infinity;

      for (const id of unvisited) {
        if (distances.get(id) < minDist) {
          minDist = distances.get(id);
          current = id;
        }
      }

      if (current === null || minDist === Infinity) break;
      if (current === targetId) break;

      unvisited.delete(current);

      const edges = this.getNodeEdges(current);
      for (const edge of edges) {
        const neighbor = edge.sourceId === current ? edge.targetId : edge.sourceId;
        if (!unvisited.has(neighbor)) continue;

        const weight = weightFn(edge);
        const alt = distances.get(current) + weight;

        if (alt < distances.get(neighbor)) {
          distances.set(neighbor, alt);
          previous.set(neighbor, { node: current, edge });
        }
      }
    }

    // Reconstruct path
    if (!previous.has(targetId)) {
      return null;
    }

    const path = [];
    const edgePath = [];
    let current = targetId;

    while (current !== sourceId) {
      const prev = previous.get(current);
      path.unshift(current);
      edgePath.unshift(prev.edge);
      current = prev.node;
    }
    path.unshift(sourceId);

    return {
      nodes: path,
      edges: edgePath,
      distance: distances.get(targetId)
    };
  }

  /**
   * Rebuild routing tables
   */
  rebuildRouting() {
    this.shortestPaths.clear();
    this.routingStale = false;
    return this;
  }

  /**
   * Propagate activation through the field
   */
  propagate(sourceId, strength = 1.0, depth = 3) {
    const visited = new Set();
    const queue = [{ nodeId: sourceId, strength, depth }];
    const activations = [];

    while (queue.length > 0) {
      const { nodeId, strength: s, depth: d } = queue.shift();

      if (visited.has(nodeId) || d <= 0 || s < 0.01) continue;
      visited.add(nodeId);

      const node = this.nodes.get(nodeId);
      if (!node) continue;

      node.activate(s);
      activations.push({ nodeId, strength: s, depth: d });

      const edges = this.getNodeEdges(nodeId);
      for (const edge of edges) {
        const neighbor = edge.sourceId === nodeId ? edge.targetId : edge.sourceId;
        const weight = edge.weight;
        const damping = 0.7;
        const newStrength = s * weight * damping;

        queue.push({ nodeId: neighbor, strength: newStrength, depth: d - 1 });
      }
    }

    return activations;
  }

  /**
   * Create a crossing between two incompatible channels
   */
  createCrossing(nodeA, channelA, nodeB, channelB) {
    const adapterId = `adapter_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Create adapter node
    const adapter = this.createNode(adapterId, {
      being: (nodeA.being + nodeB.being) / 2,
      design: (nodeA.design + nodeB.design) / 2,
      movement: (nodeA.movement + nodeB.movement) / 2,
      evolution: (nodeA.evolution + nodeB.evolution) / 2,
      space: (nodeA.space + nodeB.space) / 2,
      channelMode: 'Adapter',
      regime: 'changing',
      tension: 0.5
    });

    // Create edges to adapter
    const edgeA = this.createEdge(
      `${adapterId}_a`,
      nodeA.id,
      adapterId,
      'crossing',
      { crossing: true, adapter: true, weight: 0.5 }
    );

    const edgeB = this.createEdge(
      `${adapterId}_b`,
      nodeB.id,
      adapterId,
      'crossing',
      { crossing: true, adapter: true, weight: 0.5 }
    );

    return {
      adapter,
      edges: [edgeA, edgeB],
      nodeA,
      nodeB,
      channelA,
      channelB
    };
  }

  /**
   * Morph the field to a new form
   */
  morph(targetForm, duration = 1618) {
    const morphData = {
      from: this.currentForm,
      to: targetForm,
      duration,
      timestamp: Date.now()
    };

    this.currentForm = targetForm;

    if (this.onMorph) {
      this.onMorph(morphData);
    }

    return morphData;
  }

  /**
   * Get comprehensive field state
   */
  getState() {
    const nodes = this.getAllNodes();
    const edges = this.getAllEdges();

    // Group nodes by center
    const nodesByCenter = {};
    for (const node of nodes) {
      // Infer center from gate
      const gate = this.gatesData?.gates.find(g => g.number === node.gate);
      const center = gate ? this.inferCenterFromGate(node.gate) : 'Unknown';
      if (!nodesByCenter[center]) nodesByCenter[center] = [];
      nodesByCenter[center].push(node.id);
    }

    // Count active edges per channel
    const activeEdges = {};
    for (const edge of edges) {
      if (edge.active) {
        activeEdges[edge.channelId] = (activeEdges[edge.channelId] || 0) + 1;
      }
    }

    // Changing nodes
    const changingNodes = nodes.filter(n => n.regime === 'changing');

    this.stats = {
      nodeCount: nodes.length,
      edgeCount: edges.length,
      activeNodes: nodes.filter(n => n.binaryState === 1).length,
      changingNodes: changingNodes.length,
      lastUpdate: Date.now()
    };

    return {
      ...this.stats,
      nodesByCenter,
      activeEdges,
      changingNodes: changingNodes.map(n => n.id),
      currentForm: this.currentForm,
      coherence: this.calculateCoherence()
    };
  }

  /**
   * Infer Human Design center from gate number
   */
  inferCenterFromGate(gateNum) {
    // Simplified mapping - in reality this is more complex
    const centerMap = {
      'Head': [64, 47, 61, 24, 43, 23],
      'Ajna': [63, 4, 17, 62, 18, 58, 48, 16, 11, 56],
      'Throat': [31, 7, 33, 13, 14, 1, 8, 12, 22, 35, 36, 45, 21],
      'G': [1, 8, 14, 2, 15, 46, 25, 51, 10, 34],
      'Heart': [21, 45, 26, 44, 51, 25],
      'Spleen': [57, 20, 10, 34, 44, 26, 50, 27, 18, 58, 48, 16],
      'Sacral': [5, 15, 29, 46, 59, 6, 42, 3, 9, 52, 53, 60, 27, 50],
      'Solar': [55, 39, 30, 41, 36, 35, 22, 12, 37, 40, 49, 4, 63],
      'Root': [58, 18, 48, 16, 38, 28, 54, 32, 19, 41, 39, 55, 60, 3, 9, 52]
    };

    for (const [center, gates] of Object.entries(centerMap)) {
      if (gates.includes(gateNum)) return center;
    }
    return 'Unknown';
  }

  /**
   * Calculate field coherence
   */
  calculateCoherence() {
    const nodes = this.getAllNodes();
    if (nodes.length === 0) return 1.0;

    let totalCoherence = 0;
    for (const node of nodes) {
      const vec = node.getOperatorVector();
      const mean = vec.reduce((a, b) => a + b, 0) / vec.length;
      const variance = vec.reduce((sum, val) => sum + (val - mean) ** 2, 0) / vec.length;
      totalCoherence += 1 - Math.sqrt(variance);
    }

    return totalCoherence / nodes.length;
  }

  /**
   * Serialize entire field
   */
  serialize() {
    return {
      nodes: this.getAllNodes().map(n => n.serialize()),
      edges: this.getAllEdges(),
      currentForm: this.currentForm,
      stats: this.stats
    };
  }

  /**
   * Deserialize field
   */
  static deserialize(data) {
    const field = new UnifiedField();

    for (const nodeData of data.nodes) {
      field.createNode(nodeData.id, nodeData);
    }

    for (const edgeData of data.edges) {
      field.createEdge(
        edgeData.id,
        edgeData.sourceId,
        edgeData.targetId,
        edgeData.channelId,
        edgeData
      );
    }

    field.currentForm = data.currentForm;
    field.stats = data.stats;

    return field;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = UnifiedField;
}
