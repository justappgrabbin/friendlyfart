/**
 * FibonacciEngine - Recurrence scheduling and timing control.
 * The heartbeat of the field.
 */
class FibonacciEngine {
  constructor() {
    this.sequence = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89];
    this.phase = 0;
    this.tickCount = 0;
    this.lastTickTime = Date.now();
    this.tickInterval = 1000; // base ms per tick

    // Event callbacks
    this.onTick = null;
    this.onPhaseChange = null;
    this.onDeepRecursion = null;

    // Running state
    this.running = false;
    this.tickTimer = null;
  }

  /**
   * Get current Fibonacci value
   */
  get currentValue() {
    return this.sequence[this.phase];
  }

  /**
   * Get current resonance frequency (Hz)
   */
  get resonanceFrequency() {
    // Map Fibonacci to frequency: 1->1Hz, 1->1Hz, 2->2Hz, 3->3Hz, 5->5Hz, 8->8Hz, 13->13Hz, 21->21Hz
    return this.currentValue;
  }

  /**
   * Get current phase name
   */
  get phaseName() {
    const names = ['Pulse', 'Pulse', 'Consolidate', 'Pattern', 'Deepen', 'Dream', 'Oracle', 'Mystery', 'Eternity', 'Void'];
    return names[this.phase] || 'Unknown';
  }

  /**
   * Advance to next Fibonacci phase
   */
  advance() {
    const oldPhase = this.phase;
    this.phase = (this.phase + 1) % this.sequence.length;

    if (this.onPhaseChange) {
      this.onPhaseChange({
        oldPhase,
        newPhase: this.phase,
        oldValue: this.sequence[oldPhase],
        newValue: this.currentValue,
        phaseName: this.phaseName
      });
    }

    // Deep recursion trigger at phase 6+
    if (this.phase >= 6 && this.onDeepRecursion) {
      this.onDeepRecursion({
        phase: this.phase,
        value: this.currentValue,
        phaseName: this.phaseName
      });
    }

    return this.currentValue;
  }

  /**
   * The TICK - the heartbeat
   */
  tick() {
    this.tickCount++;
    const now = Date.now();
    const delta = now - this.lastTickTime;
    this.lastTickTime = now;

    // Every N ticks (where N = current Fibonacci value), advance phase
    if (this.tickCount % this.currentValue === 0) {
      this.advance();
    }

    const tickData = {
      tickCount: this.tickCount,
      phase: this.phase,
      fibonacciValue: this.currentValue,
      phaseName: this.phaseName,
      resonanceFrequency: this.resonanceFrequency,
      delta: delta,
      timestamp: now
    };

    if (this.onTick) {
      this.onTick(tickData);
    }

    return tickData;
  }

  /**
   * Start the engine
   */
  start() {
    if (this.running) return;
    this.running = true;

    const loop = () => {
      if (!this.running) return;
      this.tick();
      this.tickTimer = setTimeout(loop, this.tickInterval);
    };

    loop();
    return this;
  }

  /**
   * Stop the engine
   */
  stop() {
    this.running = false;
    if (this.tickTimer) {
      clearTimeout(this.tickTimer);
      this.tickTimer = null;
    }
    return this;
  }

  /**
   * Set tick speed
   */
  setSpeed(intervalMs) {
    this.tickInterval = intervalMs;
    return this;
  }

  /**
   * Get timing for a specific recursion depth
   */
  getTimingForDepth(depth) {
    // Map depth to Fibonacci phase
    const clampedDepth = Math.min(depth, this.sequence.length - 1);
    return {
      phase: clampedDepth,
      value: this.sequence[clampedDepth],
      frequency: this.sequence[clampedDepth],
      interval: this.tickInterval * this.sequence[clampedDepth]
    };
  }

  /**
   * Calculate next revisit time for a memory node
   */
  scheduleRevisit(attractorWeight) {
    // Higher attractor weight = sooner revisit
    // Map weight (0-1) to Fibonacci index (0-10)
    const index = Math.floor((1 - attractorWeight) * (this.sequence.length - 1));
    const fibValue = this.sequence[Math.max(0, Math.min(index, this.sequence.length - 1))];

    return {
      ticksUntilRevisit: fibValue,
      phaseAtRevisit: (this.phase + fibValue) % this.sequence.length,
      attractorWeight: attractorWeight
    };
  }

  /**
   * Get the golden ratio approximation from consecutive Fibonacci numbers
   */
  getGoldenRatio() {
    const idx = Math.min(this.phase + 1, this.sequence.length - 1);
    return this.sequence[idx] / this.sequence[this.phase];
  }

  /**
   * Serialize state
   */
  serialize() {
    return {
      phase: this.phase,
      tickCount: this.tickCount,
      tickInterval: this.tickInterval,
      running: this.running
    };
  }

  /**
   * Deserialize state
   */
  static deserialize(data) {
    const engine = new FibonacciEngine();
    engine.phase = data.phase;
    engine.tickCount = data.tickCount;
    engine.tickInterval = data.tickInterval;
    return engine;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FibonacciEngine;
}
