/**
 * ResonanceNode - The fundamental unit of the MRNN field.
 * Each node is a mini phase-space with 5 operator projections.
 */
class ResonanceNode {
  constructor(id, options = {}) {
    this.id = id;

    // Five operator projections (0-1 normalized)
    this.being = options.being ?? Math.random();
    this.design = options.design ?? Math.random();
    this.movement = options.movement ?? Math.random();
    this.evolution = options.evolution ?? Math.random();
    this.space = options.space ?? Math.random();

    // Fuxi binary state
    this.binaryState = options.binaryState ?? (Math.random() > 0.5 ? 1 : 0);

    // Line state (1-6) - internal state-space dimension
    this.line = options.line ?? Math.floor(Math.random() * 6) + 1;

    // Regime: stable or changing (metastable)
    this.regime = options.regime ?? 'stable';

    // Gate assignment (1-64)
    this.gate = options.gate ?? Math.floor(Math.random() * 64) + 1;

    // Activation history for recurrence
    this.activationHistory = options.activationHistory ?? [];

    // Attractor weight - memory gravity
    this.attractorWeight = options.attractorWeight ?? Math.random();

    // Recursion depth
    this.recursionDepth = options.recursionDepth ?? 0;

    // Tension level (0-1) - proximity to changing line
    this.tension = options.tension ?? 0;

    // Channel mode - processing style
    this.channelMode = options.channelMode ?? 'DFF';

    // Observer context - perspective-relative
    this.observerContext = options.observerContext ?? {};

    // Position in field (3D coordinates)
    this.x = options.x ?? 0;
    this.y = options.y ?? 0;
    this.z = options.z ?? 0;

    // Velocity (for movement dynamics)
    this.vx = options.vx ?? 0;
    this.vy = options.vy ?? 0;
    this.vz = options.vz ?? 0;

    // Visual properties
    this.radius = options.radius ?? 5;
    this.color = options.color ?? '#ffffff';
    this.glowIntensity = options.glowIntensity ?? 0.5;
    this.pulsePhase = options.pulsePhase ?? Math.random() * Math.PI * 2;

    // Connections (edge IDs)
    this.connections = options.connections ?? [];

    // Timestamp
    this.createdAt = options.createdAt ?? Date.now();
    this.lastActivated = options.lastActivated ?? Date.now();
  }

  /**
   * Get the 5 operator values as a vector
   */
  getOperatorVector() {
    return [this.being, this.design, this.movement, this.evolution, this.space];
  }

  /**
   * Set operator values from a vector
   */
  setOperatorVector(vec) {
    [this.being, this.design, this.movement, this.evolution, this.space] = vec;
  }

  /**
   * Calculate distance to another node in operator space
   */
  operatorDistance(other) {
    const v1 = this.getOperatorVector();
    const v2 = other.getOperatorVector();
    return Math.sqrt(v1.reduce((sum, val, i) => sum + (val - v2[i]) ** 2, 0));
  }

  /**
   * Calculate Euclidean distance in spatial coordinates
   */
  spatialDistance(other) {
    return Math.sqrt(
      (this.x - other.x) ** 2 +
      (this.y - other.y) ** 2 +
      (this.z - other.z) ** 2
    );
  }

  /**
   * Activate the node - add to history, increase attractor weight
   */
  activate(strength = 1.0) {
    this.binaryState = 1;
    this.activationHistory.push({
      timestamp: Date.now(),
      strength: strength,
      line: this.line
    });

    // Trim history to prevent unbounded growth
    if (this.activationHistory.length > 1000) {
      this.activationHistory = this.activationHistory.slice(-500);
    }

    this.attractorWeight = Math.min(1.0, this.attractorWeight + strength * 0.01);
    this.lastActivated = Date.now();
    this.glowIntensity = Math.min(1.0, this.glowIntensity + strength * 0.1);

    return this;
  }

  /**
   * Deactivate the node
   */
  deactivate() {
    this.binaryState = 0;
    this.glowIntensity *= 0.95;
    return this;
  }

  /**
   * Increase tension - approaching metastability
   */
  increaseTension(amount = 0.1) {
    this.tension = Math.min(1.0, this.tension + amount);

    if (this.tension > 0.8 && this.regime === 'stable') {
      this.regime = 'changing';
    }

    return this.tension;
  }

  /**
   * Decrease tension - stabilizing
   */
  decreaseTension(amount = 0.1) {
    this.tension = Math.max(0, this.tension - amount);

    if (this.tension < 0.2 && this.regime === 'changing') {
      this.regime = 'stable';
    }

    return this.tension;
  }

  /**
   * Change line - metastable transition
   */
  changeLine(newLine) {
    if (newLine < 1 || newLine > 6) {
      throw new Error('Line must be 1-6');
    }

    const oldLine = this.line;
    this.line = newLine;
    this.tension = 0;
    this.regime = 'stable';

    // Changing a line may change the hexagram
    this.recursionDepth++;

    return { oldLine, newLine, gate: this.gate };
  }

  /**
   * Update position with velocity
   */
  updatePosition(dt = 1) {
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.z += this.vz * dt;

    // Damping
    this.vx *= 0.98;
    this.vy *= 0.98;
    this.vz *= 0.98;

    return this;
  }

  /**
   * Apply force (affects velocity)
   */
  applyForce(fx, fy, fz) {
    this.vx += fx;
    this.vy += fy;
    this.vz += fz;
    return this;
  }

  /**
   * Get the hexagram for this node's gate
   */
  getHexagram(gatesData) {
    return gatesData.gates.find(g => g.number === this.gate);
  }

  /**
   * Get the line judgment for this node's current line
   */
  getLineJudgment(gatesData) {
    const hex = this.getHexagram(gatesData);
    return hex ? hex.lines[this.line - 1] : null;
  }

  /**
   * Serialize to plain object
   */
  serialize() {
    return {
      id: this.id,
      being: this.being,
      design: this.design,
      movement: this.movement,
      evolution: this.evolution,
      space: this.space,
      binaryState: this.binaryState,
      line: this.line,
      regime: this.regime,
      gate: this.gate,
      activationHistory: this.activationHistory,
      attractorWeight: this.attractorWeight,
      recursionDepth: this.recursionDepth,
      tension: this.tension,
      channelMode: this.channelMode,
      x: this.x,
      y: this.y,
      z: this.z,
      radius: this.radius,
      color: this.color,
      connections: this.connections,
      createdAt: this.createdAt,
      lastActivated: this.lastActivated
    };
  }

  /**
   * Deserialize from plain object
   */
  static deserialize(data) {
    return new ResonanceNode(data.id, data);
  }
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ResonanceNode;
}
