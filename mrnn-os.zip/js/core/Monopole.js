/**
 * Monopole - The attention router, trajectory stabilizer, attractor coordinator.
 * The conductor of the field. The heartbeat made conscious.
 */
class Monopole {
  constructor(field, fibonacciEngine) {
    this.field = field;
    this.fibonacci = fibonacciEngine;

    // Current position (which center the Monopole inhabits)
    this.position = 'G'; // Default to G-center (Space/Integration)

    // Attention focus (which node is being attended to)
    this.focusNodeId = null;

    // Routing weights for each channel type
    this.channelWeights = {
      'DFF': 1.0,
      'DBN': 1.0,
      'LSM': 1.0,
      'ActorCritic': 1.0,
      'GameTheory': 1.0,
      'RBM': 1.0,
      'Hopfield': 1.0,
      'SparseAutoencoder': 1.0,
      'ELM': 1.0,
      'Kohonen': 1.0,
      'CNN': 1.0,
      'RNN': 1.0,
      'LSTM': 1.0,
      'Seq2Seq': 1.0,
      'Autoencoder': 1.0,
      'Transformer': 1.0,
      'GenerativeLM': 1.0,
      'ReinforcementLearner': 1.0,
      'EpisodicMemory': 1.0,
      'LiquidStateMachine': 1.0,
      'NeuralTuringMachine': 1.0,
      'DeconvNet': 1.0,
      'GAN': 1.0,
      'EchoStateNetwork': 1.0,
      'GRU': 1.0,
      'VAE': 1.0,
      'RBF': 1.0,
      'Attention': 1.0,
      'SpikeNetwork': 1.0,
      'DirectPolicy': 1.0,
      'MotorPolicy': 1.0,
      'Sensorimotor': 1.0,
      'AdaptiveControl': 1.0,
      'ResourceAllocation': 1.0,
      'MemoryPrediction': 1.0,
      'EvolutionaryOptimizer': 1.0,
      'BoundaryCrossing': 1.0,
      'CaretakingRegulator': 1.0
    };

    // Active circuit family
    this.activeCircuit = null;

    // Decision history
    this.decisionHistory = [];

    // Coherence regulator
    this.coherenceTarget = 0.8;
    this.currentCoherence = 1.0;

    // Event callbacks
    this.onRoute = null;
    this.onDecision = null;
    this.onMorph = null;
  }

  /**
   * Map base to center position
   */
  baseToCenter(base) {
    const map = {
      1: 'Sacral',      // MOVEMENT
      2: 'Ajna',        // EVOLUTION
      3: 'Root',        // BEING
      4: 'Heart',       // DESIGN
      5: 'G'            // SPACE
    };
    return map[base] || 'G';
  }

  /**
   * Move the Monopole to a center
   */
  moveToCenter(center) {
    const oldCenter = this.position;
    this.position = center;

    // When Monopole moves, it changes which channels are shortest path
    this.recalculateRouting();

    return { oldCenter, newCenter: center };
  }

  /**
   * Set focus on a specific node
   */
  setFocus(nodeId) {
    const oldFocus = this.focusNodeId;
    this.focusNodeId = nodeId;

    // Increase attractor weight of focused node
    const node = this.field.getNode(nodeId);
    if (node) {
      node.attractorWeight = Math.min(1.0, node.attractorWeight + 0.1);
    }

    return { oldFocus, newFocus: nodeId };
  }

  /**
   * Select circuit family based on field gravity
   */
  selectCircuit(fieldState) {
    // Calculate gravity for each circuit
    const gravities = {};
    for (const [name, circuit] of Object.entries(this.field.circuits)) {
      gravities[name] = this.calculateCircuitGravity(circuit, fieldState);
    }

    // Select highest gravity
    const selected = Object.entries(gravities)
      .sort((a, b) => b[1] - a[1])[0];

    this.activeCircuit = selected[0];

    // Adjust channel weights based on selected circuit
    this.adjustWeightsForCircuit(this.activeCircuit);

    if (this.onRoute) {
      this.onRoute({
        circuit: this.activeCircuit,
        gravity: selected[1],
        allGravities: gravities
      });
    }

    return this.activeCircuit;
  }

  /**
   * Calculate gravity of a circuit
   */
  calculateCircuitGravity(circuit, fieldState) {
    let gravity = 0;

    // Sum attractor weights of nodes in circuit's centers
    for (const center of circuit.centers) {
      const centerNodes = fieldState.nodesByCenter?.[center] || [];
      for (const nodeId of centerNodes) {
        const node = this.field.getNode(nodeId);
        if (node) {
          gravity += node.attractorWeight * node.being;
        }
      }
    }

    // Factor in active edges
    for (const channelId of circuit.channels) {
      const edges = fieldState.activeEdges?.[channelId] || 0;
      gravity += edges * 0.1;
    }

    // Factor in user intent (if available)
    if (fieldState.userIntent) {
      const intentMatch = this.matchIntentToCircuit(fieldState.userIntent, circuit);
      gravity *= (1 + intentMatch);
    }

    return gravity;
  }

  /**
   * Match user intent to circuit
   */
  matchIntentToCircuit(intent, circuit) {
    const keywords = {
      'Understanding': ['logic', 'reason', 'analyze', 'understand', 'think', 'know', 'truth'],
      'Sensing': ['feel', 'experience', 'sense', 'body', 'intuition', 'gut', 'instinct'],
      'Knowing': ['create', 'invent', 'discover', 'breakthrough', 'insight', 'vision', 'mystery'],
      'Centering': ['integrate', 'balance', 'center', 'align', 'harmony', 'whole', 'complete'],
      'Ego': ['defend', 'protect', 'boundaries', 'resources', 'control', 'power', 'will']
    };

    const intentLower = intent.toLowerCase();
    const matches = keywords[circuit.inductive_bias.split('_')[0]] || [];
    let score = 0;

    for (const keyword of matches) {
      if (intentLower.includes(keyword)) {
        score += 0.2;
      }
    }

    return Math.min(1.0, score);
  }

  /**
   * Adjust channel weights for selected circuit
   */
  adjustWeightsForCircuit(circuitName) {
    const circuit = this.field.circuits[circuitName];
    if (!circuit) return;

    // Increase weights for channels in selected circuit
    for (const channelId of circuit.channels) {
      const channel = this.field.channels[channelId];
      if (channel) {
        this.channelWeights[channel.neural_analogue] = 1.5;
      }
    }

    // Decrease weights for other channels
    for (const [id, channel] of Object.entries(this.field.channels)) {
      if (!circuit.channels.includes(id)) {
        this.channelWeights[channel.neural_analogue] = 0.7;
      }
    }
  }

  /**
   * Route activation through the field
   */
  route(sourceNodeId, targetNodeId, signalStrength = 1.0) {
    const source = this.field.getNode(sourceNodeId);
    const target = this.field.getNode(targetNodeId);

    if (!source || !target) {
      return { success: false, reason: 'Node not found' };
    }

    // Find path
    const path = this.field.findPath(sourceNodeId, targetNodeId, {
      weightFunction: (edge) => this.channelWeights[edge.channelMode] || 1.0
    });

    if (!path) {
      return { success: false, reason: 'No path found' };
    }

    // Propagate signal
    let currentStrength = signalStrength;
    for (const edge of path.edges) {
      const weight = this.channelWeights[edge.channelMode] || 1.0;
      currentStrength *= weight * 0.9; // Damping

      if (currentStrength < 0.01) {
        return { success: false, reason: 'Signal decayed', path, finalStrength: currentStrength };
      }
    }

    // Activate target
    target.activate(currentStrength);

    const result = {
      success: true,
      path: path,
      initialStrength: signalStrength,
      finalStrength: currentStrength,
      edgesTraversed: path.edges.length,
      circuitUsed: this.activeCircuit
    };

    this.decisionHistory.push({
      timestamp: Date.now(),
      type: 'route',
      result: result
    });

    if (this.onDecision) {
      this.onDecision(result);
    }

    return result;
  }

  /**
   * Trigger morphing of the field
   */
  triggerMorph(targetForm, reason = 'user_request') {
    const morphData = {
      timestamp: Date.now(),
      fromForm: this.field.currentForm,
      toForm: targetForm,
      reason: reason,
      fibonacciPhase: this.fibonacci.phase,
      monopolePosition: this.position
    };

    if (this.onMorph) {
      this.onMorph(morphData);
    }

    return morphData;
  }

  /**
   * Regulate field coherence
   */
  regulateCoherence() {
    const nodes = this.field.getAllNodes();
    let totalCoherence = 0;

    for (const node of nodes) {
      // Coherence = alignment of 5 operators
      const vec = node.getOperatorVector();
      const mean = vec.reduce((a, b) => a + b, 0) / vec.length;
      const variance = vec.reduce((sum, val) => sum + (val - mean) ** 2, 0) / vec.length;
      const coherence = 1 - Math.sqrt(variance);
      totalCoherence += coherence;

      // Adjust node to increase coherence if needed
      if (coherence < this.coherenceTarget) {
        const adjustment = (this.coherenceTarget - coherence) * 0.1;
        for (let i = 0; i < vec.length; i++) {
          vec[i] += (mean - vec[i]) * adjustment;
        }
        node.setOperatorVector(vec);
      }
    }

    this.currentCoherence = totalCoherence / nodes.length;
    return this.currentCoherence;
  }

  /**
   * Recalculate all routing tables
   */
  recalculateRouting() {
    // This would trigger a full graph reanalysis
    // For now, just mark that routing needs refresh
    this.field.routingStale = true;
    return this;
  }

  /**
   * The TICK - heartbeat action
   */
  tick(tickData) {
    // Regulate coherence
    this.regulateCoherence();

    // Select circuit based on current field state
    const fieldState = this.field.getState();
    this.selectCircuit(fieldState);

    // Move Monopole if needed based on active circuit
    const targetCenter = this.circuitToCenter(this.activeCircuit);
    if (targetCenter !== this.position) {
      this.moveToCenter(targetCenter);
    }

    // Check for changing lines
    this.detectChangingLines();

    return {
      monopolePosition: this.position,
      activeCircuit: this.activeCircuit,
      coherence: this.currentCoherence,
      focusNode: this.focusNodeId,
      fibonacciPhase: tickData.phase
    };
  }

  /**
   * Map circuit to center
   */
  circuitToCenter(circuit) {
    const map = {
      'Understanding': 'Ajna',
      'Sensing': 'Sacral',
      'Knowing': 'Head',
      'Centering': 'G',
      'Ego': 'Heart'
    };
    return map[circuit] || 'G';
  }

  /**
   * Detect nodes approaching changing line
   */
  detectChangingLines() {
    const changing = [];
    for (const node of this.field.getAllNodes()) {
      if (node.tension > 0.8) {
        changing.push({
          nodeId: node.id,
          tension: node.tension,
          gate: node.gate,
          line: node.line,
          regime: node.regime
        });
      }
    }
    return changing;
  }

  /**
   * Get current state
   */
  getState() {
    return {
      position: this.position,
      focusNodeId: this.focusNodeId,
      activeCircuit: this.activeCircuit,
      channelWeights: { ...this.channelWeights },
      coherence: this.currentCoherence,
      decisionCount: this.decisionHistory.length
    };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = Monopole;
}
