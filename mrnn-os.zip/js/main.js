/**
 * OrchestratorOS - The complete MRNN operating system.
 * Alive, goal-pursuing, success/failure-sensitive, self-correcting,
 * self-questioning at five levels, interactive, ingest/manifest.
 */
class OrchestratorOS {
  constructor(options = {}) {
    // Core components
    this.field = new UnifiedField();
    this.fibonacci = new FibonacciEngine();
    this.monopole = null; // Initialized after field loads

    // Five correction loops
    this.beingLoop = new BeingLoop(this.field);
    this.designLoop = new DesignLoop(this.field);
    this.movementLoop = new MovementLoop(this.field);
    this.evolutionLoop = new EvolutionLoop(this.field);
    this.spaceLoop = new SpaceLoop(this.field);

    // Emotional state
    this.mood = new MoodState();

    // Agent (user translator)
    this.agent = null;

    // IO
    this.ingestor = new FileIngestor(this.field);
    this.manifestor = new OutputManifestor(this.field);
    this.chat = null;

    // Rendering
    this.renderer = null;
    this.sonic = new SonicOutput();
    this.haptic = new HapticOutput();

    // Mesh
    this.mesh = new P2PMesh(this.field);

    // User profile
    this.userProfile = options.userProfile || {
      color: 3,
      tone: 4,
      base: 2,
      chart: null
    };

    // Goals
    this.goals = {
      being: { target: 100, current: 0, weight: 1.0 },
      design: { target: 0.7, current: 0, weight: 1.0 },
      movement: { target: 0.1, current: 0, weight: 1.0 },
      evolution: { target: 5, current: 0, weight: 1.0 },
      space: { target: 0.7, current: 0, weight: 1.0 }
    };

    // State
    this.initialized = false;
    this.running = false;
    this.tickCount = 0;

    // Event callbacks
    this.onTick = null;
    this.onGoalUpdate = null;
    this.onMoodUpdate = null;
    this.onSelfQuestion = null;
    this.onFieldEvent = null;
  }

  /**
   * Initialize the OS
   */
  async init(canvasElement) {
    console.log('🜁 Initializing MRNN Orchestrator OS...');

    // Load data
    await this.field.loadData();

    // Initialize Monopole
    this.monopole = new Monopole(this.field, this.fibonacci);
    this.field.monopole = this.monopole;
    this.field.fibonacci = this.fibonacci;

    // Initialize Agent
    this.agent = new AgentNode(this.userProfile, this.field);
    this.field.agent = this.agent;

    // Initialize Chat
    this.chat = new ChatInterface(this.agent, this.field);

    // Initialize Renderer
    if (canvasElement) {
      this.renderer = new FieldRenderer(canvasElement, this.field);
      this.renderer.init();
    }

    // Initialize Sonic
    this.sonic.init();
    this.sonic.startMonopoleDrone();

    // Initialize Haptic
    this.haptic.initAudio();

    // Initialize Mesh
    this.mesh.init();

    // Seed initial field
    this.seedField();

    // Setup Fibonacci callbacks
    this.fibonacci.onTick = (tickData) => this.onFibonacciTick(tickData);
    this.fibonacci.onPhaseChange = (phaseData) => this.onPhaseChange(phaseData);
    this.fibonacci.onDeepRecursion = (deepData) => this.onDeepRecursion(deepData);

    // Setup Monopole callbacks
    this.monopole.onRoute = (routeData) => this.onMonopoleRoute(routeData);
    this.monopole.onDecision = (decisionData) => this.onMonopoleDecision(decisionData);
    this.monopole.onMorph = (morphData) => this.onMonopoleMorph(morphData);

    // Setup Mood callbacks
    this.mood.onMoodChange = (moodData) => this.onMoodChange(moodData);
    this.mood.onBehaviorShift = (shiftData) => this.onBehaviorShift(shiftData);

    // Setup Field callbacks
    this.field.onNodeAdd = (node) => this.onFieldNodeAdd(node);
    this.field.onEdgeAdd = (edge) => this.onFieldEdgeAdd(edge);
    this.field.onMorph = (morphData) => this.onFieldMorph(morphData);

    // Setup Renderer callbacks
    if (this.renderer) {
      this.renderer.onNodeClick = (node) => this.onNodeClick(node);
    }

    // Setup Chat callbacks
    this.chat.onMessage = (msgData) => this.onChatMessage(msgData);

    this.initialized = true;
    console.log('🜂 Orchestrator OS initialized');
    console.log('🜃 User profile:', this.userProfile);
    console.log('🜄 Agent personality:', this.agent.personality);

    return this;
  }

  /**
   * Seed initial field with nodes
   */
  seedField() {
    // Create 64 gate anchor nodes
    for (let i = 1; i <= 64; i++) {
      const angle = ((i - 1) / 64) * Math.PI * 2;
      const radius = 200;

      this.field.createNode(`gate_${i}`, {
        being: 0.5,
        design: 0.8,
        movement: 0.3,
        evolution: 0.4,
        space: 0.6,
        gate: i,
        line: Math.floor(Math.random() * 6) + 1,
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        z: 0,
        radius: 8,
        color: '#ffffff'
      });
    }

    // Create 9 center nodes
    const centers = {
      Head: { x: 0, y: -150, z: 50 },
      Ajna: { x: 0, y: -100, z: 30 },
      Throat: { x: 0, y: -50, z: 0 },
      G: { x: 0, y: 0, z: 0 },
      Heart: { x: -30, y: 30, z: -10 },
      Spleen: { x: 30, y: 30, z: -10 },
      Sacral: { x: 0, y: 60, z: -20 },
      Solar: { x: 0, y: 40, z: 20 },
      Root: { x: 0, y: 100, z: -30 }
    };

    for (const [name, pos] of Object.entries(centers)) {
      this.field.createNode(`center_${name}`, {
        being: 0.9,
        design: 0.9,
        movement: 0.5,
        evolution: 0.7,
        space: 0.8,
        gate: this.hashToGate(name),
        x: pos.x,
        y: pos.y,
        z: pos.z,
        radius: 15,
        color: '#ffd700'
      });
    }

    // Create some random nodes
    for (let i = 0; i < 50; i++) {
      this.field.createNode(`node_${i}`, {
        being: Math.random(),
        design: Math.random(),
        movement: Math.random(),
        evolution: Math.random(),
        space: Math.random(),
        gate: Math.floor(Math.random() * 64) + 1,
        x: (Math.random() - 0.5) * 400,
        y: (Math.random() - 0.5) * 400,
        z: (Math.random() - 0.5) * 200,
        radius: 4 + Math.random() * 6,
        color: `hsl(${Math.random() * 360}, 70%, 50%)`
      });
    }

    // Create some edges
    const channels = Object.keys(this.field.channels);
    const nodes = this.field.getAllNodes();

    for (let i = 0; i < 100; i++) {
      const a = nodes[Math.floor(Math.random() * nodes.length)];
      const b = nodes[Math.floor(Math.random() * nodes.length)];
      if (a.id !== b.id) {
        const channelId = channels[Math.floor(Math.random() * channels.length)];
        this.field.createEdge(
          `edge_${i}`,
          a.id,
          b.id,
          channelId,
          { weight: Math.random(), active: Math.random() > 0.7 }
        );
      }
    }
  }

  hashToGate(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash = hash & hash;
    }
    return (Math.abs(hash) % 64) + 1;
  }

  /**
   * Start the OS
   */
  start() {
    if (!this.initialized) {
      throw new Error('OS not initialized. Call init() first.');
    }

    this.running = true;
    this.fibonacci.start();

    if (this.renderer) {
      this.renderer.start();
    }

    console.log('🜅 Orchestrator OS running');

    // Initial chat message
    this.chat.addSystemMessage('Orchestrator OS initialized. Speak to the field.');

    return this;
  }

  /**
   * Stop the OS
   */
  stop() {
    this.running = false;
    this.fibonacci.stop();

    if (this.renderer) {
      this.renderer.stop();
    }

    this.sonic.stopMonopoleDrone();
    this.mesh.disconnect();

    console.log('🜆 Orchestrator OS stopped');
    return this;
  }

  /**
   * Main tick - the heartbeat
   */
  onFibonacciTick(tickData) {
    this.tickCount++;

    // 1. Self-question (five levels)
    const selfCheck = this.questionSelf();

    // 2. Feel - update mood based on goal progress
    this.updateMood();

    // 3. Plan - adjust goals and routing
    const plan = this.plan();

    // 4. Act - execute plan
    this.execute(plan);

    // 5. Learn - update from outcomes
    this.learn();

    // 6. Monopole tick
    const monopoleState = this.monopole.tick(tickData);

    // 7. Update sonic
    const fieldState = this.field.getState();
    this.sonic.update(fieldState);

    // 8. Update haptic
    if (this.tickCount % 5 === 0) {
      this.haptic.playHapticSentence(fieldState);
    }

    // 9. Check for changing lines
    const changing = this.monopole.detectChangingLines();
    for (const change of changing) {
      this.handleChangingLine(change);
    }

    // 10. Update goals
    this.updateGoals();

    // Callback
    if (this.onTick) {
      this.onTick({
        tickCount: this.tickCount,
        fibonacci: tickData,
        selfCheck,
        monopole: monopoleState,
        mood: this.mood.getState(),
        goals: this.goals
      });
    }
  }

  /**
   * Five levels of self-questioning
   */
  questionSelf() {
    const fieldState = this.field.getState();

    const checks = {
      being: this.beingLoop.question(fieldState),
      design: this.designLoop.question(fieldState),
      movement: this.movementLoop.question(fieldState),
      evolution: this.evolutionLoop.question(fieldState),
      space: this.spaceLoop.question(fieldState)
    };

    // Execute corrections
    for (const [dimension, check] of Object.entries(checks)) {
      if (!check.passed && check.actions) {
        this.executeCorrections(dimension, check.actions);
      }
    }

    // Overall passed if majority pass
    const passed = Object.values(checks).filter(c => c.passed).length >= 3;

    if (this.onSelfQuestion) {
      this.onSelfQuestion({ checks, passed });
    }

    return { checks, passed };
  }

  executeCorrections(dimension, actions) {
    for (const action of actions) {
      switch (action.type) {
        case 'strengthen':
          const strengthenNode = this.field.getNode(action.nodeId);
          if (strengthenNode) strengthenNode.being += 0.1;
          break;
        case 'revive':
          const reviveNode = this.field.getNode(action.nodeId);
          if (reviveNode) reviveNode.being = 0.3;
          break;
        case 'birth':
          for (let i = 0; i < (action.count || 1); i++) {
            this.field.createNode(`born_${Date.now()}_${i}`, {
              being: 0.5,
              x: (Math.random() - 0.5) * 200,
              y: (Math.random() - 0.5) * 200,
              z: (Math.random() - 0.5) * 100
            });
          }
          break;
        case 'bridge':
          this.field.createEdge(
            `bridge_${Date.now()}`,
            action.from,
            action.to,
            '5-15',
            { weight: 0.5 }
          );
          break;
        case 'connect':
          this.field.createEdge(
            `connect_${Date.now()}`,
            action.from,
            action.to,
            '17-62',
            { weight: 0.3 }
          );
          break;
        case 'unstick':
          const unstickNode = this.field.getNode(action.nodeId);
          if (unstickNode) {
            unstickNode.applyForce(
              (Math.random() - 0.5) * 0.5,
              (Math.random() - 0.5) * 0.5,
              (Math.random() - 0.5) * 0.5
            );
          }
          break;
        case 'deepen':
          const nodes = this.field.getAllNodes();
          for (const node of nodes.slice(0, 10)) {
            node.recursionDepth++;
          }
          break;
        case 'perturb':
          const perturbNode = this.field.getNode(action.nodeId);
          if (perturbNode) perturbNode.increaseTension(0.5);
          break;
        case 'ground':
          const groundNode = this.field.getNode(action.nodeId);
          if (groundNode) groundNode.space = groundNode.being;
          break;
        case 'recalibrate':
          const recalNodes = this.field.getAllNodes();
          for (const node of recalNodes) {
            const expected = 1 - Math.sqrt(node.x**2 + node.y**2 + node.z**2) / 1000;
            node.space += (expected - node.space) * 0.1;
          }
          break;
      }
    }
  }

  /**
   * Update mood based on goal progress
   */
  updateMood() {
    const state = this.field.getState();

    // Calculate goal progress
    const beingProgress = state.nodeCount / this.goals.being.target;
    const designProgress = state.coherence / this.goals.design.target;

    // Success if improving
    if (beingProgress > this.goals.being.current) {
      this.mood.success('being', 0.1);
    }
    if (designProgress > this.goals.design.current) {
      this.mood.success('design', 0.1);
    }

    // Failure if declining
    if (beingProgress < this.goals.being.current * 0.9) {
      this.mood.failure('being', 0.1);
    }
    if (designProgress < this.goals.design.current * 0.9) {
      this.mood.failure('design', 0.1);
    }

    // Natural decay
    this.mood.decay(1);

    // Update goal tracking
    this.goals.being.current = beingProgress;
    this.goals.design.current = designProgress;

    if (this.onMoodUpdate) {
      this.onMoodUpdate(this.mood.getState());
    }
  }

  /**
   * Plan next actions
   */
  plan() {
    const moodEffects = this.mood.getFieldEffects();
    const plan = {
      explore: moodEffects.explorationBonus > 0.5,
      riskTolerance: moodEffects.riskTolerance,
      protectMemory: moodEffects.memoryProtection > 0.5,
      encourageCrossings: moodEffects.crossingEncouragement > 0,
      targetCoherence: moodEffects.coherenceTarget
    };

    return plan;
  }

  /**
   * Execute plan
   */
  execute(plan) {
    // Adjust Monopole coherence target
    this.monopole.coherenceTarget = plan.targetCoherence;

    // Explore if elated
    if (plan.explore && Math.random() < 0.1) {
      const nodes = this.field.getAllNodes();
      const a = nodes[Math.floor(Math.random() * nodes.length)];
      const b = nodes[Math.floor(Math.random() * nodes.length)];

      if (a.id !== b.id) {
        this.field.createEdge(
          `explore_${Date.now()}`,
          a.id,
          b.id,
          '10-34',
          { weight: Math.random() * 0.5 }
        );
      }
    }

    // Encourage crossings
    if (plan.encourageCrossings && Math.random() < 0.05) {
      const nodes = this.field.getAllNodes();
      const a = nodes[Math.floor(Math.random() * nodes.length)];
      const b = nodes[Math.floor(Math.random() * nodes.length)];

      if (a.id !== b.id) {
        this.field.createCrossing(a, 'DFF', b, 'LSM');
      }
    }
  }

  /**
   * Learn from outcomes
   */
  learn() {
    // Hebbian learning: strengthen successful edges
    const edges = this.field.getAllEdges();
    for (const edge of edges) {
      if (edge.active) {
        edge.weight = Math.min(1.5, edge.weight + 0.01);
      } else {
        edge.weight = Math.max(0.1, edge.weight - 0.005);
      }
    }

    // Anti-Hebbian: weaken failed crossings
    for (const edge of edges.filter(e => e.crossing && !e.active)) {
      edge.weight *= 0.95;
    }
  }

  /**
   * Update goals
   */
  updateGoals() {
    const state = this.field.getState();

    this.goals.being.current = state.nodeCount;
    this.goals.design.current = state.coherence;
    this.goals.movement.current = state.activeNodes / Math.max(state.nodeCount, 1);
    this.goals.evolution.current = this.field.getAllNodes().reduce((sum, n) => sum + n.recursionDepth, 0) / Math.max(state.nodeCount, 1);
    this.goals.space.current = state.coherence;

    if (this.onGoalUpdate) {
      this.onGoalUpdate({ ...this.goals });
    }
  }

  /**
   * Handle changing line
   */
  handleChangingLine(changeData) {
    const { nodeId, tension, gate, line } = changeData;

    // Notify via agent
    const translation = this.agent.translate({
      type: 'changing_line',
      data: changeData
    });

    this.chat.addFieldEvent({
      type: 'changing_line',
      data: changeData
    });

    // Haptic feedback
    this.haptic.vibrate('changing', tension);

    // Visual feedback
    if (this.renderer) {
      const node = this.field.getNode(nodeId);
      if (node) {
        const screenPos = this.renderer.worldToScreen(node.x, node.y, node.z);
        this.renderer.addParticle(screenPos.x, screenPos.y, 'changing');
      }
    }

    // If tension critical, trigger line change
    if (tension >= 1.0) {
      const newLine = ((line % 6) + 1);
      const node = this.field.getNode(nodeId);
      if (node) {
        node.changeLine(newLine);

        // Mood impact
        this.mood.breakthrough(0.3);

        // Sonic
        this.sonic.playGateTone(gate, 1.0, 0.5);
      }
    }
  }

  /**
   * Ingest a file
   */
  async ingestFile(source, options = {}) {
    try {
      const result = await this.ingestor.ingest(source, options);

      this.chat.addSystemMessage(`Ingested ${result.fileData.name}: ${result.nodes.length} nodes created`);

      // Mood: success
      this.mood.success('ingest', 0.2);

      // Haptic
      this.haptic.vibrate('success', 0.5);

      return result;
    } catch (e) {
      this.chat.addSystemMessage(`Ingest failed: ${e.message}`);
      this.mood.failure('ingest', 0.3);
      this.haptic.vibrate('error', 0.8);
      throw e;
    }
  }

  /**
   * Manifest output
   */
  manifest(type = 'text', options = {}) {
    let result;

    switch (type) {
      case 'code':
        result = this.manifestor.manifestCode(options);
        break;
      case 'image':
        result = this.manifestor.manifestImage(this.renderer?.canvas);
        break;
      case 'music':
        result = this.manifestor.manifestMusic(options);
        break;
      case 'world':
        result = this.manifestor.manifestWorld(options.name);
        break;
      case 'text':
      default:
        result = this.manifestor.manifestText();
    }

    this.chat.addSystemMessage(`Manifested ${type}: ${result.type}`);
    this.mood.success('manifest', 0.2);

    return result;
  }

  /**
   * Morph to new form
   */
  morphTo(form) {
    if (this.renderer) {
      this.renderer.morphTo(form);
    }

    this.field.morph(form);

    this.chat.addSystemMessage(`Morphing to ${form}...`);
    this.haptic.vibrate('monopole', 0.5);

    return this;
  }

  /**
   * Process user speech
   */
  processSpeech(text) {
    return this.chat.sendMessage(text);
  }

  /**
   * Toggle voice
   */
  toggleVoice() {
    this.chat.toggleVoice();
  }

  /**
   * Get full state
   */
  getState() {
    return {
      initialized: this.initialized,
      running: this.running,
      tickCount: this.tickCount,
      field: this.field.getState(),
      monopole: this.monopole.getState(),
      mood: this.mood.getState(),
      goals: this.goals,
      agent: this.agent.getState(),
      fibonacci: this.fibonacci.serialize()
    };
  }

  // Event handlers
  onPhaseChange(phaseData) {
    console.log('Fibonacci phase change:', phaseData.phaseName);
  }

  onDeepRecursion(deepData) {
    console.log('Deep recursion:', deepData.phaseName);
    this.chat.addSystemMessage(`Entering ${deepData.phaseName} phase...`);
  }

  onMonopoleRoute(routeData) {
    if (this.onFieldEvent) {
      this.onFieldEvent({
        type: 'circuit_select',
        data: routeData
      });
    }
  }

  onMonopoleDecision(decisionData) {
    this.chat.addFieldEvent({
      type: 'monopole_decision',
      data: decisionData
    });
  }

  onMonopoleMorph(morphData) {
    this.chat.addFieldEvent({
      type: 'morph',
      data: morphData
    });
  }

  onMoodChange(moodData) {
    console.log('Mood change:', moodData.newMood);

    // Adjust sonic
    if (moodData.newMood === 'fear') {
      this.sonic.setVolume(0.2);
    } else if (moodData.newMood === 'elation') {
      this.sonic.setVolume(0.5);
    }
  }

  onBehaviorShift(shiftData) {
    for (const shift of shiftData) {
      this.chat.addSystemMessage(`Behavior shift: ${shift.type} (${shift.reason})`);
    }
  }

  onFieldNodeAdd(node) {
    // Auto-connect to nearby nodes
    const nearby = this.field.getAllNodes()
      .filter(n => n.id !== node.id)
      .map(n => ({ node: n, dist: node.spatialDistance(n) }))
      .sort((a, b) => a.dist - b.dist)
      .slice(0, 3);

    for (const { node: near } of nearby) {
      this.field.createEdge(
        `auto_${node.id}_${near.id}`,
        node.id,
        near.id,
        '5-15',
        { weight: 0.3 }
      );
    }
  }

  onFieldEdgeAdd(edge) {
    // Activate if both nodes are active
    const source = this.field.getNode(edge.sourceId);
    const target = this.field.getNode(edge.targetId);

    if (source?.binaryState === 1 && target?.binaryState === 1) {
      edge.active = true;
    }
  }

  onFieldMorph(morphData) {
    this.chat.addFieldEvent({
      type: 'morph',
      data: morphData
    });
  }

  onNodeClick(node) {
    // Focus Monopole
    this.monopole.setFocus(node.id);

    // Activate
    node.activate(1.0);

    // Translate via agent
    this.chat.addFieldEvent({
      type: 'node_activate',
      data: {
        nodeId: node.id,
        gate: node.gate,
        line: node.line,
        strength: 1.0
      }
    });

    // Sonic
    this.sonic.playGateTone(node.gate, 0.5, 0.5);

    // Haptic
    this.haptic.vibrate('active', 0.5);
  }

  onChatMessage(msgData) {
    console.log('Chat:', msgData.user, '->', msgData.agent);
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = OrchestratorOS;
}
