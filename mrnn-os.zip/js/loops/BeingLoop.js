/**
 * BeingLoop - Persistence monitoring, node existence, survival.
 * "Do I exist?"
 */
class BeingLoop {
  constructor(field) {
    this.field = field;
    this.nodeBirthRate = 0.1;
    this.nodeDeathThreshold = 0.05;
    this.persistenceTarget = 100;

    // Correction actions
    this.actions = [];
  }

  question(fieldState) {
    const nodes = this.field.getAllNodes();
    const aliveNodes = nodes.filter(n => n.being > this.nodeDeathThreshold);
    const deadNodes = nodes.filter(n => n.being <= this.nodeDeathThreshold);

    const persistence = aliveNodes.length;
    const health = aliveNodes.reduce((sum, n) => sum + n.being, 0) / (aliveNodes.length || 1);

    const passed = persistence >= this.persistenceTarget && health > 0.5;

    return {
      dimension: 'Being',
      question: 'Do I exist?',
      passed,
      persistence,
      health,
      deadCount: deadNodes.length,
      actions: passed ? [] : this.correct(aliveNodes, deadNodes)
    };
  }

  correct(aliveNodes, deadNodes) {
    const actions = [];

    // Strengthen weak nodes
    for (const node of aliveNodes.filter(n => n.being < 0.3)) {
      node.being = Math.min(1.0, node.being + 0.1);
      actions.push({ type: 'strengthen', nodeId: node.id, reason: 'low being' });
    }

    // Revive recently dead nodes if they have high attractor weight
    for (const node of deadNodes.filter(n => n.attractorWeight > 0.5)) {
      node.being = 0.3;
      actions.push({ type: 'revive', nodeId: node.id, reason: 'high attractor weight' });
    }

    // Birth new nodes if below target
    if (aliveNodes.length < this.persistenceTarget) {
      const needed = this.persistenceTarget - aliveNodes.length;
      actions.push({ type: 'birth', count: Math.min(needed, 5), reason: 'below target' });
    }

    return actions;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = BeingLoop;
}
