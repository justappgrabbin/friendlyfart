/**
 * DesignLoop - Coherence monitoring, graph connectivity.
 * "Do I hold together?"
 */
class DesignLoop {
  constructor(field) {
    this.field = field;
    this.connectivityTarget = 0.7;
    this.fragmentationThreshold = 0.3;
  }

  question(fieldState) {
    const edges = this.field.getAllEdges();
    const nodes = this.field.getAllNodes();

    if (nodes.length === 0) {
      return { dimension: 'Design', question: 'Do I hold together?', passed: false, actions: [] };
    }

    // Calculate connectivity ratio
    const maxEdges = nodes.length * (nodes.length - 1) / 2;
    const connectivity = edges.length / maxEdges;

    // Check for islands (nodes with no connections)
    const islands = nodes.filter(n => n.connections.length === 0);
    const fragmentation = islands.length / nodes.length;

    const passed = connectivity >= this.connectivityTarget && fragmentation < this.fragmentationThreshold;

    return {
      dimension: 'Design',
      question: 'Do I hold together?',
      passed,
      connectivity,
      fragmentation,
      islandCount: islands.length,
      actions: passed ? [] : this.correct(islands, connectivity)
    };
  }

  correct(islands, connectivity) {
    const actions = [];

    // Connect islands
    for (const island of islands) {
      // Find nearest connected node
      const connected = this.field.getAllNodes().filter(n => n.connections.length > 0);
      if (connected.length > 0) {
        let nearest = connected[0];
        let minDist = Infinity;

        for (const node of connected) {
          const dist = island.spatialDistance(node);
          if (dist < minDist) {
            minDist = dist;
            nearest = node;
          }
        }

        actions.push({
          type: 'bridge',
          from: island.id,
          to: nearest.id,
          reason: 'island connection'
        });
      }
    }

    // Increase connectivity if too low
    if (connectivity < this.connectivityTarget) {
      const nodes = this.field.getAllNodes();
      for (let i = 0; i < Math.min(10, nodes.length); i++) {
        const a = nodes[Math.floor(Math.random() * nodes.length)];
        const b = nodes[Math.floor(Math.random() * nodes.length)];
        if (a.id !== b.id) {
          actions.push({
            type: 'connect',
            from: a.id,
            to: b.id,
            reason: 'connectivity boost'
          });
        }
      }
    }

    return actions;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = DesignLoop;
}
