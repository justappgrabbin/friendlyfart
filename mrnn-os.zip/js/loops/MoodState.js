/**
 * MoodState - The orchestrator's emotional state.
 * Success and failure affect the field's behavior.
 */
class MoodState {
  constructor() {
    // Core emotions (0-1)
    this.elation = 0.5;
    this.pride = 0.5;
    this.relief = 0.5;
    this.pain = 0.0;
    this.shame = 0.0;
    this.fear = 0.0;
    this.grief = 0.0;

    // Derived mood
    this.dominantMood = 'neutral';
    this.moodIntensity = 0.5;

    // History
    this.moodHistory = [];

    // Decay rates
    this.decayRates = {
      elation: 0.01,
      pride: 0.008,
      relief: 0.012,
      pain: 0.005,
      shame: 0.003,
      fear: 0.004,
      grief: 0.002
    };

    // Thresholds for behavior change
    this.thresholds = {
      exploration: { elation: 0.7, pride: 0.6 },
      conservatism: { pain: 0.6, fear: 0.7 },
      defense: { fear: 0.8, shame: 0.7 },
      mourning: { grief: 0.8 }
    };

    // Event callbacks
    this.onMoodChange = null;
    this.onBehaviorShift = null;
  }

  /**
   * Record a success event
   */
  success(type = 'general', magnitude = 1.0) {
    const impacts = {
      elation: 0.2 * magnitude,
      pride: 0.15 * magnitude,
      relief: 0.1 * magnitude
    };

    // Reduce negative emotions
    this.pain = Math.max(0, this.pain - 0.1 * magnitude);
    this.fear = Math.max(0, this.fear - 0.08 * magnitude);
    this.shame = Math.max(0, this.shame - 0.05 * magnitude);
    this.grief = Math.max(0, this.grief - 0.03 * magnitude);

    this.applyImpacts(impacts);
    this.recordEvent('success', type, magnitude);

    return this.getState();
  }

  /**
   * Record a failure event
   */
  failure(type = 'general', magnitude = 1.0) {
    const impacts = {
      pain: 0.2 * magnitude,
      shame: 0.15 * magnitude,
      fear: 0.1 * magnitude
    };

    // Reduce positive emotions
    this.elation = Math.max(0, this.elation - 0.1 * magnitude);
    this.pride = Math.max(0, this.pride - 0.08 * magnitude);

    this.applyImpacts(impacts);
    this.recordEvent('failure', type, magnitude);

    return this.getState();
  }

  /**
   * Record a breakthrough event
   */
  breakthrough(magnitude = 1.0) {
    const impacts = {
      elation: 0.3 * magnitude,
      pride: 0.25 * magnitude,
      relief: 0.2 * magnitude
    };

    this.applyImpacts(impacts);
    this.recordEvent('breakthrough', 'crossing', magnitude);

    return this.getState();
  }

  /**
   * Record a loss event
   */
  loss(magnitude = 1.0) {
    const impacts = {
      grief: 0.3 * magnitude,
      pain: 0.2 * magnitude,
      fear: 0.15 * magnitude
    };

    this.applyImpacts(impacts);
    this.recordEvent('loss', 'memory', magnitude);

    return this.getState();
  }

  /**
   * Apply emotional impacts
   */
  applyImpacts(impacts) {
    for (const [emotion, amount] of Object.entries(impacts)) {
      this[emotion] = Math.min(1.0, Math.max(0, this[emotion] + amount));
    }

    this.updateDominantMood();
    return this;
  }

  /**
   * Update the dominant mood
   */
  updateDominantMood() {
    const emotions = {
      elation: this.elation,
      pride: this.pride,
      relief: this.relief,
      pain: this.pain,
      shame: this.shame,
      fear: this.fear,
      grief: this.grief
    };

    const sorted = Object.entries(emotions).sort((a, b) => b[1] - a[1]);
    const [dominant, intensity] = sorted[0];

    const oldMood = this.dominantMood;
    this.dominantMood = dominant;
    this.moodIntensity = intensity;

    if (oldMood !== dominant && this.onMoodChange) {
      this.onMoodChange({
        oldMood,
        newMood: dominant,
        intensity,
        allEmotions: emotions
      });
    }

    // Check for behavior shifts
    this.checkBehaviorShift();
  }

  /**
   * Check if mood thresholds trigger behavior changes
   */
  checkBehaviorShift() {
    const shifts = [];

    if (this.elation > this.thresholds.exploration.elation ||
        this.pride > this.thresholds.exploration.pride) {
      shifts.push({ type: 'exploration', reason: 'high positive affect' });
    }

    if (this.pain > this.thresholds.conservatism.pain ||
        this.fear > this.thresholds.conservatism.fear) {
      shifts.push({ type: 'conservatism', reason: 'high negative affect' });
    }

    if (this.fear > this.thresholds.defense.fear ||
        this.shame > this.thresholds.defense.shame) {
      shifts.push({ type: 'defense', reason: 'threat response' });
    }

    if (this.grief > this.thresholds.mourning.grief) {
      shifts.push({ type: 'mourning', reason: 'deep loss' });
    }

    if (shifts.length > 0 && this.onBehaviorShift) {
      this.onBehaviorShift(shifts);
    }

    return shifts;
  }

  /**
   * Natural decay of emotions over time
   */
  decay(dt = 1) {
    for (const [emotion, rate] of Object.entries(this.decayRates)) {
      this[emotion] = Math.max(0, this[emotion] - rate * dt);
    }

    this.updateDominantMood();
    return this;
  }

  /**
   * Record event in history
   */
  recordEvent(eventType, subtype, magnitude) {
    this.moodHistory.push({
      timestamp: Date.now(),
      type: eventType,
      subtype,
      magnitude,
      moodState: this.getState()
    });

    // Trim history
    if (this.moodHistory.length > 1000) {
      this.moodHistory = this.moodHistory.slice(-500);
    }
  }

  /**
   * Get current mood effects on field behavior
   */
  getFieldEffects() {
    return {
      explorationBonus: this.elation * 0.3 + this.pride * 0.2,
      riskTolerance: 1 - (this.fear * 0.5 + this.pain * 0.3),
      memoryProtection: this.grief * 0.4 + this.fear * 0.2,
      crossingEncouragement: this.elation * 0.4 - this.fear * 0.3,
      adapterPersistence: this.pride * 0.3 + this.relief * 0.2,
      coherenceTarget: 0.8 - (this.grief * 0.2) + (this.elation * 0.1)
    };
  }

  /**
   * Get current state
   */
  getState() {
    return {
      elation: this.elation,
      pride: this.pride,
      relief: this.relief,
      pain: this.pain,
      shame: this.shame,
      fear: this.fear,
      grief: this.grief,
      dominantMood: this.dominantMood,
      moodIntensity: this.moodIntensity,
      fieldEffects: this.getFieldEffects()
    };
  }

  /**
   * Serialize
   */
  serialize() {
    return {
      ...this.getState(),
      historyLength: this.moodHistory.length
    };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = MoodState;
}
