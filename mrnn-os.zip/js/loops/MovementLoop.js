/**
 * MovementLoop - Flow monitoring, signal propagation.
 * "Do I flow?"
 */
class MovementLoop {
  constructor(field) {
    this.field = field;
    this.velocityTarget = 0.1;
    this.deadlockThreshold = 5; // seconds without signal movement
  }

  question(fieldState) {
    const nodes = this.field.getAllNodes();
    const activeNodes = nodes.filter(n => n.binaryState === 1);

    if (activeNodes.length === 0) {
      return { dimension: 'Movement', question: 'Do I flow?', passed: false, actions: [] };
    }

    // Calculate average velocity
    const avgVelocity = activeNodes.reduce((sum, n) => {
      const v = Math.sqrt(n.vx ** 2 + n.vy ** 2 + n.vz ** 2);
      return sum + v;
    }, 0) / activeNodes.length;

    // Check for deadlocks (nodes stuck with high tension)
    const deadlocked = activeNodes.filter(n => {
      const v = Math.sqrt(n.vx ** 2 + n.vy ** 2 + n.vz ** 2);
      return v < 0.01 && n.tension > 0.5;
    });

    const passed = avgVelocity >= this.velocityTarget && deadlocked.length < activeNodes.length * 0.2;

    return {
      dimension: 'Movement',
      question: 'Do I flow?',
      passed,
      avgVelocity,
      deadlockedCount: deadlocked.length,
      actions: passed ? [] : this.correct(deadlocked, avgVelocity)
    };
  }

  correct(deadlocked, avgVelocity) {
    const actions = [];

    // Unstick deadlocked nodes
    for (const node of deadlocked) {
      // Apply random impulse
      const force = 0.5;
      const angle = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;

      node.applyForce(
        force * Math.sin(phi) * Math.cos(angle),
        force * Math.sin(phi) * Math.sin(angle),
        force * Math.cos(phi)
      );

      node.decreaseTension(0.3);

      actions.push({
        type: 'unstick',
        nodeId: node.id,
        reason: 'deadlock detected'
      });
    }

    // Boost overall velocity if too low
    if (avgVelocity < this.velocityTarget) {
      const nodes = this.field.getAllNodes().filter(n => n.binaryState === 1);
      for (const node of nodes) {
        node.applyForce(
          (Math.random() - 0.5) * 0.2,
          (Math.random() - 0.5) * 0.2,
          (Math.random() - 0.5) * 0.2
        );
      }

      actions.push({
        type: 'boost',
        reason: 'low velocity'
      });
    }

    return actions;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = MovementLoop;
}
