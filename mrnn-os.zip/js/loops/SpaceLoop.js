/**
 * SpaceLoop - Clarity monitoring, observer projection.
 * "Do I see clearly?"
 */
class SpaceLoop {
  constructor(field) {
    this.field = field;
    this.clarityTarget = 0.7;
    this.hallucinationThreshold = 0.3;
  }

  question(fieldState) {
    const nodes = this.field.getAllNodes();

    // Check projection fidelity (alignment of space operator with actual positions)
    const spaceAlignment = nodes.reduce((sum, n) => {
      const expectedSpace = this.calculateExpectedSpace(n);
      return sum + (1 - Math.abs(n.space - expectedSpace));
    }, 0) / (nodes.length || 1);

    // Check for hallucination (nodes with high space but low being)
    const hallucinations = nodes.filter(n => n.space > 0.7 && n.being < 0.3);

    // Check observer drift (space values too uniform = no perspective)
    const spaceVariance = this.calculateVariance(nodes.map(n => n.space));
    const drift = spaceVariance < 0.1;

    const passed = spaceAlignment >= this.clarityTarget && 
                   hallucinations.length < nodes.length * this.hallucinationThreshold &&
                   !drift;

    return {
      dimension: 'Space',
      question: 'Do I see clearly?',
      passed,
      spaceAlignment,
      hallucinationCount: hallucinations.length,
      drift,
      actions: passed ? [] : this.correct(hallucinations, drift)
    };
  }

  calculateExpectedSpace(node) {
    // Space should correlate with position centrality
    const centerDist = Math.sqrt(node.x ** 2 + node.y ** 2 + node.z ** 2);
    const maxDist = 1000; // arbitrary field size
    return 1 - Math.min(1, centerDist / maxDist);
  }

  calculateVariance(values) {
    if (values.length === 0) return 0;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    return values.reduce((sum, val) => sum + (val - mean) ** 2, 0) / values.length;
  }

  correct(hallucinations, drift) {
    const actions = [];

    // Ground hallucinations
    for (const node of hallucinations) {
      node.space = node.being; // Space must match being
      actions.push({
        type: 'ground',
        nodeId: node.id,
        reason: 'hallucination detected'
      });
    }

    // Correct drift
    if (drift) {
      const nodes = this.field.getAllNodes();
      for (const node of nodes) {
        const expected = this.calculateExpectedSpace(node);
        node.space += (expected - node.space) * 0.1;
      }

      actions.push({
        type: 'recalibrate',
        reason: 'observer drift'
      });
    }

    return actions;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SpaceLoop;
}
