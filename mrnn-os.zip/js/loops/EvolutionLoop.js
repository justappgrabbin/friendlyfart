/**
 * EvolutionLoop - Growth monitoring, memory depth.
 * "Do I grow?"
 */
class EvolutionLoop {
  constructor(field) {
    this.field = field;
    this.memoryDepthTarget = 5;
    this.repetitionThreshold = 0.8; // 80% same states = stuck
  }

  question(fieldState) {
    const nodes = this.field.getAllNodes();

    // Check recursion depth
    const avgDepth = nodes.reduce((sum, n) => sum + n.recursionDepth, 0) / (nodes.length || 1);

    // Check for repetition (stuck attractors)
    const recentStates = this.getRecentStates(100);
    const uniqueStates = new Set(recentStates.map(s => JSON.stringify(s))).size;
    const repetition = 1 - (uniqueStates / recentStates.length);

    // Check memory graph size
    const memorySize = this.field.memory.size;

    const passed = avgDepth >= this.memoryDepthTarget && 
                   repetition < this.repetitionThreshold &&
                   memorySize > 10;

    return {
      dimension: 'Evolution',
      question: 'Do I grow?',
      passed,
      avgDepth,
      repetition,
      memorySize,
      actions: passed ? [] : this.correct(avgDepth, repetition)
    };
  }

  getRecentStates(count) {
    // This would pull from actual history
    // Simplified: return current node states
    return this.field.getAllNodes().map(n => ({
      gate: n.gate,
      line: n.line,
      binaryState: n.binaryState
    })).slice(0, count);
  }

  correct(avgDepth, repetition) {
    const actions = [];

    // Deepen recursion if too shallow
    if (avgDepth < this.memoryDepthTarget) {
      const nodes = this.field.getAllNodes();
      for (const node of nodes.slice(0, 10)) {
        node.recursionDepth++;
      }

      actions.push({
        type: 'deepen',
        reason: 'shallow recursion'
      });
    }

    // Break repetition if stuck
    if (repetition > this.repetitionThreshold) {
      // Force some nodes to change lines
      const nodes = this.field.getAllNodes();
      for (const node of nodes.filter(n => n.regime === 'stable').slice(0, 5)) {
        node.increaseTension(0.5);
        actions.push({
          type: 'perturb',
          nodeId: node.id,
          reason: 'repetition detected'
        });
      }
    }

    // Seed new memory
    if (this.field.memory.size < 10) {
      actions.push({
        type: 'seed_memory',
        reason: 'low memory'
      });
    }

    return actions;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = EvolutionLoop;
}
