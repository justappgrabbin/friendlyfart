/**
 * ChatInterface - Voice/text input, agent output.
 * The bridge between user and field.
 */
class ChatInterface {
  constructor(agent, field) {
    this.agent = agent;
    this.field = field;

    // DOM elements
    this.container = null;
    this.messagesContainer = null;
    this.inputElement = null;
    this.voiceButton = null;

    // Voice recognition
    this.recognition = null;
    this.isListening = false;

    // Message history
    this.messages = [];

    // Event callbacks
    this onMessage = null;
    this.onVoiceStart = null;
    this.onVoiceEnd = null;
  }

  /**
   * Initialize the chat UI
   */
  init(containerId) {
    this.container = document.getElementById(containerId);
    if (!this.container) {
      // Create floating chat panel
      this.container = document.createElement('div');
      this.container.id = 'chat-panel';
      this.container.className = 'chat-panel';
      document.body.appendChild(this.container);
    }

    this.renderUI();
    this.initVoiceRecognition();

    return this;
  }

  renderUI() {
    this.container.innerHTML = `
      <div class="chat-header">
        <span class="chat-title">Field Translator</span>
        <button class="chat-toggle">−</button>
      </div>
      <div class="chat-messages"></div>
      <div class="chat-input-area">
        <input type="text" class="chat-input" placeholder="Speak to the field..." />
        <button class="chat-voice-btn">🎤</button>
        <button class="chat-send-btn">→</button>
      </div>
    `;

    this.messagesContainer = this.container.querySelector('.chat-messages');
    this.inputElement = this.container.querySelector('.chat-input');
    this.voiceButton = this.container.querySelector('.chat-voice-btn');

    // Event listeners
    this.inputElement.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        this.sendMessage(this.inputElement.value);
      }
    });

    this.container.querySelector('.chat-send-btn').addEventListener('click', () => {
      this.sendMessage(this.inputElement.value);
    });

    this.voiceButton.addEventListener('click', () => {
      this.toggleVoice();
    });

    this.container.querySelector('.chat-toggle').addEventListener('click', () => {
      this.container.classList.toggle('chat-minimized');
    });
  }

  /**
   * Initialize Web Speech API
   */
  initVoiceRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = 'en-US';

      this.recognition.onstart = () => {
        this.isListening = true;
        this.voiceButton.classList.add('listening');
        if (this.onVoiceStart) this.onVoiceStart();
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.voiceButton.classList.remove('listening');
        if (this.onVoiceEnd) this.onVoiceEnd();
      };

      this.recognition.onresult = (event) => {
        let finalTranscript = '';
        let interimTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          } else {
            interimTranscript += transcript;
          }
        }

        if (finalTranscript) {
          this.sendMessage(finalTranscript);
        }

        // Update input with interim
        if (interimTranscript) {
          this.inputElement.value = interimTranscript;
        }
      };

      this.recognition.onerror = (event) => {
        console.warn('Speech recognition error:', event.error);
        this.isListening = false;
        this.voiceButton.classList.remove('listening');
      };
    }
  }

  /**
   * Toggle voice recognition
   */
  toggleVoice() {
    if (!this.recognition) {
      this.addSystemMessage('Voice recognition not available in this browser.');
      return;
    }

    if (this.isListening) {
      this.recognition.stop();
    } else {
      this.recognition.start();
    }
  }

  /**
   * Send a message
   */
  sendMessage(text) {
    if (!text.trim()) return;

    // Add user message
    this.addMessage('user', text);
    this.inputElement.value = '';

    // Process through agent
    const processed = this.agent.processUserSpeech(text);

    // Apply to field
    this.applyToField(processed.operators);

    // Generate agent response
    const response = processed.response;

    // Add agent message
    this.addMessage('agent', response);

    // Speak if enabled
    if (this.agent.voiceEnabled) {
      this.agent.speak(response);
    }

    // Callback
    if (this.onMessage) {
      this.onMessage({ user: text, agent: response, processed });
    }

    return processed;
  }

  /**
   * Apply operator changes to field
   */
  applyToField(operators) {
    // Find nodes near center and adjust
    const nodes = this.field.getAllNodes();
    const centerNodes = nodes
      .map(n => ({ node: n, dist: Math.sqrt(n.x**2 + n.y**2 + n.z**2) }))
      .sort((a, b) => a.dist - b.dist)
      .slice(0, 10);

    for (const { node } of centerNodes) {
      node.being = Math.min(1, Math.max(0, node.being + (operators.being - 0.5) * 0.2));
      node.design = Math.min(1, Math.max(0, node.design + (operators.design - 0.5) * 0.2));
      node.movement = Math.min(1, Math.max(0, node.movement + (operators.movement - 0.5) * 0.2));
      node.evolution = Math.min(1, Math.max(0, node.evolution + (operators.evolution - 0.5) * 0.2));
      node.space = Math.min(1, Math.max(0, node.space + (operators.space - 0.5) * 0.2));
    }
  }

  /**
   * Add a message to the chat
   */
  addMessage(sender, text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `chat-message chat-message-${sender}`;
    msgDiv.innerHTML = `
      <div class="chat-message-content">${this.escapeHtml(text)}</div>
      <div class="chat-message-time">${new Date().toLocaleTimeString()}</div>
    `;

    this.messagesContainer.appendChild(msgDiv);
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;

    this.messages.push({
      sender,
      text,
      timestamp: Date.now()
    });

    // Trim if too many
    while (this.messagesContainer.children.length > 100) {
      this.messagesContainer.removeChild(this.messagesContainer.firstChild);
    }
  }

  /**
   * Add a system message
   */
  addSystemMessage(text) {
    this.addMessage('system', text);
  }

  /**
   * Add a field event message (translated by agent)
   */
  addFieldEvent(fieldEvent) {
    const translation = this.agent.translate(fieldEvent);
    this.addMessage('field', translation);

    // Speak if enabled
    if (this.agent.voiceEnabled) {
      this.agent.speak(translation);
    }
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Get message history
   */
  getHistory() {
    return this.messages;
  }

  /**
   * Clear chat
   */
  clear() {
    this.messagesContainer.innerHTML = '';
    this.messages = [];
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = ChatInterface;
}
