/**
 * OutputManifestor - Creates outputs from field state.
 * Code, art, music, worlds.
 */
class OutputManifestor {
  constructor(field) {
    this.field = field;
    this.manifestations = [];
  }

  /**
   * Manifest field state as code
   */
  manifestCode(options = {}) {
    const nodes = this.field.getAllNodes();
    const edges = this.field.getAllEdges();

    const language = options.language || 'javascript';

    let code = `// Manifested from MRNN field state
`;
    code += `// Timestamp: ${new Date().toISOString()}
`;
    code += `// Nodes: ${nodes.length}, Edges: ${edges.length}

`;

    if (language === 'javascript') {
      code += `const fieldGraph = {
`;
      code += `  nodes: [
`;

      for (const node of nodes) {
        code += `    {
`;
        code += `      id: "${node.id}",
`;
        code += `      gate: ${node.gate},
`;
        code += `      line: ${node.line},
`;
        code += `      being: ${node.being.toFixed(3)},
`;
        code += `      design: ${node.design.toFixed(3)},
`;
        code += `      movement: ${node.movement.toFixed(3)},
`;
        code += `      evolution: ${node.evolution.toFixed(3)},
`;
        code += `      space: ${node.space.toFixed(3)},
`;
        code += `      x: ${node.x.toFixed(2)}, y: ${node.y.toFixed(2)}, z: ${node.z.toFixed(2)}
`;
        code += `    },
`;
      }

      code += `  ],
`;
      code += `  edges: [
`;

      for (const edge of edges) {
        code += `    {
`;
        code += `      id: "${edge.id}",
`;
        code += `      source: "${edge.sourceId}",
`;
        code += `      target: "${edge.targetId}",
`;
        code += `      channel: "${edge.channelId}",
`;
        code += `      weight: ${edge.weight.toFixed(3)}
`;
        code += `    },
`;
      }

      code += `  ]
`;
      code += `};
`;
    }

    this.recordManifestation('code', code.length);
    return { type: 'code', language, content: code };
  }

  /**
   * Manifest as image (canvas snapshot)
   */
  manifestImage(canvas) {
    const dataURL = canvas.toDataURL('image/png');

    this.recordManifestation('image', dataURL.length);
    return { type: 'image', format: 'png', dataURL };
  }

  /**
   * Manifest as music (MIDI-like sequence)
   */
  manifestMusic(options = {}) {
    const nodes = this.field.getAllNodes();
    const activeNodes = nodes.filter(n => n.binaryState === 1);

    // Generate note sequence from gate activations
    const notes = [];
    const scale = [0, 2, 4, 5, 7, 9, 11]; // Major scale intervals

    for (const node of activeNodes) {
      const gate = node.gate;
      const line = node.line;

      // Map gate to pitch
      const octave = Math.floor(gate / 8) + 3;
      const noteIdx = (gate - 1) % 7;
      const pitch = octave * 12 + scale[noteIdx];

      // Map line to duration
      const duration = line * 0.25;

      // Map attractor weight to velocity
      const velocity = Math.floor(node.attractorWeight * 127);

      notes.push({
        pitch,
        duration,
        velocity,
        gate: node.gate,
        line: node.line,
        timestamp: notes.length * 0.5
      });
    }

    // Sort by timestamp
    notes.sort((a, b) => a.timestamp - b.timestamp);

    this.recordManifestation('music', notes.length);
    return { type: 'music', format: 'sequence', notes };
  }

  /**
   * Manifest as a portable world (attractor basin)
   */
  manifestWorld(name = 'world') {
    const state = this.field.serialize();

    const world = {
      name,
      timestamp: Date.now(),
      version: '1.0',
      field: state,
      metadata: {
        nodeCount: state.stats.nodeCount,
        edgeCount: state.stats.edgeCount,
        currentForm: state.currentForm,
        coherence: this.field.calculateCoherence()
      }
    };

    this.recordManifestation('world', JSON.stringify(world).length);
    return { type: 'world', format: 'json', content: world };
  }

  /**
   * Manifest as text description
   */
  manifestText() {
    const state = this.field.getState();

    let text = `Field State Report
`;
    text += `==================

`;
    text += `Nodes: ${state.nodeCount} (Active: ${state.activeNodes}, Changing: ${state.changingNodes})
`;
    text += `Edges: ${state.edgeCount}
`;
    text += `Current Form: ${state.currentForm}
`;
    text += `Coherence: ${(state.coherence * 100).toFixed(1)}%

`;

    text += `Active Circuits:
`;
    for (const [channelId, count] of Object.entries(state.activeEdges || {})) {
      const channel = this.field.channels[channelId];
      text += `  ${channelId} (${channel?.name || 'Unknown'}): ${count} edges
`;
    }

    text += `
Changing Nodes:
`;
    for (const nodeId of state.changingNodes || []) {
      const node = this.field.getNode(nodeId);
      if (node) {
        text += `  ${nodeId}: Gate ${node.gate}, Line ${node.line}, Tension ${(node.tension * 100).toFixed(1)}%
`;
      }
    }

    this.recordManifestation('text', text.length);
    return { type: 'text', format: 'plain', content: text };
  }

  /**
   * Record manifestation
   */
  recordManifestation(type, size) {
    this.manifestations.push({
      timestamp: Date.now(),
      type,
      size
    });
  }

  /**
   * Get manifestation history
   */
  getHistory() {
    return this.manifestations;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = OutputManifestor;
}
