/**
 * FileIngestor - Absorbs files into the field.
 * Not storage. Transformation into graph topology.
 */
class FileIngestor {
  constructor(field) {
    this.field = field;
    this.supportedTypes = [
      'text/plain', 'text/html', 'text/css', 'text/javascript',
      'application/json', 'application/javascript',
      'image/png', 'image/jpeg', 'image/gif', 'image/svg+xml',
      'audio/mpeg', 'audio/wav', 'audio/ogg',
      'video/mp4', 'video/webm'
    ];

    // Ingestion history
    this.ingestions = [];
  }

  /**
   * Ingest a file from various sources
   */
  async ingest(source, options = {}) {
    let fileData;

    if (source instanceof File) {
      fileData = await this.ingestFileObject(source);
    } else if (typeof source === 'string') {
      if (source.startsWith('http')) {
        fileData = await this.ingestURL(source);
      } else {
        fileData = await this.ingestText(source, options.type || 'text/plain');
      }
    } else if (source instanceof ArrayBuffer) {
      fileData = await this.ingestBuffer(source, options.type);
    }

    if (!fileData) {
      throw new Error('Could not ingest source');
    }

    // Transform into field nodes
    const nodes = await this.transformToField(fileData);

    // Record
    this.ingestions.push({
      timestamp: Date.now(),
      source: fileData.name || 'unknown',
      type: fileData.type,
      size: fileData.size,
      nodeCount: nodes.length
    });

    return {
      fileData,
      nodes,
      ingestId: `ingest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    };
  }

  /**
   * Ingest a File object (from drag-drop or input)
   */
  async ingestFileObject(file) {
    const content = await this.readFile(file);
    return {
      name: file.name,
      type: file.type,
      size: file.size,
      content,
      lastModified: file.lastModified
    };
  }

  /**
   * Read file content based on type
   */
  readFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = (e) => reject(e);

      if (file.type.startsWith('text/') || file.type === 'application/json' || file.type === 'application/javascript') {
        reader.readAsText(file);
      } else if (file.type.startsWith('image/')) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsArrayBuffer(file);
      }
    });
  }

  /**
   * Ingest from URL
   */
  async ingestURL(url) {
    const response = await fetch(url);
    const blob = await response.blob();
    const content = await this.readFile(new File([blob], 'downloaded'));

    return {
      name: url.split('/').pop() || 'download',
      type: blob.type,
      size: blob.size,
      content,
      source: url
    };
  }

  /**
   * Ingest raw text
   */
  async ingestText(text, type = 'text/plain') {
    return {
      name: 'pasted_text',
      type,
      size: text.length,
      content: text
    };
  }

  /**
   * Ingest ArrayBuffer
   */
  async ingestBuffer(buffer, type = 'application/octet-stream') {
    return {
      name: 'buffer',
      type,
      size: buffer.byteLength,
      content: buffer
    };
  }

  /**
   * Transform ingested data into field nodes
   */
  async transformToField(fileData) {
    const nodes = [];

    switch (true) {
      case fileData.type.startsWith('text/'):
        nodes.push(...this.textToNodes(fileData));
        break;
      case fileData.type === 'application/json':
        nodes.push(...this.jsonToNodes(fileData));
        break;
      case fileData.type.startsWith('image/'):
        nodes.push(...await this.imageToNodes(fileData));
        break;
      case fileData.type.startsWith('audio/'):
        nodes.push(...await this.audioToNodes(fileData));
        break;
      case fileData.type.startsWith('video/'):
        nodes.push(...await this.videoToNodes(fileData));
        break;
      default:
        nodes.push(...this.genericToNodes(fileData));
    }

    return nodes;
  }

  /**
   * Text → semantic graph
   */
  textToNodes(fileData) {
    const text = fileData.content;
    const words = text.split(/\s+/).filter(w => w.length > 0);
    const sentences = text.split(/[.!?]+/).filter(s => s.length > 0);

    const nodes = [];
    const baseId = `text_${Date.now()}`;

    // Document node
    const docNode = this.field.createNode(`${baseId}_doc`, {
      being: 0.8,
      design: 0.9,
      movement: 0.3,
      evolution: 0.5,
      space: 0.4,
      gate: this.hashToGate(fileData.name),
      channelMode: 'DFF',
      x: 0, y: 0, z: 0,
      radius: 15,
      color: '#4a90d9'
    });
    nodes.push(docNode);

    // Sentence nodes
    for (let i = 0; i < Math.min(sentences.length, 50); i++) {
      const sent = sentences[i].trim();
      const sentNode = this.field.createNode(`${baseId}_sent_${i}`, {
        being: 0.6,
        design: 0.7,
        movement: 0.4,
        evolution: 0.3,
        space: 0.5,
        gate: this.hashToGate(sent),
        channelMode: 'RNN',
        x: Math.cos(i * 0.5) * 50,
        y: Math.sin(i * 0.5) * 50,
        z: i * 10,
        radius: 8,
        color: '#6bb5e7'
      });
      nodes.push(sentNode);

      // Connect to document
      this.field.createEdge(
        `${baseId}_edge_doc_${i}`,
        docNode.id,
        sentNode.id,
        '11-56',
        { weight: 0.8 }
      );

      // Connect sentences sequentially
      if (i > 0) {
        this.field.createEdge(
          `${baseId}_edge_seq_${i}`,
          `${baseId}_sent_${i-1}`,
          sentNode.id,
          '36-35',
          { weight: 0.6 }
        );
      }
    }

    // Word frequency attractors
    const wordFreq = {};
    for (const word of words) {
      const w = word.toLowerCase().replace(/[^a-z]/g, '');
      if (w.length > 3) {
        wordFreq[w] = (wordFreq[w] || 0) + 1;
      }
    }

    const topWords = Object.entries(wordFreq)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 20);

    for (let i = 0; i < topWords.length; i++) {
      const [word, freq] = topWords[i];
      const wordNode = this.field.createNode(`${baseId}_word_${i}`, {
        being: 0.4 + (freq / words.length) * 0.6,
        design: 0.5,
        movement: 0.2,
        evolution: 0.7,
        space: 0.3,
        gate: this.hashToGate(word),
        channelMode: 'Hopfield',
        x: Math.cos(i * 0.8) * 100,
        y: Math.sin(i * 0.8) * 100,
        z: -20,
        radius: 5 + freq,
        color: '#e74c3c'
      });
      nodes.push(wordNode);

      // Connect to document
      this.field.createEdge(
        `${baseId}_edge_word_${i}`,
        docNode.id,
        wordNode.id,
        '16-48',
        { weight: freq / 10 }
      );
    }

    return nodes;
  }

  /**
   * JSON → structured graph
   */
  jsonToNodes(fileData) {
    try {
      const data = JSON.parse(fileData.content);
      return this.objectToNodes(data, `json_${Date.now()}`);
    } catch (e) {
      // Fallback to text
      return this.textToNodes(fileData);
    }
  }

  /**
   * Recursive object → nodes
   */
  objectToNodes(obj, baseId, depth = 0, parentId = null) {
    const nodes = [];

    if (depth > 5) return nodes;

    const nodeId = `${baseId}_d${depth}_${Math.random().toString(36).substr(2, 5)}`;

    const node = this.field.createNode(nodeId, {
      being: 0.5,
      design: 0.8,
      movement: 0.3,
      evolution: 0.4,
      space: 0.6,
      gate: this.hashToGate(JSON.stringify(obj).slice(0, 50)),
      channelMode: 'DBN',
      x: depth * 30,
      y: Math.random() * 50,
      z: depth * 20,
      radius: 10 - depth,
      color: `hsl(${depth * 60}, 70%, 50%)`
    });
    nodes.push(node);

    if (parentId) {
      this.field.createEdge(
        `${nodeId}_parent`,
        parentId,
        nodeId,
        '53-42',
        { weight: 1.0 - depth * 0.15 }
      );
    }

    if (Array.isArray(obj)) {
      for (let i = 0; i < Math.min(obj.length, 20); i++) {
        const childNodes = this.objectToNodes(obj[i], `${baseId}_i${i}`, depth + 1, nodeId);
        nodes.push(...childNodes);
      }
    } else if (typeof obj === 'object' && obj !== null) {
      for (const [key, value] of Object.entries(obj).slice(0, 20)) {
        const keyNode = this.field.createNode(`${nodeId}_key_${key}`, {
          being: 0.6,
          design: 0.9,
          movement: 0.2,
          evolution: 0.3,
          space: 0.7,
          gate: this.hashToGate(key),
          channelMode: 'DFF',
          x: depth * 30 + 15,
          y: Math.random() * 30,
          z: depth * 20 + 10,
          radius: 6,
          color: '#f39c12'
        });
        nodes.push(keyNode);

        this.field.createEdge(
          `${nodeId}_keyedge_${key}`,
          nodeId,
          keyNode.id,
          '17-62',
          { weight: 0.9 }
        );

        const childNodes = this.objectToNodes(value, `${baseId}_v${key}`, depth + 1, keyNode.id);
        nodes.push(...childNodes);
      }
    }

    return nodes;
  }

  /**
   * Image → visual feature graph
   */
  async imageToNodes(fileData) {
    const nodes = [];
    const baseId = `img_${Date.now()}`;

    // Create image node
    const imgNode = this.field.createNode(`${baseId}_root`, {
      being: 0.9,
      design: 0.8,
      movement: 0.2,
      evolution: 0.4,
      space: 0.9,
      gate: 22, // Grace
      channelMode: 'CNN',
      x: 0, y: 0, z: 0,
      radius: 20,
      color: '#e91e63'
    });
    nodes.push(imgNode);

    // Create a canvas to analyze image
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
      img.src = fileData.content;
    });

    canvas.width = 100;
    canvas.height = 100;
    ctx.drawImage(img, 0, 0, 100, 100);

    const imageData = ctx.getImageData(0, 0, 100, 100);
    const pixels = imageData.data;

    // Sample pixels as nodes
    for (let y = 0; y < 100; y += 10) {
      for (let x = 0; x < 100; x += 10) {
        const idx = (y * 100 + x) * 4;
        const r = pixels[idx];
        const g = pixels[idx + 1];
        const b = pixels[idx + 2];

        const pixelNode = this.field.createNode(`${baseId}_px_${x}_${y}`, {
          being: (r + g + b) / (3 * 255),
          design: 0.5,
          movement: 0.1,
          evolution: 0.2,
          space: 0.8,
          gate: this.hashToGate(`${r},${g},${b}`),
          channelMode: 'CNN',
          x: (x - 50) * 2,
          y: (y - 50) * 2,
          z: 0,
          radius: 3,
          color: `rgb(${r},${g},${b})`
        });
        nodes.push(pixelNode);

        // Connect to root
        this.field.createEdge(
          `${baseId}_edge_${x}_${y}`,
          imgNode.id,
          pixelNode.id,
          '7-31',
          { weight: (r + g + b) / (3 * 255) * 0.5 }
        );
      }
    }

    return nodes;
  }

  /**
   * Audio → spectral graph
   */
  async audioToNodes(fileData) {
    const nodes = [];
    const baseId = `audio_${Date.now()}`;

    // Create audio context and analyze
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();

    let arrayBuffer;
    if (fileData.content instanceof ArrayBuffer) {
      arrayBuffer = fileData.content;
    } else {
      arrayBuffer = await fetch(fileData.content).then(r => r.arrayBuffer());
    }

    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);

    // Create root node
    const rootNode = this.field.createNode(`${baseId}_root`, {
      being: 0.8,
      design: 0.6,
      movement: 0.9,
      evolution: 0.5,
      space: 0.7,
      gate: 55, // Abundance
      channelMode: 'LSM',
      x: 0, y: 0, z: 0,
      radius: 18,
      color: '#9c27b0'
    });
    nodes.push(rootNode);

    // Analyze frequency data
    const analyser = audioContext.createAnalyser();
    analyser.fftSize = 256;
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    // Sample at different times
    const duration = audioBuffer.duration;
    const sampleCount = 20;

    for (let i = 0; i < sampleCount; i++) {
      const time = (i / sampleCount) * duration;

      // Create sample node
      const sampleNode = this.field.createNode(`${baseId}_sample_${i}`, {
        being: 0.5,
        design: 0.4,
        movement: 0.8,
        evolution: 0.3 + (i / sampleCount) * 0.4,
        space: 0.6,
        gate: this.hashToGate(`sample_${i}_${time}`),
        channelMode: 'EchoStateNetwork',
        x: Math.cos(i * 0.5) * 60,
        y: Math.sin(i * 0.5) * 60,
        z: time * 10,
        radius: 5 + (i / sampleCount) * 5,
        color: `hsl(${i * 18}, 70%, 50%)`
      });
      nodes.push(sampleNode);

      this.field.createEdge(
        `${baseId}_edge_${i}`,
        rootNode.id,
        sampleNode.id,
        '5-15',
        { weight: 0.7 }
      );

      // Connect sequential samples
      if (i > 0) {
        this.field.createEdge(
          `${baseId}_seq_${i}`,
          `${baseId}_sample_${i-1}`,
          sampleNode.id,
          '41-30',
          { weight: 0.8 }
        );
      }
    }

    return nodes;
  }

  /**
   * Video → temporal-spatial graph
   */
  async videoToNodes(fileData) {
    // Similar to audio but with frame analysis
    // Simplified: treat as audio + image hybrid
    const audioNodes = await this.audioToNodes(fileData);
    const baseId = `video_${Date.now()}`;

    // Add temporal frame nodes
    for (let i = 0; i < 10; i++) {
      const frameNode = this.field.createNode(`${baseId}_frame_${i}`, {
        being: 0.7,
        design: 0.8,
        movement: 0.6,
        evolution: 0.4 + i * 0.05,
        space: 0.9,
        gate: 20, // Contemplation
        channelMode: 'Transformer',
        x: i * 20,
        y: 0,
        z: i * 15,
        radius: 8,
        color: '#ff5722'
      });

      if (i > 0) {
        this.field.createEdge(
          `${baseId}_frame_edge_${i}`,
          `${baseId}_frame_${i-1}`,
          frameNode.id,
          '64-47',
          { weight: 0.9 }
        );
      }
    }

    return audioNodes;
  }

  /**
   * Generic fallback
   */
  genericToNodes(fileData) {
    const node = this.field.createNode(`generic_${Date.now()}`, {
      being: 0.5,
      design: 0.5,
      movement: 0.5,
      evolution: 0.5,
      space: 0.5,
      gate: this.hashToGate(fileData.name || 'unknown'),
      channelMode: 'DFF',
      x: 0, y: 0, z: 0,
      radius: 10,
      color: '#95a5a6'
    });

    return [node];
  }

  /**
   * Hash string to gate number (1-64)
   */
  hashToGate(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash = hash & hash;
    }
    return (Math.abs(hash) % 64) + 1;
  }

  /**
   * Get ingestion history
   */
  getHistory() {
    return this.ingestions;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FileIngestor;
}
