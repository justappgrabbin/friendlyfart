/**
 * FieldRenderer - Canvas/WebGL visualization of the MRNN field.
 * Fullscreen, immersive, morphing.
 */
class FieldRenderer {
  constructor(canvas, field) {
    this.canvas = canvas;
    this.field = field;
    this.ctx = canvas.getContext('2d');

    // Camera
    this.camera = {
      x: 0, y: 0, z: 500,
      rotationX: 0, rotationY: 0,
      zoom: 1.0,
      targetX: 0, targetY: 0, targetZ: 500
    };

    // Visual modes
    this.mode = 'void'; // void, mandala, tree, hexagram, neural, hardware, unified
    this.morphProgress = 0;
    this.morphTarget = null;
    this.morphDuration = 1618; // ms
    this.morphStartTime = 0;

    // Animation
    this.running = false;
    this.lastFrame = 0;

    // Colors
    this.colors = {
      void: '#000000',
      grid: '#1a1a2e',
      nodeActive: '#00d4ff',
      nodeLatent: '#1a1a2e',
      edgeStable: '#16213e',
      edgeActive: '#e94560',
      edgeCrossing: '#f39c12',
      monopole: '#ffd700',
      circuit: {
        Understanding: '#3498db',
        Sensing: '#2ecc71',
        Knowing: '#e74c3c',
        Centering: '#f39c12',
        Ego: '#9b59b6'
      }
    };

    // Particle system for crossings
    this.particles = [];

    // Event callbacks
    this.onRender = null;
    this.onNodeClick = null;
  }

  /**
   * Initialize renderer
   */
  init() {
    this.resize();
    window.addEventListener('resize', () => this.resize());

    // Mouse/touch interaction
    this.canvas.addEventListener('mousedown', (e) => this.onMouseDown(e));
    this.canvas.addEventListener('mousemove', (e) => this.onMouseMove(e));
    this.canvas.addEventListener('mouseup', (e) => this.onMouseUp(e));
    this.canvas.addEventListener('wheel', (e) => this.onWheel(e));

    return this;
  }

  resize() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    this.centerX = this.canvas.width / 2;
    this.centerY = this.canvas.height / 2;
  }

  /**
   * Start render loop
   */
  start() {
    this.running = true;
    this.lastFrame = performance.now();
    this.loop();
    return this;
  }

  stop() {
    this.running = false;
    return this;
  }

  /**
   * Main render loop
   */
  loop() {
    if (!this.running) return;

    const now = performance.now();
    const dt = now - this.lastFrame;
    this.lastFrame = now;

    // Update morph
    this.updateMorph(now);

    // Update particles
    this.updateParticles(dt);

    // Update camera
    this.updateCamera(dt);

    // Clear
    this.ctx.fillStyle = this.colors.void;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

    // Draw based on mode
    switch (this.mode) {
      case 'void':
        this.drawVoid();
        break;
      case 'mandala':
        this.drawMandala();
        break;
      case 'tree':
        this.drawTree();
        break;
      case 'hexagram':
        this.drawHexagram();
        break;
      case 'neural':
        this.drawNeural();
        break;
      case 'hardware':
        this.drawHardware();
        break;
      case 'unified':
        this.drawUnified();
        break;
    }

    // Draw particles (crossings, changing lines)
    this.drawParticles();

    // Draw Monopole
    this.drawMonopole();

    // Draw UI overlay
    this.drawOverlay();

    if (this.onRender) {
      this.onRender({ mode: this.mode, dt, nodeCount: this.field.getAllNodes().length });
    }

    requestAnimationFrame(() => this.loop());
  }

  /**
   * Draw the void (default state)
   */
  drawVoid() {
    // Subtle radial grid
    this.ctx.strokeStyle = this.colors.grid;
    this.ctx.lineWidth = 0.5;

    const rings = 8;
    for (let i = 1; i <= rings; i++) {
      const radius = (i / rings) * Math.min(this.centerX, this.centerY) * 0.8;
      this.ctx.beginPath();
      this.ctx.arc(this.centerX, this.centerY, radius, 0, Math.PI * 2);
      this.ctx.stroke();
    }

    // Radial lines
    const spokes = 12;
    for (let i = 0; i < spokes; i++) {
      const angle = (i / spokes) * Math.PI * 2;
      const maxR = Math.min(this.centerX, this.centerY) * 0.8;
      this.ctx.beginPath();
      this.ctx.moveTo(this.centerX, this.centerY);
      this.ctx.lineTo(
        this.centerX + Math.cos(angle) * maxR,
        this.centerY + Math.sin(angle) * maxR
      );
      this.ctx.stroke();
    }

    // Draw distant nodes (stars)
    const nodes = this.field.getAllNodes();
    const time = Date.now() * 0.001;

    for (const node of nodes) {
      const pulse = Math.sin(time * 2 + node.pulsePhase) * 0.3 + 0.7;
      const alpha = node.binaryState === 1 ? pulse * node.glowIntensity : 0.1;

      const screenPos = this.worldToScreen(node.x, node.y, node.z);

      this.ctx.beginPath();
      this.ctx.arc(screenPos.x, screenPos.y, node.radius * 0.5, 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
      this.ctx.fill();
    }
  }

  /**
   * Draw the mandala (64 gates ring)
   */
  drawMandala() {
    const centerX = this.centerX;
    const centerY = this.centerY;
    const maxRadius = Math.min(centerX, centerY) * 0.85;
    const innerRadius = maxRadius * 0.3;

    // Draw 64 gate sectors
    const gates = this.field.gatesData?.gates || [];
    const nodes = this.field.getAllNodes();

    for (let i = 0; i < 64; i++) {
      const angle = (i / 64) * Math.PI * 2 - Math.PI / 2;
      const nextAngle = ((i + 1) / 64) * Math.PI * 2 - Math.PI / 2;

      // Find nodes in this gate
      const gateNodes = nodes.filter(n => n.gate === i + 1);
      const activeCount = gateNodes.filter(n => n.binaryState === 1).length;
      const totalTension = gateNodes.reduce((sum, n) => sum + n.tension, 0);

      // Color based on activity
      let hue = (i / 64) * 360;
      let saturation = 30 + (activeCount / Math.max(gateNodes.length, 1)) * 70;
      let lightness = 20 + (totalTension / Math.max(gateNodes.length, 1)) * 40;

      // Draw sector
      this.ctx.beginPath();
      this.ctx.moveTo(centerX, centerY);
      this.ctx.arc(centerX, centerY, maxRadius, angle, nextAngle);
      this.ctx.closePath();
      this.ctx.fillStyle = `hsl(${hue}, ${saturation}%, ${lightness}%)`;
      this.ctx.fill();
      this.ctx.strokeStyle = 'rgba(255,255,255,0.1)';
      this.ctx.lineWidth = 1;
      this.ctx.stroke();

      // Draw hexagram
      const gate = gates[i];
      if (gate) {
        const midAngle = (angle + nextAngle) / 2;
        const labelRadius = (innerRadius + maxRadius) / 2;
        const lx = centerX + Math.cos(midAngle) * labelRadius;
        const ly = centerY + Math.sin(midAngle) * labelRadius;

        this.ctx.fillStyle = 'rgba(255,255,255,0.6)';
        this.ctx.font = '10px monospace';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(`${i + 1}`, lx, ly);
      }
    }

    // Draw center
    this.ctx.beginPath();
    this.ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
    this.ctx.fillStyle = 'rgba(0,0,0,0.8)';
    this.ctx.fill();
    this.ctx.strokeStyle = 'rgba(255,255,255,0.3)';
    this.ctx.lineWidth = 2;
    this.ctx.stroke();

    // Draw nodes on the ring
    for (const node of nodes) {
      const angle = ((node.gate - 1) / 64) * Math.PI * 2 - Math.PI / 2;
      const radius = innerRadius + (node.line / 6) * (maxRadius - innerRadius);

      const x = centerX + Math.cos(angle) * radius;
      const y = centerY + Math.sin(angle) * radius;

      const time = Date.now() * 0.001;
      const pulse = Math.sin(time * 3 + node.pulsePhase) * 0.5 + 0.5;
      const alpha = node.binaryState === 1 ? pulse * node.glowIntensity : 0.2;

      const circuit = this.getNodeCircuit(node);
      const color = this.colors.circuit[circuit] || '#ffffff';

      this.ctx.beginPath();
      this.ctx.arc(x, y, node.radius, 0, Math.PI * 2);
      this.ctx.fillStyle = color;
      this.ctx.globalAlpha = alpha;
      this.ctx.fill();
      this.ctx.globalAlpha = 1;

      // Glow for active nodes
      if (node.binaryState === 1) {
        this.ctx.beginPath();
        this.ctx.arc(x, y, node.radius * 3, 0, Math.PI * 2);
        const gradient = this.ctx.createRadialGradient(x, y, 0, x, y, node.radius * 3);
        gradient.addColorStop(0, color);
        gradient.addColorStop(1, 'transparent');
        this.ctx.fillStyle = gradient;
        this.ctx.globalAlpha = alpha * 0.3;
        this.ctx.fill();
        this.ctx.globalAlpha = 1;
      }
    }

    // Draw edges (channels)
    const edges = this.field.getAllEdges();
    for (const edge of edges) {
      const source = this.field.getNode(edge.sourceId);
      const target = this.field.getNode(edge.targetId);
      if (!source || !target) continue;

      const sAngle = ((source.gate - 1) / 64) * Math.PI * 2 - Math.PI / 2;
      const tAngle = ((target.gate - 1) / 64) * Math.PI * 2 - Math.PI / 2;
      const sRadius = innerRadius + (source.line / 6) * (maxRadius - innerRadius);
      const tRadius = innerRadius + (target.line / 6) * (maxRadius - innerRadius);

      const sx = centerX + Math.cos(sAngle) * sRadius;
      const sy = centerY + Math.sin(sAngle) * sRadius;
      const tx = centerX + Math.cos(tAngle) * tRadius;
      const ty = centerY + Math.sin(tAngle) * tRadius;

      this.ctx.beginPath();
      this.ctx.moveTo(sx, sy);

      // Curved connection
      const midX = (sx + tx) / 2;
      const midY = (sy + ty) / 2;
      const controlX = centerX + (midX - centerX) * 0.3;
      const controlY = centerY + (midY - centerY) * 0.3;

      this.ctx.quadraticCurveTo(controlX, controlY, tx, ty);

      const alpha = edge.active ? 0.6 : 0.1;
      const width = edge.active ? 2 : 0.5;

      if (edge.crossing) {
        this.ctx.strokeStyle = `rgba(243, 156, 18, ${alpha})`;
      } else {
        this.ctx.strokeStyle = `rgba(22, 33, 62, ${alpha})`;
      }

      this.ctx.lineWidth = width;
      this.ctx.stroke();
    }
  }

  /**
   * Draw tree of life
   */
  drawTree() {
    // Sephirot positions (simplified 2D layout)
    const sephirot = {
      Keter: { x: 0, y: -250 },
      Chochmah: { x: 150, y: -150 },
      Binah: { x: -150, y: -150 },
      Daat: { x: 0, y: -80 },
      Chesed: { x: 150, y: 0 },
      Gevurah: { x: -150, y: 0 },
      Tiferet: { x: 0, y: 0 },
      Netzach: { x: 150, y: 150 },
      Hod: { x: -150, y: 150 },
      Yesod: { x: 0, y: 150 },
      Malkhut: { x: 0, y: 250 }
    };

    const centerX = this.centerX;
    const centerY = this.centerY;
    const scale = Math.min(centerX, centerY) / 300;

    // Draw paths
    const paths = [
      ['Keter', 'Chochmah'], ['Keter', 'Binah'], ['Chochmah', 'Binah'],
      ['Chochmah', 'Chesed'], ['Binah', 'Gevurah'], ['Chesed', 'Gevurah'],
      ['Chesed', 'Tiferet'], ['Gevurah', 'Tiferet'], ['Tiferet', 'Daat'],
      ['Tiferet', 'Netzach'], ['Tiferet', 'Hod'], ['Netzach', 'Hod'],
      ['Netzach', 'Yesod'], ['Hod', 'Yesod'], ['Yesod', 'Malkhut'],
      ['Chesed', 'Netzach'], ['Gevurah', 'Hod'], ['Tiferet', 'Yesod']
    ];

    for (const [from, to] of paths) {
      const fx = centerX + sephirot[from].x * scale;
      const fy = centerY + sephirot[from].y * scale;
      const tx = centerX + sephirot[to].x * scale;
      const ty = centerY + sephirot[to].y * scale;

      this.ctx.beginPath();
      this.ctx.moveTo(fx, fy);
      this.ctx.lineTo(tx, ty);
      this.ctx.strokeStyle = 'rgba(255,255,255,0.2)';
      this.ctx.lineWidth = 2;
      this.ctx.stroke();
    }

    // Draw Sephirot
    for (const [name, pos] of Object.entries(sephirot)) {
      const x = centerX + pos.x * scale;
      const y = centerY + pos.y * scale;

      // Find nodes in this Sephira
      const nodes = this.field.getAllNodes().filter(n => {
        const center = this.field.inferCenterFromGate(n.gate);
        return center === name || this.mapCenterToSephira(center) === name;
      });

      const activeCount = nodes.filter(n => n.binaryState === 1).length;
      const radius = 20 + activeCount * 3;

      this.ctx.beginPath();
      this.ctx.arc(x, y, radius, 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(255, 215, 0, ${0.1 + activeCount * 0.1})`;
      this.ctx.fill();
      this.ctx.strokeStyle = 'rgba(255,215,0,0.5)';
      this.ctx.lineWidth = 2;
      this.ctx.stroke();

      // Label
      this.ctx.fillStyle = 'rgba(255,255,255,0.8)';
      this.ctx.font = '12px serif';
      this.ctx.textAlign = 'center';
      this.ctx.textBaseline = 'middle';
      this.ctx.fillText(name, x, y);
    }
  }

  /**
   * Draw hexagram mode
   */
  drawHexagram() {
    // Focus on a single hexagram
    const focusNode = this.field.getNode(this.field.monopole?.focusNodeId);
    const gate = focusNode?.gate || 1;
    const hex = this.field.gatesData?.gates.find(g => g.number === gate);

    if (!hex) return;

    const centerX = this.centerX;
    const centerY = this.centerY;
    const lineHeight = 40;
    const lineWidth = 200;
    const startY = centerY - (6 * lineHeight) / 2;

    // Draw 6 lines
    for (let i = 0; i < 6; i++) {
      const y = startY + i * lineHeight;
      const isYang = hex.hexagram[i] === '1';
      const isChanging = focusNode?.line === (6 - i) && focusNode?.regime === 'changing';

      this.ctx.lineWidth = isChanging ? 4 : 2;

      if (isYang) {
        // Solid line
        this.ctx.beginPath();
        this.ctx.moveTo(centerX - lineWidth / 2, y);
        this.ctx.lineTo(centerX + lineWidth / 2, y);
        this.ctx.strokeStyle = isChanging ? '#e74c3c' : '#3498db';
        this.ctx.stroke();
      } else {
        // Broken line
        const gap = 20;
        this.ctx.beginPath();
        this.ctx.moveTo(centerX - lineWidth / 2, y);
        this.ctx.lineTo(centerX - gap, y);
        this.ctx.moveTo(centerX + gap, y);
        this.ctx.lineTo(centerX + lineWidth / 2, y);
        this.ctx.strokeStyle = isChanging ? '#e74c3c' : '#3498db';
        this.ctx.stroke();
      }

      // Line number and judgment
      this.ctx.fillStyle = 'rgba(255,255,255,0.6)';
      this.ctx.font = '11px monospace';
      this.ctx.textAlign = 'right';
      this.ctx.fillText(`${6 - i}`, centerX - lineWidth / 2 - 10, y + 4);

      this.ctx.textAlign = 'left';
      this.ctx.fillText(hex.lines[5 - i].slice(0, 40), centerX + lineWidth / 2 + 10, y + 4);
    }

    // Gate info
    this.ctx.fillStyle = 'rgba(255,255,255,0.9)';
    this.ctx.font = 'bold 16px serif';
    this.ctx.textAlign = 'center';
    this.ctx.fillText(`${gate}. ${hex.name}`, centerX, startY - 30);
  }

  /**
   * Draw neural network mode
   */
  drawNeural() {
    const layers = 5;
    const nodesPerLayer = [5, 8, 12, 8, 5];
    const layerWidth = this.canvas.width * 0.8;
    const layerSpacing = layerWidth / (layers - 1);

    const nodes = this.field.getAllNodes();

    // Group nodes by circuit family
    const circuitGroups = {};
    for (const node of nodes) {
      const circuit = this.getNodeCircuit(node);
      if (!circuitGroups[circuit]) circuitGroups[circuit] = [];
      circuitGroups[circuit].push(node);
    }

    // Draw layers
    for (let l = 0; l < layers; l++) {
      const x = this.canvas.width * 0.1 + l * layerSpacing;
      const count = nodesPerLayer[l];
      const layerHeight = this.canvas.height * 0.8;
      const nodeSpacing = layerHeight / (count + 1);

      for (let n = 0; n < count; n++) {
        const y = this.canvas.height * 0.1 + (n + 1) * nodeSpacing;

        // Find matching node
        const nodeIndex = l * 8 + n;
        const node = nodes[nodeIndex];

        const radius = node ? 8 + node.attractorWeight * 8 : 8;
        const alpha = node ? (node.binaryState === 1 ? 1 : 0.3) : 0.2;
        const color = node ? (this.colors.circuit[this.getNodeCircuit(node)] || '#ffffff') : '#555';

        this.ctx.beginPath();
        this.ctx.arc(x, y, radius, 0, Math.PI * 2);
        this.ctx.fillStyle = color;
        this.ctx.globalAlpha = alpha;
        this.ctx.fill();
        this.ctx.globalAlpha = 1;
      }
    }

    // Draw connections
    const edges = this.field.getAllEdges();
    for (const edge of edges) {
      // Simplified: draw random connections between layers
      // In real implementation, map edges to layer positions
    }
  }

  /**
   * Draw hardware mode
   */
  drawHardware() {
    // Photonic components visualization
    const components = [
      { type: 'MZI', x: 100, y: 100, label: 'MZI' },
      { type: 'D2NN', x: 300, y: 100, label: 'Metasurface' },
      { type: 'SRAM', x: 500, y: 100, label: 'SRAM' },
      { type: 'ADC', x: 700, y: 100, label: 'ADC Array' },
      { type: 'Comparator', x: 500, y: 300, label: 'Monopole' }
    ];

    for (const comp of components) {
      // Draw component box
      this.ctx.fillStyle = 'rgba(30, 30, 50, 0.8)';
      this.ctx.fillRect(comp.x - 40, comp.y - 30, 80, 60);
      this.ctx.strokeStyle = 'rgba(0, 212, 255, 0.5)';
      this.ctx.lineWidth = 2;
      this.ctx.strokeRect(comp.x - 40, comp.y - 30, 80, 60);

      // Label
      this.ctx.fillStyle = '#00d4ff';
      this.ctx.font = '12px monospace';
      this.ctx.textAlign = 'center';
      this.ctx.fillText(comp.label, comp.x, comp.y + 5);

      // Status indicator
      const nodes = this.field.getAllNodes().filter(n => n.channelMode === comp.type);
      const active = nodes.filter(n => n.binaryState === 1).length;

      this.ctx.beginPath();
      this.ctx.arc(comp.x + 30, comp.y - 20, 4, 0, Math.PI * 2);
      this.ctx.fillStyle = active > 0 ? '#2ecc71' : '#e74c3c';
      this.ctx.fill();
    }

    // Draw light paths
    const time = Date.now() * 0.001;
    for (let i = 0; i < 5; i++) {
      const progress = (time + i * 0.2) % 1;
      const x = 100 + progress * 600;
      const y = 100 + Math.sin(progress * Math.PI * 2) * 50;

      this.ctx.beginPath();
      this.ctx.arc(x, y, 3, 0, Math.PI * 2);
      this.ctx.fillStyle = `rgba(255, 215, 0, ${1 - progress})`;
      this.ctx.fill();
    }
  }

  /**
   * Draw unified field (all modes superimposed)
   */
  drawUnified() {
    // Draw all modes at reduced opacity
    this.ctx.save();
    this.ctx.globalAlpha = 0.3;
    this.drawMandala();
    this.ctx.restore();

    this.ctx.save();
    this.ctx.globalAlpha = 0.2;
    this.drawTree();
    this.ctx.restore();

    this.ctx.save();
    this.ctx.globalAlpha = 0.15;
    this.drawNeural();
    this.ctx.restore();

    // Draw nodes with full opacity
    const nodes = this.field.getAllNodes();
    for (const node of nodes) {
      const screenPos = this.worldToScreen(node.x, node.y, node.z);

      const circuit = this.getNodeCircuit(node);
      const color = this.colors.circuit[circuit] || '#ffffff';

      this.ctx.beginPath();
      this.ctx.arc(screenPos.x, screenPos.y, node.radius, 0, Math.PI * 2);
      this.ctx.fillStyle = color;
      this.ctx.globalAlpha = node.binaryState === 1 ? node.glowIntensity : 0.2;
      this.ctx.fill();
    }
    this.ctx.globalAlpha = 1;
  }

  /**
   * Draw Monopole
   */
  drawMonopole() {
    const x = this.centerX;
    const y = this.centerY;
    const time = Date.now() * 0.001;

    // Dodecahedron representation (simplified as circle with 12 points)
    const radius = 30 + Math.sin(time * 2) * 5;

    this.ctx.beginPath();
    this.ctx.arc(x, y, radius, 0, Math.PI * 2);
    this.ctx.fillStyle = 'rgba(255, 215, 0, 0.1)';
    this.ctx.fill();
    this.ctx.strokeStyle = 'rgba(255, 215, 0, 0.5)';
    this.ctx.lineWidth = 2;
    this.ctx.stroke();

    // 12 points (faces)
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2 + time * 0.5;
      const px = x + Math.cos(angle) * radius;
      const py = y + Math.sin(angle) * radius;

      this.ctx.beginPath();
      this.ctx.arc(px, py, 3, 0, Math.PI * 2);
      this.ctx.fillStyle = 'rgba(255, 215, 0, 0.8)';
      this.ctx.fill();
    }

    // Pulse ring
    const pulseRadius = radius + Math.sin(time * 3) * 10;
    this.ctx.beginPath();
    this.ctx.arc(x, y, pulseRadius, 0, Math.PI * 2);
    this.ctx.strokeStyle = `rgba(255, 215, 0, ${0.3 + Math.sin(time * 3) * 0.2})`;
    this.ctx.lineWidth = 1;
    this.ctx.stroke();
  }

  /**
   * Draw particles (crossings, changing lines)
   */
  drawParticles() {
    const time = Date.now() * 0.001;

    for (const particle of this.particles) {
      const life = 1 - (time - particle.birth) / particle.lifespan;
      if (life <= 0) continue;

      const x = particle.x + Math.cos(time * 5 + particle.phase) * 10;
      const y = particle.y + Math.sin(time * 5 + particle.phase) * 10;

      this.ctx.beginPath();
      this.ctx.arc(x, y, particle.size * life, 0, Math.PI * 2);
      this.ctx.fillStyle = particle.color;
      this.ctx.globalAlpha = life;
      this.ctx.fill();
    }
    this.ctx.globalAlpha = 1;
  }

  /**
   * Update particles
   */
  updateParticles(dt) {
    const time = Date.now() * 0.001;
    this.particles = this.particles.filter(p => (time - p.birth) < p.lifespan);
  }

  /**
   * Add particle effect
   */
  addParticle(x, y, type = 'crossing') {
    const colors = {
      crossing: '#f39c12',
      changing: '#e74c3c',
      activate: '#2ecc71',
      morph: '#9b59b6'
    };

    this.particles.push({
      x, y,
      birth: Date.now() * 0.001,
      lifespan: 2,
      size: 5 + Math.random() * 10,
      color: colors[type] || '#ffffff',
      phase: Math.random() * Math.PI * 2
    });
  }

  /**
   * Draw UI overlay
   */
  drawOverlay() {
    // Mode indicator
    this.ctx.fillStyle = 'rgba(255,255,255,0.5)';
    this.ctx.font = '14px monospace';
    this.ctx.textAlign = 'left';
    this.ctx.fillText(`Mode: ${this.mode.toUpperCase()}`, 20, 30);

    // Stats
    const state = this.field.getState();
    this.ctx.fillText(`Nodes: ${state.nodeCount} | Active: ${state.activeNodes} | Changing: ${state.changingNodes}`, 20, 50);
    this.ctx.fillText(`Coherence: ${(state.coherence * 100).toFixed(1)}%`, 20, 70);

    // Fibonacci phase
    if (this.field.fibonacci) {
      this.ctx.fillText(`Fibonacci: ${this.field.fibonacci.phaseName} (${this.field.fibonacci.currentValue})`, 20, 90);
    }

    // Monopole position
    if (this.field.monopole) {
      this.ctx.fillText(`Monopole: ${this.field.monopole.position} | Circuit: ${this.field.monopole.activeCircuit || 'none'}`, 20, 110);
    }
  }

  /**
   * World to screen projection
   */
  worldToScreen(x, y, z) {
    const scale = this.camera.zoom * (500 / (500 + z - this.camera.z));
    return {
      x: this.centerX + (x - this.camera.x) * scale,
      y: this.centerY + (y - this.camera.y) * scale
    };
  }

  /**
   * Update camera
   */
  updateCamera(dt) {
    // Smooth camera movement
    this.camera.x += (this.camera.targetX - this.camera.x) * 0.05;
    this.camera.y += (this.camera.targetY - this.camera.y) * 0.05;
    this.camera.z += (this.camera.targetZ - this.camera.z) * 0.05;
  }

  /**
   * Update morph animation
   */
  updateMorph(now) {
    if (!this.morphTarget) return;

    const elapsed = now - this.morphStartTime;
    this.morphProgress = Math.min(1, elapsed / this.morphDuration);

    if (this.morphProgress >= 1) {
      this.mode = this.morphTarget;
      this.morphTarget = null;
      this.morphProgress = 0;
    }
  }

  /**
   * Trigger morph to new form
   */
  morphTo(targetForm) {
    this.morphTarget = targetForm;
    this.morphStartTime = performance.now();
    this.morphProgress = 0;

    // Add particle burst
    for (let i = 0; i < 20; i++) {
      this.addParticle(
        this.centerX + (Math.random() - 0.5) * 200,
        this.centerY + (Math.random() - 0.5) * 200,
        'morph'
      );
    }

    return this;
  }

  /**
   * Get circuit for a node
   */
  getNodeCircuit(node) {
    const channel = Object.values(this.field.channels).find(c => {
      return this.field.getNodeEdges(node.id).some(e => e.channelId === c.id);
    });
    return channel?.circuit || 'Understanding';
  }

  /**
   * Map center to Sephira
   */
  mapCenterToSephira(center) {
    const map = {
      'Head': 'Keter',
      'Ajna': 'Daat',
      'Throat': 'Tiferet',
      'G': 'Tiferet',
      'Heart': 'Chesed',
      'Spleen': 'Gevurah',
      'Sacral': 'Yesod',
      'Solar': 'Netzach',
      'Root': 'Malkhut'
    };
    return map[center] || 'Tiferet';
  }

  /**
   * Mouse interaction
   */
  onMouseDown(e) {
    this.dragging = true;
    this.lastMouseX = e.clientX;
    this.lastMouseY = e.clientY;

    // Check node click
    const rect = this.canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    const nodes = this.field.getAllNodes();
    for (const node of nodes) {
      const screenPos = this.worldToScreen(node.x, node.y, node.z);
      const dist = Math.sqrt((mx - screenPos.x) ** 2 + (my - screenPos.y) ** 2);

      if (dist < node.radius * 2) {
        node.activate(1.0);
        this.addParticle(screenPos.x, screenPos.y, 'activate');

        if (this.onNodeClick) {
          this.onNodeClick(node);
        }
        break;
      }
    }
  }

  onMouseMove(e) {
    if (!this.dragging) return;

    const dx = e.clientX - this.lastMouseX;
    const dy = e.clientY - this.lastMouseY;

    this.camera.targetX -= dx * 2;
    this.camera.targetY -= dy * 2;

    this.lastMouseX = e.clientX;
    this.lastMouseY = e.clientY;
  }

  onMouseUp(e) {
    this.dragging = false;
  }

  onWheel(e) {
    e.preventDefault();
    this.camera.targetZ += e.deltaY * 2;
    this.camera.targetZ = Math.max(100, Math.min(2000, this.camera.targetZ));
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FieldRenderer;
}
