/**
 * HapticOutput - Vibration patterns, pseudo-haptics.
 * The field speaks through touch.
 */
class HapticOutput {
  constructor() {
    this.enabled = true;
    this.device = this.detectDevice();

    // Vibration patterns (ms on, ms off)
    this.patterns = {
      stable: [50, 100],
      active: [100, 50],
      changing: [30, 30, 30, 30],
      crossing: [20, 40, 20, 40, 20],
      monopole: [200, 100],
      error: [100, 50, 100, 50, 100],
      success: [50, 50, 50],
      warning: [100, 100, 100]
    };

    // Audio-based haptic fallback (sub-bass)
    this.audioContext = null;
    this.hapticOsc = null;
  }

  /**
   * Detect available haptic capabilities
   */
  detectDevice() {
    const device = {
      hasVibrator: 'vibrate' in navigator,
      hasHapticEngine: false, // iOS specific
      hasGamepad: 'getGamepads' in navigator,
      hasAudio: typeof Audio !== 'undefined'
    };

    // Check for iOS haptic
    if (window.navigator && window.navigator.userAgent) {
      device.hasHapticEngine = /iPhone|iPad|iPod/.test(navigator.userAgent);
    }

    return device;
  }

  /**
   * Initialize audio fallback
   */
  initAudio() {
    if (!this.audioContext && this.device.hasAudio) {
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
    }
    return this;
  }

  /**
   * Trigger vibration pattern
   */
  vibrate(patternName, intensity = 1.0) {
    if (!this.enabled) return;

    const pattern = this.patterns[patternName] || this.patterns.stable;

    // Scale intensity
    const scaledPattern = pattern.map(d => Math.floor(d * (1 + (1 - intensity) * 0.5)));

    if (this.device.hasVibrator) {
      navigator.vibrate(scaledPattern);
    } else {
      // Audio fallback
      this.playAudioHaptic(patternName, intensity);
    }

    return this;
  }

  /**
   * Play audio-based haptic (sub-bass)
   */
  playAudioHaptic(type, intensity = 1.0) {
    if (!this.device.hasAudio || !this.audioContext) return;

    this.initAudio();

    const freqs = {
      stable: 60,
      active: 120,
      changing: 80,
      crossing: 100,
      monopole: 40,
      error: 200,
      success: 150,
      warning: 180
    };

    const freq = freqs[type] || 60;
    const osc = this.audioContext.createOscillator();
    const gain = this.audioContext.createGain();

    osc.type = 'sine';
    osc.frequency.value = freq;

    gain.gain.setValueAtTime(0, this.audioContext.currentTime);
    gain.gain.linearRampToValueAtTime(intensity * 0.5, this.audioContext.currentTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + 0.3);

    osc.connect(gain);
    gain.connect(this.audioContext.destination);

    osc.start();
    osc.stop(this.audioContext.currentTime + 0.3);
  }

  /**
   * Haptic sentence - complex pattern from field state
   */
  playHapticSentence(fieldState) {
    if (!this.enabled) return;

    // Build pattern from state
    const { activeNodes, changingNodes, coherence } = fieldState;

    let pattern = [];

    // Base rhythm from coherence
    const baseInterval = Math.floor(100 + (1 - coherence) * 200);

    // Add pulses for active nodes
    for (let i = 0; i < Math.min(activeNodes, 5); i++) {
      pattern.push(50, baseInterval);
    }

    // Add sharp pulses for changing nodes
    for (let i = 0; i < Math.min(changingNodes.length, 3); i++) {
      pattern.push(30, 30, 30, baseInterval);
    }

    if (pattern.length === 0) {
      pattern = this.patterns.stable;
    }

    if (this.device.hasVibrator) {
      navigator.vibrate(pattern);
    } else {
      // Play as sequence of audio haptics
      let delay = 0;
      for (let i = 0; i < pattern.length; i += 2) {
        const on = pattern[i];
        const off = pattern[i + 1] || 100;

        setTimeout(() => {
          this.playAudioHaptic('active', 0.3);
        }, delay);

        delay += on + off;
      }
    }

    return this;
  }

  /**
   * Enable/disable
   */
  setEnabled(enabled) {
    this.enabled = enabled;
    return this;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = HapticOutput;
}
