/**
 * SonicOutput - Field's raw voice. Gate tones, channel timbres, crossing beats.
 * Not speech. Music of the spheres.
 */
class SonicOutput {
  constructor() {
    this.audioContext = null;
    this.masterGain = null;
    this.oscillators = new Map();
    this.gainNodes = new Map();

    // Just intonation scale for 64 gates
    this.gatePitches = this.generateGatePitches();

    // Channel timbres
    this.timbres = {
      'DFF': { type: 'sine', harmonics: [1] },
      'DBN': { type: 'sine', harmonics: [1, 0.5, 0.25] },
      'LSM': { type: 'sawtooth', harmonics: [1, 0.3, 0.2, 0.1] },
      'RBM': { type: 'triangle', harmonics: [1, 0.4, 0.2] },
      'Hopfield': { type: 'sine', harmonics: [1, 0.8, 0.6, 0.4] },
      'SparseAutoencoder': { type: 'square', harmonics: [1, 0.2, 0.1] },
      'ELM': { type: 'sine', harmonics: [1, 0.3, 0.1, 0.05] },
      'Kohonen': { type: 'triangle', harmonics: [1, 0.5, 0.3, 0.2] },
      'CNN': { type: 'sawtooth', harmonics: [1, 0.4, 0.2, 0.1, 0.05] },
      'RNN': { type: 'sine', harmonics: [1, 0.6, 0.3, 0.15] },
      'LSTM': { type: 'triangle', harmonics: [1, 0.5, 0.25, 0.125] },
      'Seq2Seq': { type: 'sine', harmonics: [1, 0.4, 0.2] },
      'Autoencoder': { type: 'sine', harmonics: [1, 0.3, 0.1] },
      'Transformer': { type: 'sawtooth', harmonics: [1, 0.5, 0.3, 0.2, 0.1] },
      'GenerativeLM': { type: 'triangle', harmonics: [1, 0.6, 0.4, 0.2] },
      'ReinforcementLearner': { type: 'square', harmonics: [1, 0.3, 0.15] },
      'EpisodicMemory': { type: 'sine', harmonics: [1, 0.7, 0.5, 0.3] },
      'LiquidStateMachine': { type: 'sawtooth', harmonics: [1, 0.5, 0.3, 0.2, 0.1, 0.05] },
      'NeuralTuringMachine': { type: 'triangle', harmonics: [1, 0.4, 0.2, 0.1] },
      'DeconvNet': { type: 'sine', harmonics: [1, 0.5, 0.25] },
      'GAN': { type: 'square', harmonics: [1, 0.4, 0.2, 0.1] },
      'EchoStateNetwork': { type: 'sine', harmonics: [1, 0.8, 0.6, 0.4, 0.2] },
      'GRU': { type: 'triangle', harmonics: [1, 0.5, 0.3] },
      'VAE': { type: 'sine', harmonics: [1, 0.3, 0.15, 0.08] },
      'RBF': { type: 'sine', harmonics: [1, 0.6, 0.3] },
      'Attention': { type: 'triangle', harmonics: [1, 0.4, 0.2, 0.1] },
      'SpikeNetwork': { type: 'square', harmonics: [1, 0.5, 0.25] },
      'DirectPolicy': { type: 'sawtooth', harmonics: [1, 0.3, 0.15] },
      'MotorPolicy': { type: 'triangle', harmonics: [1, 0.5, 0.25, 0.125] },
      'Sensorimotor': { type: 'sine', harmonics: [1, 0.4, 0.2, 0.1] },
      'AdaptiveControl': { type: 'triangle', harmonics: [1, 0.6, 0.3, 0.15] },
      'ResourceAllocation': { type: 'square', harmonics: [1, 0.4, 0.2] },
      'MemoryPrediction': { type: 'sine', harmonics: [1, 0.5, 0.3, 0.2] },
      'EvolutionaryOptimizer': { type: 'sawtooth', harmonics: [1, 0.5, 0.3, 0.2, 0.1] },
      'BoundaryCrossing': { type: 'triangle', harmonics: [1, 0.4, 0.2, 0.1, 0.05] },
      'CaretakingRegulator': { type: 'sine', harmonics: [1, 0.6, 0.4, 0.2] }
    };

    // Monopole drone
    this.monopoleDrone = null;
    this.monopoleGain = null;

    // Enabled
    this.enabled = true;
    this.volume = 0.3;
  }

  /**
   * Initialize audio context
   */
  init() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
      this.masterGain = this.audioContext.createGain();
      this.masterGain.gain.value = this.volume;
      this.masterGain.connect(this.audioContext.destination);
    }
    return this;
  }

  /**
   * Generate just intonation pitches for 64 gates
   */
  generateGatePitches() {
    const baseFreq = 110; // A2
    const ratios = [
      1/1, 16/15, 9/8, 6/5, 5/4, 4/3, 45/32, 3/2,
      8/5, 5/3, 9/5, 15/8, 2/1, 32/15, 18/9, 12/5
    ];

    const pitches = [];
    for (let i = 0; i < 64; i++) {
      const octave = Math.floor(i / 16);
      const ratioIdx = i % 16;
      const freq = baseFreq * Math.pow(2, octave) * ratios[ratioIdx];
      pitches.push(freq);
    }

    return pitches;
  }

  /**
   * Play gate tone
   */
  playGateTone(gateNumber, duration = 1.0, velocity = 0.5) {
    if (!this.enabled || !this.audioContext) return;

    const freq = this.gatePitches[(gateNumber - 1) % 64];

    const osc = this.audioContext.createOscillator();
    const gain = this.audioContext.createGain();

    osc.type = 'sine';
    osc.frequency.value = freq;

    gain.gain.setValueAtTime(0, this.audioContext.currentTime);
    gain.gain.linearRampToValueAtTime(velocity * 0.3, this.audioContext.currentTime + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start();
    osc.stop(this.audioContext.currentTime + duration);

    return { osc, gain };
  }

  /**
   * Play channel timbre
   */
  playChannelTimbre(channelMode, freq, duration = 2.0, velocity = 0.5) {
    if (!this.enabled || !this.audioContext) return;

    const timbre = this.timbres[channelMode] || this.timbres['DFF'];

    const oscillators = [];
    const masterGain = this.audioContext.createGain();
    masterGain.gain.value = velocity * 0.2;

    for (let i = 0; i < timbre.harmonics.length; i++) {
      const osc = this.audioContext.createOscillator();
      const gain = this.audioContext.createGain();

      osc.type = timbre.type;
      osc.frequency.value = freq * (i + 1);

      gain.gain.value = timbre.harmonics[i];

      osc.connect(gain);
      gain.connect(masterGain);

      osc.start();
      osc.stop(this.audioContext.currentTime + duration);
      oscillators.push(osc);
    }

    masterGain.connect(this.masterGain);

    // Envelope
    masterGain.gain.setValueAtTime(0, this.audioContext.currentTime);
    masterGain.gain.linearRampToValueAtTime(velocity * 0.2, this.audioContext.currentTime + 0.1);
    masterGain.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration);

    return { oscillators, masterGain };
  }

  /**
   * Play crossing beat (binaural/interference)
   */
  playCrossingBeat(freqA, freqB, duration = 3.0) {
    if (!this.enabled || !this.audioContext) return;

    // Create binaural beat effect
    const oscA = this.audioContext.createOscillator();
    const oscB = this.audioContext.createOscillator();
    const gainA = this.audioContext.createGain();
    const gainB = this.audioContext.createGain();
    const merger = this.audioContext.createChannelMerger(2);

    oscA.type = 'sine';
    oscA.frequency.value = freqA;
    oscB.type = 'sine';
    oscB.frequency.value = freqB;

    gainA.gain.value = 0.15;
    gainB.gain.value = 0.15;

    oscA.connect(gainA);
    oscB.connect(gainB);
    gainA.connect(merger, 0, 0);
    gainB.connect(merger, 0, 1);
    merger.connect(this.masterGain);

    oscA.start();
    oscB.start();
    oscA.stop(this.audioContext.currentTime + duration);
    oscB.stop(this.audioContext.currentTime + duration);

    // Fade out
    gainA.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration);
    gainB.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration);

    return { oscA, oscB, beatFreq: Math.abs(freqA - freqB) };
  }

  /**
   * Start Monopole drone
   */
  startMonopoleDrone() {
    if (!this.enabled || !this.audioContext) return;

    if (this.monopoleDrone) {
      this.stopMonopoleDrone();
    }

    this.monopoleDrone = this.audioContext.createOscillator();
    this.monopoleGain = this.audioContext.createGain();

    this.monopoleDrone.type = 'sine';
    this.monopoleDrone.frequency.value = 55; // A1

    this.monopoleGain.gain.value = 0.05;

    this.monopoleDrone.connect(this.monopoleGain);
    this.monopoleGain.connect(this.masterGain);

    this.monopoleDrone.start();

    // Slowly modulate
    const lfo = this.audioContext.createOscillator();
    const lfoGain = this.audioContext.createGain();
    lfo.frequency.value = 0.1;
    lfoGain.gain.value = 5;
    lfo.connect(lfoGain);
    lfoGain.connect(this.monopoleDrone.frequency);
    lfo.start();

    return this;
  }

  /**
   * Stop Monopole drone
   */
  stopMonopoleDrone() {
    if (this.monopoleDrone) {
      this.monopoleDrone.stop();
      this.monopoleDrone = null;
    }
    if (this.monopoleGain) {
      this.monopoleGain = null;
    }
    return this;
  }

  /**
   * Update sonic output based on field state
   */
  update(fieldState) {
    if (!this.enabled || !this.audioContext) return;

    // Play tones for active gates
    const activeNodes = fieldState.activeNodes || 0;
    if (activeNodes > 0 && Math.random() < 0.1) {
      const randomGate = Math.floor(Math.random() * 64) + 1;
      this.playGateTone(randomGate, 0.5, 0.2);
    }

    // Play crossing beats for changing nodes
    const changingNodes = fieldState.changingNodes || [];
    if (changingNodes.length > 0 && Math.random() < 0.05) {
      const gateA = Math.floor(Math.random() * 64) + 1;
      const gateB = Math.floor(Math.random() * 64) + 1;
      const freqA = this.gatePitches[gateA - 1];
      const freqB = this.gatePitches[gateB - 1];
      this.playCrossingBeat(freqA, freqB, 2.0);
    }
  }

  /**
   * Set volume
   */
  setVolume(vol) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain) {
      this.masterGain.gain.value = this.volume;
    }
    return this;
  }

  /**
   * Enable/disable
   */
  setEnabled(enabled) {
    this.enabled = enabled;
    if (!enabled) {
      this.stopMonopoleDrone();
    } else {
      this.startMonopoleDrone();
    }
    return this;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = SonicOutput;
}
