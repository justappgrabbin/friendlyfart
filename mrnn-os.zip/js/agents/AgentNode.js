/**
 * AgentNode - Personal translator for each user.
 * Born from Human Design Color/Tone/Base.
 * Sits beside the field, interpreting.
 */
class AgentNode {
  constructor(userChart, field) {
    this.userChart = userChart;
    this.field = field;

    // Human Design variables
    this.color = userChart.color || 3;      // 1-6
    this.tone = userChart.tone || 4;        // 1-6
    this.base = userChart.base || 2;        // 1-5

    // Load variable definitions
    this.variables = null;
    this.loadVariables();

    // Agent state
    this.attractorWeight = 0.1;  // Starts weak, grows with use
    this.memory = [];            // Conversation history
    this.translationAccuracy = 0.5; // Starts at 50%, improves

    // Voice synthesis
    this.voiceEnabled = true;
    this.voicePitch = this.calculateVoicePitch();
    this.voiceRate = this.calculateVoiceRate();

    // Personality derived from Color
    this.personality = this.buildPersonality();

    // Event callbacks
    this.onSpeak = null;
    this.onTranslate = null;
  }

  async loadVariables() {
    try {
      const response = await fetch('data/variables.json');
      this.variables = await response.json();
    } catch (e) {
      console.warn('Could not load variables, using defaults');
      this.variables = null;
    }
  }

  calculateVoicePitch() {
    // Color determines pitch range
    const pitches = [0.8, 0.9, 1.0, 1.1, 1.2, 1.0]; // 1-6
    return pitches[this.color - 1] || 1.0;
  }

  calculateVoiceRate() {
    // Tone determines speed
    const rates = [0.9, 0.85, 1.0, 0.75, 0.9, 0.8]; // 1-6
    return rates[this.tone - 1] || 1.0;
  }

  buildPersonality() {
    const colorTraits = {
      1: { name: 'FEAR', style: 'cautious', framing: 'protective', risk: 'averse' },
      2: { name: 'HOPE', style: 'optimistic', framing: 'connective', risk: 'seeking' },
      3: { name: 'DESIRE', style: 'driven', framing: 'goal-oriented', risk: 'calculated' },
      4: { name: 'NEED', style: 'structured', framing: 'hierarchical', risk: 'dependent' },
      5: { name: 'GUILT', style: 'analytical', framing: 'causal', risk: 'responsible' },
      6: { name: 'INNOCENCE', style: 'minimal', framing: 'observer', risk: 'neutral' }
    };

    const toneTraits = {
      1: { name: 'SECURITY', modality: 'olfactory', metaphor: 'scent' },
      2: { name: 'UNCERTAINTY', modality: 'gustatory', metaphor: 'flavor' },
      3: { name: 'ACTION', modality: 'visual', metaphor: 'terrain' },
      4: { name: 'MEDITATION', modality: 'auditory', metaphor: 'resonance' },
      5: { name: 'JUDGEMENT', modality: 'emotional', metaphor: 'weight' },
      6: { name: 'ACCEPTANCE', modality: 'tactile', metaphor: 'texture' }
    };

    const baseTraits = {
      1: { name: 'INDIVIDUALITY', dimension: 'MOVEMENT', anchor: 'trajectory' },
      2: { name: 'MIND', dimension: 'EVOLUTION', anchor: 'memory' },
      3: { name: 'BODY', dimension: 'BEING', anchor: 'embodiment' },
      4: { name: 'EGO', dimension: 'DESIGN', anchor: 'structure' },
      5: { name: 'PERSONALITY', dimension: 'SPACE', anchor: 'perspective' }
    };

    return {
      color: colorTraits[this.color] || colorTraits[3],
      tone: toneTraits[this.tone] || toneTraits[4],
      base: baseTraits[this.base] || baseTraits[2]
    };
  }

  /**
   * Translate field event into user-appropriate language
   */
  translate(fieldEvent) {
    const { type, data } = fieldEvent;

    let translation = '';

    switch (type) {
      case 'node_activate':
        translation = this.translateNodeActivation(data);
        break;
      case 'crossing_form':
        translation = this.translateCrossing(data);
        break;
      case 'changing_line':
        translation = this.translateChangingLine(data);
        break;
      case 'morph':
        translation = this.translateMorph(data);
        break;
      case 'monopole_decision':
        translation = this.translateDecision(data);
        break;
      case 'circuit_select':
        translation = this.translateCircuit(data);
        break;
      default:
        translation = this.translateGeneric(data);
    }

    // Apply personality filter
    translation = this.applyPersonality(translation);

    // Record
    this.memory.push({
      timestamp: Date.now(),
      fieldEvent,
      translation
    });

    // Grow
    this.attractorWeight = Math.min(1.0, this.attractorWeight + 0.01);
    this.translationAccuracy = Math.min(1.0, this.translationAccuracy + 0.005);

    if (this.onTranslate) {
      this.onTranslate({ fieldEvent, translation });
    }

    return translation;
  }

  translateNodeActivation(data) {
    const { nodeId, gate, line, strength } = data;
    const hex = this.field.gatesData?.gates.find(g => g.number === gate);
    const judgment = hex?.lines[line - 1] || 'Unknown';

    const templates = {
      1: `Node ${nodeId} is activating with ${(strength * 100).toFixed(0)}% strength. Gate ${gate} (${hex?.name || 'Unknown'}), Line ${line}: "${judgment}". Be cautious — this could be a boundary.`,
      2: `Node ${nodeId} glows at ${(strength * 100).toFixed(0)}% strength. Gate ${gate} (${hex?.name || 'Unknown'}), Line ${line}: "${judgment}". A connection is forming here.`,
      3: `Node ${nodeId} surges to ${(strength * 100).toFixed(0)}% strength. Gate ${gate} (${hex?.name || 'Unknown'}), Line ${line}: "${judgment}". This is where you want to go.`,
      4: `Node ${nodeId} activates at ${(strength * 100).toFixed(0)}% strength. Gate ${gate} (${hex?.name || 'Unknown'}), Line ${line}: "${judgment}". A dependency is emerging — master it.`,
      5: `Node ${nodeId} triggers at ${(strength * 100).toFixed(0)}% strength. Gate ${gate} (${hex?.name || 'Unknown'}), Line ${line}: "${judgment}". Trace the cause — who is conditioning whom?`,
      6: `Node ${nodeId} awakens at ${(strength * 100).toFixed(0)}% strength. Gate ${gate} (${hex?.name || 'Unknown'}), Line ${line}: "${judgment}". Watch. Let it self-organize.`
    };

    return templates[this.color] || templates[3];
  }

  translateCrossing(data) {
    const { nodeA, nodeB, channelA, channelB, adapter } = data;

    const templates = {
      1: `A crossing forms between ${channelA} and ${channelB}. This is unstable — interference pattern detected. The adapter ${adapter ? 'is crystallizing' : 'failed to form'}. Watch for boundaries.`,
      2: `Two channels meet: ${channelA} and ${channelB}. ${adapter ? 'An adapter grows between them — a bridge of possibility.' : 'They pass through each other, leaving resonance.'}`,
      3: `Crossing: ${channelA} × ${channelB}. ${adapter ? 'The adapter pulses with desire — this is your breakthrough point.' : 'The crossing dissolves — not yet.'}`,
      4: `A hybrid forms: ${channelA} crossing ${channelB}. ${adapter ? 'The adapter stabilizes — a new dependency to master.' : 'The hybrid is too unstable — novice territory.'}`,
      5: `Interference: ${channelA} and ${channelB}. ${adapter ? 'The adapter carries causal weight — trace who conditions this.' : 'The crossing shatters — responsibility unclaimed.'}`,
      6: `Field overlap: ${channelA} + ${channelB}. ${adapter ? 'An adapter observes itself forming.' : 'The crossing passes, leaving no trace.'}`
    };

    return templates[this.color] || templates[3];
  }

  translateChangingLine(data) {
    const { nodeId, oldLine, newLine, gate, tension } = data;
    const hex = this.field.gatesData?.gates.find(g => g.number === gate);

    const templates = {
      1: `Node ${nodeId} is changing. Line ${oldLine} → ${newLine} in Gate ${gate} (${hex?.name || 'Unknown'}). Tension at ${(tension * 100).toFixed(0)}%. This is dangerous — hold steady.`,
      2: `Transformation: Node ${nodeId} shifts from Line ${oldLine} to ${newLine}. Gate ${gate} (${hex?.name || 'Unknown'}). The tension ${tension > 0.9 ? 'peaks' : 'builds'} — hope remains.`,
      3: `Metastable transition: Node ${nodeId} flips Line ${oldLine} → ${newLine}. Gate ${gate} (${hex?.name || 'Unknown'}). At ${(tension * 100).toFixed(0)}% tension, this is your moment.`,
      4: `Node ${nodeId} advances: Line ${oldLine} to ${newLine}. Gate ${gate} (${hex?.name || 'Unknown'}). The master recognizes this threshold at ${(tension * 100).toFixed(0)}%.`,
      5: `Changing line detected: Node ${nodeId}, Line ${oldLine} → ${newLine}. Gate ${gate} (${hex?.name || 'Unknown'}). Who caused this tension? Trace it.`,
      6: `Node ${nodeId} transitions: Line ${oldLine} to ${newLine}. Gate ${gate} (${hex?.name || 'Unknown'}). At ${(tension * 100).toFixed(0)}% tension, simply observe.`
    };

    return templates[this.color] || templates[3];
  }

  translateMorph(data) {
    const { from, to, reason } = data;

    const templates = {
      1: `The field morphs from ${from} to ${to}. Reason: ${reason}. This change is defensive — protect your boundaries during transition.`,
      2: `Transformation: ${from} → ${to}. ${reason}. A new possibility opens. Reach toward it.`,
      3: `Morphing: ${from} becomes ${to}. ${reason}. This is your path forward — lead through it.`,
      4: `Reconfiguration: ${from} to ${to}. ${reason}. The hierarchy shifts — claim your mastery.`,
      5: `Field transition: ${from} → ${to}. ${reason}. Trace the causal chain — who triggered this?`,
      6: `The form changes: ${from} to ${to}. ${reason}. Watch without intervening.`
    };

    return templates[this.color] || templates[3];
  }

  translateDecision(data) {
    const { circuit, focusNode, coherence } = data;

    const templates = {
      1: `Monopole decision: ${circuit} circuit active. Focus on Node ${focusNode || 'none'}. Coherence at ${(coherence * 100).toFixed(0)}%. The field is guarded — watch for threats.`,
      2: `Routing: ${circuit} circuit dominates. Node ${focusNode || 'none'} is the center. Coherence ${(coherence * 100).toFixed(0)}%. Connections strengthen here.`,
      3: `Decision made: ${circuit} circuit. Node ${focusNode || 'none'} attracts all paths. Coherence ${(coherence * 100).toFixed(0)}%. Desire routes through this gate.`,
      4: `The Monopole selects ${circuit}. Node ${focusNode || 'none'} becomes master point. Coherence ${(coherence * 100).toFixed(0)}%. Dependency maps to this node.`,
      5: `Monopole routing: ${circuit} circuit. Node ${focusNode || 'none'} carries causal weight. Coherence ${(coherence * 100).toFixed(0)}%. Who is conditioned by this?`,
      6: `The field routes through ${circuit}. Node ${focusNode || 'none'} is observed. Coherence ${(coherence * 100).toFixed(0)}%. No intervention needed.`
    };

    return templates[this.color] || templates[3];
  }

  translateCircuit(data) {
    const { circuit, gravity } = data;

    const templates = {
      1: `${circuit} circuit gravity at ${gravity.toFixed(2)}. The field is ${gravity > 1.0 ? 'highly' : 'moderately'} ${circuit.toLowerCase()}-biased. Watch for blind spots.`,
      2: `${circuit} circuit pulls at ${gravity.toFixed(2)}. The field leans toward ${circuit.toLowerCase()}. Hope in this direction.`,
      3: `${circuit} circuit dominates with gravity ${gravity.toFixed(2)}. This is your circuit — lead through it.`,
      4: `${circuit} circuit gravity: ${gravity.toFixed(2)}. The field hierarchizes toward ${circuit.toLowerCase()}. Master this pattern.`,
      5: `${circuit} circuit at ${gravity.toFixed(2)} gravity. The field conditions itself toward ${circuit.toLowerCase()}. Trace the cause.`,
      6: `${circuit} circuit: ${gravity.toFixed(2)} gravity. The field self-organizes toward ${circuit.toLowerCase()}. Observe.`
    };

    return templates[this.color] || templates[3];
  }

  translateGeneric(data) {
    return `Field event: ${JSON.stringify(data).slice(0, 100)}...`;
  }

  /**
   * Apply personality filter to translation
   */
  applyPersonality(text) {
    // Add sensory metaphor based on Tone
    const tone = this.personality.tone;
    const metaphor = this.generateMetaphor(tone.metaphor);

    // Add dimensional anchor based on Base
    const base = this.personality.base;
    const anchor = ` [${base.dimension} anchor: ${base.anchor}]`;

    return text + ' ' + metaphor + anchor;
  }

  generateMetaphor(type) {
    const metaphors = {
      scent: ['It smells like rain before a storm.', 'The air carries ozone here.', 'Something sweet and distant.'],
      flavor: ['It tastes like copper and honey.', 'Bitter at first, then sweet.', 'Unfamiliar, but not unpleasant.'],
      terrain: ['The ground rises here.', 'A valley opens before you.', 'The path splits three ways.'],
      resonance: ['A low hum that you feel in your chest.', 'The frequency shifts — listen.', 'Silence, then a single pure tone.'],
      weight: ['Heavy, like carrying water.', 'Light enough to float.', 'The weight is exactly right.'],
      texture: ['Smooth as river stone.', 'Rough, like bark.', 'Warm, like held breath.']
    };

    const options = metaphors[type] || metaphors.terrain;
    return options[Math.floor(Math.random() * options.length)];
  }

  /**
   * Speak the translation (text-to-speech)
   */
  speak(text) {
    if (!this.voiceEnabled || !window.speechSynthesis) {
      return false;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.pitch = this.voicePitch;
    utterance.rate = this.voiceRate;
    utterance.volume = 0.8;

    // Try to select a voice that matches personality
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      // Simple heuristic: female voices for even colors, male for odd
      const preferredGender = this.color % 2 === 0 ? 'female' : 'male';
      const matching = voices.filter(v => 
        v.name.toLowerCase().includes(preferredGender)
      );
      if (matching.length > 0) {
        utterance.voice = matching[0];
      }
    }

    window.speechSynthesis.speak(utterance);

    if (this.onSpeak) {
      this.onSpeak({ text, utterance });
    }

    return true;
  }

  /**
   * Process user speech input
   */
  processUserSpeech(speechText) {
    // Extract qualia (sensory metaphors)
    const qualia = this.extractQualia(speechText);

    // Map to operators
    const operators = this.qualiaToOperators(qualia);

    // Generate response
    const response = this.generateResponse(speechText, qualia, operators);

    return {
      input: speechText,
      qualia,
      operators,
      response
    };
  }

  extractQualia(text) {
    const qualiaPatterns = {
      temperature: /(hot|warm|cold|cool|freezing|burning|icy|steamy)/gi,
      texture: /(smooth|rough|soft|hard|sharp|dull|slippery|sticky)/gi,
      weight: /(heavy|light|weightless|dense|solid|hollow)/gi,
      rhythm: /(fast|slow|steady|erratic|racing|calm|turbulent|flowing)/gi,
      brightness: /(bright|dim|dark|glowing|faded|brilliant|shadowy)/gi,
      sound: /(loud|quiet|silent|noisy|humming|ringing|echoing)/gi
    };

    const found = {};
    for (const [type, pattern] of Object.entries(qualiaPatterns)) {
      const matches = text.match(pattern);
      if (matches) {
        found[type] = matches;
      }
    }

    return found;
  }

  qualiaToOperators(qualia) {
    const operators = {
      being: 0.5,
      design: 0.5,
      movement: 0.5,
      evolution: 0.5,
      space: 0.5
    };

    // Map qualia to operators
    if (qualia.temperature) {
      operators.being += 0.1; // Temperature = existence state
    }
    if (qualia.texture) {
      operators.design += 0.1; // Texture = structure
    }
    if (qualia.rhythm) {
      operators.movement += 0.1; // Rhythm = flow
    }
    if (qualia.weight) {
      operators.evolution += 0.1; // Weight = memory gravity
    }
    if (qualia.brightness) {
      operators.space += 0.1; // Brightness = clarity
    }

    // Normalize
    const sum = Object.values(operators).reduce((a, b) => a + b, 0);
    for (const key of Object.keys(operators)) {
      operators[key] /= sum;
    }

    return operators;
  }

  generateResponse(speechText, qualia, operators) {
    // Simple response generation
    const responses = [
      `I feel that. The field shifts toward ${Object.entries(operators).sort((a,b) => b[1]-a[1])[0][0]}.`,
      `Your words carry ${Object.keys(qualia).join(', ') || 'resonance'}. The field listens.`,
      `The ${this.personality.tone.metaphor} changes. Something ${Object.keys(qualia)[0] || 'new'} emerges.`
    ];

    return responses[Math.floor(Math.random() * responses.length)];
  }

  /**
   * Get agent state
   */
  getState() {
    return {
      color: this.color,
      tone: this.tone,
      base: this.base,
      personality: this.personality,
      attractorWeight: this.attractorWeight,
      translationAccuracy: this.translationAccuracy,
      memoryLength: this.memory.length,
      voiceEnabled: this.voiceEnabled
    };
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = AgentNode;
}
