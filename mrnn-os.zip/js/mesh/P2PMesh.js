/**
 * P2PMesh - Swarm network. Every instance is a node.
 * Resonance matching, shared attractors, agent collaboration.
 */
class P2PMesh {
  constructor(field) {
    this.field = field;
    this.peers = new Map();
    this.connections = new Map();
    this.localId = this.generateId();

    // Discovery
    this.discoveryInterval = null;
    this.heartbeatInterval = null;

    // Shared state
    this.sharedAttractors = new Map();
    this.sharedAdapters = new Map();

    // Event callbacks
    this.onPeerConnect = null;
    this.onPeerDisconnect = null;
    this.onSharedAdapter = null;
    this.onResonanceMatch = null;
  }

  generateId() {
    return `peer_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Initialize mesh
   */
  init(options = {}) {
    // In a real implementation, this would use WebRTC, WebSocket, or libp2p
    // For now, we simulate with localStorage/broadcast channel

    if (typeof BroadcastChannel !== 'undefined') {
      this.channel = new BroadcastChannel('mrnn-mesh');
      this.channel.onmessage = (e) => this.handleMessage(e.data);
    }

    // Start discovery
    this.discoveryInterval = setInterval(() => this.discover(), 5000);
    this.heartbeatInterval = setInterval(() => this.heartbeat(), 3000);

    // Announce presence
    this.announce();

    return this;
  }

  /**
   * Announce presence to mesh
   */
  announce() {
    const profile = this.getProfile();
    this.broadcast({
      type: 'announce',
      from: this.localId,
      profile,
      timestamp: Date.now()
    });
  }

  /**
   * Get local profile for resonance matching
   */
  getProfile() {
    const nodes = this.field.getAllNodes();
    const avgOperators = nodes.reduce((sum, n) => {
      const vec = n.getOperatorVector();
      return sum.map((v, i) => v + vec[i]);
    }, [0, 0, 0, 0, 0]).map(v => v / (nodes.length || 1));

    return {
      id: this.localId,
      operatorSignature: avgOperators,
      nodeCount: nodes.length,
      activeCircuit: this.field.monopole?.activeCircuit,
      color: this.field.agent?.color || 3,
      tone: this.field.agent?.tone || 4,
      base: this.field.agent?.base || 2
    };
  }

  /**
   * Discover peers
   */
  discover() {
    this.broadcast({
      type: 'discover',
      from: this.localId,
      timestamp: Date.now()
    });
  }

  /**
   * Send heartbeat
   */
  heartbeat() {
    this.broadcast({
      type: 'heartbeat',
      from: this.localId,
      timestamp: Date.now()
    });
  }

  /**
   * Broadcast message to mesh
   */
  broadcast(message) {
    if (this.channel) {
      this.channel.postMessage(message);
    }

    // Also store in localStorage for persistence
    try {
      const messages = JSON.parse(localStorage.getItem('mrnn-mesh') || '[]');
      messages.push({ ...message, receivedAt: Date.now() });
      if (messages.length > 100) messages.shift();
      localStorage.setItem('mrnn-mesh', JSON.stringify(messages));
    } catch (e) {
      // localStorage not available
    }
  }

  /**
   * Handle incoming message
   */
  handleMessage(message) {
    if (message.from === this.localId) return;

    switch (message.type) {
      case 'announce':
        this.handleAnnounce(message);
        break;
      case 'discover':
        this.announce(); // Respond to discovery
        break;
      case 'heartbeat':
        this.updatePeer(message.from, { lastSeen: Date.now() });
        break;
      case 'resonance':
        this.handleResonance(message);
        break;
      case 'adapter':
        this.handleSharedAdapter(message);
        break;
      case 'field_state':
        this.handleFieldState(message);
        break;
    }
  }

  /**
   * Handle peer announcement
   */
  handleAnnounce(message) {
    const peer = {
      id: message.from,
      profile: message.profile,
      connectedAt: Date.now(),
      lastSeen: Date.now()
    };

    this.peers.set(message.from, peer);

    // Check resonance
    const resonance = this.calculateResonance(this.getProfile(), message.profile);

    if (resonance > 0.7) {
      this.connections.set(message.from, peer);

      if (this.onResonanceMatch) {
        this.onResonanceMatch({ peer, resonance });
      }

      if (this.onPeerConnect) {
        this.onPeerConnect(peer);
      }
    }
  }

  /**
   * Calculate resonance between two profiles
   */
  calculateResonance(profileA, profileB) {
    // Operator signature similarity
    const opsA = profileA.operatorSignature;
    const opsB = profileB.operatorSignature;

    let dotProduct = 0;
    let magA = 0;
    let magB = 0;

    for (let i = 0; i < 5; i++) {
      dotProduct += opsA[i] * opsB[i];
      magA += opsA[i] ** 2;
      magB += opsB[i] ** 2;
    }

    const cosineSimilarity = dotProduct / (Math.sqrt(magA) * Math.sqrt(magB) || 1);

    // Color/Tone/Base compatibility
    const colorCompat = 1 - Math.abs(profileA.color - profileB.color) / 5;
    const toneCompat = 1 - Math.abs(profileA.tone - profileB.tone) / 5;
    const baseCompat = 1 - Math.abs(profileA.base - profileB.base) / 4;

    return (cosineSimilarity * 0.5 + colorCompat * 0.2 + toneCompat * 0.2 + baseCompat * 0.1);
  }

  /**
   * Handle resonance request
   */
  handleResonance(message) {
    const resonance = this.calculateResonance(this.getProfile(), message.profile);

    this.broadcast({
      type: 'resonance_response',
      from: this.localId,
      to: message.from,
      resonance,
      timestamp: Date.now()
    });
  }

  /**
   * Handle shared adapter
   */
  handleSharedAdapter(message) {
    const adapter = message.adapter;
    this.sharedAdapters.set(adapter.id, adapter);

    if (this.onSharedAdapter) {
      this.onSharedAdapter(adapter);
    }
  }

  /**
   * Handle field state from peer
   */
  handleFieldState(message) {
    // Create ghost nodes from peer's field
    for (const nodeData of message.state.nodes.slice(0, 20)) {
      const ghostId = `ghost_${message.from}_${nodeData.id}`;

      if (!this.field.getNode(ghostId)) {
        this.field.createNode(ghostId, {
          ...nodeData,
          being: nodeData.being * 0.3, // Ghosts are dim
          x: nodeData.x + (Math.random() - 0.5) * 100,
          y: nodeData.y + (Math.random() - 0.5) * 100,
          z: nodeData.z + (Math.random() - 0.5) * 100,
          radius: 3,
          color: 'rgba(255,255,255,0.3)'
        });
      }
    }
  }

  /**
   * Share an adapter with the mesh
   */
  shareAdapter(adapter) {
    this.broadcast({
      type: 'adapter',
      from: this.localId,
      adapter: {
        id: adapter.id,
        nodeA: adapter.nodeA.id,
        nodeB: adapter.nodeB.id,
        channelA: adapter.channelA,
        channelB: adapter.channelB,
        timestamp: Date.now()
      }
    });
  }

  /**
   * Share field state with mesh
   */
  shareFieldState() {
    const state = this.field.serialize();

    this.broadcast({
      type: 'field_state',
      from: this.localId,
      state: {
        nodes: state.nodes.slice(0, 50), // Limit for bandwidth
        stats: state.stats
      },
      timestamp: Date.now()
    });
  }

  /**
   * Update peer info
   */
  updatePeer(peerId, updates) {
    const peer = this.peers.get(peerId);
    if (peer) {
      Object.assign(peer, updates);
    }
  }

  /**
   * Get connected peers
   */
  getConnectedPeers() {
    return Array.from(this.connections.values());
  }

  /**
   * Get all known peers
   */
  getAllPeers() {
    return Array.from(this.peers.values());
  }

  /**
   * Disconnect from mesh
   */
  disconnect() {
    if (this.discoveryInterval) clearInterval(this.discoveryInterval);
    if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
    if (this.channel) this.channel.close();

    this.broadcast({
      type: 'disconnect',
      from: this.localId,
      timestamp: Date.now()
    });

    return this;
  }
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = P2PMesh;
}
