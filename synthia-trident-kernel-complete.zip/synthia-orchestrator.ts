/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  SYNTHIA ORCHESTRATOR — Decision-maker using MRNN coords    ║
 * ║  Routes entities based on their Trident-assigned address.   ║
 * ║  Synthia decides what the named thing can do.               ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import { EventEmitter } from 'events';
import { TridentAddressingService, TridentResult, EntityInput } from './trident-addressing-service';
import { EntityRegistry, RegistryEntry } from './entity-registry';
import { AgentProfileManager, AgentProfile } from './agent-profiles';

export interface OrchestrationRequest {
  entity_input: EntityInput;
  intent: 'execute' | 'query' | 'communicate' | 'create' | 'destroy' | 'transform' | 'observe';
  target_mesh?: string;
  required_capability?: string;
  priority: 'low' | 'normal' | 'high' | 'critical';
  requesting_agent?: string;
  context?: Record<string, any>;
}

export interface OrchestrationResult {
  request_id: string;
  status: 'routed' | 'queued' | 'rejected' | 'failed' | 'requires_approval';
  entity_id: string;
  assigned_mesh: string;
  assigned_agents: string[];
  policy_decision: string;
  trust_gate_passed: boolean;
  estimated_completion_ms: number;
  audit_trail: string[];
  rejection_reason?: string;
}

export interface PolicyRule {
  id: string;
  name: string;
  condition: (entry: RegistryEntry, request: OrchestrationRequest) => boolean;
  action: 'allow' | 'deny' | 'escalate' | 'throttle';
  priority: number;
  description: string;
}

export class SynthiaOrchestrator extends EventEmitter {
  private trident: TridentAddressingService;
  private registry: EntityRegistry;
  private agents: AgentProfileManager;
  private policies: PolicyRule[] = [];
  private queue: OrchestrationRequest[] = [];
  private active: Map<string, OrchestrationResult> = new Map();
  private auditLog: string[] = [];
  private stats = { routed: 0, rejected: 0, queued: 0, failed: 0 };

  constructor(
    trident: TridentAddressingService,
    registry: EntityRegistry,
    agents: AgentProfileManager
  ) {
    super();
    this.trident = trident;
    this.registry = registry;
    this.agents = agents;
    this.loadDefaultPolicies();
  }

  // ═══════════════════════════════════════════════════════════
  // Core: ingest → address → policy → route
  // ═══════════════════════════════════════════════════════════
  async ingest(request: OrchestrationRequest): Promise<OrchestrationResult> {
    const request_id = `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const audit: string[] = [`[${request_id}] Ingest started: ${request.intent}`];

    try {
      // Step 1: Trident addressing
      const tridentResult = await this.trident.register(request.entity_input);
      audit.push(`[${request_id}] Trident assigned: ${tridentResult.entity_id} → ${tridentResult.mrnn_address.mesh}`);

      // Step 2: Store in registry
      const registryEntry = await this.registry.storeEntity(tridentResult, {
        access_level: this.priorityToAccess(request.priority),
        tags: request.entity_input.context_tags
      });
      audit.push(`[${request_id}] Registry stored: lifecycle=${registryEntry.lifecycle}, trust=${registryEntry.trust_score.toFixed(2)}`);

      // Step 3: Policy check
      const policyOutcome = this.evaluatePolicies(registryEntry, request);
      audit.push(`[${request_id}] Policy: ${policyOutcome.action} (${policyOutcome.matched_rule || 'default'})`);

      if (policyOutcome.action === 'deny') {
        this.stats.rejected++;
        const result: OrchestrationResult = {
          request_id,
          status: 'rejected',
          entity_id: tridentResult.entity_id,
          assigned_mesh: tridentResult.mrnn_address.mesh,
          assigned_agents: [],
          policy_decision: policyOutcome.matched_rule || 'default_deny',
          trust_gate_passed: false,
          estimated_completion_ms: 0,
          audit_trail: audit,
          rejection_reason: policyOutcome.reason
        };
        this.emit('rejected', result);
        this.logAudit(audit);
        return result;
      }

      if (policyOutcome.action === 'escalate') {
        this.stats.queued++;
        this.queue.push(request);
        const result: OrchestrationResult = {
          request_id,
          status: 'requires_approval',
          entity_id: tridentResult.entity_id,
          assigned_mesh: tridentResult.mrnn_address.mesh,
          assigned_agents: [],
          policy_decision: policyOutcome.matched_rule || 'escalation',
          trust_gate_passed: false,
          estimated_completion_ms: -1,
          audit_trail: audit
        };
        this.emit('escalated', result);
        this.logAudit(audit);
        return result;
      }

      // Step 4: Trust gate
      const trustPassed = registryEntry.trust_score > 0.3 || request.priority === 'critical';
      audit.push(`[${request_id}] Trust gate: ${trustPassed ? 'PASS' : 'FAIL'} (score=${registryEntry.trust_score.toFixed(2)})`);

      if (!trustPassed && policyOutcome.action !== 'allow') {
        this.queue.push(request);
        this.stats.queued++;
        const result: OrchestrationResult = {
          request_id,
          status: 'queued',
          entity_id: tridentResult.entity_id,
          assigned_mesh: tridentResult.mrnn_address.mesh,
          assigned_agents: [],
          policy_decision: 'trust_gate_hold',
          trust_gate_passed: false,
          estimated_completion_ms: 5000,
          audit_trail: audit
        };
        this.emit('queued', result);
        this.logAudit(audit);
        return result;
      }

      // Step 5: Agent assignment
      const targetMesh = request.target_mesh || tridentResult.mrnn_address.mesh;
      const capableAgents = request.required_capability
        ? await this.agents.findCapableAgents(request.required_capability, targetMesh)
        : this.agents.getMeshPopulation(targetMesh);

      const selectedAgents = capableAgents
        .filter(a => a.current_load < a.max_concurrent)
        .slice(0, request.priority === 'critical' ? 3 : 1)
        .map(a => a.agent_id);

      for (const agentId of selectedAgents) {
        await this.agents.assignTask(agentId);
      }

      audit.push(`[${request_id}] Agents assigned: ${selectedAgents.join(', ') || 'NONE'}`);

      // Step 6: Route
      const result: OrchestrationResult = {
        request_id,
        status: 'routed',
        entity_id: tridentResult.entity_id,
        assigned_mesh: targetMesh,
        assigned_agents: selectedAgents,
        policy_decision: policyOutcome.matched_rule || 'default_allow',
        trust_gate_passed: trustPassed,
        estimated_completion_ms: this.estimateCompletion(request, selectedAgents.length),
        audit_trail: audit
      };

      this.active.set(request_id, result);
      this.stats.routed++;

      // Update registry lifecycle
      await this.registry.updateEntity(tridentResult.entity_id, { lifecycle: 'active' });

      this.emit('routed', result);
      this.logAudit(audit);
      return result;

    } catch (err) {
      this.stats.failed++;
      audit.push(`[${request_id}] FAILED: ${(err as Error).message}`);
      this.logAudit(audit);
      this.emit('failed', { request_id, error: (err as Error).message });

      return {
        request_id,
        status: 'failed',
        entity_id: 'unknown',
        assigned_mesh: 'error_space',
        assigned_agents: [],
        policy_decision: 'error',
        trust_gate_passed: false,
        estimated_completion_ms: 0,
        audit_trail: audit,
        rejection_reason: (err as Error).message
      };
    }
  }

  // ─── Policy Engine ─────────────────────────────────────────

  addPolicy(rule: PolicyRule): void {
    this.policies.push(rule);
    this.policies.sort((a, b) => b.priority - a.priority);
  }

  private evaluatePolicies(entry: RegistryEntry, request: OrchestrationRequest): {
    action: 'allow' | 'deny' | 'escalate' | 'throttle';
    matched_rule?: string;
    reason?: string;
  } {
    for (const policy of this.policies) {
      if (policy.condition(entry, request)) {
        return {
          action: policy.action,
          matched_rule: policy.name,
          reason: policy.description
        };
      }
    }
    return { action: 'allow', matched_rule: 'default_allow' };
  }

  private loadDefaultPolicies(): void {
    // Policy 1: Critical priority bypass
    this.addPolicy({
      id: 'pol_001',
      name: 'critical_bypass',
      condition: (_e, r) => r.priority === 'critical',
      action: 'allow',
      priority: 100,
      description: 'Critical priority requests bypass standard trust gates'
    });

    // Policy 2: Destructive modulation requires escalation
    this.addPolicy({
      id: 'pol_002',
      name: 'destructive_escalation',
      condition: (e, _r) => e.mrnn_address.modulation_state === 'destructive',
      action: 'escalate',
      priority: 90,
      description: 'Destructive modulation entities require human approval'
    });

    // Policy 3: Low trust + high intent = throttle
    this.addPolicy({
      id: 'pol_003',
      name: 'low_trust_throttle',
      condition: (e, r) => e.trust_score < 0.2 && ['execute', 'destroy', 'transform'].includes(r.intent),
      action: 'throttle',
      priority: 80,
      description: 'Low trust entities throttled for destructive intents'
    });

    // Policy 4: Suspended lifecycle = deny
    this.addPolicy({
      id: 'pol_004',
      name: 'suspended_denial',
      condition: (e, _r) => e.lifecycle === 'suspended',
      action: 'deny',
      priority: 95,
      description: 'Suspended entities cannot participate'
    });

    // Policy 5: Adult sovereign content gate
    this.addPolicy({
      id: 'pol_005',
      name: 'adult_sovereign_gate',
      condition: (e, r) => e.access_level === 'adult_sovereign' && r.intent === 'communicate',
      action: 'allow',
      priority: 85,
      description: 'Adult sovereign access permitted for communication'
    });

    // Policy 6: Public mesh fast track
    this.addPolicy({
      id: 'pol_006',
      name: 'public_fast_track',
      condition: (e, _r) => e.mrnn_address.mesh === 'public_space',
      action: 'allow',
      priority: 70,
      description: 'Public mesh entities fast-tracked'
    });
  }

  // ─── Queue Management ────────────────────────────────────

  async processQueue(batchSize = 5): Promise<OrchestrationResult[]> {
    const toProcess = this.queue.splice(0, batchSize);
    return Promise.all(toProcess.map(req => this.ingest(req)));
  }

  getQueueLength(): number {
    return this.queue.length;
  }

  // ─── Completion & Cleanup ──────────────────────────────────

  async complete(request_id: string, outcome: 'success' | 'failure' | 'partial'): Promise<void> {
    const result = this.active.get(request_id);
    if (!result) return;

    // Release agents
    for (const agentId of result.assigned_agents) {
      await this.agents.releaseTask(agentId);
    }

    // Record interaction for trust evolution
    const interactionOutcome = outcome === 'success' ? 'success' : outcome === 'failure' ? 'failure' : 'ambiguous';
    await this.registry.recordInteraction(result.entity_id, interactionOutcome);

    this.active.delete(request_id);
    this.emit('completed', { request_id, outcome });
  }

  // ─── Helpers ─────────────────────────────────────────────

  private priorityToAccess(priority: OrchestrationRequest['priority']): RegistryEntry['access_level'] {
    const map: Record<string, RegistryEntry['access_level']> = {
      low: 'public',
      normal: 'general',
      high: 'restricted',
      critical: 'adult_sovereign'
    };
    return map[priority] || 'general';
  }

  private estimateCompletion(request: OrchestrationRequest, agentCount: number): number {
    const base = { execute: 2000, query: 500, communicate: 1000, create: 3000, destroy: 1500, transform: 4000, observe: 800 };
    const priorityMult = { low: 2.0, normal: 1.0, high: 0.7, critical: 0.3 };
    return Math.floor(base[request.intent] * (priorityMult[request.priority] || 1.0) / (agentCount || 1));
  }

  private logAudit(entries: string[]): void {
    this.auditLog.push(...entries);
    if (this.auditLog.length > 10000) this.auditLog = this.auditLog.slice(-5000);
  }

  getAuditLog(limit = 100): string[] {
    return this.auditLog.slice(-limit);
  }

  getStats() {
    return { ...this.stats, active: this.active.size, queued: this.queue.length };
  }
}

export default SynthiaOrchestrator;
