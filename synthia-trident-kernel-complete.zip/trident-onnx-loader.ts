/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  ONYX RUNTIME LOADER — Trident_synthia.onnx integration      ║
 * ║  Production-ready ONNX inference for Trident addressing.     ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import * as ort from 'onnxruntime-node';
import { MRNNAddress, EntityInput } from './trident-addressing-service';

export interface ONNXModelConfig {
  modelPath: string;
  inputDim: number;
  outputDim: number;
  warmupRuns: number;
  maxBatchSize: number;
}

export interface ONNXInferenceResult {
  mesh_logits: Float32Array;
  layer_logits: Float32Array;
  center_logits: Float32Array;
  gate_logits: Float32Array;
  line_pred: number;
  color_pred: number;
  tone_pred: number;
  zodiac_logits: Float32Array;
  modulation_logits: Float32Array;
  confidence: number;
  processing_ms: number;
}

export class TridentONNXLoader {
  private session: ort.InferenceSession | null = null;
  private config: ONNXModelConfig;
  private isLoaded: boolean = false;
  private inputCache: Map<string, Float32Array> = new Map();

  constructor(config?: Partial<ONNXModelConfig>) {
    this.config = {
      modelPath: './models/trident_synthia.onnx',
      inputDim: 512,
      outputDim: 128,
      warmupRuns: 3,
      maxBatchSize: 16,
      ...config
    };
  }

  async load(): Promise<void> {
    if (this.isLoaded) return;

    try {
      this.session = await ort.InferenceSession.create(this.config.modelPath, {
        executionProviders: ['cpu'], // or 'cuda' if GPU available
        graphOptimizationLevel: 'all'
      });

      // Warmup runs
      const dummyInput = new Float32Array(this.config.inputDim).fill(0.1);
      for (let i = 0; i < this.config.warmupRuns; i++) {
        await this.runInference(dummyInput);
      }

      this.isLoaded = true;
      console.log(`[TridentONNX] Model loaded: ${this.config.modelPath}`);
    } catch (err) {
      console.error(`[TridentONNX] Failed to load model: ${(err as Error).message}`);
      throw err;
    }
  }

  async infer(entity: EntityInput): Promise<{
    mesh: string;
    layer: string;
    center: string;
    gate: string;
    line: number;
    color: number;
    tone: number;
    zodiac: string;
    modulation: MRNNAddress['modulation_state'];
    confidence: number;
    symbolic: Record<string, any>;
  }> {
    if (!this.isLoaded) await this.load();

    const start = performance.now();

    // Encode entity to tensor
    const inputTensor = this.encodeEntity(entity);

    // Run ONNX inference
    const rawResult = await this.runInference(inputTensor);

    // Decode outputs to MRNN address components
    const decoded = this.decodeOutputs(rawResult);

    const processing_ms = performance.now() - start;

    // Build symbolic fields from raw logits
    const symbolic = this.extractSymbolic(decoded, entity);

    return {
      mesh: decoded.mesh,
      layer: decoded.layer,
      center: decoded.center,
      gate: decoded.gate,
      line: decoded.line,
      color: decoded.color,
      tone: decoded.tone,
      zodiac: decoded.zodiac,
      modulation: decoded.modulation,
      confidence: decoded.confidence,
      symbolic
    };
  }

  async inferBatch(entities: EntityInput[]): Promise<Array<ReturnType<typeof this.infer>>> {
    const batchSize = Math.min(entities.length, this.config.maxBatchSize);
    const results = [];

    for (let i = 0; i < entities.length; i += batchSize) {
      const batch = entities.slice(i, i + batchSize);
      const batchResults = await Promise.all(batch.map(e => this.infer(e)));
      results.push(...batchResults);
    }

    return results;
  }

  // ─── Private: Encoding ─────────────────────────────────────

  private encodeEntity(entity: EntityInput): Float32Array {
    const cacheKey = JSON.stringify(entity.raw_payload) + entity.source_type;
    if (this.inputCache.has(cacheKey)) return this.inputCache.get(cacheKey)!;

    const vec = new Float32Array(this.config.inputDim).fill(0);

    // Encode source type (one-hot-ish, first 8 dims)
    const types = ['task', 'agent', 'file', 'message', 'api_call', 'user_action', 'system_event'];
    const typeIdx = types.indexOf(entity.source_type);
    if (typeIdx >= 0) vec[typeIdx] = 1.0;

    // Encode payload text (simple char frequency + semantic hash)
    const text = JSON.stringify(entity.raw_payload).toLowerCase();
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = ((hash << 5) - hash) + text.charCodeAt(i);
      hash |= 0;
      // Distribute across dimensions 8-256
      const dim = 8 + (Math.abs(hash) % 248);
      vec[dim] += 0.01;
    }

    // Encode tags (dims 256-384)
    const tags = entity.context_tags || [];
    for (let i = 0; i < Math.min(tags.length, 128); i++) {
      const tagHash = tags[i].split('').reduce((h, c) => ((h << 5) - h) + c.charCodeAt(0), 0);
      vec[256 + i] = Math.abs(tagHash % 100) / 100;
    }

    // Encode priority (dim 384)
    vec[384] = entity.priority_hint || 0.5;

    // Encode timestamp features (dims 385-400)
    const ts = entity.timestamp || Date.now();
    const date = new Date(ts);
    vec[385] = date.getHours() / 24;
    vec[386] = date.getDay() / 7;
    vec[387] = date.getMonth() / 12;
    vec[388] = Math.sin(2 * Math.PI * date.getHours() / 24); // circadian
    vec[389] = Math.cos(2 * Math.PI * date.getMonth() / 12); // seasonal

    // Normalize
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    if (norm > 0) {
      for (let i = 0; i < vec.length; i++) vec[i] /= norm;
    }

    this.inputCache.set(cacheKey, vec);
    if (this.inputCache.size > 1000) {
      const firstKey = this.inputCache.keys().next().value;
      this.inputCache.delete(firstKey);
    }

    return vec;
  }

  // ─── Private: ONNX Inference ───────────────────────────────

  private async runInference(input: Float32Array): Promise<ONNXInferenceResult> {
    if (!this.session) throw new Error('ONNX session not initialized');

    const tensor = new ort.Tensor('float32', input, [1, this.config.inputDim]);
    const feeds = { input: tensor };
    const results = await this.session.run(feeds);

    // Extract outputs (names must match model output names)
    const mesh_logits = results.mesh_logits?.data as Float32Array || new Float32Array(8);
    const layer_logits = results.layer_logits?.data as Float32Array || new Float32Array(8);
    const center_logits = results.center_logits?.data as Float32Array || new Float32Array(8);
    const gate_logits = results.gate_logits?.data as Float32Array || new Float32Array(9);
    const line_pred = results.line_pred?.data as Float32Array || new Float32Array([3]);
    const color_pred = results.color_pred?.data as Float32Array || new Float32Array([3]);
    const tone_pred = results.tone_pred?.data as Float32Array || new Float32Array([3]);
    const zodiac_logits = results.zodiac_logits?.data as Float32Array || new Float32Array(12);
    const modulation_logits = results.modulation_logits?.data as Float32Array || new Float32Array(5);
    const confidence = results.confidence?.data as Float32Array || new Float32Array([0.5]);

    return {
      mesh_logits,
      layer_logits,
      center_logits,
      gate_logits,
      line_pred: Math.round(line_pred[0]),
      color_pred: Math.round(color_pred[0]),
      tone_pred: Math.round(tone_pred[0]),
      zodiac_logits,
      modulation_logits,
      confidence: confidence[0],
      processing_ms: 0 // filled by caller
    };
  }

  // ─── Private: Decoding ─────────────────────────────────────

  private decodeOutputs(result: ONNXInferenceResult): {
    mesh: string;
    layer: string;
    center: string;
    gate: string;
    line: number;
    color: number;
    tone: number;
    zodiac: string;
    modulation: MRNNAddress['modulation_state'];
    confidence: number;
  } {
    const meshes = ['construction_space', 'agent_space', 'knowledge_space', 'communication_space', 'interface_space', 'priority_space', 'general_space', 'error_space'];
    const layers = ['task_execution', 'autonomous_operation', 'data_management', 'interaction_layer', 'api_gateway', 'critical_path', 'general'];
    const centers = ['creative_direction', 'mental_processing', 'emotional_intelligence', 'manifestation', 'communication', 'intuitive_awareness', 'will_power', 'identity_definition'];
    const gates = ['entry', 'initiation', 'knowing', 'logic', 'feelings', 'building', 'expression', 'power', 'identity'];
    const zodiacs = ['cardinal_fire', 'fixed_earth', 'mutable_air', 'cardinal_water', 'fixed_fire', 'mutable_earth', 'cardinal_air', 'fixed_water', 'mutable_fire', 'cardinal_earth', 'fixed_air', 'mutable_water'];
    const modulations: MRNNAddress['modulation_state'][] = ['constructive', 'destructive', 'neutral', 'emergent', 'resonant'];

    return {
      mesh: meshes[this.argmax(result.mesh_logits)],
      layer: layers[this.argmax(result.layer_logits)],
      center: centers[this.argmax(result.center_logits)],
      gate: gates[this.argmax(result.gate_logits)],
      line: Math.max(1, Math.min(6, result.line_pred)),
      color: Math.max(1, Math.min(6, result.color_pred)),
      tone: Math.max(1, Math.min(6, result.tone_pred)),
      zodiac: zodiacs[this.argmax(result.zodiac_logits)],
      modulation: modulations[this.argmax(result.modulation_logits)],
      confidence: Math.max(0, Math.min(1, result.confidence))
    };
  }

  // ─── Private: Symbolic Extraction ──────────────────────────

  private extractSymbolic(decoded: ReturnType<typeof this.decodeOutputs>, entity: EntityInput): Record<string, any> {
    const payload = JSON.stringify(entity.raw_payload).toLowerCase();
    return {
      entropy: payload.length > 100 ? 'high' : 'low',
      coherence: decoded.confidence > 0.7 ? 'stable' : 'unstable',
      trajectory: decoded.modulation === 'constructive' ? 'ascending' : decoded.modulation === 'destructive' ? 'descending' : 'lateral',
      density: (entity.context_tags?.length || 0) > 3 ? 'dense' : 'sparse',
      harmonic: (decoded.line + decoded.color + decoded.tone) % 7 === 0 ? 'perfect' : 'imperfect',
      ingress: entity.source_type === 'task' ? 'active' : entity.source_type === 'agent' ? 'autonomous' : 'passive',
      egress: decoded.modulation === 'emergent' ? 'unknown' : 'determined',
      model_confidence: decoded.confidence,
      input_richness: (entity.context_tags?.length || 0) * 0.1 + (entity.priority_hint || 0.3)
    };
  }

  private argmax(arr: Float32Array): number {
    let maxIdx = 0;
    let maxVal = arr[0];
    for (let i = 1; i < arr.length; i++) {
      if (arr[i] > maxVal) { maxVal = arr[i]; maxIdx = i; }
    }
    return maxIdx;
  }

  getSessionInfo(): { loaded: boolean; path: string; inputDim: number } {
    return { loaded: this.isLoaded, path: this.config.modelPath, inputDim: this.config.inputDim };
  }

  dispose(): void {
    this.session?.release();
    this.session = null;
    this.isLoaded = false;
    this.inputCache.clear();
  }
}

export const onnxLoader = new TridentONNXLoader();
export default onnxLoader;
