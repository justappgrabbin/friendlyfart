/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  INTEGRATION DEMO v2 — Full Trident → Synthia pipeline      ║
 * ║  Demonstrates: ONNX inference, WebSocket gateway, resonance ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import { trident, EntityInput } from './trident-addressing-service';
import { registry } from './entity-registry';
import { agentProfiles } from './agent-profiles';
import SynthiaOrchestrator from './synthia-orchestrator';
import { resonanceScorer } from './resonance-scorer';
import { auditMemory } from './audit-memory';
import { TridentONNXLoader } from './trident-onnx-loader';

async function runDemoV2() {
  console.log('🌊 Synthia Trident Kernel v2 — Full Integration Demo\n');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

  await trident.initialize();
  const orchestrator = new SynthiaOrchestrator(trident, registry, agentProfiles);

  // Try ONNX
  let onnxLoader: TridentONNXLoader | null = null;
  try {
    onnxLoader = new TridentONNXLoader({ modelPath: './models/trident_synthia.onnx' });
    await onnxLoader.load();
    console.log('✅ ONNX Runtime: Trident_synthia.onnx loaded\n');
  } catch {
    console.log('⚠️  ONNX Runtime: Using deterministic fallback\n');
  }

  // ═══════════════════════════════════════════════════════════
  // 1. Register diverse entities (with ONNX if available)
  // ═══════════════════════════════════════════════════════════
  console.log('━━━ 1. ENTITY REGISTRATION ━━━');

  const entities: EntityInput[] = [
    {
      raw_payload: { title: 'Build neural net visualizer', description: 'Create a 3D morphing neural network visualization with teal and purple styling, message-passing graph architecture' },
      source_type: 'task',
      context_tags: ['critical', 'frontend', 'visualization', 'mrnn', 'graph'],
      priority_hint: 0.92,
      timestamp: Date.now()
    },
    {
      raw_payload: { name: 'MorphAgent-Alpha', role: 'autonomous visualizer builder', capabilities: ['three.js', 'react', 'shader', 'mrnn-inference'] },
      source_type: 'agent',
      context_tags: ['autonomous', 'creative', 'trusted', 'visual'],
      priority_hint: 0.88,
      timestamp: Date.now()
    },
    {
      raw_payload: { filename: 'trident_synthia.onnx', size: 45000000, type: 'model', architecture: 'resnet-like-address-encoder' },
      source_type: 'file',
      context_tags: ['model', 'kernel', 'critical', 'onnx'],
      priority_hint: 0.97,
      timestamp: Date.now()
    },
    {
      raw_payload: { message: 'User requested human design chart with sidereal coordinates, Fagan/Bradley ayanamsa', channel: 'chat', user_id: 'usr_123' },
      source_type: 'message',
      context_tags: ['astrology', 'human-design', 'user-request', 'sidereal'],
      priority_hint: 0.65,
      timestamp: Date.now()
    },
    {
      raw_payload: { endpoint: '/api/v1/ingest', method: 'POST', payload_size: 2048, auth: 'bearer_token' },
      source_type: 'api_call',
      context_tags: ['api', 'ingestion', 'system', 'authenticated'],
      priority_hint: 0.75,
      timestamp: Date.now()
    },
    {
      raw_payload: { action: 'Deploy to Netlify + Render + Supabase simultaneously', targets: ['netlify', 'render', 'supabase'] },
      source_type: 'task',
      context_tags: ['deploy', 'multi-platform', 'critical', 'ci-cd'],
      priority_hint: 0.85,
      timestamp: Date.now()
    },
    {
      raw_payload: { name: 'TrustScorer-Beta', role: 'resonance analysis agent', capabilities: ['resonance-computation', 'pattern-detection', 'trust-evolution'] },
      source_type: 'agent',
      context_tags: ['autonomous', 'analytical', 'trust', 'resonance'],
      priority_hint: 0.80,
      timestamp: Date.now()
    }
  ];

  const registered = [];
  for (const input of entities) {
    let result;

    if (onnxLoader) {
      const onnxResult = await onnxLoader.infer(input);
      result = await trident.register(input);
      // Override with ONNX
      result.mrnn_address = {
        ...result.mrnn_address,
        mesh: onnxResult.mesh,
        layer: onnxResult.layer,
        center: onnxResult.center,
        gate: onnxResult.gate,
        line: onnxResult.line,
        color: onnxResult.color,
        tone: onnxResult.tone,
        zodiac_context: onnxResult.zodiac,
        modulation_state: onnxResult.modulation,
        confidence: onnxResult.confidence
      };
      result.symbolic_fields = onnxResult.symbolic;
      result.address_source = 'trident_synthia_onnx';
    } else {
      result = await trident.register(input);
    }

    await registry.storeEntity(result, { tags: input.context_tags });
    registered.push(result);

    const onnxBadge = onnxLoader ? ' [ONNX]' : '';
    console.log(`  ✅ ${result.entity_id.slice(0, 14)}...${onnxBadge}`);
    console.log(`     → ${result.mrnn_address.mesh} | ${result.mrnn_address.center} | gate:${result.mrnn_address.gate} | conf:${result.mrnn_address.confidence.toFixed(2)} | mod:${result.mrnn_address.modulation_state}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 2. Entity comparison + resonance scoring
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 2. ENTITY COMPARISON & RESONANCE ━━━');

  const comparePairs = [[0, 1], [0, 2], [1, 3], [2, 4], [5, 6], [0, 5]];
  for (const [i, j] of comparePairs) {
    const result = await trident.compare(registered[i].entity_id, registered[j].entity_id);

    // Register for resonance scorer
    resonanceScorer.registerEntity(registered[i].entity_id, registered[i].mrnn_address);
    resonanceScorer.registerEntity(registered[j].entity_id, registered[j].mrnn_address);

    const bar = '█'.repeat(Math.abs(result.resonance_score) * 20) + '░'.repeat(20 - Math.abs(result.resonance_score) * 20);
    const color = result.resonance_score > 0 ? '[32m' : '[31m';
    const reset = '[0m';

    console.log(`  🔗 ${registered[i].entity_type} vs ${registered[j].entity_type}`);
    console.log(`     ${color}${bar}${reset} ${result.resonance_score.toFixed(3)} → ${result.recommendation.toUpperCase()}`);
    if (result.synergy_points.length > 0) console.log(`     ✨ synergy: ${result.synergy_points.join(', ')}`);
    if (result.conflict_points.length > 0) console.log(`     ⚠️  conflict: ${result.conflict_points.join(', ')}`);
  }

  // Full resonance matrix
  const allIds = registered.map(r => r.entity_id);
  const matrix = resonanceScorer.computeMatrix(allIds);
  console.log(`\n  📊 Matrix: avg=${matrix.average_resonance.toFixed(3)} | field=${matrix.field_strength.toFixed(3)} | clusters=${matrix.clusters.length} | outliers=${matrix.outliers.length}`);

  // ═══════════════════════════════════════════════════════════
  // 3. Create specialized agents
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 3. AGENT CREATION ━━━');

  const agentConfigs = [
    {
      entity: registered[1], // MorphAgent
      options: {
        display_name: 'MorphAgent-Alpha',
        capabilities: [
          { name: 'three.js_rendering', domain: 'frontend', proficiency: 0.92 },
          { name: 'react_development', domain: 'frontend', proficiency: 0.88 },
          { name: 'shader_programming', domain: 'graphics', proficiency: 0.78 },
          { name: 'mrnn_inference', domain: 'ml', proficiency: 0.65 }
        ],
        personality: { autonomy: 0.9, creativity: 0.95, empathy: 0.35, precision: 0.82, speed: 0.7 },
        max_concurrent: 3,
        preferred_modalities: ['text', 'image', 'code']
      }
    },
    {
      entity: registered[6], // TrustScorer
      options: {
        display_name: 'TrustScorer-Beta',
        capabilities: [
          { name: 'resonance_computation', domain: 'analysis', proficiency: 0.90 },
          { name: 'pattern_detection', domain: 'analysis', proficiency: 0.85 },
          { name: 'trust_evolution', domain: 'governance', proficiency: 0.80 },
          { name: 'audit_analysis', domain: 'compliance', proficiency: 0.75 }
        ],
        personality: { autonomy: 0.7, creativity: 0.4, empathy: 0.6, precision: 0.95, speed: 0.5 },
        max_concurrent: 5,
        preferred_modalities: ['text', 'data']
      }
    }
  ];

  for (const { entity, options } of agentConfigs) {
    const profile = await agentProfiles.createAgent(entity, options);
    console.log(`  🤖 ${profile.display_name}`);
    console.log(`     mesh: ${profile.home_mesh} | load: ${profile.current_load}/${profile.max_concurrent}`);
    console.log(`     personality: A=${profile.personality_vector.autonomy.toFixed(2)} C=${profile.personality_vector.creativity.toFixed(2)} E=${profile.personality_vector.empathy.toFixed(2)} P=${profile.personality_vector.precision.toFixed(2)} S=${profile.personality_vector.speed.toFixed(2)}`);
    console.log(`     caps: ${profile.capabilities.map(c => `${c.name}(${(c.proficiency * 100).toFixed(0)}%)`).join(', ')}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 4. Orchestrate diverse requests
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 4. ORCHESTRATION ━━━');

  const requests = [
    {
      entity_input: {
        raw_payload: { task: 'Deploy visualizer to Netlify with GitHub Actions auto-deploy', urgency: 'high', branch: 'main' },
        source_type: 'task' as const,
        context_tags: ['deploy', 'netlify', 'critical', 'ci-cd'],
        priority_hint: 0.92
      },
      intent: 'execute' as const,
      required_capability: 'three.js_rendering',
      priority: 'critical' as const
    },
    {
      entity_input: {
        raw_payload: { query: 'Get user trust score history for longitudinal coherence analysis' },
        source_type: 'api_call' as const,
        context_tags: ['query', 'trust', 'audit', 'analysis'],
        priority_hint: 0.55
      },
      intent: 'query' as const,
      priority: 'normal' as const
    },
    {
      entity_input: {
        raw_payload: { action: 'Delete old model checkpoint trident_v0_backup.onnx', target: 'trident_v0_backup' },
        source_type: 'task' as const,
        context_tags: ['delete', 'cleanup', 'destructive', 'model'],
        priority_hint: 0.42
      },
      intent: 'destroy' as const,
      priority: 'normal' as const
    },
    {
      entity_input: {
        raw_payload: { action: 'Merge two agent profiles into unified resonance profile', agents: ['MorphAgent-Alpha', 'TrustScorer-Beta'] },
        source_type: 'task' as const,
        context_tags: ['merge', 'agent', 'resonance', 'transform'],
        priority_hint: 0.78
      },
      intent: 'transform' as const,
      priority: 'high' as const
    },
    {
      entity_input: {
        raw_payload: { observation: 'Monitor emergent behavior in construction_space mesh for anomaly detection' },
        source_type: 'system_event' as const,
        context_tags: ['monitor', 'emergent', 'anomaly', 'watch'],
        priority_hint: 0.60
      },
      intent: 'observe' as const,
      priority: 'normal' as const
    }
  ];

  for (const req of requests) {
    const result = await orchestrator.ingest(req);
    const statusColor = result.status === 'routed' ? '[32m' : result.status === 'rejected' ? '[31m' : '[33m';
    const reset = '[0m';

    console.log(`  📡 ${req.intent.toUpperCase().padEnd(10)} ${statusColor}${result.status.toUpperCase()}${reset}`);
    console.log(`     mesh: ${result.assigned_mesh} | agents: [${result.assigned_agents.join(', ') || 'none'}] | trust: ${result.trust_gate_passed ? 'PASS' : 'HOLD'}`);
    if (result.rejection_reason) console.log(`     ❌ ${result.rejection_reason}`);
    if (result.policy_decision) console.log(`     📋 policy: ${result.policy_decision}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 5. Trust evolution simulation
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 5. TRUST EVOLUTION ━━━');

  const testEntity = registered[0]; // the visualizer task
  const outcomes: Array<'success' | 'failure' | 'ambiguous'> = ['success', 'success', 'success', 'ambiguous', 'failure', 'success', 'success'];

  for (let i = 0; i < outcomes.length; i++) {
    const before = await registry.getEntity(testEntity.entity_id);
    await registry.recordInteraction(testEntity.entity_id, outcomes[i]);
    const updated = await registry.getEntity(testEntity.entity_id);

    const trustBar = '█'.repeat(updated!.trust_score * 20) + '░'.repeat(20 - updated!.trust_score * 20);
    const color = updated!.trust_score > 0.6 ? '[32m' : updated!.trust_score > 0.3 ? '[33m' : '[31m';

    console.log(`  interaction ${i + 1} (${outcomes[i].padEnd(9)}): ${color}${trustBar}${reset} trust=${updated!.trust_score.toFixed(3)} | lifecycle=${updated!.lifecycle} | interactions=${updated!.interaction_count}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 6. Registry queries
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 6. REGISTRY QUERIES ━━━');

  const queries = [
    { mesh: 'construction_space', limit: 5 },
    { center: 'creative_direction', limit: 5 },
    { min_trust: 0.5, limit: 5 },
    { lifecycle: 'active', limit: 5 },
    { access_level: 'general', limit: 5 }
  ];

  for (const q of queries) {
    const results = await registry.query(q);
    const desc = Object.entries(q)
      .filter(([k]) => k !== 'limit')
      .map(([k, v]) => `${k}=${v}`)
      .join(', ');
    console.log(`  🔍 query [${desc}]: ${results.length} results`);
    for (const r of results.slice(0, 3)) {
      console.log(`     → ${r.entity_id.slice(0, 12)}... | ${r.mrnn_address.mesh} | trust=${r.trust_score.toFixed(2)}`);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 7. Audit patterns
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 7. AUDIT & PATTERNS ━━━');

  const auditStats = auditMemory.getStats();
  console.log(`  📋 Total entries: ${auditStats.total_entries}`);
  console.log(`  👤 Entities tracked: ${auditStats.entities_tracked}`);
  console.log(`  🔍 Patterns detected: ${auditStats.patterns_detected}`);

  const patterns = auditMemory.getPatterns();
  console.log(`\n  Top patterns:`);
  for (const pattern of patterns.slice(0, 5)) {
    const freqBar = '█'.repeat(Math.min(10, pattern.frequency)) + '░'.repeat(Math.max(0, 10 - pattern.frequency));
    console.log(`     ${freqBar} "${pattern.pattern_id}" (n=${pattern.frequency}, success=${pattern.observed_outcomes.success_rate.toFixed(2)}, trust_Δ=${pattern.observed_outcomes.avg_trust_delta.toFixed(3)})`);
  }

  // Policy effectiveness
  console.log(`\n  Policy effectiveness:`);
  for (const policyName of ['critical_bypass', 'destructive_escalation', 'low_trust_throttle']) {
    const eff = auditMemory.getPolicyEffectiveness(policyName);
    if (eff.total > 0) {
      const rate = (eff.successes / eff.total * 100).toFixed(0);
      console.log(`     ${policyName}: ${eff.successes}/${eff.total} success (${rate}%), avg trust Δ=${eff.avg_trust_delta.toFixed(3)}`);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 8. Final system stats
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 8. SYSTEM STATE ━━━');
  console.log(`  Trident:      ${JSON.stringify(trident.getStats())}`);
  console.log(`  Registry:     ${JSON.stringify(registry.getStats())}`);
  console.log(`  Agents:       ${JSON.stringify(agentProfiles.getStats())}`);
  console.log(`  Orchestrator: ${JSON.stringify(orchestrator.getStats())}`);
  console.log(`  ONNX:         ${onnxLoader ? 'LOADED' : 'FALLBACK'}`);

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('✨ Demo complete. Trident Addressing Service v2 operational.');
  console.log('   Trident names the thing. Synthia decides what it can do.');
}

runDemoV2().catch(console.error);
