/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  AUDIT / OUTCOME MEMORY — Longitudinal coherence storage      ║
 * ║  Every decision, outcome, and trust evolution is recorded.  ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

export interface AuditEntry {
  entry_id: string;
  timestamp: string;
  entity_id: string;
  event_type: 'registration' | 'resolution' | 'comparison' | 'validation' | 'orchestration' | 'interaction' | 'trust_change' | 'lifecycle_change' | 'policy_decision';
  event_data: Record<string, any>;
  mrnn_address_snapshot: {
    mesh: string;
    layer: string;
    center: string;
    gate: string;
    line: number;
    color: number;
    tone: number;
    zodiac: string;
    modulation: string;
    confidence: number;
  };
  outcome?: 'success' | 'failure' | 'partial' | 'pending' | 'ambiguous';
  trust_before: number;
  trust_after: number;
  policy_applied?: string;
  agents_involved: string[];
  resonance_context?: number; // average resonance of involved entities
}

export interface OutcomePattern {
  pattern_id: string;
  description: string;
  trigger_conditions: Record<string, any>;
  observed_outcomes: { success_rate: number; avg_trust_delta: number; common_mesh: string; common_center: string };
  frequency: number;
  first_seen: string;
  last_seen: string;
}

export class AuditMemory {
  private entries: AuditEntry[] = [];
  private entityHistory: Map<string, AuditEntry[]> = new Map();
  private patterns: Map<string, OutcomePattern> = new Map();
  private maxEntries = 50000;

  record(entry: Omit<AuditEntry, 'entry_id'>): AuditEntry {
    const fullEntry: AuditEntry = {
      ...entry,
      entry_id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
    };

    this.entries.push(fullEntry);
    if (this.entries.length > this.maxEntries) {
      this.entries = this.entries.slice(-this.maxEntries / 2);
    }

    if (!this.entityHistory.has(entry.entity_id)) this.entityHistory.set(entry.entity_id, []);
    this.entityHistory.get(entry.entity_id)!.push(fullEntry);

    // Pattern detection
    this.detectPattern(fullEntry);

    return fullEntry;
  }

  getEntityHistory(entity_id: string, limit = 50): AuditEntry[] {
    const history = this.entityHistory.get(entity_id) || [];
    return history.slice(-limit);
  }

  getTrustTrajectory(entity_id: string): { timestamps: string[]; trust_values: number[] } {
    const history = this.entityHistory.get(entity_id) || [];
    const trustChanges = history.filter(e => e.event_type === 'trust_change' || e.event_type === 'interaction');
    return {
      timestamps: trustChanges.map(e => e.timestamp),
      trust_values: trustChanges.map(e => e.trust_after)
    };
  }

  getPolicyEffectiveness(policyName: string): { total: number; successes: number; failures: number; avg_trust_delta: number } {
    const relevant = this.entries.filter(e => e.policy_applied === policyName);
    const successes = relevant.filter(e => e.outcome === 'success').length;
    const failures = relevant.filter(e => e.outcome === 'failure').length;
    const avgDelta = relevant.length > 0
      ? relevant.reduce((s, e) => s + (e.trust_after - e.trust_before), 0) / relevant.length
      : 0;

    return { total: relevant.length, successes, failures, avg_trust_delta: parseFloat(avgDelta.toFixed(4)) };
  }

  getMeshOutcomes(mesh: string, days = 7): { total: number; success_rate: number; avg_resonance: number } {
    const cutoff = new Date(Date.now() - days * 86400000).toISOString();
    const relevant = this.entries.filter(e =>
      e.mrnn_address_snapshot.mesh === mesh && e.timestamp > cutoff
    );
    const successes = relevant.filter(e => e.outcome === 'success').length;
    const avgResonance = relevant.length > 0
      ? relevant.reduce((s, e) => s + (e.resonance_context || 0), 0) / relevant.length
      : 0;

    return {
      total: relevant.length,
      success_rate: relevant.length > 0 ? successes / relevant.length : 0,
      avg_resonance: parseFloat(avgResonance.toFixed(4))
    };
  }

  getPatterns(): OutcomePattern[] {
    return Array.from(this.patterns.values()).sort((a, b) => b.frequency - a.frequency);
  }

  // ─── Pattern Detection ─────────────────────────────────────

  private detectPattern(entry: AuditEntry): void {
    // Simple pattern: same center + same outcome = pattern
    const key = `${entry.mrnn_address_snapshot.center}_${entry.outcome}`;
    const existing = this.patterns.get(key);

    if (existing) {
      existing.frequency++;
      existing.last_seen = entry.timestamp;
      existing.observed_outcomes.success_rate =
        (existing.observed_outcomes.success_rate * (existing.frequency - 1) +
         (entry.outcome === 'success' ? 1 : 0)) / existing.frequency;
      existing.observed_outcomes.avg_trust_delta =
        (existing.observed_outcomes.avg_trust_delta * (existing.frequency - 1) +
         (entry.trust_after - entry.trust_before)) / existing.frequency;
    } else {
      this.patterns.set(key, {
        pattern_id: key,
        description: `Center "${entry.mrnn_address_snapshot.center}" with outcome "${entry.outcome}"`,
        trigger_conditions: { center: entry.mrnn_address_snapshot.center },
        observed_outcomes: {
          success_rate: entry.outcome === 'success' ? 1 : 0,
          avg_trust_delta: entry.trust_after - entry.trust_before,
          common_mesh: entry.mrnn_address_snapshot.mesh,
          common_center: entry.mrnn_address_snapshot.center
        },
        frequency: 1,
        first_seen: entry.timestamp,
        last_seen: entry.timestamp
      });
    }
  }

  // ─── Query Methods ─────────────────────────────────────────

  query(options: {
    entity_id?: string;
    event_type?: string;
    mesh?: string;
    center?: string;
    outcome?: string;
    since?: string;
    until?: string;
    limit?: number;
  }): AuditEntry[] {
    let results = this.entries;

    if (options.entity_id) results = results.filter(e => e.entity_id === options.entity_id);
    if (options.event_type) results = results.filter(e => e.event_type === options.event_type);
    if (options.mesh) results = results.filter(e => e.mrnn_address_snapshot.mesh === options.mesh);
    if (options.center) results = results.filter(e => e.mrnn_address_snapshot.center === options.center);
    if (options.outcome) results = results.filter(e => e.outcome === options.outcome);
    if (options.since) results = results.filter(e => e.timestamp >= options.since!);
    if (options.until) results = results.filter(e => e.timestamp <= options.until!);

    results = results.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    if (options.limit) results = results.slice(0, options.limit);

    return results;
  }

  getStats() {
    return {
      total_entries: this.entries.length,
      entities_tracked: this.entityHistory.size,
      patterns_detected: this.patterns.size,
      event_type_breakdown: this.countBy('event_type'),
      outcome_breakdown: this.countBy('outcome')
    };
  }

  private countBy(field: keyof AuditEntry): Record<string, number> {
    const counts: Record<string, number> = {};
    for (const entry of this.entries) {
      const val = String(entry[field] || 'unknown');
      counts[val] = (counts[val] || 0) + 1;
    }
    return counts;
  }
}

export const auditMemory = new AuditMemory();
export default auditMemory;
