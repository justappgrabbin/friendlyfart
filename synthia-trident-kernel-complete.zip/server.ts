/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  SYNTHIA API SERVER — HTTP layer for Trident kernel          ║
 * ║  Routes: /trident/*, /registry/*, /agents/*, /orchestrate/*║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import express from 'express';
import cors from 'cors';
import { trident, EntityInput } from './trident-addressing-service';
import { registry } from './entity-registry';
import { agentProfiles } from './agent-profiles';
import SynthiaOrchestrator from './synthia-orchestrator';
import { resonanceScorer } from './resonance-scorer';
import { auditMemory } from './audit-memory';

const app = express();
app.use(cors());
app.use(express.json());

// Initialize orchestrator
const orchestrator = new SynthiaOrchestrator(trident, registry, agentProfiles);

// ═══════════════════════════════════════════════════════════
// TRIDENT ENDPOINTS
// ═══════════════════════════════════════════════════════════

// POST /trident/register
app.post('/trident/register', async (req, res) => {
  try {
    const input: EntityInput = req.body;
    const result = await trident.register(input);

    // Audit
    auditMemory.record({
      timestamp: new Date().toISOString(),
      entity_id: result.entity_id,
      event_type: 'registration',
      event_data: { input },
      mrnn_address_snapshot: {
        mesh: result.mrnn_address.mesh,
        layer: result.mrnn_address.layer,
        center: result.mrnn_address.center,
        gate: result.mrnn_address.gate,
        line: result.mrnn_address.line,
        color: result.mrnn_address.color,
        tone: result.mrnn_address.tone,
        zodiac: result.mrnn_address.zodiac_context,
        modulation: result.mrnn_address.modulation_state,
        confidence: result.mrnn_address.confidence
      },
      trust_before: result.mrnn_address.confidence * 0.5,
      trust_after: result.mrnn_address.confidence * 0.5,
      agents_involved: []
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /trident/resolve
app.post('/trident/resolve', async (req, res) => {
  try {
    const { entity_id } = req.body;
    const result = await trident.resolve(entity_id);
    if (!result) return res.status(404).json({ error: 'Entity not found' });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /trident/compare
app.post('/trident/compare', async (req, res) => {
  try {
    const { entity_a, entity_b } = req.body;
    const result = await trident.compare(entity_a, entity_b);

    // Register for resonance scoring
    const a = await trident.resolve(entity_a);
    const b = await trident.resolve(entity_b);
    if (a && b) {
      resonanceScorer.registerEntity(entity_a, a.mrnn_address);
      resonanceScorer.registerEntity(entity_b, b.mrnn_address);
    }

    auditMemory.record({
      timestamp: new Date().toISOString(),
      entity_id: `${entity_a}_vs_${entity_b}`,
      event_type: 'comparison',
      event_data: { entity_a, entity_b, result },
      mrnn_address_snapshot: { mesh: 'comparison', layer: 'analysis', center: 'mental_processing', gate: 'logic', line: 1, color: 1, tone: 1, zodiac: 'neutral', modulation: 'neutral', confidence: result.resonance_score },
      trust_before: 0.5,
      trust_after: 0.5,
      agents_involved: []
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /trident/validate
app.post('/trident/validate', async (req, res) => {
  try {
    const { entity_id } = req.body;
    const result = await trident.validate(entity_id);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// POST /trident/register-batch
app.post('/trident/register-batch', async (req, res) => {
  try {
    const { entities } = req.body;
    const results = await trident.registerBatch(entities);
    res.json({ count: results.length, results });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ═══════════════════════════════════════════════════════════
// REGISTRY ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.get('/registry/entity/:id', async (req, res) => {
  const entry = await registry.getEntity(req.params.id);
  if (!entry) return res.status(404).json({ error: 'Not found' });
  res.json(entry);
});

app.post('/registry/query', async (req, res) => {
  const results = await registry.query(req.body);
  res.json({ count: results.length, entities: results });
});

app.post('/registry/interact', async (req, res) => {
  const { entity_id, outcome } = req.body;
  await registry.recordInteraction(entity_id, outcome);
  const updated = await registry.getEntity(entity_id);
  res.json(updated);
});

app.get('/registry/stats', async (_req, res) => {
  res.json(registry.getStats());
});

// ═══════════════════════════════════════════════════════════
// AGENT ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.post('/agents/create', async (req, res) => {
  try {
    const { entity_input, options } = req.body;
    const tridentResult = await trident.register(entity_input);
    const registryEntry = await registry.storeEntity(tridentResult, {
      access_level: 'general',
      tags: ['agent']
    });
    const profile = await agentProfiles.createAgent(tridentResult, options);
    res.json(profile);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.get('/agents/:id', async (req, res) => {
  const profile = await agentProfiles.getAgent(req.params.id);
  if (!profile) return res.status(404).json({ error: 'Not found' });
  res.json(profile);
});

app.get('/agents', async (_req, res) => {
  res.json({
    agents: Array.from((agentProfiles as any).profiles?.values() || []),
    stats: agentProfiles.getStats()
  });
});

app.post('/agents/find-capable', async (req, res) => {
  const { capability, mesh, min_proficiency } = req.body;
  const agents = await agentProfiles.findCapableAgents(capability, mesh, min_proficiency);
  res.json({ count: agents.length, agents });
});

// ═══════════════════════════════════════════════════════════
// ORCHESTRATOR ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.post('/orchestrate/ingest', async (req, res) => {
  try {
    const result = await orchestrator.ingest(req.body);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.post('/orchestrate/complete', async (req, res) => {
  const { request_id, outcome } = req.body;
  await orchestrator.complete(request_id, outcome);
  res.json({ status: 'completed' });
});

app.get('/orchestrate/queue', async (_req, res) => {
  res.json({ length: orchestrator.getQueueLength() });
});

app.get('/orchestrate/routes/active', async (_req, res) => {
  res.json({ routes: Array.from((orchestrator as any).active?.values() || []) });
});

app.get('/orchestrate/audit', async (req, res) => {
  const limit = Number(req.query.limit) || 100;
  res.json({ entries: orchestrator.getAuditLog(limit) });
});

// ═══════════════════════════════════════════════════════════
// RESONANCE ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.post('/resonance/compute', async (req, res) => {
  const { entity_a, entity_b } = req.body;
  const a = await trident.resolve(entity_a);
  const b = await trident.resolve(entity_b);
  if (!a || !b) return res.status(404).json({ error: 'One or both entities not found' });

  resonanceScorer.registerEntity(entity_a, a.mrnn_address);
  resonanceScorer.registerEntity(entity_b, b.mrnn_address);
  const score = resonanceScorer.computeResonance(entity_a, entity_b);

  res.json({ entity_a, entity_b, resonance_score: score });
});

app.post('/resonance/matrix', async (req, res) => {
  const { entity_ids } = req.body;
  for (const id of entity_ids) {
    const entity = await trident.resolve(id);
    if (entity) resonanceScorer.registerEntity(id, entity.mrnn_address);
  }
  const matrix = resonanceScorer.computeMatrix(entity_ids);
  res.json(matrix);
});

// ═══════════════════════════════════════════════════════════
// AUDIT ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.get('/audit/stats', async (_req, res) => {
  res.json(auditMemory.getStats());
});

app.post('/audit/query', async (req, res) => {
  const results = auditMemory.query(req.body);
  res.json({ count: results.length, entries: results });
});

app.get('/audit/patterns', async (_req, res) => {
  res.json({ patterns: auditMemory.getPatterns() });
});

app.get('/audit/entity/:id/history', async (req, res) => {
  const history = auditMemory.getEntityHistory(req.params.id);
  res.json({ entity_id: req.params.id, count: history.length, history });
});

// ═══════════════════════════════════════════════════════════
// DASHBOARD STATS ENDPOINT
// ═══════════════════════════════════════════════════════════

app.get('/api/stats', async (_req, res) => {
  res.json({
    trident: trident.getStats(),
    registry: registry.getStats(),
    agents: agentProfiles.getStats(),
    orchestrator: orchestrator.getStats(),
    audit: auditMemory.getStats()
  });
});

app.get('/api/entities', async (req, res) => {
  const limit = Number(req.query.limit) || 20;
  const all = await registry.query({ limit });
  res.json({ entities: all });
});

// ═══════════════════════════════════════════════════════════
// HEALTH
// ═══════════════════════════════════════════════════════════

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'synthia-trident', version: '0.1.0' });
});

// ═══════════════════════════════════════════════════════════
// START
// ═══════════════════════════════════════════════════════════

const PORT = process.env.PORT || 8787;

async function main() {
  await trident.initialize();
  app.listen(PORT, () => {
    console.log(`🌊 Synthia Trident Kernel listening on port ${PORT}`);
    console.log(`   POST /trident/register    — Register entity`);
    console.log(`   POST /trident/resolve   — Resolve address`);
    console.log(`   POST /trident/compare   — Compare entities`);
    console.log(`   POST /trident/validate  — Validate address`);
    console.log(`   POST /orchestrate/ingest — Ingest & route`);
    console.log(`   GET  /api/stats         — Dashboard data`);
  });
}

main().catch(console.error);

export default app;
