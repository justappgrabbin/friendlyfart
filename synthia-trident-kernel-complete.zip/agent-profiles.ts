/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  AGENT PROFILES — Embodied Agent Identity System             ║
 * ║  Each agent gets an MRNN address + profile + capability map  ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import { TridentResult, MRNNAddress } from './trident-addressing-service';
import { RegistryEntry } from './entity-registry';

export interface AgentCapability {
  name: string;
  domain: string;
  proficiency: number; // 0.0 - 1.0
  last_used: string;
  success_rate: number;
  enabled: boolean;
}

export interface AgentProfile {
  agent_id: string;
  display_name: string;
  trident_address: MRNNAddress;
  registry_entry: RegistryEntry;
  capabilities: AgentCapability[];
  personality_vector: {
    autonomy: number;      // self-directed vs instructed
    creativity: number;    // generative vs analytical
    empathy: number;       // human-aligned vs task-aligned
    precision: number;     // exact vs approximate
    speed: number;         // fast vs thorough
  };
  memory_capacity: number; // tokens or items
  current_load: number;    // active tasks
  max_concurrent: number;
  preferred_modalities: string[]; // text, voice, image, code, data
  home_mesh: string;
  created_at: string;
  version: string;
}

export class AgentProfileManager {
  private profiles: Map<string, AgentProfile> = new Map();
  private meshAgents: Map<string, Set<string>> = new Map();
  private capabilityIndex: Map<string, Set<string>> = new Map();

  async createAgent(
    tridentResult: TridentResult,
    options: {
      display_name?: string;
      capabilities?: Partial<AgentCapability>[];
      personality?: Partial<AgentProfile['personality_vector']>;
      max_concurrent?: number;
      preferred_modalities?: string[];
    } = {}
  ): Promise<AgentProfile> {
    const agent_id = tridentResult.entity_id;

    // Derive personality from MRNN address
    const personality = this.derivePersonality(tridentResult.mrnn_address, options.personality);

    const profile: AgentProfile = {
      agent_id,
      display_name: options.display_name || `Agent_${agent_id.slice(0, 8)}`,
      trident_address: tridentResult.mrnn_address,
      registry_entry: tridentResult as RegistryEntry,
      capabilities: (options.capabilities || []).map(c => ({
        name: c.name || 'general',
        domain: c.domain || 'universal',
        proficiency: c.proficiency || 0.5,
        last_used: new Date().toISOString(),
        success_rate: 0.5,
        enabled: true
      })),
      personality_vector: personality,
      memory_capacity: 10000,
      current_load: 0,
      max_concurrent: options.max_concurrent || 5,
      preferred_modalities: options.preferred_modalities || ['text'],
      home_mesh: tridentResult.mrnn_address.mesh,
      created_at: new Date().toISOString(),
      version: 'agent-v0.1'
    };

    this.profiles.set(agent_id, profile);
    this.indexAgent(profile);

    return profile;
  }

  async getAgent(agent_id: string): Promise<AgentProfile | null> {
    return this.profiles.get(agent_id) || null;
  }

  async updateCapability(agent_id: string, capability_name: string, outcome: 'success' | 'failure'): Promise<void> {
    const profile = this.profiles.get(agent_id);
    if (!profile) return;

    const cap = profile.capabilities.find(c => c.name === capability_name);
    if (!cap) return;

    cap.last_used = new Date().toISOString();
    const n = cap.success_rate < 0.9 ? 10 : 50; // dynamic sample size
    const alpha = outcome === 'success' ? 1 : 0;
    cap.success_rate = (cap.success_rate * (n - 1) + alpha) / n;
    cap.proficiency = Math.min(1.0, cap.proficiency + (outcome === 'success' ? 0.02 : -0.03));
  }

  async assignTask(agent_id: string): Promise<boolean> {
    const profile = this.profiles.get(agent_id);
    if (!profile) return false;
    if (profile.current_load >= profile.max_concurrent) return false;
    profile.current_load++;
    return true;
  }

  async releaseTask(agent_id: string): Promise<void> {
    const profile = this.profiles.get(agent_id);
    if (profile) profile.current_load = Math.max(0, profile.current_load - 1);
  }

  async findCapableAgents(capability: string, mesh?: string, min_proficiency = 0.5): Promise<AgentProfile[]> {
    const ids = this.capabilityIndex.get(capability) || new Set();
    return Array.from(ids)
      .map(id => this.profiles.get(id)!)
      .filter(p => {
        if (!p) return false;
        if (mesh && p.home_mesh !== mesh) return false;
        const cap = p.capabilities.find(c => c.name === capability);
        if (!cap || !cap.enabled) return false;
        return cap.proficiency >= min_proficiency && p.current_load < p.max_concurrent;
      })
      .sort((a, b) => {
        const capA = a.capabilities.find(c => c.name === capability)!;
        const capB = b.capabilities.find(c => c.name === capability)!;
        return capB.proficiency - capA.proficiency;
      });
  }

  async findAgentsByPersonality(
    trait: keyof AgentProfile['personality_vector'],
    minValue: number,
    mesh?: string
  ): Promise<AgentProfile[]> {
    return Array.from(this.profiles.values())
      .filter(p => {
        if (mesh && p.home_mesh !== mesh) return false;
        return p.personality_vector[trait] >= minValue && p.current_load < p.max_concurrent;
      })
      .sort((a, b) => b.personality_vector[trait] - a.personality_vector[trait]);
  }

  getMeshPopulation(mesh: string): AgentProfile[] {
    const ids = this.meshAgents.get(mesh) || new Set();
    return Array.from(ids).map(id => this.profiles.get(id)!).filter(Boolean);
  }

  getStats() {
    return {
      total_agents: this.profiles.size,
      by_mesh: Object.fromEntries(
        Array.from(this.meshAgents.entries()).map(([k, v]) => [k, v.size])
      ),
      by_capability: Object.fromEntries(
        Array.from(this.capabilityIndex.entries()).map(([k, v]) => [k, v.size])
      ),
      avg_load: Array.from(this.profiles.values()).reduce((s, p) => s + p.current_load, 0) / (this.profiles.size || 1)
    };
  }

  // ─── Private ───────────────────────────────────────────────

  private derivePersonality(
    addr: MRNNAddress,
    overrides?: Partial<AgentProfile['personality_vector']>
  ): AgentProfile['personality_vector'] {
    const base = {
      autonomy: addr.line / 6,
      creativity: addr.color / 6,
      empathy: addr.tone / 6,
      precision: addr.confidence,
      speed: addr.modulation_state === 'constructive' ? 0.8 : addr.modulation_state === 'destructive' ? 0.3 : 0.5
    };
    return { ...base, ...overrides };
  }

  private indexAgent(profile: AgentProfile): void {
    const id = profile.agent_id;
    if (!this.meshAgents.has(profile.home_mesh)) this.meshAgents.set(profile.home_mesh, new Set());
    this.meshAgents.get(profile.home_mesh)!.add(id);

    for (const cap of profile.capabilities) {
      if (!this.capabilityIndex.has(cap.name)) this.capabilityIndex.set(cap.name, new Set());
      this.capabilityIndex.get(cap.name)!.add(id);
    }
  }
}

export const agentProfiles = new AgentProfileManager();
export default agentProfiles;
