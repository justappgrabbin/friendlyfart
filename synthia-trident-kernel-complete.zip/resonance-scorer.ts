/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  RESONANCE SCORER — Multi-dimensional compatibility engine   ║
 * ║  Computes resonance, conflict, and synergy across entities.  ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import { MRNNAddress } from './trident-addressing-service';

export interface ResonanceProfile {
  entity_id: string;
  address: MRNNAddress;
  resonance_history: number[]; // last N resonance scores with others
  dominant_frequency: number; // derived from line+color+tone
  harmonic_signature: string; // e.g. "3-2-5"
  phase: number; // 0-2π, current position in cycle
}

export interface ResonanceMatrix {
  pairs: [string, string][];
  scores: number[];
  average_resonance: number;
  clusters: string[][]; // groups of mutually resonant entities
  outliers: string[]; // entities with low average resonance
  field_strength: number; // overall coherence of the set
}

export class ResonanceScorer {
  private profiles: Map<string, ResonanceProfile> = new Map();
  private interactionMatrix: Map<string, Map<string, number>> = new Map();

  registerEntity(entity_id: string, address: MRNNAddress): ResonanceProfile {
    const frequency = (address.line * 0.3) + (address.color * 0.2) + (address.tone * 0.15);
    const profile: ResonanceProfile = {
      entity_id,
      address,
      resonance_history: [],
      dominant_frequency: frequency,
      harmonic_signature: `${address.line}-${address.color}-${address.tone}`,
      phase: Math.random() * Math.PI * 2
    };
    this.profiles.set(entity_id, profile);
    return profile;
  }

  computeResonance(a_id: string, b_id: string): number {
    const a = this.profiles.get(a_id);
    const b = this.profiles.get(b_id);
    if (!a || !b) return 0;

    const addrA = a.address;
    const addrB = b.address;

    // Dimensional resonance (weighted multi-factor)
    const meshScore = addrA.mesh === addrB.mesh ? 1.0 : this.meshDistance(addrA.mesh, addrB.mesh);
    const layerScore = addrA.layer === addrB.layer ? 1.0 : 0.3;
    const centerScore = this.centerResonance(addrA.center, addrB.center);
    const gateScore = addrA.gate === addrB.gate ? 1.0 : this.gateDistance(addrA.gate, addrB.gate);
    const lineScore = 1.0 - Math.abs(addrA.line - addrB.line) / 6;
    const colorScore = 1.0 - Math.abs(addrA.color - addrB.color) / 6;
    const toneScore = 1.0 - Math.abs(addrA.tone - addrB.tone) / 6;
    const zodiacScore = this.zodiacResonance(addrA.zodiac_context, addrB.zodiac_context);
    const modulationScore = this.modulationResonance(addrA.modulation_state, addrB.modulation_state);

    // Frequency interference
    const freqDiff = Math.abs(a.dominant_frequency - b.dominant_frequency);
    const frequencyScore = Math.max(0, 1.0 - freqDiff / 3.0);

    // Phase alignment (constructive/destructive interference)
    const phaseDiff = Math.abs(a.phase - b.phase);
    const phaseScore = Math.cos(phaseDiff) * 0.5 + 0.5;

    const weights = {
      mesh: 0.10, layer: 0.08, center: 0.18, gate: 0.08,
      line: 0.08, color: 0.05, tone: 0.05, zodiac: 0.10,
      modulation: 0.12, frequency: 0.08, phase: 0.08
    };

    const resonance =
      meshScore * weights.mesh +
      layerScore * weights.layer +
      centerScore * weights.center +
      gateScore * weights.gate +
      lineScore * weights.line +
      colorScore * weights.color +
      toneScore * weights.tone +
      zodiacScore * weights.zodiac +
      modulationScore * weights.modulation +
      frequencyScore * weights.frequency +
      phaseScore * weights.phase;

    const clamped = Math.max(-1, Math.min(1, resonance * 2 - 1));

    // Store interaction
    if (!this.interactionMatrix.has(a_id)) this.interactionMatrix.set(a_id, new Map());
    this.interactionMatrix.get(a_id)!.set(b_id, clamped);

    // Update history
    a.resonance_history.push(clamped);
    if (a.resonance_history.length > 100) a.resonance_history.shift();

    return parseFloat(clamped.toFixed(4));
  }

  computeMatrix(entity_ids: string[]): ResonanceMatrix {
    const scores: number[] = [];
    const pairs: [string, string][] = [];
    const entityScores: Map<string, number[]> = new Map();

    for (let i = 0; i < entity_ids.length; i++) {
      for (let j = i + 1; j < entity_ids.length; j++) {
        const score = this.computeResonance(entity_ids[i], entity_ids[j]);
        scores.push(score);
        pairs.push([entity_ids[i], entity_ids[j]]);

        if (!entityScores.has(entity_ids[i])) entityScores.set(entity_ids[i], []);
        if (!entityScores.has(entity_ids[j])) entityScores.set(entity_ids[j], []);
        entityScores.get(entity_ids[i])!.push(score);
        entityScores.get(entity_ids[j])!.push(score);
      }
    }

    const avgResonance = scores.length > 0 ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;

    // Clustering: entities with mutual resonance > 0.5
    const clusters: string[][] = [];
    const clustered = new Set<string>();
    for (const id of entity_ids) {
      if (clustered.has(id)) continue;
      const cluster = [id];
      for (const other of entity_ids) {
        if (other === id || clustered.has(other)) continue;
        const score = this.getCachedResonance(id, other);
        if (score !== undefined && score > 0.5) {
          cluster.push(other);
          clustered.add(other);
        }
      }
      if (cluster.length > 1) {
        clusters.push(cluster);
        clustered.add(id);
      }
    }

    // Outliers: entities with average resonance < 0
    const outliers: string[] = [];
    for (const [id, scs] of entityScores) {
      const avg = scs.reduce((a, b) => a + b, 0) / scs.length;
      if (avg < 0) outliers.push(id);
    }

    // Field strength: variance of all scores (lower variance = stronger field)
    const variance = scores.length > 1
      ? scores.reduce((s, x) => s + Math.pow(x - avgResonance, 2), 0) / scores.length
      : 0;
    const fieldStrength = Math.max(0, 1.0 - variance);

    return {
      pairs,
      scores,
      average_resonance: parseFloat(avgResonance.toFixed(4)),
      clusters,
      outliers,
      field_strength: parseFloat(fieldStrength.toFixed(4))
    };
  }

  getCachedResonance(a: string, b: string): number | undefined {
    return this.interactionMatrix.get(a)?.get(b) ?? this.interactionMatrix.get(b)?.get(a);
  }

  getEntityResonanceHistory(entity_id: string): number[] {
    return this.profiles.get(entity_id)?.resonance_history || [];
  }

  getDominantFrequency(entity_id: string): number {
    return this.profiles.get(entity_id)?.dominant_frequency || 0;
  }

  // ─── Resonance Rules ───────────────────────────────────────

  private meshDistance(a: string, b: string): number {
    const domains: Record<string, string[]> = {
      construction: ['construction_space', 'agent_space'],
      knowledge: ['knowledge_space', 'communication_space'],
      interface: ['interface_space', 'communication_space'],
      priority: ['priority_space']
    };
    for (const [, group] of Object.entries(domains)) {
      if (group.includes(a) && group.includes(b)) return 0.5;
    }
    return 0.1;
  }

  private centerResonance(a: string, b: string): number {
    if (a === b) return 1.0;
    const harmonies: Record<string, string[]> = {
      creative_direction: ['manifestation', 'communication'],
      mental_processing: ['intuitive_awareness', 'identity_definition'],
      emotional_intelligence: ['will_power', 'creative_direction'],
      manifestation: ['creative_direction', 'will_power'],
      communication: ['creative_direction', 'mental_processing'],
      intuitive_awareness: ['mental_processing', 'identity_definition'],
      will_power: ['manifestation', 'emotional_intelligence'],
      identity_definition: ['intuitive_awareness', 'mental_processing']
    };
    if (harmonies[a]?.includes(b) || harmonies[b]?.includes(a)) return 0.7;
    return 0.2;
  }

  private gateDistance(a: string, b: string): number {
    const gateOrder = ['entry', 'initiation', 'knowing', 'logic', 'feelings', 'building', 'expression', 'power', 'identity'];
    const idxA = gateOrder.indexOf(a);
    const idxB = gateOrder.indexOf(b);
    if (idxA === -1 || idxB === -1) return 0.1;
    const dist = Math.abs(idxA - idxB);
    return Math.max(0.1, 1.0 - dist / gateOrder.length);
  }

  private zodiacResonance(a: string, b: string): number {
    if (a === b) return 1.0;
    const elemA = a.split('_')[1];
    const elemB = b.split('_')[1];
    if (elemA === elemB) return 0.8;
    const comp: Record<string, string> = { fire: 'air', air: 'fire', earth: 'water', water: 'earth' };
    if (comp[elemA] === elemB) return 0.6;
    return 0.3;
  }

  private modulationResonance(a: string, b: string): number {
    const table: Record<string, Record<string, number>> = {
      constructive: { constructive: 1.0, resonant: 0.9, neutral: 0.7, emergent: 0.5, destructive: 0.0 },
      resonant: { constructive: 0.9, resonant: 1.0, neutral: 0.8, emergent: 0.7, destructive: 0.1 },
      neutral: { constructive: 0.7, resonant: 0.8, neutral: 1.0, emergent: 0.6, destructive: 0.3 },
      emergent: { constructive: 0.5, resonant: 0.7, neutral: 0.6, emergent: 1.0, destructive: 0.2 },
      destructive: { constructive: 0.0, resonant: 0.1, neutral: 0.3, emergent: 0.2, destructive: 1.0 }
    };
    return table[a]?.[b] ?? 0.3;
  }
}

export const resonanceScorer = new ResonanceScorer();
export default resonanceScorer;
