/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  INTEGRATION TEST — Full Trident → Synthia pipeline demo      ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import { trident, EntityInput } from './trident-addressing-service';
import { registry } from './entity-registry';
import { agentProfiles } from './agent-profiles';
import SynthiaOrchestrator from './synthia-orchestrator';
import { resonanceScorer } from './resonance-scorer';
import { auditMemory } from './audit-memory';

async function runDemo() {
  console.log('🌊 Synthia Trident Kernel — Integration Demo\n');

  await trident.initialize();
  const orchestrator = new SynthiaOrchestrator(trident, registry, agentProfiles);

  // ═══════════════════════════════════════════════════════════
  // 1. Register diverse entities
  // ═══════════════════════════════════════════════════════════
  console.log('━━━ 1. ENTITY REGISTRATION ━━━');

  const entities: EntityInput[] = [
    {
      raw_payload: { title: 'Build neural net visualizer', description: 'Create a 3D morphing neural network visualization with teal and purple styling' },
      source_type: 'task',
      context_tags: ['critical', 'frontend', 'visualization'],
      priority_hint: 0.9
    },
    {
      raw_payload: { name: 'MorphAgent', role: 'autonomous visualizer builder', capabilities: ['three.js', 'react', 'shader'] },
      source_type: 'agent',
      context_tags: ['autonomous', 'creative', 'trusted'],
      priority_hint: 0.85
    },
    {
      raw_payload: { filename: 'trident_synthia.onnx', size: 45000000, type: 'model' },
      source_type: 'file',
      context_tags: ['model', 'kernel', 'critical'],
      priority_hint: 0.95
    },
    {
      raw_payload: { message: 'User requested human design chart with sidereal coordinates', channel: 'chat' },
      source_type: 'message',
      context_tags: ['astrology', 'human-design', 'user-request'],
      priority_hint: 0.6
    },
    {
      raw_payload: { endpoint: '/api/v1/ingest', method: 'POST', payload_size: 2048 },
      source_type: 'api_call',
      context_tags: ['api', 'ingestion', 'system'],
      priority_hint: 0.7
    }
  ];

  const registered = [];
  for (const input of entities) {
    const result = await trident.register(input);
    await registry.storeEntity(result, { tags: input.context_tags });
    registered.push(result);
    console.log(`  ✅ ${result.entity_id.slice(0, 16)}... → ${result.mrnn_address.mesh} | ${result.mrnn_address.center} | confidence:${result.mrnn_address.confidence.toFixed(2)}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 2. Compare entities
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 2. ENTITY COMPARISON ━━━');

  const comparePairs = [[0, 1], [0, 2], [1, 3], [2, 4]];
  for (const [i, j] of comparePairs) {
    const result = await trident.compare(registered[i].entity_id, registered[j].entity_id);
    console.log(`  🔗 ${registered[i].entity_type} vs ${registered[j].entity_type}: resonance=${result.resonance_score.toFixed(3)} → ${result.recommendation}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 3. Create agents from entities
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 3. AGENT CREATION ━━━');

  const agentEntity = registered[1]; // the agent entity
  const agentProfile = await agentProfiles.createAgent(agentEntity, {
    display_name: 'MorphAgent-Alpha',
    capabilities: [
      { name: 'three.js_rendering', domain: 'frontend', proficiency: 0.9 },
      { name: 'react_development', domain: 'frontend', proficiency: 0.85 },
      { name: 'shader_programming', domain: 'graphics', proficiency: 0.75 },
      { name: 'mrnn_inference', domain: 'ml', proficiency: 0.6 }
    ],
    personality: { autonomy: 0.9, creativity: 0.95, empathy: 0.4, precision: 0.8, speed: 0.7 },
    max_concurrent: 3,
    preferred_modalities: ['text', 'image', 'code']
  });
  console.log(`  🤖 ${agentProfile.display_name} created`);
  console.log(`     home_mesh: ${agentProfile.home_mesh}`);
  console.log(`     personality: autonomy=${agentProfile.personality_vector.autonomy.toFixed(2)}, creativity=${agentProfile.personality_vector.creativity.toFixed(2)}`);
  console.log(`     capabilities: ${agentProfile.capabilities.map(c => `${c.name}(${(c.proficiency * 100).toFixed(0)}%)`).join(', ')}`);

  // ═══════════════════════════════════════════════════════════
  // 4. Orchestrate requests
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 4. ORCHESTRATION ━━━');

  const requests = [
    {
      entity_input: {
        raw_payload: { task: 'Deploy visualizer to Netlify', urgency: 'high' },
        source_type: 'task' as const,
        context_tags: ['deploy', 'netlify', 'critical'],
        priority_hint: 0.9
      },
      intent: 'execute' as const,
      required_capability: 'three.js_rendering',
      priority: 'critical' as const
    },
    {
      entity_input: {
        raw_payload: { query: 'Get user trust score history' },
        source_type: 'api_call' as const,
        context_tags: ['query', 'trust', 'audit'],
        priority_hint: 0.5
      },
      intent: 'query' as const,
      priority: 'normal' as const
    },
    {
      entity_input: {
        raw_payload: { action: 'Delete old model checkpoint', target: 'trident_v0_backup' },
        source_type: 'task' as const,
        context_tags: ['delete', 'cleanup', 'destructive'],
        priority_hint: 0.4
      },
      intent: 'destroy' as const,
      priority: 'normal' as const
    }
  ];

  for (const req of requests) {
    const result = await orchestrator.ingest(req);
    console.log(`  📡 ${req.intent.toUpperCase()} → ${result.status} | mesh:${result.assigned_mesh} | agents:[${result.assigned_agents.join(', ') || 'none'}] | trust_gate:${result.trust_gate_passed}`);
    if (result.rejection_reason) console.log(`     ❌ reason: ${result.rejection_reason}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 5. Resonance matrix
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 5. RESONANCE MATRIX ━━━');

  const allIds = registered.map(r => r.entity_id);
  for (const id of allIds) {
    resonanceScorer.registerEntity(id, (await trident.resolve(id))!.mrnn_address);
  }
  const matrix = resonanceScorer.computeMatrix(allIds);
  console.log(`  📊 Average resonance: ${matrix.average_resonance.toFixed(3)}`);
  console.log(`  🌐 Field strength: ${matrix.field_strength.toFixed(3)}`);
  console.log(`  🔗 Clusters: ${matrix.clusters.length} (${matrix.clusters.map(c => `[${c.length}]`).join(' ')})`);
  console.log(`  ⚠️  Outliers: ${matrix.outliers.length > 0 ? matrix.outliers.join(', ') : 'none'}`);

  // ═══════════════════════════════════════════════════════════
  // 6. Trust evolution
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 6. TRUST EVOLUTION ━━━');

  const testEntity = registered[0];
  for (let i = 0; i < 5; i++) {
    const outcome = i < 3 ? 'success' as const : i === 3 ? 'ambiguous' as const : 'failure' as const;
    await registry.recordInteraction(testEntity.entity_id, outcome);
    const updated = await registry.getEntity(testEntity.entity_id);
    console.log(`  interaction ${i + 1} (${outcome}): trust=${updated!.trust_score.toFixed(3)} | lifecycle=${updated!.lifecycle}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 7. Audit & patterns
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 7. AUDIT & PATTERNS ━━━');

  const stats = auditMemory.getStats();
  console.log(`  📋 Total entries: ${stats.total_entries}`);
  console.log(`  🔍 Patterns detected: ${stats.patterns_detected}`);

  const patterns = auditMemory.getPatterns();
  for (const pattern of patterns.slice(0, 3)) {
    console.log(`     Pattern "${pattern.pattern_id}": freq=${pattern.frequency}, success_rate=${pattern.observed_outcomes.success_rate.toFixed(2)}, trust_delta=${pattern.observed_outcomes.avg_trust_delta.toFixed(3)}`);
  }

  // ═══════════════════════════════════════════════════════════
  // 8. Final stats
  // ═══════════════════════════════════════════════════════════
  console.log('\n━━━ 8. SYSTEM STATS ━━━');
  console.log(`  Trident: ${JSON.stringify(trident.getStats())}`);
  console.log(`  Registry: ${JSON.stringify(registry.getStats())}`);
  console.log(`  Agents: ${JSON.stringify(agentProfiles.getStats())}`);
  console.log(`  Orchestrator: ${JSON.stringify(orchestrator.getStats())}`);

  console.log('\n✨ Demo complete. Trident Addressing Service operational.');
}

runDemo().catch(console.error);
