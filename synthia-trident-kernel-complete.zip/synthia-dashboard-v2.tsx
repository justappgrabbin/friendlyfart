/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  SYNTHIA DASHBOARD v2 — Real-time WebSocket + Resonance Viz  ║
 * ║  Full monitoring for Trident kernel with live resonance field. ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';

// ─── Types ────────────────────────────────────────────────────

interface MRNNAddress {
  mesh: string; layer: string; center: string; gate: string;
  line: number; color: number; tone: number;
  zodiac_context: string; modulation_state: string;
  confidence: number; version: string;
}

interface RegistryEntry {
  entity_id: string; entity_type: string;
  mrnn_address: MRNNAddress;
  lifecycle: string; access_level: string;
  trust_score: number; interaction_count: number;
  registered_at: string; policy_flags: string[];
}

interface AgentProfile {
  agent_id: string; display_name: string;
  trident_address: MRNNAddress;
  current_load: number; max_concurrent: number;
  capabilities: { name: string; proficiency: number; enabled: boolean }[];
  personality_vector: { autonomy: number; creativity: number; empathy: number; precision: number; speed: number };
}

interface OrchestrationResult {
  request_id: string; status: string;
  entity_id: string; assigned_mesh: string;
  assigned_agents: string[]; policy_decision: string;
  trust_gate_passed: boolean; estimated_completion_ms: number;
}

interface ResonanceMatrix {
  pairs: [string, string][]; scores: number[];
  average_resonance: number; clusters: string[][];
  outliers: string[]; field_strength: number;
}

interface SystemStats {
  trident: { registered: number; resolved: number; compared: number; validated: number; registry_size: number };
  registry: { total: number; avg_trust: number; by_lifecycle: Record<string, number>; by_mesh: Record<string, number> };
  agents: { total_agents: number; avg_load: number; by_mesh: Record<string, number>; by_capability: Record<string, number> };
  orchestrator: { routed: number; rejected: number; queued: number; failed: number; active: number };
  audit: { total_entries: number; entities_tracked: number; patterns_detected: number };
  gateway: { connected_clients: number; active_subscriptions: number; messages_processed: number };
  onnx: { loaded: boolean; path: string };
}

// ─── Color Maps ───────────────────────────────────────────────

const MESH_COLORS: Record<string, string> = {
  construction_space: '#00d4aa', agent_space: '#a855f7',
  knowledge_space: '#3b82f6', communication_space: '#f59e0b',
  interface_space: '#ef4444', priority_space: '#ec4899',
  general_space: '#6b7280', error_space: '#dc2626'
};

const CENTER_COLORS: Record<string, string> = {
  creative_direction: '#f472b6', mental_processing: '#60a5fa',
  emotional_intelligence: '#fbbf24', manifestation: '#34d399',
  communication: '#a78bfa', intuitive_awareness: '#22d3ee',
  will_power: '#fb7185', identity_definition: '#818cf8',
  general: '#9ca3af'
};

const MODULATION_COLORS: Record<string, string> = {
  constructive: '#22c55e', destructive: '#ef4444',
  neutral: '#6b7280', emergent: '#f59e0b', resonant: '#8b5cf6'
};

// ─── Components ──────────────────────────────────────────────

const Card: React.FC<{ title: string; children: React.ReactNode; className?: string; accent?: string }> =
  ({ title, children, className = '', accent = '#334155' }) => (
  <div className={`bg-slate-900/80 border rounded-xl overflow-hidden ${className}`} style={{ borderColor: accent + '30' }}>
    <div className="px-4 py-2 border-b flex items-center justify-between" style={{ borderColor: accent + '20', backgroundColor: accent + '08' }}>
      <h3 className="text-xs font-semibold uppercase tracking-wider" style={{ color: accent }}>{title}</h3>
    </div>
    <div className="p-4">{children}</div>
  </div>
);

const Badge: React.FC<{ text: string; color: string; size?: 'sm' | 'xs' }> = ({ text, color, size = 'sm' }) => (
  <span className={`inline-flex items-center rounded font-medium ${size === 'xs' ? 'px-1.5 py-0.5 text-[10px]' : 'px-2 py-0.5 text-xs'}`}
    style={{ backgroundColor: color + '15', color, border: `1px solid ${color}30` }}>
    {text}
  </span>
);

const Stat: React.FC<{ label: string; value: string | number; color?: string; sub?: string }> =
  ({ label, value, color, sub }) => (
  <div className="flex flex-col">
    <span className="text-slate-500 text-[10px] uppercase tracking-wider">{label}</span>
    <span className="text-lg font-bold tabular-nums" style={{ color: color || '#e2e8f0' }}>{value}</span>
    {sub && <span className="text-[10px] text-slate-600">{sub}</span>}
  </div>
);

const ProgressBar: React.FC<{ value: number; max: number; color?: string; height?: number }> =
  ({ value, max, color = '#22c55e', height = 6 }) => {
  const pct = Math.min(100, (value / max) * 100);
  const isHigh = pct > 80;
  const isMed = pct > 50;
  const barColor = isHigh ? '#ef4444' : isMed ? '#f59e0b' : color;
  return (
    <div className="w-full bg-slate-700/50 rounded-full overflow-hidden" style={{ height }}>
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, backgroundColor: barColor }} />
    </div>
  );
};

// ─── Address Node Visualizer ────────────────────────────────

const AddressNode: React.FC<{ address: MRNNAddress; size?: number }> = ({ address, size = 48 }) => {
  const s = size;
  const r = s / 2;
  const c = { x: r, y: r };
  const orbit1 = r * 0.85;
  const orbit2 = r * 0.65;
  const orbit3 = r * 0.45;

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: s, height: s }}>
      <svg viewBox={`0 0 ${s} ${s}`} className="absolute inset-0 w-full h-full">
        {/* Outer orbit - mesh */}
        <circle cx={c.x} cy={c.y} r={orbit1} fill="none" stroke={MESH_COLORS[address.mesh] || '#475569'} strokeWidth="1.5" opacity="0.4" />
        {/* Middle orbit - center */}
        <circle cx={c.x} cy={c.y} r={orbit2} fill="none" stroke={CENTER_COLORS[address.center] || '#64748b'} strokeWidth="1" opacity="0.5"
          strokeDasharray={`${address.color * 8} ${50 - address.color * 8}`} />
        {/* Inner orbit - modulation */}
        <circle cx={c.x} cy={c.y} r={orbit3} fill="none" stroke={MODULATION_COLORS[address.modulation_state] || '#64748b'} strokeWidth="2" opacity="0.6" />
        {/* Core */}
        <circle cx={c.x} cy={c.y} r={orbit3 * 0.4} fill={MESH_COLORS[address.mesh] || '#475569'} opacity={address.confidence} />
        {/* Line marker */}
        <text x={c.x} y={c.y + 3} textAnchor="middle" fill="white" fontSize={orbit3 * 0.35} fontWeight="bold">{address.line}</text>
      </svg>
      <div className="absolute -bottom-1 text-[8px] font-mono text-slate-500 whitespace-nowrap">
        L{address.line}C{address.color}T{address.tone}
      </div>
    </div>
  );
};

// ─── Resonance Field Visualizer ─────────────────────────────

const ResonanceField: React.FC<{ matrix?: ResonanceMatrix; entityIds: string[] }> = ({ matrix, entityIds }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current || !matrix) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Draw field background
    const gradient = ctx.createRadialGradient(w/2, h/2, 0, w/2, h/2, w/2);
    gradient.addColorStop(0, `rgba(0, 212, 170, ${matrix.field_strength * 0.1})`);
    gradient.addColorStop(1, 'rgba(15, 23, 42, 0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, w, h);

    // Position entities in circle
    const n = entityIds.length;
    const positions = entityIds.map((_, i) => {
      const angle = (i / n) * Math.PI * 2 - Math.PI / 2;
      return {
        x: w/2 + Math.cos(angle) * (w * 0.35),
        y: h/2 + Math.sin(angle) * (h * 0.35)
      };
    });

    // Draw connections
    matrix.pairs.forEach(([a, b], idx) => {
      const score = matrix.scores[idx];
      const i = entityIds.indexOf(a);
      const j = entityIds.indexOf(b);
      if (i < 0 || j < 0) return;

      const p1 = positions[i];
      const p2 = positions[j];
      const alpha = Math.abs(score) * 0.6;
      const color = score > 0 ? `rgba(0, 212, 170, ${alpha})` : `rgba(239, 68, 68, ${alpha})`;

      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.abs(score) * 2;
      ctx.stroke();
    });

    // Draw nodes
    positions.forEach((pos, i) => {
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#00d4aa';
      ctx.fill();
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.fillText(entityIds[i].slice(0, 8), pos.x - 15, pos.y + 18);
    });

  }, [matrix, entityIds]);

  return (
    <div className="relative">
      <canvas ref={canvasRef} width={300} height={300} className="w-full rounded-lg bg-slate-950" />
      <div className="absolute top-2 left-2 text-[10px] text-slate-500">
        field_strength: {matrix?.field_strength.toFixed(3) || '—'}
      </div>
    </div>
  );
};

// ─── Main Dashboard ──────────────────────────────────────────

export const SynthiaDashboardV2: React.FC = () => {
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [entities, setEntities] = useState<RegistryEntry[]>([]);
  const [agents, setAgents] = useState<AgentProfile[]>([]);
  const [activeRoutes, setActiveRoutes] = useState<OrchestrationResult[]>([]);
  const [resonanceMatrix, setResonanceMatrix] = useState<ResonanceMatrix | null>(null);
  const [selectedMesh, setSelectedMesh] = useState<string>('all');
  const [selectedTab, setSelectedTab] = useState<'overview' | 'entities' | 'agents' | 'resonance' | 'audit'>('overview');
  const [isConnected, setIsConnected] = useState(false);
  const [wsStatus, setWsStatus] = useState<'connecting' | 'open' | 'closed'>('closed');
  const [liveEvents, setLiveEvents] = useState<string[]>([]);
  const wsRef = useRef<WebSocket | null>(null);

  const API_BASE = process.env.REACT_APP_SYNTHIA_API || 'ws://localhost:8787';
  const HTTP_BASE = API_BASE.replace('ws://', 'http://').replace('wss://', 'https://');

  // HTTP polling
  const fetchData = useCallback(async () => {
    try {
      const [statsRes, entitiesRes, agentsRes, routesRes] = await Promise.all([
        fetch(`${HTTP_BASE}/api/stats`).then(r => r.json()),
        fetch(`${HTTP_BASE}/api/entities?limit=30`).then(r => r.json()),
        fetch(`${HTTP_BASE}/agents`).then(r => r.json()),
        fetch(`${HTTP_BASE}/orchestrate/routes/active`).then(r => r.json())
      ]);
      setStats(statsRes);
      setEntities(entitiesRes.entities || []);
      setAgents(agentsRes.agents || []);
      setActiveRoutes(routesRes.routes || []);
      setIsConnected(true);
    } catch {
      setIsConnected(false);
    }
  }, [HTTP_BASE]);

  // WebSocket connection
  useEffect(() => {
    const ws = new WebSocket(`${API_BASE}/trident/stream`);
    wsRef.current = ws;

    ws.onopen = () => {
      setWsStatus('open');
      // Subscribe to all mesh updates
      ws.send(JSON.stringify({ id: 'sub_all', type: 'subscribe', payload: { entity_id: '*' }, timestamp: Date.now() }));
    };

    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.type === 'event' && msg.payload?.event) {
        setLiveEvents(prev => [msg.payload.event, ...prev].slice(0, 20));
      }
    };

    ws.onclose = () => setWsStatus('closed');
    ws.onerror = () => setWsStatus('closed');

    return () => ws.close();
  }, [API_BASE]);

  // Polling
  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 3000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Compute resonance matrix for visible entities
  useEffect(() => {
    const ids = entities.slice(0, 8).map(e => e.entity_id);
    if (ids.length < 2) return;

    fetch(`${HTTP_BASE}/resonance/matrix`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entity_ids: ids })
    })
      .then(r => r.json())
      .then(setResonanceMatrix)
      .catch(() => {});
  }, [entities, HTTP_BASE]);

  const filteredEntities = selectedMesh === 'all'
    ? entities
    : entities.filter(e => e.mrnn_address.mesh === selectedMesh);

  const meshes = Array.from(new Set(entities.map(e => e.mrnn_address.mesh)));

  const wsIndicatorColor = wsStatus === 'open' ? '#22c55e' : wsStatus === 'connecting' ? '#f59e0b' : '#ef4444';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 font-sans">
      {/* Header */}
      <header className="border-b border-slate-800/50 bg-slate-900/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-teal-500 to-purple-600 flex items-center justify-center shadow-lg shadow-teal-500/20">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <h1 className="text-base font-bold text-white tracking-tight">Synthia Kernel</h1>
              <p className="text-[10px] text-slate-500 font-mono">Trident Addressing Service v0.2</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Live events ticker */}
            <div className="hidden md:flex items-center gap-2 bg-slate-800/50 rounded-lg px-3 py-1.5 max-w-xs">
              <div className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" />
              <span className="text-[10px] text-slate-400 font-mono truncate">
                {liveEvents[0] || 'idle'}
              </span>
            </div>

            {/* Connection status */}
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: wsIndicatorColor }} />
              <span className="text-[10px] text-slate-500 uppercase">{wsStatus}</span>
            </div>

            {/* ONNX badge */}
            {stats?.onnx?.loaded && (
              <Badge text="ONNX" color="#a855f7" size="xs" />
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="max-w-7xl mx-auto px-4 flex gap-1">
          {(['overview', 'entities', 'agents', 'resonance', 'audit'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setSelectedTab(tab)}
              className={`px-4 py-2 text-xs font-medium capitalize transition-colors border-b-2 ${
                selectedTab === tab
                  ? 'text-teal-400 border-teal-400'
                  : 'text-slate-500 border-transparent hover:text-slate-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* OVERVIEW TAB */}
        {selectedTab === 'overview' && stats && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              <Card title="Trident" accent="#00d4aa">
                <div className="grid grid-cols-2 gap-3">
                  <Stat label="Registered" value={stats.trident.registered} color="#00d4aa" />
                  <Stat label="Resolved" value={stats.trident.resolved} color="#3b82f6" />
                  <Stat label="Compared" value={stats.trident.compared} color="#a855f7" />
                  <Stat label="Validated" value={stats.trident.validated} color="#f59e0b" />
                </div>
              </Card>

              <Card title="Registry" accent="#3b82f6">
                <div className="space-y-2">
                  <Stat label="Total" value={stats.registry.total} color="#e2e8f0" />
                  <Stat label="Avg Trust" value={stats.registry.avg_trust.toFixed(2)} color="#22c55e" />
                  <div className="flex gap-1 mt-1">
                    {Object.entries(stats.registry.by_lifecycle || {}).map(([k, v]) => (
                      <Badge key={k} text={`${k}:${v}`} color={k === 'active' ? '#22c55e' : k === 'provisional' ? '#fbbf24' : '#ef4444'} size="xs" />
                    ))}
                  </div>
                </div>
              </Card>

              <Card title="Agents" accent="#a855f7">
                <div className="space-y-2">
                  <Stat label="Total" value={stats.agents.total_agents} color="#a855f7" />
                  <Stat label="Avg Load" value={stats.agents.avg_load.toFixed(1)} color="#f472b6" />
                  <ProgressBar value={stats.agents.avg_load} max={5} color="#a855f7" />
                </div>
              </Card>

              <Card title="Orchestrator" accent="#f59e0b">
                <div className="grid grid-cols-2 gap-2">
                  <Stat label="Routed" value={stats.orchestrator.routed} color="#22c55e" />
                  <Stat label="Rejected" value={stats.orchestrator.rejected} color="#ef4444" />
                  <Stat label="Queued" value={stats.orchestrator.queued} color="#f59e0b" />
                  <Stat label="Active" value={stats.orchestrator.active} color="#3b82f6" />
                </div>
              </Card>

              <Card title="Audit" accent="#64748b">
                <div className="space-y-2">
                  <Stat label="Entries" value={stats.audit.total_entries} color="#94a3b8" />
                  <Stat label="Patterns" value={stats.audit.patterns_detected} color="#a78bfa" />
                </div>
              </Card>

              <Card title="Gateway" accent="#22d3ee">
                <div className="space-y-2">
                  <Stat label="Clients" value={stats.gateway.connected_clients} color="#22d3ee" />
                  <Stat label="Messages" value={stats.gateway.messages_processed} color="#22d3ee" />
                </div>
              </Card>
            </div>

            {/* Mesh Distribution + Active Routes */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card title="Mesh Distribution" accent="#00d4aa" className="lg:col-span-1">
                <div className="space-y-2">
                  {Object.entries(stats.registry.by_mesh || {}).sort((a, b) => b[1] - a[1]).map(([mesh, count]) => (
                    <div key={mesh} className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: MESH_COLORS[mesh] || '#6b7280' }} />
                      <span className="text-xs text-slate-400 flex-1">{mesh.replace('_space', '')}</span>
                      <span className="text-xs font-mono text-slate-300">{count}</span>
                      <div className="w-20">
                        <ProgressBar value={count} max={stats.registry.total} color={MESH_COLORS[mesh]} height={4} />
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card title="Active Routes" accent="#f59e0b" className="lg:col-span-2">
                <div className="space-y-2 max-h-[200px] overflow-y-auto">
                  {activeRoutes.length === 0 && (
                    <p className="text-xs text-slate-600 italic">No active routes</p>
                  )}
                  {activeRoutes.map(route => (
                    <div key={route.request_id} className="flex items-center gap-3 p-2 bg-slate-800/40 rounded-lg">
                      <AddressNode address={{ mesh: route.assigned_mesh, layer: 'orchestration', center: 'will_power', gate: 'power', line: 1, color: 1, tone: 1, zodiac_context: 'neutral', modulation_state: route.trust_gate_passed ? 'constructive' : 'neutral', confidence: 0.7, version: 'v0.1' }} size={32} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono text-slate-400">{route.request_id.slice(0, 12)}...</span>
                          <Badge text={route.status} color={route.status === 'routed' ? '#22c55e' : '#f59e0b'} size="xs" />
                        </div>
                        <div className="text-[10px] text-slate-500 mt-0.5">
                          {route.assigned_mesh} · {route.assigned_agents.length} agents · {route.estimated_completion_ms}ms
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] text-slate-500">{route.policy_decision}</div>
                        <div className={`text-[10px] ${route.trust_gate_passed ? 'text-green-400' : 'text-yellow-400'}`}>
                          trust: {route.trust_gate_passed ? 'PASS' : 'HOLD'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        )}

        {/* ENTITIES TAB */}
        {selectedTab === 'entities' && (
          <div className="space-y-4">
            {/* Mesh Filter */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              <button onClick={() => setSelectedMesh('all')}
                className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${selectedMesh === 'all' ? 'bg-slate-700 text-white' : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'}`}>
                All Meshes ({entities.length})
              </button>
              {meshes.map(mesh => (
                <button key={mesh} onClick={() => setSelectedMesh(mesh)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors flex items-center gap-1.5 ${selectedMesh === mesh ? 'bg-slate-700 text-white' : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'}`}>
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: MESH_COLORS[mesh] || '#6b7280' }} />
                  {mesh.replace('_space', '')} ({entities.filter(e => e.mrnn_address.mesh === mesh).length})
                </button>
              ))}
            </div>

            {/* Entity List */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredEntities.map(entity => (
                <div key={entity.entity_id} className="bg-slate-900/60 border border-slate-800/50 rounded-xl p-4 hover:border-slate-700/50 transition-colors">
                  <div className="flex items-start gap-4">
                    <AddressNode address={entity.mrnn_address} size={56} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-white font-mono">{entity.entity_id.slice(0, 16)}...</span>
                        <Badge text={entity.entity_type} color={MESH_COLORS[entity.mrnn_address.mesh] || '#6b7280'} size="xs" />
                        <Badge text={entity.lifecycle} color={entity.lifecycle === 'active' ? '#22c55e' : entity.lifecycle === 'provisional' ? '#fbbf24' : '#ef4444'} size="xs" />
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-500 mb-2">
                        <span>center: <span style={{ color: CENTER_COLORS[entity.mrnn_address.center] }}>{entity.mrnn_address.center}</span></span>
                        <span>gate: {entity.mrnn_address.gate}</span>
                        <span style={{ color: MODULATION_COLORS[entity.mrnn_address.modulation_state] }}>{entity.mrnn_address.modulation_state}</span>
                        <span>zodiac: {entity.mrnn_address.zodiac_context}</span>
                        <span>access: {entity.access_level}</span>
                        <span>interactions: {entity.interaction_count}</span>
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="flex-1">
                          <ProgressBar value={entity.trust_score} max={1} color={entity.trust_score > 0.7 ? '#22c55e' : entity.trust_score > 0.4 ? '#f59e0b' : '#ef4444'} height={4} />
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">{(entity.trust_score * 100).toFixed(0)}%</span>
                      </div>

                      {entity.policy_flags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {entity.policy_flags.map(flag => (
                            <span key={flag} className="text-[9px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20">{flag}</span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* AGENTS TAB */}
        {selectedTab === 'agents' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {agents.map(agent => (
              <Card key={agent.agent_id} title={agent.display_name} accent={MESH_COLORS[agent.home_mesh] || '#6b7280'}>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <AddressNode address={agent.trident_address} size={40} />
                    <div>
                      <div className="text-xs text-slate-400">{agent.home_mesh}</div>
                      <div className="text-[10px] text-slate-600 font-mono">{agent.agent_id.slice(0, 16)}...</div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px]">
                      <span className="text-slate-500">Load</span>
                      <span className="text-slate-400">{agent.current_load}/{agent.max_concurrent}</span>
                    </div>
                    <ProgressBar value={agent.current_load} max={agent.max_concurrent} color="#a855f7" />
                  </div>

                  <div className="grid grid-cols-5 gap-1">
                    {Object.entries(agent.personality_vector).map(([trait, val]) => (
                      <div key={trait} className="text-center">
                        <div className="text-[8px] text-slate-600 capitalize">{trait.slice(0, 4)}</div>
                        <div className="text-[10px] font-mono" style={{ color: val > 0.7 ? '#22c55e' : val > 0.4 ? '#f59e0b' : '#ef4444' }}>{val.toFixed(1)}</div>
                      </div>
                    ))}
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {agent.capabilities.map(cap => (
                      <span key={cap.name} className={`text-[9px] px-1.5 py-0.5 rounded border ${cap.enabled ? 'bg-slate-800/50 text-slate-400 border-slate-700/50' : 'bg-slate-900/50 text-slate-600 border-slate-800/30 line-through'}`}>
                        {cap.name} {(cap.proficiency * 100).toFixed(0)}%
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* RESONANCE TAB */}
        {selectedTab === 'resonance' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card title="Resonance Field" accent="#8b5cf6">
              <ResonanceField matrix={resonanceMatrix || undefined} entityIds={entities.slice(0, 8).map(e => e.entity_id)} />
            </Card>

            <Card title="Matrix Details" accent="#8b5cf6">
              {resonanceMatrix ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <Stat label="Avg Resonance" value={resonanceMatrix.average_resonance.toFixed(3)} color="#8b5cf6" />
                    <Stat label="Field Strength" value={resonanceMatrix.field_strength.toFixed(3)} color="#22d3ee" />
                    <Stat label="Clusters" value={resonanceMatrix.clusters.length} color="#a855f7" />
                    <Stat label="Outliers" value={resonanceMatrix.outliers.length} color={resonanceMatrix.outliers.length > 0 ? '#ef4444' : '#22c55e'} />
                  </div>

                  <div className="space-y-1 max-h-[200px] overflow-y-auto">
                    {resonanceMatrix.pairs.map(([a, b], i) => {
                      const score = resonanceMatrix.scores[i];
                      return (
                        <div key={`${a}-${b}`} className="flex items-center gap-2 text-[10px]">
                          <span className="text-slate-500 font-mono w-16 truncate">{a.slice(0, 8)}</span>
                          <div className="flex-1 h-1 bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full rounded-full transition-all" style={{
                              width: `${Math.abs(score) * 50 + 50}%`,
                              backgroundColor: score > 0 ? '#8b5cf6' : '#ef4444',
                              marginLeft: score < 0 ? '0' : 'auto',
                              marginRight: score < 0 ? 'auto' : '0'
                            }} />
                          </div>
                          <span className="text-slate-500 font-mono w-16 truncate">{b.slice(0, 8)}</span>
                          <span className={`font-mono w-12 text-right ${score > 0 ? 'text-purple-400' : 'text-red-400'}`}>{score.toFixed(2)}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <p className="text-xs text-slate-600 italic">Need at least 2 entities for resonance matrix</p>
              )}
            </Card>
          </div>
        )}

        {/* AUDIT TAB */}
        {selectedTab === 'audit' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card title="Event Breakdown" accent="#64748b">
                {stats && (
                  <div className="space-y-1">
                    {Object.entries(stats.audit.event_type_breakdown || {}).sort((a, b) => b[1] - a[1]).map(([type, count]) => (
                      <div key={type} className="flex justify-between text-xs">
                        <span className="text-slate-400">{type}</span>
                        <span className="text-slate-300 font-mono">{count}</span>
                      </div>
                    ))}
                  </div>
                )}
              </Card>

              <Card title="Outcome Breakdown" accent="#64748b">
                {stats && (
                  <div className="space-y-1">
                    {Object.entries(stats.audit.outcome_breakdown || {}).sort((a, b) => b[1] - a[1]).map(([outcome, count]) => (
                      <div key={outcome} className="flex justify-between text-xs">
                        <span className="text-slate-400">{outcome}</span>
                        <span className="text-slate-300 font-mono">{count}</span>
                      </div>
                    ))}
                  </div>
                )}
              </Card>

              <Card title="Live Events" accent="#22d3ee">
                <div className="space-y-1 max-h-[200px] overflow-y-auto">
                  {liveEvents.map((evt, i) => (
                    <div key={i} className="text-[10px] text-slate-400 font-mono flex items-center gap-2">
                      <div className="w-1 h-1 rounded-full bg-teal-400" />
                      {evt}
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default SynthiaDashboardV2;
