/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  TRIDENT GATEWAY — Unified entry point for all entities       ║
 * ║  WebSocket stream + HTTP REST + Server-Sent Events           ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import { WebSocketServer, WebSocket } from 'ws';
import { createServer } from 'http';
import express from 'express';
import { trident, EntityInput } from './trident-addressing-service';
import { registry } from './entity-registry';
import SynthiaOrchestrator from './synthia-orchestrator';
import { agentProfiles } from './agent-profiles';
import { auditMemory } from './audit-memory';

interface GatewayMessage {
  id: string;
  type: 'register' | 'resolve' | 'compare' | 'validate' | 'ingest' | 'subscribe' | 'ping';
  payload: any;
  timestamp: number;
}

interface GatewayResponse {
  id: string;
  type: 'result' | 'error' | 'event' | 'pong';
  payload: any;
  processing_ms: number;
  timestamp: number;
}

export class TridentGateway {
  private wss: WebSocketServer | null = null;
  private clients: Map<string, WebSocket> = new Map();
  private subscriptions: Map<string, Set<string>> = new Map(); // entity_id -> client_ids
  private orchestrator: SynthiaOrchestrator;
  private messageCount = 0;
  private errorCount = 0;

  constructor(orchestrator: SynthiaOrchestrator) {
    this.orchestrator = orchestrator;
  }

  attachToServer(httpServer: ReturnType<typeof createServer>): void {
    this.wss = new WebSocketServer({ server: httpServer, path: '/trident/stream' });

    this.wss.on('connection', (ws, req) => {
      const clientId = `cli_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      this.clients.set(clientId, ws);

      console.log(`[Gateway] Client connected: ${clientId} from ${req.socket.remoteAddress}`);

      ws.on('message', async (data) => {
        const start = Date.now();
        try {
          const msg: GatewayMessage = JSON.parse(data.toString());
          this.messageCount++;

          const response = await this.handleMessage(msg, clientId);
          ws.send(JSON.stringify({
            ...response,
            processing_ms: Date.now() - start,
            timestamp: Date.now()
          }));
        } catch (err) {
          this.errorCount++;
          ws.send(JSON.stringify({
            id: 'error',
            type: 'error',
            payload: { message: (err as Error).message },
            processing_ms: Date.now() - start,
            timestamp: Date.now()
          }));
        }
      });

      ws.on('close', () => {
        this.clients.delete(clientId);
        // Clean up subscriptions
        for (const [entityId, clientSet] of this.subscriptions) {
          clientSet.delete(clientId);
          if (clientSet.size === 0) this.subscriptions.delete(entityId);
        }
        console.log(`[Gateway] Client disconnected: ${clientId}`);
      });

      // Send welcome
      ws.send(JSON.stringify({
        id: 'welcome',
        type: 'event',
        payload: { client_id: clientId, service: 'trident-gateway', version: '0.1.0' },
        processing_ms: 0,
        timestamp: Date.now()
      }));
    });
  }

  private async handleMessage(msg: GatewayMessage, clientId: string): Promise<GatewayResponse> {
    switch (msg.type) {
      case 'register': {
        const input: EntityInput = msg.payload;
        const result = await trident.register(input);
        await registry.storeEntity(result, { tags: input.context_tags });

        // Notify subscribers of this mesh
        this.broadcastToMesh(result.mrnn_address.mesh, {
          id: msg.id,
          type: 'event',
          payload: { event: 'entity_registered', entity: result },
          processing_ms: 0,
          timestamp: Date.now()
        });

        return { id: msg.id, type: 'result', payload: result, processing_ms: 0, timestamp: Date.now() };
      }

      case 'resolve': {
        const { entity_id } = msg.payload;
        const result = await trident.resolve(entity_id);
        return { id: msg.id, type: 'result', payload: result, processing_ms: 0, timestamp: Date.now() };
      }

      case 'compare': {
        const { entity_a, entity_b } = msg.payload;
        const result = await trident.compare(entity_a, entity_b);
        return { id: msg.id, type: 'result', payload: result, processing_ms: 0, timestamp: Date.now() };
      }

      case 'validate': {
        const { entity_id } = msg.payload;
        const result = await trident.validate(entity_id);
        return { id: msg.id, type: 'result', payload: result, processing_ms: 0, timestamp: Date.now() };
      }

      case 'ingest': {
        const result = await this.orchestrator.ingest(msg.payload);
        return { id: msg.id, type: 'result', payload: result, processing_ms: 0, timestamp: Date.now() };
      }

      case 'subscribe': {
        const { entity_id } = msg.payload;
        if (!this.subscriptions.has(entity_id)) this.subscriptions.set(entity_id, new Set());
        this.subscriptions.get(entity_id)!.add(clientId);
        return { id: msg.id, type: 'result', payload: { subscribed: true, entity_id }, processing_ms: 0, timestamp: Date.now() };
      }

      case 'ping': {
        return { id: msg.id, type: 'pong', payload: { messages: this.messageCount, errors: this.errorCount }, processing_ms: 0, timestamp: Date.now() };
      }

      default:
        throw new Error(`Unknown message type: ${msg.type}`);
    }
  }

  private broadcastToMesh(mesh: string, message: GatewayResponse): void {
    const entityIdsInMesh = Array.from(this.subscriptions.entries())
      .filter(([_, clients]) => {
        // Check if any client is subscribed to entities in this mesh
        // This is simplified — in production, maintain mesh->entity mapping
        return true;
      })
      .map(([entityId, _]) => entityId);

    for (const entityId of entityIdsInMesh) {
      const clients = this.subscriptions.get(entityId);
      if (!clients) continue;
      for (const clientId of clients) {
        const ws = this.clients.get(clientId);
        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify(message));
        }
      }
    }
  }

  broadcast(event: string, payload: any): void {
    const message: GatewayResponse = {
      id: `broadcast_${Date.now()}`,
      type: 'event',
      payload: { event, ...payload },
      processing_ms: 0,
      timestamp: Date.now()
    };

    for (const [clientId, ws] of this.clients) {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
      }
    }
  }

  getStats() {
    return {
      connected_clients: this.clients.size,
      active_subscriptions: this.subscriptions.size,
      messages_processed: this.messageCount,
      errors: this.errorCount
    };
  }
}

export default TridentGateway;
