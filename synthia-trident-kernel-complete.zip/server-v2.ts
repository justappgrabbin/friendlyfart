/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  SYNTHIA API SERVER v2 — With Gateway + ONNX Runtime        ║
 * ║  Unified HTTP + WebSocket entry point for Trident kernel.   ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { trident, EntityInput } from './trident-addressing-service';
import { registry } from './entity-registry';
import { agentProfiles } from './agent-profiles';
import SynthiaOrchestrator from './synthia-orchestrator';
import { resonanceScorer } from './resonance-scorer';
import { auditMemory } from './audit-memory';
import { TridentONNXLoader } from './trident-onnx-loader';
import TridentGateway from './trident-gateway';

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

const httpServer = createServer(app);

// Initialize services
const orchestrator = new SynthiaOrchestrator(trident, registry, agentProfiles);
const gateway = new TridentGateway(orchestrator);

// Try to load ONNX model, fallback to deterministic inference
let onnxLoader: TridentONNXLoader | null = null;
try {
  onnxLoader = new TridentONNXLoader({ modelPath: './models/trident_synthia.onnx' });
  await onnxLoader.load();
  console.log('[Server] ONNX model loaded successfully');
} catch {
  console.log('[Server] ONNX model not available, using deterministic inference fallback');
}

// ═══════════════════════════════════════════════════════════
// TRIDENT ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.post('/trident/register', async (req, res) => {
  try {
    const input: EntityInput = req.body;
    let result;

    if (onnxLoader) {
      // Use ONNX inference
      const onnxResult = await onnxLoader.infer(input);
      result = await trident.register(input); // still runs through service for registry/audit
      // Override with ONNX predictions
      result.mrnn_address = {
        ...result.mrnn_address,
        mesh: onnxResult.mesh,
        layer: onnxResult.layer,
        center: onnxResult.center,
        gate: onnxResult.gate,
        line: onnxResult.line,
        color: onnxResult.color,
        tone: onnxResult.tone,
        zodiac_context: onnxResult.zodiac,
        modulation_state: onnxResult.modulation,
        confidence: onnxResult.confidence
      };
      result.symbolic_fields = onnxResult.symbolic;
      result.address_source = 'trident_synthia_onnx';
    } else {
      result = await trident.register(input);
    }

    await registry.storeEntity(result, { tags: input.context_tags });

    auditMemory.record({
      timestamp: new Date().toISOString(),
      entity_id: result.entity_id,
      event_type: 'registration',
      event_data: { input, onnx_used: !!onnxLoader },
      mrnn_address_snapshot: {
        mesh: result.mrnn_address.mesh,
        layer: result.mrnn_address.layer,
        center: result.mrnn_address.center,
        gate: result.mrnn_address.gate,
        line: result.mrnn_address.line,
        color: result.mrnn_address.color,
        tone: result.mrnn_address.tone,
        zodiac: result.mrnn_address.zodiac_context,
        modulation: result.mrnn_address.modulation_state,
        confidence: result.mrnn_address.confidence
      },
      trust_before: result.mrnn_address.confidence * 0.5,
      trust_after: result.mrnn_address.confidence * 0.5,
      agents_involved: []
    });

    // Broadcast via gateway
    gateway.broadcast('entity_registered', { entity: result });

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.post('/trident/register-batch', async (req, res) => {
  try {
    const { entities } = req.body;
    let results;

    if (onnxLoader) {
      const onnxResults = await onnxLoader.inferBatch(entities);
      results = await trident.registerBatch(entities);
      // Merge ONNX predictions
      for (let i = 0; i < results.length; i++) {
        results[i].mrnn_address = {
          ...results[i].mrnn_address,
          mesh: onnxResults[i].mesh,
          layer: onnxResults[i].layer,
          center: onnxResults[i].center,
          gate: onnxResults[i].gate,
          line: onnxResults[i].line,
          color: onnxResults[i].color,
          tone: onnxResults[i].tone,
          zodiac_context: onnxResults[i].zodiac,
          modulation_state: onnxResults[i].modulation,
          confidence: onnxResults[i].confidence
        };
        results[i].symbolic_fields = onnxResults[i].symbolic;
      }
    } else {
      results = await trident.registerBatch(entities);
    }

    for (const result of results) {
      await registry.storeEntity(result, { tags: req.body.entities.find((e: any) => e === result.entity_id)?.context_tags });
    }

    res.json({ count: results.length, results });
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.post('/trident/resolve', async (req, res) => {
  try {
    const { entity_id } = req.body;
    const result = await trident.resolve(entity_id);
    if (!result) return res.status(404).json({ error: 'Entity not found' });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.post('/trident/compare', async (req, res) => {
  try {
    const { entity_a, entity_b } = req.body;
    const result = await trident.compare(entity_a, entity_b);

    const a = await trident.resolve(entity_a);
    const b = await trident.resolve(entity_b);
    if (a && b) {
      resonanceScorer.registerEntity(entity_a, a.mrnn_address);
      resonanceScorer.registerEntity(entity_b, b.mrnn_address);
    }

    auditMemory.record({
      timestamp: new Date().toISOString(),
      entity_id: `${entity_a}_vs_${entity_b}`,
      event_type: 'comparison',
      event_data: { entity_a, entity_b, result },
      mrnn_address_snapshot: { mesh: 'comparison', layer: 'analysis', center: 'mental_processing', gate: 'logic', line: 1, color: 1, tone: 1, zodiac: 'neutral', modulation: 'neutral', confidence: result.resonance_score },
      trust_before: 0.5,
      trust_after: 0.5,
      agents_involved: []
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.post('/trident/validate', async (req, res) => {
  try {
    const { entity_id } = req.body;
    const result = await trident.validate(entity_id);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

// ═══════════════════════════════════════════════════════════
// REGISTRY ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.get('/registry/entity/:id', async (req, res) => {
  const entry = await registry.getEntity(req.params.id);
  if (!entry) return res.status(404).json({ error: 'Not found' });
  res.json(entry);
});

app.post('/registry/query', async (req, res) => {
  const results = await registry.query(req.body);
  res.json({ count: results.length, entities: results });
});

app.post('/registry/interact', async (req, res) => {
  const { entity_id, outcome } = req.body;
  const before = await registry.getEntity(entity_id);
  await registry.recordInteraction(entity_id, outcome);
  const updated = await registry.getEntity(entity_id);

  auditMemory.record({
    timestamp: new Date().toISOString(),
    entity_id,
    event_type: 'interaction',
    event_data: { outcome },
    mrnn_address_snapshot: {
      mesh: updated!.mrnn_address.mesh,
      layer: updated!.mrnn_address.layer,
      center: updated!.mrnn_address.center,
      gate: updated!.mrnn_address.gate,
      line: updated!.mrnn_address.line,
      color: updated!.mrnn_address.color,
      tone: updated!.mrnn_address.tone,
      zodiac: updated!.mrnn_address.zodiac_context,
      modulation: updated!.mrnn_address.modulation_state,
      confidence: updated!.mrnn_address.confidence
    },
    outcome,
    trust_before: before?.trust_score || 0,
    trust_after: updated!.trust_score,
    agents_involved: []
  });

  res.json(updated);
});

app.get('/registry/stats', async (_req, res) => {
  res.json(registry.getStats());
});

// ═══════════════════════════════════════════════════════════
// AGENT ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.post('/agents/create', async (req, res) => {
  try {
    const { entity_input, options } = req.body;
    const tridentResult = await trident.register(entity_input);
    await registry.storeEntity(tridentResult, { access_level: 'general', tags: ['agent'] });
    const profile = await agentProfiles.createAgent(tridentResult, options);
    res.json(profile);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.get('/agents/:id', async (req, res) => {
  const profile = await agentProfiles.getAgent(req.params.id);
  if (!profile) return res.status(404).json({ error: 'Not found' });
  res.json(profile);
});

app.get('/agents', async (_req, res) => {
  res.json({
    agents: Array.from((agentProfiles as any).profiles?.values() || []),
    stats: agentProfiles.getStats()
  });
});

app.post('/agents/find-capable', async (req, res) => {
  const { capability, mesh, min_proficiency } = req.body;
  const agents = await agentProfiles.findCapableAgents(capability, mesh, min_proficiency);
  res.json({ count: agents.length, agents });
});

app.post('/agents/find-personality', async (req, res) => {
  const { trait, min_value, mesh } = req.body;
  const agents = await agentProfiles.findAgentsByPersonality(trait, min_value, mesh);
  res.json({ count: agents.length, agents });
});

// ═══════════════════════════════════════════════════════════
// ORCHESTRATOR ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.post('/orchestrate/ingest', async (req, res) => {
  try {
    const result = await orchestrator.ingest(req.body);

    // Audit the orchestration
    auditMemory.record({
      timestamp: new Date().toISOString(),
      entity_id: result.entity_id,
      event_type: 'orchestration',
      event_data: { request_id: result.request_id, intent: req.body.intent, status: result.status },
      mrnn_address_snapshot: { mesh: result.assigned_mesh, layer: 'orchestration', center: 'will_power', gate: 'power', line: 1, color: 1, tone: 1, zodiac: 'neutral', modulation: result.trust_gate_passed ? 'constructive' : 'neutral', confidence: result.trust_gate_passed ? 0.8 : 0.4 },
      outcome: result.status === 'routed' ? 'success' : result.status === 'rejected' ? 'failure' : 'pending',
      trust_before: 0.5,
      trust_after: result.trust_gate_passed ? 0.6 : 0.3,
      policy_applied: result.policy_decision,
      agents_involved: result.assigned_agents
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

app.post('/orchestrate/complete', async (req, res) => {
  const { request_id, outcome } = req.body;
  await orchestrator.complete(request_id, outcome);
  res.json({ status: 'completed' });
});

app.get('/orchestrate/queue', async (_req, res) => {
  res.json({ length: orchestrator.getQueueLength() });
});

app.get('/orchestrate/routes/active', async (_req, res) => {
  res.json({ routes: Array.from((orchestrator as any).active?.values() || []) });
});

app.get('/orchestrate/audit', async (req, res) => {
  const limit = Number(req.query.limit) || 100;
  res.json({ entries: orchestrator.getAuditLog(limit) });
});

// ═══════════════════════════════════════════════════════════
// RESONANCE ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.post('/resonance/compute', async (req, res) => {
  const { entity_a, entity_b } = req.body;
  const a = await trident.resolve(entity_a);
  const b = await trident.resolve(entity_b);
  if (!a || !b) return res.status(404).json({ error: 'One or both entities not found' });

  resonanceScorer.registerEntity(entity_a, a.mrnn_address);
  resonanceScorer.registerEntity(entity_b, b.mrnn_address);
  const score = resonanceScorer.computeResonance(entity_a, entity_b);

  res.json({ entity_a, entity_b, resonance_score: score });
});

app.post('/resonance/matrix', async (req, res) => {
  const { entity_ids } = req.body;
  for (const id of entity_ids) {
    const entity = await trident.resolve(id);
    if (entity) resonanceScorer.registerEntity(id, entity.mrnn_address);
  }
  const matrix = resonanceScorer.computeMatrix(entity_ids);
  res.json(matrix);
});

app.get('/resonance/entity/:id/history', async (req, res) => {
  const history = resonanceScorer.getEntityResonanceHistory(req.params.id);
  const freq = resonanceScorer.getDominantFrequency(req.params.id);
  res.json({ entity_id: req.params.id, history, dominant_frequency: freq });
});

// ═══════════════════════════════════════════════════════════
// AUDIT ENDPOINTS
// ═══════════════════════════════════════════════════════════

app.get('/audit/stats', async (_req, res) => {
  res.json(auditMemory.getStats());
});

app.post('/audit/query', async (req, res) => {
  const results = auditMemory.query(req.body);
  res.json({ count: results.length, entries: results });
});

app.get('/audit/patterns', async (_req, res) => {
  res.json({ patterns: auditMemory.getPatterns() });
});

app.get('/audit/entity/:id/history', async (req, res) => {
  const history = auditMemory.getEntityHistory(req.params.id);
  const trajectory = auditMemory.getTrustTrajectory(req.params.id);
  res.json({ entity_id: req.params.id, count: history.length, history, trust_trajectory: trajectory });
});

app.get('/audit/policy/:name', async (req, res) => {
  const effectiveness = auditMemory.getPolicyEffectiveness(req.params.name);
  res.json({ policy: req.params.name, ...effectiveness });
});

// ═══════════════════════════════════════════════════════════
// DASHBOARD STATS ENDPOINT
// ═══════════════════════════════════════════════════════════

app.get('/api/stats', async (_req, res) => {
  res.json({
    trident: trident.getStats(),
    registry: registry.getStats(),
    agents: agentProfiles.getStats(),
    orchestrator: orchestrator.getStats(),
    audit: auditMemory.getStats(),
    gateway: gateway.getStats(),
    onnx: onnxLoader ? onnxLoader.getSessionInfo() : { loaded: false, path: 'none', inputDim: 0 }
  });
});

app.get('/api/entities', async (req, res) => {
  const limit = Number(req.query.limit) || 20;
  const mesh = req.query.mesh as string | undefined;
  const all = await registry.query({ limit, mesh });
  res.json({ entities: all });
});

app.get('/api/meshes', async (_req, res) => {
  const stats = registry.getStats();
  res.json({ meshes: stats.by_mesh });
});

// ═══════════════════════════════════════════════════════════
// GATEWAY STATS
// ═══════════════════════════════════════════════════════════

app.get('/gateway/stats', async (_req, res) => {
  res.json(gateway.getStats());
});

// ═══════════════════════════════════════════════════════════
// HEALTH
// ═══════════════════════════════════════════════════════════

app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'synthia-trident',
    version: '0.2.0',
    onnx_loaded: !!onnxLoader,
    gateway_clients: gateway.getStats().connected_clients,
    uptime: process.uptime()
  });
});

// ═══════════════════════════════════════════════════════════
// START
// ═══════════════════════════════════════════════════════════

const PORT = process.env.PORT || 8787;

async function main() {
  await trident.initialize();
  gateway.attachToServer(httpServer);

  httpServer.listen(PORT, () => {
    console.log(`🌊 Synthia Trident Kernel v2 listening on port ${PORT}`);
    console.log(`   HTTP:  http://localhost:${PORT}`);
    console.log(`   WS:    ws://localhost:${PORT}/trident/stream`);
    console.log('');
    console.log('   POST /trident/register     — Register entity (ONNX-powered)');
    console.log('   POST /trident/resolve      — Resolve address');
    console.log('   POST /trident/compare      — Compare entities');
    console.log('   POST /trident/validate     — Validate address');
    console.log('   POST /orchestrate/ingest   — Ingest & route');
    console.log('   POST /resonance/compute    — Compute resonance');
    console.log('   POST /resonance/matrix     — Resonance matrix');
    console.log('   GET  /api/stats            — Dashboard data');
    console.log('   GET  /health               — Health check');
  });
}

main().catch(console.error);

export { app, httpServer, gateway, orchestrator, onnxLoader };
