/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  ENTITY REGISTRY — Persistent address storage                 ║
 * ║  Backs Trident with durable, queryable entity records.        ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import { TridentResult, MRNNAddress } from './trident-addressing-service';

export interface RegistryEntry extends TridentResult {
  lifecycle: 'provisional' | 'active' | 'suspended' | 'archived' | 'destroyed';
  access_level: 'public' | 'verified_young' | 'general' | 'restricted' | 'adult_sovereign';
  trust_score: number; // 0.0 - 1.0, earned through longitudinal coherence
  interaction_count: number;
  last_interaction: string;
  created_at: string;
  updated_at: string;
  lineage: string[]; // parent entity_ids
  children: string[]; // child entity_ids
  tags: string[];
  metadata: Record<string, any>;
}

export class EntityRegistry {
  private store: Map<string, RegistryEntry> = new Map();
  private meshIndex: Map<string, Set<string>> = new Map();
  private typeIndex: Map<string, Set<string>> = new Map();
  private centerIndex: Map<string, Set<string>> = new Map();
  private gateIndex: Map<string, Set<string>> = new Map();
  private accessIndex: Map<string, Set<string>> = new Map();
  private trustHistory: Map<string, number[]> = new Map(); // entity_id -> [scores]

  async storeEntity(result: TridentResult, options?: {
    access_level?: RegistryEntry['access_level'];
    lineage?: string[];
    tags?: string[];
    metadata?: Record<string, any>;
  }): Promise<RegistryEntry> {
    const now = new Date().toISOString();
    const entry: RegistryEntry = {
      ...result,
      lifecycle: 'provisional',
      access_level: options?.access_level || 'general',
      trust_score: result.mrnn_address.confidence * 0.5, // starts at half confidence
      interaction_count: 0,
      last_interaction: now,
      created_at: now,
      updated_at: now,
      lineage: options?.lineage || [],
      children: [],
      tags: options?.tags || [],
      metadata: options?.metadata || {}
    };

    this.store.set(result.entity_id, entry);
    this.indexEntity(entry);
    this.trustHistory.set(result.entity_id, [entry.trust_score]);

    return entry;
  }

  async getEntity(entity_id: string): Promise<RegistryEntry | null> {
    return this.store.get(entity_id) || null;
  }

  async updateEntity(entity_id: string, updates: Partial<RegistryEntry>): Promise<RegistryEntry | null> {
    const entry = this.store.get(entity_id);
    if (!entry) return null;

    // Re-index if address changed
    if (updates.mrnn_address && updates.mrnn_address !== entry.mrnn_address) {
      this.deindexEntity(entry);
    }

    const updated = { ...entry, ...updates, updated_at: new Date().toISOString() };
    this.store.set(entity_id, updated);

    if (updates.mrnn_address) this.indexEntity(updated);

    return updated;
  }

  async recordInteraction(entity_id: string, outcome: 'success' | 'failure' | 'neutral' | 'ambiguous'): Promise<void> {
    const entry = this.store.get(entity_id);
    if (!entry) return;

    entry.interaction_count++;
    entry.last_interaction = new Date().toISOString();

    // Trust evolution — longitudinal coherence
    const history = this.trustHistory.get(entity_id) || [];
    const currentTrust = entry.trust_score;
    let delta = 0;

    if (outcome === 'success') delta = 0.05;
    else if (outcome === 'failure') delta = -0.08;
    else if (outcome === 'ambiguous') delta = 0.01;

    // Decay old trust slightly
    const decay = history.length > 10 ? 0.02 : 0;
    const newTrust = Math.max(0, Math.min(1, currentTrust + delta - decay));

    entry.trust_score = newTrust;
    history.push(newTrust);
    if (history.length > 50) history.shift(); // keep last 50
    this.trustHistory.set(entity_id, history);

    // Lifecycle transitions based on trust
    if (entry.lifecycle === 'provisional' && newTrust > 0.6 && entry.interaction_count > 3) {
      entry.lifecycle = 'active';
    }
    if (entry.lifecycle === 'active' && newTrust < 0.2 && entry.interaction_count > 5) {
      entry.lifecycle = 'suspended';
    }

    this.store.set(entity_id, entry);
  }

  async promoteAccess(entity_id: string, newLevel: RegistryEntry['access_level']): Promise<boolean> {
    const entry = this.store.get(entity_id);
    if (!entry) return false;

    const levels: RegistryEntry['access_level'][] = ['public', 'verified_young', 'general', 'restricted', 'adult_sovereign'];
    const currentIdx = levels.indexOf(entry.access_level);
    const newIdx = levels.indexOf(newLevel);

    // Trust-gated promotion
    if (newIdx > currentIdx && entry.trust_score < 0.7) return false;

    this.deindexEntity(entry);
    entry.access_level = newLevel;
    this.indexEntity(entry);
    this.store.set(entity_id, entry);
    return true;
  }

  // ─── Query Methods ─────────────────────────────────────────

  query(options: {
    mesh?: string;
    type?: string;
    center?: string;
    gate?: string;
    access_level?: string;
    lifecycle?: string;
    min_trust?: number;
    tags?: string[];
    limit?: number;
  }): RegistryEntry[] {
    let candidates: Set<string> | null = null;

    if (options.mesh) {
      const meshSet = this.meshIndex.get(options.mesh);
      candidates = candidates ? this.intersect(candidates, meshSet || new Set()) : (meshSet || new Set());
    }
    if (options.type) {
      const typeSet = this.typeIndex.get(options.type);
      candidates = candidates ? this.intersect(candidates, typeSet || new Set()) : (typeSet || new Set());
    }
    if (options.center) {
      const centerSet = this.centerIndex.get(options.center);
      candidates = candidates ? this.intersect(candidates, centerSet || new Set()) : (centerSet || new Set());
    }
    if (options.gate) {
      const gateSet = this.gateIndex.get(options.gate);
      candidates = candidates ? this.intersect(candidates, gateSet || new Set()) : (gateSet || new Set());
    }
    if (options.access_level) {
      const accessSet = this.accessIndex.get(options.access_level);
      candidates = candidates ? this.intersect(candidates, accessSet || new Set()) : (accessSet || new Set());
    }

    let results = Array.from(candidates || this.store.keys())
      .map(id => this.store.get(id)!)
      .filter(e => {
        if (options.lifecycle && e.lifecycle !== options.lifecycle) return false;
        if (options.min_trust && e.trust_score < options.min_trust) return false;
        if (options.tags && !options.tags.every(t => e.tags.includes(t))) return false;
        return true;
      })
      .sort((a, b) => b.trust_score - a.trust_score);

    if (options.limit) results = results.slice(0, options.limit);
    return results;
  }

  getTrustTrajectory(entity_id: string): number[] {
    return this.trustHistory.get(entity_id) || [];
  }

  getStats() {
    return {
      total: this.store.size,
      by_lifecycle: this.countBy('lifecycle'),
      by_access: this.countBy('access_level'),
      by_mesh: this.countByIndex(this.meshIndex),
      by_type: this.countByIndex(this.typeIndex),
      avg_trust: Array.from(this.store.values()).reduce((s, e) => s + e.trust_score, 0) / (this.store.size || 1)
    };
  }

  // ─── Private ───────────────────────────────────────────────

  private indexEntity(entry: RegistryEntry): void {
    const id = entry.entity_id;
    this.addToIndex(this.meshIndex, entry.mrnn_address.mesh, id);
    this.addToIndex(this.typeIndex, entry.entity_type, id);
    this.addToIndex(this.centerIndex, entry.mrnn_address.center, id);
    this.addToIndex(this.gateIndex, entry.mrnn_address.gate, id);
    this.addToIndex(this.accessIndex, entry.access_level, id);
  }

  private deindexEntity(entry: RegistryEntry): void {
    const id = entry.entity_id;
    this.meshIndex.get(entry.mrnn_address.mesh)?.delete(id);
    this.typeIndex.get(entry.entity_type)?.delete(id);
    this.centerIndex.get(entry.mrnn_address.center)?.delete(id);
    this.gateIndex.get(entry.mrnn_address.gate)?.delete(id);
    this.accessIndex.get(entry.access_level)?.delete(id);
  }

  private addToIndex(index: Map<string, Set<string>>, key: string, id: string): void {
    if (!index.has(key)) index.set(key, new Set());
    index.get(key)!.add(id);
  }

  private intersect(a: Set<string>, b: Set<string>): Set<string> {
    return new Set([...a].filter(x => b.has(x)));
  }

  private countBy(field: keyof RegistryEntry): Record<string, number> {
    const counts: Record<string, number> = {};
    for (const entry of this.store.values()) {
      const val = String(entry[field]);
      counts[val] = (counts[val] || 0) + 1;
    }
    return counts;
  }

  private countByIndex(index: Map<string, Set<string>>): Record<string, number> {
    const counts: Record<string, number> = {};
    for (const [key, set] of index) counts[key] = set.size;
    return counts;
  }
}

export const registry = new EntityRegistry();
export default registry;
