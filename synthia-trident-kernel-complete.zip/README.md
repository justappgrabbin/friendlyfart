# Synthia Trident Kernel

## Trident Addressing Service — Layer 1 of the Synthia Civilization Platform

> **Trident names the thing. Synthia decides what the named thing can do.**

### Architecture

```
Entity appears
    ↓
Trident Gateway
    ↓
Trident_synthia.onnx inference
    ↓
MRNN / resonance address generated or refined
    ↓
Policy check
    ↓
Orchestrator can route it
```

### Build Order

1. **Trident Addressing Service** ← `trident-addressing-service.ts`
2. **Entity Registry** ← `entity-registry.ts`
3. **Agent Profiles** ← `agent-profiles.ts`
4. **Synthia Orchestrator** ← `synthia-orchestrator.ts`
5. **Resonance Scorer** ← `resonance-scorer.ts`
6. **Audit/Outcome Memory** ← `audit-memory.ts`
7. **Tiny Dashboard Shell** ← `synthia-dashboard.tsx`
8. **API Server** ← `server.ts`

### API Endpoints

#### Trident
- `POST /trident/register` — Register entity, run ONNX inference, generate MRNN address
- `POST /trident/resolve` — Resolve entity by ID
- `POST /trident/compare` — Compare two entities, return resonance score
- `POST /trident/validate` — Validate address integrity
- `POST /trident/register-batch` — Batch registration

#### Registry
- `GET /registry/entity/:id` — Get entity details
- `POST /registry/query` — Query with filters (mesh, type, center, trust, etc.)
- `POST /registry/interact` — Record interaction outcome (success/failure)
- `GET /registry/stats` — Registry statistics

#### Agents
- `POST /agents/create` — Create agent from entity
- `GET /agents/:id` — Get agent profile
- `GET /agents` — List all agents
- `POST /agents/find-capable` — Find agents by capability

#### Orchestrator
- `POST /orchestrate/ingest` — Ingest request, address, policy-check, route
- `POST /orchestrate/complete` — Mark request complete
- `GET /orchestrate/queue` — Queue length
- `GET /orchestrate/routes/active` — Active routes
- `GET /orchestrate/audit` — Audit trail

#### Resonance
- `POST /resonance/compute` — Compute resonance between two entities
- `POST /resonance/matrix` — Compute full resonance matrix for entity set

#### Audit
- `GET /audit/stats` — Audit statistics
- `POST /audit/query` — Query audit entries
- `GET /audit/patterns` — Detected outcome patterns
- `GET /audit/entity/:id/history` — Entity-specific history

#### Dashboard
- `GET /api/stats` — Aggregated stats for dashboard
- `GET /api/entities` — Entity list for dashboard

### MRNN Address Format

```json
{
  "mesh": "construction_space",
  "layer": "task_execution",
  "center": "creative_direction",
  "gate": "initiation",
  "line": 3,
  "color": 2,
  "tone": 5,
  "zodiac_context": "mutable_fire",
  "modulation_state": "constructive",
  "confidence": 0.82,
  "version": "mrnn-v0.1"
}
```

### Trust Model

- Starts at `confidence * 0.5`
- Grows with successful interactions (+0.05)
- Decays with failures (-0.08)
- Longitudinal coherence tracked over last 50 interactions
- Lifecycle transitions: provisional → active → suspended
- Access levels: public → verified_young → general → restricted → adult_sovereign

### Policy Engine

Default rules:
1. **critical_bypass** — Critical priority bypasses trust gates
2. **destructive_escalation** — Destructive modulation requires approval
3. **low_trust_throttle** — Low trust + destructive intent = throttle
4. **suspended_denial** — Suspended entities denied
5. **adult_sovereign_gate** — Adult sovereign access for communication
6. **public_fast_track** — Public mesh fast-tracked

### Running

```bash
npm install
npm run build
npm start
# or dev mode:
npm run dev
```

Dashboard runs at `http://localhost:8787` (API) + React frontend.
