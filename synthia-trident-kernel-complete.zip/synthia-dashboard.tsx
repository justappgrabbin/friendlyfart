/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  TINY DASHBOARD SHELL — Synthia Kernel Monitor               ║
 * ║  Real-time view of Trident addresses, agents, resonance.    ║
 * ╚══════════════════════════════════════════════════════════════╝
 */

import React, { useState, useEffect, useCallback } from 'react';

// ─── Types matching the backend ──────────────────────────────

interface MRNNAddress {
  mesh: string;
  layer: string;
  center: string;
  gate: string;
  line: number;
  color: number;
  tone: number;
  zodiac_context: string;
  modulation_state: string;
  confidence: number;
  version: string;
}

interface TridentResult {
  entity_id: string;
  entity_type: string;
  address_source: string;
  mrnn_address: MRNNAddress;
  symbolic_fields: Record<string, any>;
  policy_flags: string[];
  explanation: string;
  processing_ms: number;
  registered_at: string;
}

interface RegistryEntry extends TridentResult {
  lifecycle: string;
  access_level: string;
  trust_score: number;
  interaction_count: number;
}

interface AgentProfile {
  agent_id: string;
  display_name: string;
  trident_address: MRNNAddress;
  current_load: number;
  max_concurrent: number;
  capabilities: { name: string; proficiency: number; enabled: boolean }[];
}

interface OrchestrationResult {
  request_id: string;
  status: string;
  entity_id: string;
  assigned_mesh: string;
  assigned_agents: string[];
  policy_decision: string;
  trust_gate_passed: boolean;
}

interface DashboardStats {
  trident: { registered: number; resolved: number; compared: number; validated: number; registry_size: number };
  registry: { total: number; avg_trust: number; by_lifecycle: Record<string, number> };
  agents: { total_agents: number; avg_load: number; by_mesh: Record<string, number> };
  orchestrator: { routed: number; rejected: number; queued: number; failed: number; active: number };
}

// ─── Color Maps ──────────────────────────────────────────────

const MESH_COLORS: Record<string, string> = {
  construction_space: '#00d4aa',
  agent_space: '#a855f7',
  knowledge_space: '#3b82f6',
  communication_space: '#f59e0b',
  interface_space: '#ef4444',
  priority_space: '#ec4899',
  general_space: '#6b7280',
  error_space: '#dc2626'
};

const CENTER_COLORS: Record<string, string> = {
  creative_direction: '#f472b6',
  mental_processing: '#60a5fa',
  emotional_intelligence: '#fbbf24',
  manifestation: '#34d399',
  communication: '#a78bfa',
  intuitive_awareness: '#22d3ee',
  will_power: '#fb7185',
  identity_definition: '#818cf8',
  general: '#9ca3af'
};

const MODULATION_COLORS: Record<string, string> = {
  constructive: '#22c55e',
  destructive: '#ef4444',
  neutral: '#6b7280',
  emergent: '#f59e0b',
  resonant: '#8b5cf6'
};

// ─── Components ──────────────────────────────────────────────

const Card: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className = '' }) => (
  <div className={`bg-slate-900/80 border border-slate-700/50 rounded-xl p-4 ${className}`}>
    <h3 className="text-slate-300 text-sm font-semibold uppercase tracking-wider mb-3">{title}</h3>
    {children}
  </div>
);

const Badge: React.FC<{ text: string; color: string }> = ({ text, color }) => (
  <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium" style={{ backgroundColor: color + '20', color, border: `1px solid ${color}40` }}>
    {text}
  </span>
);

const Stat: React.FC<{ label: string; value: string | number; color?: string }> = ({ label, value, color }) => (
  <div className="flex flex-col">
    <span className="text-slate-500 text-xs">{label}</span>
    <span className="text-xl font-bold" style={{ color: color || '#e2e8f0' }}>{value}</span>
  </div>
);

const AddressVisualizer: React.FC<{ address: MRNNAddress }> = ({ address }) => {
  const size = 40 + address.confidence * 60;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full animate-spin" style={{ animationDuration: `${20 - address.line * 2}s` }}>
        <circle cx="50" cy="50" r="45" fill="none" stroke={MESH_COLORS[address.mesh] || '#6b7280'} strokeWidth="2" opacity="0.3" />
        <circle cx="50" cy="50" r="35" fill="none" stroke={CENTER_COLORS[address.center] || '#9ca3af'} strokeWidth="1.5" opacity="0.5" strokeDasharray={`${address.color * 10} ${60 - address.color * 10}`} />
        <circle cx="50" cy="50" r="25" fill="none" stroke={MODULATION_COLORS[address.modulation_state] || '#6b7280'} strokeWidth="2" opacity="0.6" />
      </svg>
      <div className="text-center z-10">
        <div className="text-xs font-bold" style={{ color: MESH_COLORS[address.mesh] }}>{address.mesh.split('_')[0]}</div>
        <div className="text-[10px] text-slate-400">L{address.line}C{address.color}T{address.tone}</div>
      </div>
    </div>
  );
};

// ─── Main Dashboard ──────────────────────────────────────────

export const SynthiaDashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [entities, setEntities] = useState<RegistryEntry[]>([]);
  const [agents, setAgents] = useState<AgentProfile[]>([]);
  const [activeRoutes, setActiveRoutes] = useState<OrchestrationResult[]>([]);
  const [selectedMesh, setSelectedMesh] = useState<string>('all');
  const [refreshInterval, setRefreshInterval] = useState<number>(3000);
  const [isConnected, setIsConnected] = useState(false);

  const API_BASE = process.env.REACT_APP_SYNTHIA_API || 'http://localhost:8787';

  const fetchData = useCallback(async () => {
    try {
      const [statsRes, entitiesRes, agentsRes, routesRes] = await Promise.all([
        fetch(`${API_BASE}/api/stats`).then(r => r.json()),
        fetch(`${API_BASE}/api/entities?limit=20`).then(r => r.json()),
        fetch(`${API_BASE}/api/agents`).then(r => r.json()),
        fetch(`${API_BASE}/api/routes/active`).then(r => r.json())
      ]);
      setStats(statsRes);
      setEntities(entitiesRes.entities || []);
      setAgents(agentsRes.agents || []);
      setActiveRoutes(routesRes.routes || []);
      setIsConnected(true);
    } catch {
      setIsConnected(false);
    }
  }, [API_BASE]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, refreshInterval);
    return () => clearInterval(interval);
  }, [fetchData, refreshInterval]);

  const filteredEntities = selectedMesh === 'all'
    ? entities
    : entities.filter(e => e.mrnn_address.mesh === selectedMesh);

  const meshes = Array.from(new Set(entities.map(e => e.mrnn_address.mesh)));

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-teal-500 to-purple-600 flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Synthia Kernel</h1>
            <p className="text-xs text-slate-500">Trident Addressing Service v0.1</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
            <span className="text-xs text-slate-500">{isConnected ? 'Connected' : 'Offline'}</span>
          </div>
          <select
            value={refreshInterval}
            onChange={e => setRefreshInterval(Number(e.target.value))}
            className="bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs"
          >
            <option value={1000}>1s</option>
            <option value={3000}>3s</option>
            <option value={5000}>5s</option>
            <option value={10000}>10s</option>
          </select>
        </div>
      </div>

      {/* Stats Grid */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card title="Trident">
            <div className="grid grid-cols-2 gap-2">
              <Stat label="Registered" value={stats.trident.registered} color="#00d4aa" />
              <Stat label="Resolved" value={stats.trident.resolved} color="#3b82f6" />
              <Stat label="Compared" value={stats.trident.compared} color="#a855f7" />
              <Stat label="Validated" value={stats.trident.validated} color="#f59e0b" />
            </div>
          </Card>

          <Card title="Registry">
            <div className="grid grid-cols-2 gap-2">
              <Stat label="Total" value={stats.registry.total} color="#e2e8f0" />
              <Stat label="Avg Trust" value={stats.registry.avg_trust.toFixed(2)} color="#22c55e" />
              <Stat label="Active" value={stats.registry.by_lifecycle.active || 0} color="#34d399" />
              <Stat label="Provisional" value={stats.registry.by_lifecycle.provisional || 0} color="#fbbf24" />
            </div>
          </Card>

          <Card title="Agents">
            <div className="grid grid-cols-2 gap-2">
              <Stat label="Total" value={stats.agents.total_agents} color="#a855f7" />
              <Stat label="Avg Load" value={stats.agents.avg_load.toFixed(1)} color="#f472b6" />
              <Stat label="Available" value={Math.max(0, stats.agents.total_agents - stats.agents.avg_load * stats.agents.total_agents).toFixed(0)} color="#22d3ee" />
            </div>
          </Card>

          <Card title="Orchestrator">
            <div className="grid grid-cols-2 gap-2">
              <Stat label="Routed" value={stats.orchestrator.routed} color="#22c55e" />
              <Stat label="Rejected" value={stats.orchestrator.rejected} color="#ef4444" />
              <Stat label="Queued" value={stats.orchestrator.queued} color="#f59e0b" />
              <Stat label="Active" value={stats.orchestrator.active} color="#3b82f6" />
            </div>
          </Card>
        </div>
      )}

      {/* Mesh Filter */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
        <button
          onClick={() => setSelectedMesh('all')}
          className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${selectedMesh === 'all' ? 'bg-slate-700 text-white' : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'}`}
        >
          All Meshes
        </button>
        {meshes.map(mesh => (
          <button
            key={mesh}
            onClick={() => setSelectedMesh(mesh)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-colors flex items-center gap-1.5 ${selectedMesh === mesh ? 'bg-slate-700 text-white' : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'}`}
          >
            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: MESH_COLORS[mesh] || '#6b7280' }} />
            {mesh.replace('_space', '')}
          </button>
        ))}
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Entities Panel */}
        <Card title={`Entities (${filteredEntities.length})`} className="lg:col-span-2">
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {filteredEntities.map(entity => (
              <div key={entity.entity_id} className="flex items-center gap-3 p-3 bg-slate-800/40 rounded-lg hover:bg-slate-800/60 transition-colors">
                <AddressVisualizer address={entity.mrnn_address} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-white truncate">{entity.entity_id.slice(0, 16)}...</span>
                    <Badge text={entity.entity_type} color={MESH_COLORS[entity.mrnn_address.mesh] || '#6b7280'} />
                    <Badge text={entity.lifecycle} color={entity.lifecycle === 'active' ? '#22c55e' : entity.lifecycle === 'provisional' ? '#fbbf24' : '#ef4444'} />
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span>{entity.mrnn_address.center}</span>
                    <span>·</span>
                    <span>{entity.mrnn_address.gate}</span>
                    <span>·</span>
                    <span style={{ color: MODULATION_COLORS[entity.mrnn_address.modulation_state] }}>{entity.mrnn_address.modulation_state}</span>
                    <span>·</span>
                    <span>trust: {(entity.trust_score * 100).toFixed(0)}%</span>
                  </div>
                  {entity.policy_flags.length > 0 && (
                    <div className="flex gap-1 mt-1">
                      {entity.policy_flags.map(flag => (
                        <span key={flag} className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20">{flag}</span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">{entity.processing_ms}ms</div>
                  <div className="text-[10px] text-slate-600">{new Date(entity.registered_at).toLocaleTimeString()}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Agents & Routes Panel */}
        <div className="space-y-4">
          <Card title={`Agents (${agents.length})`}>
            <div className="space-y-2 max-h-[250px] overflow-y-auto">
              {agents.map(agent => (
                <div key={agent.agent_id} className="p-2 bg-slate-800/40 rounded-lg">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-white">{agent.display_name}</span>
                    <span className="text-xs text-slate-500">{agent.current_load}/{agent.max_concurrent}</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-1.5 mb-1">
                    <div
                      className="h-1.5 rounded-full transition-all"
                      style={{
                        width: `${(agent.current_load / agent.max_concurrent) * 100}%`,
                        backgroundColor: agent.current_load / agent.max_concurrent > 0.8 ? '#ef4444' : agent.current_load / agent.max_concurrent > 0.5 ? '#f59e0b' : '#22c55e'
                      }}
                    />
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {agent.capabilities.slice(0, 3).map(cap => (
                      <span key={cap.name} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-700/50 text-slate-400">
                        {cap.name} {(cap.proficiency * 100).toFixed(0)}%
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card title={`Active Routes (${activeRoutes.length})`}>
            <div className="space-y-2 max-h-[200px] overflow-y-auto">
              {activeRoutes.map(route => (
                <div key={route.request_id} className="p-2 bg-slate-800/40 rounded-lg text-xs">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono text-slate-400">{route.request_id.slice(0, 12)}</span>
                    <Badge text={route.status} color={route.status === 'routed' ? '#22c55e' : '#f59e0b'} />
                  </div>
                  <div className="text-slate-500">
                    {route.assigned_mesh} · {route.assigned_agents.length} agents
                  </div>
                  <div className="text-slate-600 mt-0.5">
                    policy: {route.policy_decision}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default SynthiaDashboard;
