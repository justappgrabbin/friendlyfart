/**
 * Analysis Pipeline Stage
 * Intent classification and entity extraction
 */

import { IntentClassification, AgentId } from '../types/index.js';
import { IntentRouter } from '../orchestrator/router.js';
import { logger } from '../utils/logger.js';

export class AnalyzeStage {
  private router = new IntentRouter();

  async process(message: string): Promise<{
    intent: IntentClassification;
    agent: AgentId;
  }> {
    const startTime = Date.now();

    const intent = this.router.classify(message);
    const agent = this.router.selectAgent(intent);

    logger.info({
      intent: intent.primary,
      agent,
      confidence: intent.confidence,
      duration: Date.now() - startTime,
    }, 'Analysis complete');

    return { intent, agent };
  }
}
