/**
 * Ingestion Pipeline Stage
 * Validates, sanitizes, and prepares incoming requests
 */

import { z } from 'zod';
import { logger } from '../utils/logger.js';

const IngestSchema = z.object({
  message: z.string().min(1).max(10000),
  sessionId: z.string().uuid().optional(),
  userId: z.string().min(1).max(100),
  userProfile: z.object({
    name: z.string().optional(),
    preferences: z.record(z.unknown()).optional(),
    humanDesign: z.object({
      type: z.string(),
      strategy: z.string(),
      authority: z.string(),
      profile: z.string(),
      definedCenters: z.array(z.string()),
      channels: z.array(z.string()),
      gates: z.array(z.number()),
    }).optional(),
    astrological: z.object({
      sunSign: z.string(),
      moonSign: z.string(),
      risingSign: z.string(),
      siderealPositions: z.record(z.number()),
    }).optional(),
  }).optional(),
  metadata: z.record(z.unknown()).optional(),
});

export type IngestedRequest = z.infer<typeof IngestSchema>;

export class IngestStage {
  async process(raw: unknown): Promise<IngestedRequest> {
    const startTime = Date.now();

    try {
      // Validate schema
      const validated = IngestSchema.parse(raw);

      // Sanitize message
      validated.message = this.sanitize(validated.message);

      // Check for abuse patterns
      const threatScore = this.threatCheck(validated.message);
      if (threatScore > 0.8) {
        logger.warn({ userId: validated.userId, threatScore }, 'High threat score detected');
        throw new Error('Request blocked by security policy');
      }

      logger.info({ 
        userId: validated.userId, 
        messageLength: validated.message.length,
        duration: Date.now() - startTime,
      }, 'Request ingested');

      return validated;
    } catch (error) {
      if (error instanceof z.ZodError) {
        logger.error({ errors: error.errors }, 'Validation failed');
        throw new Error(`Invalid request: ${error.errors.map(e => e.message).join(', ')}`);
      }
      throw error;
    }
  }

  private sanitize(input: string): string {
    // Remove null bytes
    let cleaned = input.replace(/\x00/g, '');

    // Trim excessive whitespace
    cleaned = cleaned.replace(/\s+/g, ' ').trim();

    // Limit length
    cleaned = cleaned.slice(0, 10000);

    return cleaned;
  }

  private threatCheck(input: string): number {
    const threatPatterns = [
      /\b(drop|delete|truncate)\s+(table|database)\b/gi,
      /\b(union\s+select|insert\s+into)\b/gi,
      /\b(eval\s*\(|exec\s*\()\b/gi,
      /\b(rm\s+-rf|\/etc\/passwd)\b/gi,
    ];

    let score = 0;
    for (const pattern of threatPatterns) {
      if (pattern.test(input)) score += 0.25;
    }

    return Math.min(score, 1.0);
  }
}
