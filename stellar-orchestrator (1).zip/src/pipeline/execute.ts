/**
 * Execution Pipeline Stage
 * Dispatches to agents and manages the request lifecycle
 */

import { Session, AgentMessage, IntentClassification, RoutingDecision } from '../types/index.js';
import { Dispatcher } from '../orchestrator/dispatcher.js';
import { ModelRouter } from '../models/model-router.js';
import { logger } from '../utils/logger.js';

export class ExecuteStage {
  constructor(
    private dispatcher: Dispatcher,
    private modelRouter: ModelRouter
  ) {}

  async process(
    session: Session,
    message: string,
    intent: IntentClassification
  ): Promise<AgentMessage> {
    const startTime = Date.now();

    // Get agent from dispatcher
    const agentId = intent.primary === 'code' ? 'joseph' :
                    intent.primary === 'analysis' ? 'claude' :
                    intent.primary === 'human_design' || intent.primary === 'astrology' ? 'user' :
                    'chatgpt';

    const agent = this.dispatcher['agents'].get(agentId);
    if (!agent) {
      throw new Error(`Agent ${agentId} not available`);
    }

    // Route to models
    const routing = await this.modelRouter.route(intent, agent['profile'], []);

    // Execute
    const response = await this.dispatcher.dispatch(session, message, intent, routing);

    logger.info({
      agent: agentId,
      model: response.metadata?.modelUsed,
      latency: Date.now() - startTime,
    }, 'Execution complete');

    return response;
  }
}
