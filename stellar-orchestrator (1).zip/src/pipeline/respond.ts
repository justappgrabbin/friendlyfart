/**
 * Response Pipeline Stage
 * Formats, enriches, and delivers responses
 */

import { AgentMessage, Session } from '../types/index.js';
import { logger } from '../utils/logger.js';

export class RespondStage {
  async process(
    response: AgentMessage,
    session: Session,
    options: {
      format?: 'text' | 'json' | 'markdown';
      includeMetadata?: boolean;
      enrich?: boolean;
    } = {}
  ): Promise<{
    content: string;
    metadata?: Record<string, unknown>;
    sessionId: string;
  }> {
    const { format = 'markdown', includeMetadata = true, enrich = true } = options;

    let content = response.content;

    // Format conversion
    if (format === 'json') {
      content = JSON.stringify({ response: content });
    }

    // Enrichment
    if (enrich) {
      content = this.enrichResponse(content, session);
    }

    const result: any = {
      content,
      sessionId: session.id,
    };

    if (includeMetadata && response.metadata) {
      result.metadata = {
        agent: response.agentId,
        model: response.metadata.modelUsed,
        latency: response.metadata.latencyMs,
        tokens: {
          in: response.metadata.tokensIn,
          out: response.metadata.tokensOut,
        },
      };
    }

    logger.info({ sessionId: session.id, agent: response.agentId }, 'Response delivered');

    return result;
  }

  private enrichResponse(content: string, session: Session): string {
    // Add session context if relevant
    if (session.messages.length > 10) {
      content += `

---
💬 *This is message ${session.messages.length} in our conversation.*`;
    }

    return content;
  }
}
