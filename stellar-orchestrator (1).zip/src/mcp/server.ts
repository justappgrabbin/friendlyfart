/**
 * MCP Server Implementation
 * Exposes tools and resources to external MCP clients
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';
import { CONFIG } from '../config/index.js';
import { logger } from '../utils/logger.js';

// Tool schemas
const CalculateSchema = z.object({
  expression: z.string().describe('Mathematical expression to evaluate'),
});

const SearchSchema = z.object({
  query: z.string().describe('Search query'),
  limit: z.number().optional().default(10),
});

const CodeExecuteSchema = z.object({
  code: z.string().describe('Code to execute'),
  language: z.enum(['javascript', 'typescript', 'python']).default('javascript'),
});

const FileReadSchema = z.object({
  path: z.string().describe('File path to read'),
});

const GitHubSchema = z.object({
  action: z.enum(['get_repo', 'list_issues', 'create_issue', 'get_file']),
  repo: z.string().describe('Repository name (owner/repo)'),
  params: z.record(z.string()).optional(),
});

export class MCPServer {
  private server: Server;

  constructor() {
    this.server = new Server(
      {
        name: CONFIG.MCP_SERVER_NAME,
        version: CONFIG.MCP_SERVER_VERSION,
      },
      {
        capabilities: {
          tools: {},
          resources: {},
        },
      }
    );

    this.setupHandlers();
  }

  private setupHandlers(): void {
    // List available tools
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: [
        {
          name: 'calculate',
          description: 'Evaluate mathematical expressions safely',
          inputSchema: {
            type: 'object',
            properties: {
              expression: { type: 'string', description: 'Math expression' },
            },
            required: ['expression'],
          },
        },
        {
          name: 'search',
          description: 'Search across indexed knowledge',
          inputSchema: {
            type: 'object',
            properties: {
              query: { type: 'string' },
              limit: { type: 'number', default: 10 },
            },
            required: ['query'],
          },
        },
        {
          name: 'code_execute',
          description: 'Execute code in a sandboxed environment',
          inputSchema: {
            type: 'object',
            properties: {
              code: { type: 'string' },
              language: { type: 'string', enum: ['javascript', 'typescript', 'python'] },
            },
            required: ['code'],
          },
        },
        {
          name: 'file_read',
          description: 'Read file contents',
          inputSchema: {
            type: 'object',
            properties: {
              path: { type: 'string' },
            },
            required: ['path'],
          },
        },
        {
          name: 'github',
          description: 'GitHub operations',
          inputSchema: {
            type: 'object',
            properties: {
              action: { type: 'string', enum: ['get_repo', 'list_issues', 'create_issue', 'get_file'] },
              repo: { type: 'string' },
              params: { type: 'object' },
            },
            required: ['action', 'repo'],
          },
        },
        {
          name: 'agent_stats',
          description: 'Get current agent statistics',
          inputSchema: {
            type: 'object',
            properties: {},
          },
        },
        {
          name: 'model_health',
          description: 'Get model health status',
          inputSchema: {
            type: 'object',
            properties: {},
          },
        },
      ],
    }));

    // Execute tool calls
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      logger.info({ tool: name, args }, 'MCP tool called');

      try {
        switch (name) {
          case 'calculate': {
            const calc = CalculateSchema.parse(args);
            // Safe evaluation using Function constructor
            const result = new Function('return ' + calc.expression)();
            return {
              content: [{ type: 'text', text: String(result) }],
            };
          }

          case 'search': {
            const search = SearchSchema.parse(args);
            // Placeholder: would integrate with vector DB
            return {
              content: [{ type: 'text', text: `Search results for "${search.query}" (placeholder)` }],
            };
          }

          case 'code_execute': {
            const code = CodeExecuteSchema.parse(args);
            // Placeholder: would use vm2 or isolated-vm
            return {
              content: [{ type: 'text', text: `Executed ${code.language} code (sandbox placeholder)` }],
            };
          }

          case 'file_read': {
            const file = FileReadSchema.parse(args);
            // Placeholder: would read from allowed paths
            return {
              content: [{ type: 'text', text: `File ${file.path} contents (placeholder)` }],
            };
          }

          case 'github': {
            const gh = GitHubSchema.parse(args);
            return {
              content: [{ type: 'text', text: `GitHub ${gh.action} on ${gh.repo} (placeholder)` }],
            };
          }

          case 'agent_stats': {
            return {
              content: [{ type: 'text', text: 'Agent stats: Joseph, ChatGPT, Claude, User all active' }],
            };
          }

          case 'model_health': {
            return {
              content: [{ type: 'text', text: 'All 7 HF models + OpenAI + Anthropic operational' }],
            };
          }

          default:
            throw new Error(`Unknown tool: ${name}`);
        }
      } catch (error) {
        logger.error({ tool: name, error: (error as Error).message }, 'Tool execution failed');
        return {
          content: [{ type: 'text', text: `Error: ${(error as Error).message}` }],
          isError: true,
        };
      }
    });

    // List resources
    this.server.setRequestHandler(ListResourcesRequestSchema, async () => ({
      resources: [
        {
          uri: 'orchestrator://agents',
          name: 'Agent Registry',
          mimeType: 'application/json',
          description: 'Current agent configurations and stats',
        },
        {
          uri: 'orchestrator://models',
          name: 'Model Registry',
          mimeType: 'application/json',
          description: 'Available models and their capabilities',
        },
        {
          uri: 'orchestrator://health',
          name: 'System Health',
          mimeType: 'application/json',
          description: 'Current system health status',
        },
      ],
    }));

    // Read resources
    this.server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
      const { uri } = request.params;

      switch (uri) {
        case 'orchestrator://agents':
          return {
            contents: [{
              uri,
              mimeType: 'application/json',
              text: JSON.stringify({
                agents: ['joseph', 'chatgpt', 'claude', 'user'],
                status: 'active',
              }),
            }],
          };

        case 'orchestrator://models':
          return {
            contents: [{
              uri,
              mimeType: 'application/json',
              text: JSON.stringify({
                models: 7,
                providers: ['huggingface', 'openai', 'anthropic'],
              }),
            }],
          };

        case 'orchestrator://health':
          return {
            contents: [{
              uri,
              mimeType: 'application/json',
              text: JSON.stringify({
                status: 'healthy',
                timestamp: Date.now(),
              }),
            }],
          };

        default:
          throw new Error(`Unknown resource: ${uri}`);
      }
    });
  }

  async start(): Promise<void> {
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    logger.info('🔌 MCP server connected via stdio');
  }
}
