/**
 * HuggingFace Inference Client
 * Unified interface for all 7 HF models with retry, fallback, and streaming
 */

import { HfInference } from '@huggingface/inference';
import { CONFIG } from '../config/index.js';
import { 
  ModelRequest, 
  ModelResponse, 
  TokenUsage, 
  ToolCall,
  ModelDefinition 
} from '../types/index.js';
import { logger } from '../utils/logger.js';

export class HuggingFaceClient {
  private client: HfInference;
  private modelRegistry: Map<string, ModelDefinition>;
  private requestQueue: Map<string, Promise<unknown>> = new Map();

  constructor(modelRegistry: ModelDefinition[]) {
    this.client = new HfInference(CONFIG.HF_TOKEN);
    this.modelRegistry = new Map(modelRegistry.map(m => [m.id, m]));
  }

  /**
   * Main inference method with automatic retry and fallback
   */
  async infer(request: ModelRequest): Promise<ModelResponse> {
    const modelDef = this.modelRegistry.get(request.modelId);
    if (!modelDef) {
      throw new Error(`Model ${request.modelId} not registered`);
    }

    const startTime = Date.now();
    let lastError: Error | null = null;

    for (let attempt = 0; attempt < CONFIG.MAX_RETRIES; attempt++) {
      try {
        const response = await this.executeInference(request, modelDef);
        const latencyMs = Date.now() - startTime;

        logger.info({ 
          model: request.modelId, 
          latencyMs, 
          attempt: attempt + 1,
          tokens: response.usage.total 
        }, 'HF inference success');

        return { ...response, latencyMs };
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        logger.warn({ 
          model: request.modelId, 
          attempt: attempt + 1, 
          error: lastError.message 
        }, 'HF inference attempt failed');

        if (attempt < CONFIG.MAX_RETRIES - 1) {
          await this.delay(CONFIG.RETRY_DELAY_MS * Math.pow(2, attempt));
        }
      }
    }

    // All retries exhausted
    logger.error({ model: request.modelId, error: lastError?.message }, 'HF inference failed permanently');
    return this.createErrorResponse(request.modelId, lastError!);
  }

  /**
   * Route to correct inference method based on model capabilities
   */
  private async executeInference(
    request: ModelRequest, 
    modelDef: ModelDefinition
  ): Promise<ModelResponse> {
    const caps = modelDef.capabilities;

    if (caps.includes('chat') || caps.includes('text-generation')) {
      return this.textInference(request, modelDef);
    }
    if (caps.includes('image-generation')) {
      return this.imageInference(request, modelDef);
    }
    if (caps.includes('embedding')) {
      return this.embeddingInference(request, modelDef);
    }
    if (caps.includes('speech-to-text')) {
      return this.speechInference(request, modelDef);
    }

    throw new Error(`No inference handler for capabilities: ${caps.join(', ')}`);
  }

  /**
   * Text/Chat inference via HF Inference API
   */
  private async textInference(
    request: ModelRequest, 
    modelDef: ModelDefinition
  ): Promise<ModelResponse> {
    const messages = request.messages.map(m => ({
      role: m.role as 'system' | 'user' | 'assistant',
      content: m.content,
    }));

    const response = await this.client.chatCompletion({
      model: request.modelId,
      messages,
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens ?? modelDef.maxTokens,
      stream: false,
    });

    const content = response.choices[0]?.message?.content || '';
    const usage: TokenUsage = {
      prompt: response.usage?.prompt_tokens || this.estimateTokens(messages),
      completion: response.usage?.completion_tokens || this.estimateTokens([{ role: 'assistant', content }]),
      total: response.usage?.total_tokens || 0,
    };

    return {
      modelId: request.modelId,
      content,
      usage,
      latencyMs: 0, // filled by caller
      finishReason: response.choices[0]?.finish_reason === 'stop' ? 'stop' : 'length',
      raw: response,
    };
  }

  /**
   * Image generation via HF Inference API
   */
  private async imageInference(
    request: ModelRequest,
    modelDef: ModelDefinition
  ): Promise<ModelResponse> {
    const prompt = request.messages[request.messages.length - 1]?.content || '';

    const blob = await this.client.textToImage({
      model: request.modelId,
      inputs: prompt,
      parameters: {
        ...request.parameters,
        num_inference_steps: 28,
        guidance_scale: 7.5,
      },
    });

    // Convert blob to base64 for transport
    const buffer = await blob.arrayBuffer();
    const base64 = Buffer.from(buffer).toString('base64');
    const mimeType = blob.type || 'image/png';

    return {
      modelId: request.modelId,
      content: `data:${mimeType};base64,${base64}`,
      usage: { prompt: 0, completion: 0, total: 0 },
      latencyMs: 0,
      finishReason: 'stop',
      raw: { size: buffer.byteLength },
    };
  }

  /**
   * Embedding inference
   */
  private async embeddingInference(
    request: ModelRequest,
    modelDef: ModelDefinition
  ): Promise<ModelResponse> {
    const text = request.messages[request.messages.length - 1]?.content || '';

    const result = await this.client.featureExtraction({
      model: request.modelId,
      inputs: text,
    });

    return {
      modelId: request.modelId,
      content: JSON.stringify(result),
      usage: { prompt: 0, completion: 0, total: 0 },
      latencyMs: 0,
      finishReason: 'stop',
      raw: result,
    };
  }

  /**
   * Speech-to-text inference
   */
  private async speechInference(
    request: ModelRequest,
    modelDef: ModelDefinition
  ): Promise<ModelResponse> {
    // Expect audio data as base64 in the last message content
    const audioBase64 = request.messages[request.messages.length - 1]?.content || '';
    const audioBuffer = Buffer.from(audioBase64, 'base64');

    const blob = new Blob([audioBuffer], { type: 'audio/wav' });

    const result = await this.client.automaticSpeechRecognition({
      model: request.modelId,
      data: blob,
    });

    return {
      modelId: request.modelId,
      content: result.text,
      usage: { prompt: 0, completion: 0, total: 0 },
      latencyMs: 0,
      finishReason: 'stop',
      raw: result,
    };
  }

  /**
   * Streaming text inference (returns AsyncIterator)
   */
  async *streamInfer(request: ModelRequest): AsyncGenerator<string, void, unknown> {
    const modelDef = this.modelRegistry.get(request.modelId);
    if (!modelDef) throw new Error(`Model ${request.modelId} not found`);

    const messages = request.messages.map(m => ({
      role: m.role as 'system' | 'user' | 'assistant',
      content: m.content,
    }));

    const stream = await this.client.chatCompletionStream({
      model: request.modelId,
      messages,
      temperature: request.temperature ?? 0.7,
      max_tokens: request.maxTokens ?? modelDef.maxTokens,
    });

    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta?.content;
      if (delta) yield delta;
    }
  }

  /**
   * Check model health/availability
   */
  async healthCheck(modelId: string): Promise<boolean> {
    try {
      await this.client.chatCompletion({
        model: modelId,
        messages: [{ role: 'user', content: 'hi' }],
        max_tokens: 5,
      });
      return true;
    } catch {
      return false;
    }
  }

  private estimateTokens(messages: { role: string; content: string }[]): number {
    // Rough estimate: 1 token ≈ 4 chars
    return messages.reduce((sum, m) => sum + Math.ceil(m.content.length / 4), 0);
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private createErrorResponse(modelId: string, error: Error): ModelResponse {
    return {
      modelId,
      content: `Error: ${error.message}`,
      usage: { prompt: 0, completion: 0, total: 0 },
      latencyMs: 0,
      finishReason: 'error',
      raw: { error: error.message },
    };
  }
}
