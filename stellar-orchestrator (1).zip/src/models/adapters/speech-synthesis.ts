/**
 * Speech Adapter
 * Handles Whisper STT and TTS outputs
 */

export interface SpeechOutput {
  text: string;
  confidence?: number;
  language?: string;
}

export function normalizeSpeechRecognition(
  raw: any,
  modelId: string
): SpeechOutput {
  // Whisper format
  if (raw.text) {
    return {
      text: raw.text,
      confidence: raw.confidence,
      language: raw.language || 'en',
    };
  }

  // Direct string
  if (typeof raw === 'string') {
    return { text: raw };
  }

  return { text: '' };
}
