/**
 * Embedding Adapter
 * Normalizes embedding outputs for semantic search
 */

export interface EmbeddingOutput {
  embedding: number[];
  dimensions: number;
}

export function normalizeEmbedding(
  raw: any,
  modelId: string
): EmbeddingOutput {
  // HF feature extraction returns array directly
  if (Array.isArray(raw)) {
    const flat = raw.flat(Infinity);
    return {
      embedding: flat,
      dimensions: flat.length,
    };
  }

  // Object wrapper
  if (raw.embedding) {
    return {
      embedding: raw.embedding,
      dimensions: raw.embedding.length,
    };
  }

  return {
    embedding: [],
    dimensions: 0,
  };
}

export function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;

  let dot = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }

  return dot / (Math.sqrt(normA) * Math.sqrt(normB) + 1e-10);
}
