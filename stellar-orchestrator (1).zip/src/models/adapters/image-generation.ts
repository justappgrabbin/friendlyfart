/**
 * Image Generation Adapter
 * Handles Stable Diffusion and other image model outputs
 */

export interface ImageGenOutput {
  imageBase64: string;
  mimeType: string;
  seed?: number;
}

export async function normalizeImageGeneration(
  blob: Blob,
  modelId: string
): Promise<ImageGenOutput> {
  const buffer = await blob.arrayBuffer();
  const base64 = Buffer.from(buffer).toString('base64');

  return {
    imageBase64: base64,
    mimeType: blob.type || 'image/png',
  };
}
