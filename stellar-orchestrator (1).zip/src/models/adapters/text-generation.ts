/**
 * Text Generation Adapter
 * Normalizes responses from different text generation models
 */

import { ModelResponse, TokenUsage } from '../../types/index.js';

export interface TextGenOutput {
  text: string;
  finishReason: 'stop' | 'length' | 'error';
  usage: TokenUsage;
}

export function normalizeTextGeneration(
  raw: any,
  modelId: string
): TextGenOutput {
  // HuggingFace Inference API format
  if (raw.choices && raw.choices[0]) {
    return {
      text: raw.choices[0].message?.content || raw.choices[0].text || '',
      finishReason: raw.choices[0].finish_reason === 'stop' ? 'stop' : 'length',
      usage: {
        prompt: raw.usage?.prompt_tokens || 0,
        completion: raw.usage?.completion_tokens || 0,
        total: raw.usage?.total_tokens || 0,
      },
    };
  }

  // Direct generation format
  if (typeof raw === 'string') {
    return {
      text: raw,
      finishReason: 'stop',
      usage: { prompt: 0, completion: 0, total: 0 },
    };
  }

  // Fallback
  return {
    text: JSON.stringify(raw),
    finishReason: 'stop',
    usage: { prompt: 0, completion: 0, total: 0 },
  };
}
