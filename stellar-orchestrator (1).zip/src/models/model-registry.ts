/**
 * Model Registry
 * Central catalog of all models with capability-based lookup
 */

import { HF_MODELS } from '../config/index.js';
import { ModelDefinition, ModelCapability } from '../types/index.js';

export class ModelRegistry {
  private models: Map<string, ModelDefinition> = new Map();
  private capabilityIndex: Map<ModelCapability, string[]> = new Map();

  constructor() {
    this.registerModels(HF_MODELS);
  }

  registerModels(models: ModelDefinition[]): void {
    for (const model of models) {
      this.models.set(model.id, model);

      // Index by capability
      for (const cap of model.capabilities) {
        const existing = this.capabilityIndex.get(cap) || [];
        existing.push(model.id);
        this.capabilityIndex.set(cap, existing);
      }
    }
  }

  getModel(id: string): ModelDefinition | undefined {
    return this.models.get(id);
  }

  getAllModels(): ModelDefinition[] {
    return Array.from(this.models.values());
  }

  findByCapability(capability: ModelCapability): ModelDefinition[] {
    const ids = this.capabilityIndex.get(capability) || [];
    return ids.map(id => this.models.get(id)).filter((m): m is ModelDefinition => !!m);
  }

  findByTag(tag: string): ModelDefinition[] {
    return this.getAllModels().filter(m => m.tags.includes(tag));
  }

  findByProvider(provider: string): ModelDefinition[] {
    return this.getAllModels().filter(m => m.provider === provider);
  }

  /**
   * Rank models for a task based on latency/quality profile
   */
  rankForTask(
    capability: ModelCapability,
    priority: 'speed' | 'quality' | 'cost' = 'balanced'
  ): ModelDefinition[] {
    const candidates = this.findByCapability(capability);

    return candidates.sort((a, b) => {
      if (priority === 'speed') {
        const latencyOrder = { fast: 0, balanced: 1, slow: 2 };
        return latencyOrder[a.latencyProfile] - latencyOrder[b.latencyProfile];
      }
      if (priority === 'quality') {
        const qualityOrder = { fast: 2, balanced: 1, quality: 0 };
        return qualityOrder[a.qualityProfile] - qualityOrder[b.qualityProfile];
      }
      if (priority === 'cost') {
        return a.costPer1KTokens - b.costPer1KTokens;
      }
      // balanced: prefer balanced latency + quality
      const scoreA = (a.latencyProfile === 'balanced' ? 2 : 0) + 
                     (a.qualityProfile === 'balanced' ? 2 : 0);
      const scoreB = (b.latencyProfile === 'balanced' ? 2 : 0) + 
                     (b.qualityProfile === 'balanced' ? 2 : 0);
      return scoreB - scoreA;
    });
  }

  /**
   * Get fallback chain for a model
   */
  getFallbackChain(modelId: string): string[] {
    const model = this.models.get(modelId);
    if (!model) return [];

    // Find models with same primary capability, excluding self
    const primaryCap = model.capabilities[0];
    const alternatives = this.findByCapability(primaryCap)
      .filter(m => m.id !== modelId)
      .sort((a, b) => a.costPer1KTokens - b.costPer1KTokens);

    return alternatives.map(m => m.id);
  }
}

// Singleton export
export const modelRegistry = new ModelRegistry();
