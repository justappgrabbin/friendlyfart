/**
 * Model Router
 * Intelligent dispatch with load balancing, fallback chains, and health checks
 */

import { HuggingFaceClient } from './hf-client.js';
import { ModelRegistry, modelRegistry } from './model-registry.js';
import { 
  ModelRequest, 
  ModelResponse, 
  RoutingDecision,
  IntentClassification,
  AgentProfile 
} from '../types/index.js';
import { CONFIG, INTENT_MODEL_MAP } from '../config/index.js';
import { logger } from '../utils/logger.js';

interface ModelHealth {
  modelId: string;
  healthy: boolean;
  lastChecked: number;
  avgLatency: number;
  errorRate: number;
  consecutiveErrors: number;
}

export class ModelRouter {
  private hfClient: HuggingFaceClient;
  private registry: ModelRegistry;
  private healthStatus: Map<string, ModelHealth> = new Map();
  private circuitBreakers: Map<string, { open: boolean; openedAt: number }> = new Map();
  private requestCounts: Map<string, number> = new Map();

  constructor() {
    this.registry = modelRegistry;
    this.hfClient = new HuggingFaceClient(this.registry.getAllModels());

    // Initialize health status for all models
    for (const model of this.registry.getAllModels()) {
      this.healthStatus.set(model.id, {
        modelId: model.id,
        healthy: true,
        lastChecked: 0,
        avgLatency: 0,
        errorRate: 0,
        consecutiveErrors: 0,
      });
    }

    // Start health check loop
    this.startHealthChecks();
  }

  /**
   * Route a request based on intent + agent preference
   */
  async route(
    intent: IntentClassification,
    agent: AgentProfile,
    messages: { role: string; content: string }[]
  ): Promise<RoutingDecision> {
    const preferredModels = this.resolveModels(intent, agent);
    const strategy = this.determineStrategy(intent, preferredModels);

    // Filter to healthy models
    const healthyModels = preferredModels.filter(id => this.isModelHealthy(id));

    if (healthyModels.length === 0) {
      // Emergency fallback: any healthy model with text capability
      const emergency = this.registry.findByCapability('text-generation')
        .filter(m => this.isModelHealthy(m.id))
        .map(m => m.id);

      logger.warn({ intent: intent.primary, agent: agent.id }, 'All preferred models unhealthy, using emergency fallback');

      return {
        targetAgent: agent.id,
        targetModels: emergency.slice(0, 2),
        strategy: 'cascade',
        reasoning: 'Emergency fallback: all preferred models unhealthy',
        estimatedLatency: 5000,
      };
    }

    const estimatedLatency = this.estimateLatency(healthyModels[0]);

    return {
      targetAgent: agent.id,
      targetModels: healthyModels,
      strategy,
      reasoning: `Intent: ${intent.primary} (confidence: ${intent.confidence.toFixed(2)}). Agent ${agent.id} prefers ${agent.modelPreference}. Selected ${healthyModels.length} healthy models.`,
      estimatedLatency,
    };
  }

  /**
   * Execute the routed request
   */
  async execute(decision: RoutingDecision, messages: { role: string; content: string }[]): Promise<ModelResponse> {
    const request: ModelRequest = {
      modelId: decision.targetModels[0],
      messages: messages.map(m => ({ ...m, id: crypto.randomUUID(), agentId: decision.targetAgent, timestamp: Date.now(), metadata: {} })),
      temperature: 0.7,
      stream: false,
    };

    switch (decision.strategy) {
      case 'single':
        return this.executeSingle(request);

      case 'cascade':
        return this.executeCascade(request, decision.targetModels);

      case 'ensemble':
        return this.executeEnsemble(request, decision.targetModels);

      case 'consensus':
        return this.executeConsensus(request, decision.targetModels);

      default:
        return this.executeSingle(request);
    }
  }

  /**
   * Single model execution
   */
  private async executeSingle(request: ModelRequest): Promise<ModelResponse> {
    this.incrementCounter(request.modelId);
    const response = await this.hfClient.infer(request);
    this.updateHealth(request.modelId, response.latencyMs, response.finishReason !== 'error');
    return response;
  }

  /**
   * Cascade: try models in order until one succeeds
   */
  private async executeCascade(request: ModelRequest, modelIds: string[]): Promise<ModelResponse> {
    for (const modelId of modelIds) {
      try {
        const response = await this.executeSingle({ ...request, modelId });
        if (response.finishReason !== 'error') {
          return { ...response, modelId };
        }
      } catch (error) {
        logger.warn({ modelId, error: (error as Error).message }, 'Cascade model failed');
        this.updateHealth(modelId, 0, false);
      }
    }

    throw new Error(`All models in cascade failed: ${modelIds.join(', ')}`);
  }

  /**
   * Ensemble: run all models in parallel, return best (by confidence/heuristic)
   */
  private async executeEnsemble(request: ModelRequest, modelIds: string[]): Promise<ModelResponse> {
    const promises = modelIds.map(async modelId => {
      try {
        return await this.executeSingle({ ...request, modelId });
      } catch (error) {
        return this.createErrorResponse(modelId, error as Error);
      }
    });

    const responses = await Promise.all(promises);
    const validResponses = responses.filter(r => r.finishReason !== 'error');

    if (validResponses.length === 0) {
      throw new Error('All ensemble models failed');
    }

    // Pick by: shortest latency + longest content (heuristic for quality)
    const best = validResponses.reduce((best, current) => {
      const bestScore = best.content.length / (best.latencyMs + 1);
      const currentScore = current.content.length / (current.latencyMs + 1);
      return currentScore > bestScore ? current : best;
    });

    return best;
  }

  /**
   * Consensus: run multiple, synthesize agreement
   */
  private async executeConsensus(request: ModelRequest, modelIds: string[]): Promise<ModelResponse> {
    // For now, delegate to consensus engine (separate module)
    // Simplified: run ensemble and mark as consensus
    const response = await this.executeEnsemble(request, modelIds);
    return { ...response, finishReason: 'stop' };
  }

  /**
   * Resolve which models to use for this intent + agent
   */
  private resolveModels(intent: IntentClassification, agent: AgentProfile): string[] {
    // 1. Agent's preferred model (if it supports this intent)
    const agentPref = agent.modelPreference;
    const agentModel = this.registry.getModel(agentPref);

    if (agentModel && this.modelSupportsIntent(agentModel, intent.primary)) {
      return [agentPref, ...agent.fallbackModels];
    }

    // 2. Intent-mapped models from config
    const mapped = INTENT_MODEL_MAP[intent.primary] || INTENT_MODEL_MAP['general'] || [];

    // 3. Merge and dedupe: agent preference first, then mapped, then fallbacks
    const ordered = [...new Set([agentPref, ...mapped, ...agent.fallbackModels])];

    return ordered.filter(id => this.registry.getModel(id) !== undefined);
  }

  /**
   * Determine strategy based on intent criticality and model availability
   */
  private determineStrategy(intent: IntentClassification, models: string[]): RoutingDecision['strategy'] {
    if (models.length === 1) return 'single';
    if (intent.urgency === 'critical') return 'ensemble'; // max reliability
    if (intent.confidence > 0.9 && models.length >= 2) return 'single'; // high confidence = single model
    if (CONFIG.ENABLE_CONSENSUS && models.length >= 3) return 'consensus';
    return 'cascade'; // default: try best first, fallback if fail
  }

  /**
   * Check if model supports a given intent type
   */
  private modelSupportsIntent(model: import('../types/index.js').ModelDefinition, intent: string): boolean {
    const intentCapMap: Record<string, string[]> = {
      code: ['text-generation', 'chat', 'code'],
      creative: ['text-generation', 'image-generation'],
      analysis: ['text-generation', 'chat'],
      conversation: ['text-generation', 'chat'],
      image: ['image-generation'],
      speech: ['speech-to-text', 'text-to-speech'],
      embedding: ['embedding'],
      research: ['text-generation', 'chat'],
      human_design: ['text-generation', 'chat'],
      astrology: ['text-generation', 'chat'],
      morph: ['text-generation', 'chat'],
      general: ['text-generation', 'chat'],
    };

    const requiredCaps = intentCapMap[intent] || ['text-generation'];
    return requiredCaps.some(cap => model.capabilities.includes(cap as import('../types/index.js').ModelCapability));
  }

  /**
   * Health check system
   */
  private isModelHealthy(modelId: string): boolean {
    const cb = this.circuitBreakers.get(modelId);
    if (cb?.open) {
      // Check if circuit should close (30s cooldown)
      if (Date.now() - cb.openedAt > 30000) {
        this.circuitBreakers.set(modelId, { open: false, openedAt: 0 });
        return true;
      }
      return false;
    }

    const health = this.healthStatus.get(modelId);
    if (!health) return true; // unknown = assume healthy

    return health.consecutiveErrors < 3 && health.errorRate < 0.5;
  }

  private updateHealth(modelId: string, latencyMs: number, success: boolean): void {
    const health = this.healthStatus.get(modelId);
    if (!health) return;

    if (success) {
      health.consecutiveErrors = 0;
      health.avgLatency = (health.avgLatency * 0.9) + (latencyMs * 0.1);
    } else {
      health.consecutiveErrors++;
      health.errorRate = (health.errorRate * 0.9) + 0.1;

      if (health.consecutiveErrors >= 5) {
        this.circuitBreakers.set(modelId, { open: true, openedAt: Date.now() });
        logger.error({ modelId }, 'Circuit breaker opened for model');
      }
    }

    health.lastChecked = Date.now();
  }

  private startHealthChecks(): void {
    const interval = 60000; // 1 minute

    const check = async () => {
      for (const [modelId, health] of this.healthStatus) {
        try {
          const isHealthy = await this.hfClient.healthCheck(modelId);
          this.updateHealth(modelId, health.avgLatency, isHealthy);
        } catch {
          this.updateHealth(modelId, 0, false);
        }
      }
    };

    setInterval(check, interval);
    check(); // initial check
  }

  private estimateLatency(modelId: string): number {
    const health = this.healthStatus.get(modelId);
    return health?.avgLatency || 2000;
  }

  private incrementCounter(modelId: string): void {
    const current = this.requestCounts.get(modelId) || 0;
    this.requestCounts.set(modelId, current + 1);
  }

  private createErrorResponse(modelId: string, error: Error): ModelResponse {
    return {
      modelId,
      content: `Error: ${error.message}`,
      usage: { prompt: 0, completion: 0, total: 0 },
      latencyMs: 0,
      finishReason: 'error',
      raw: { error: error.message },
    };
  }

  getHealthReport(): Record<string, ModelHealth> {
    return Object.fromEntries(this.healthStatus);
  }

  getRequestStats(): Record<string, number> {
    return Object.fromEntries(this.requestCounts);
  }
}
