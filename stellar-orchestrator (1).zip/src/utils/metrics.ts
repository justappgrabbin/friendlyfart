/**
 * Metrics Collector
 * Simple in-memory metrics with Prometheus-compatible format
 */

import { logger } from './logger.js';

interface MetricValue {
  count: number;
  sum: number;
  values: number[];
}

export class MetricsCollector {
  private counters: Map<string, number> = new Map();
  private timings: Map<string, MetricValue> = new Map();
  private startTime: number = Date.now();

  increment(name: string, value: number = 1): void {
    const current = this.counters.get(name) || 0;
    this.counters.set(name, current + value);
  }

  timing(name: string, value: number): void {
    const current = this.timings.get(name) || { count: 0, sum: 0, values: [] };
    current.count++;
    current.sum += value;
    current.values.push(value);

    // Keep last 1000 values
    if (current.values.length > 1000) {
      current.values = current.values.slice(-1000);
    }

    this.timings.set(name, current);
  }

  getCounter(name: string): number {
    return this.counters.get(name) || 0;
  }

  getTiming(name: string): { count: number; avg: number; p95: number; p99: number } | null {
    const metric = this.timings.get(name);
    if (!metric) return null;

    const sorted = [...metric.values].sort((a, b) => a - b);
    const p95Index = Math.floor(sorted.length * 0.95);
    const p99Index = Math.floor(sorted.length * 0.99);

    return {
      count: metric.count,
      avg: metric.sum / metric.count,
      p95: sorted[p95Index] || 0,
      p99: sorted[p99Index] || 0,
    };
  }

  getAllMetrics(): Record<string, unknown> {
    const result: Record<string, unknown> = {
      uptime_seconds: Math.floor((Date.now() - this.startTime) / 1000),
    };

    for (const [name, value] of this.counters) {
      result[`counter_${name}`] = value;
    }

    for (const [name, metric] of this.timings) {
      result[`timing_${name}`] = this.getTiming(name);
    }

    return result;
  }

  toPrometheus(): string {
    const lines: string[] = [];

    for (const [name, value] of this.counters) {
      lines.push(`# TYPE ${name} counter`);
      lines.push(`${name} ${value}`);
    }

    for (const [name, metric] of this.timings) {
      const timing = this.getTiming(name);
      if (timing) {
        lines.push(`# TYPE ${name} summary`);
        lines.push(`${name}_count ${timing.count}`);
        lines.push(`${name}_sum ${timing.avg * timing.count}`);
      }
    }

    return lines.join('
');
  }
}

export const metrics = new MetricsCollector();
