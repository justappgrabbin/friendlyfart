/**
 * Structured Logger
 * Pino-based with pretty printing in dev
 */

import pino from 'pino';
import { CONFIG } from '../config/index.js';

export const logger = pino({
  level: CONFIG.NODE_ENV === 'development' ? 'debug' : 'info',
  transport: CONFIG.NODE_ENV === 'development' 
    ? { target: 'pino-pretty', options: { colorize: true } }
    : undefined,
  base: {
    service: 'stellar-orchestrator',
    version: '1.0.0',
  },
});
