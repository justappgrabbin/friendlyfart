/**
 * Error Handling
 * Custom error classes with recovery hints
 */

export class OrchestratorError extends Error {
  constructor(
    message: string,
    public code: string,
    public recoverable: boolean = false,
    public context?: Record<string, unknown>
  ) {
    super(message);
    this.name = 'OrchestratorError';
  }
}

export class ModelError extends OrchestratorError {
  constructor(
    message: string,
    public modelId: string,
    recoverable: boolean = true
  ) {
    super(message, 'MODEL_ERROR', recoverable, { modelId });
    this.name = 'ModelError';
  }
}

export class AgentError extends OrchestratorError {
  constructor(
    message: string,
    public agentId: string,
    recoverable: boolean = true
  ) {
    super(message, 'AGENT_ERROR', recoverable, { agentId });
    this.name = 'AgentError';
  }
}

export class ValidationError extends OrchestratorError {
  constructor(message: string, public field?: string) {
    super(message, 'VALIDATION_ERROR', false, { field });
    this.name = 'ValidationError';
  }
}

export class SessionError extends OrchestratorError {
  constructor(message: string, public sessionId: string) {
    super(message, 'SESSION_ERROR', true, { sessionId });
    this.name = 'SessionError';
  }
}

export function handleError(error: unknown): { message: string; code: string; recoverable: boolean } {
  if (error instanceof OrchestratorError) {
    return {
      message: error.message,
      code: error.code,
      recoverable: error.recoverable,
    };
  }

  if (error instanceof Error) {
    return {
      message: error.message,
      code: 'UNKNOWN_ERROR',
      recoverable: false,
    };
  }

  return {
    message: 'An unknown error occurred',
    code: 'UNKNOWN',
    recoverable: false,
  };
}
