/**
 * ChatGPT Agent
 * Generalist, creative, friendly synthesizer
 */

import { BaseAgent } from './base-agent.js';
import { AgentProfile, AgentMessage, Session, ModelResponse } from '../types/index.js';
import { ModelRouter } from '../models/model-router.js';
import { logger } from '../utils/logger.js';

export class ChatGPTAgent extends BaseAgent {
  constructor(profile: AgentProfile, router: ModelRouter) {
    super(profile, router);
  }

  protected async postProcess(response: ModelResponse, session: Session): Promise<AgentMessage> {
    let content = response.content;

    // ChatGPT's voice: friendly, accessible, acknowledges uncertainty
    content = this.ensureFriendlyTone(content);

    // Add creative flair if the topic warrants it
    if (this.isCreativeTopic(session)) {
      content = this.addCreativeSpark(content);
    }

    return {
      id: crypto.randomUUID(),
      agentId: this.id,
      role: 'assistant',
      content,
      timestamp: Date.now(),
      metadata: {
        modelUsed: response.modelId,
        latencyMs: response.latencyMs,
        tokensIn: response.usage.prompt,
        tokensOut: response.usage.completion,
        confidence: 0.85,
      },
    };
  }

  private ensureFriendlyTone(content: string): string {
    // Avoid overly formal language
    const formalPatterns = [
      /It is important to note that/gi,
      /Please be advised/gi,
      /We would like to inform you/gi,
    ];

    let result = content;
    for (const pattern of formalPatterns) {
      result = result.replace(pattern, '');
    }

    return result;
  }

  private isCreativeTopic(session: Session): boolean {
    const creativeKeywords = ['creative', 'design', 'art', 'story', 'imagine', 'brainstorm', 'morph'];
    const lastMessages = session.messages.slice(-3);
    const combined = lastMessages.map(m => m.content.toLowerCase()).join(' ');

    return creativeKeywords.some(kw => combined.includes(kw));
  }

  private addCreativeSpark(content: string): string {
    const sparks = [
      "✨",
      "🎨",
      "💡",
      "🌟",
      "🔮",
    ];
    const spark = sparks[Math.floor(Math.random() * sparks.length)];

    return `${spark} ${content}`;
  }

  /**
   * Rapid brainstorming mode
   */
  async brainstorm(topic: string, count: number = 5): Promise<AgentMessage> {
    const prompt = `Brainstorm ${count} creative ideas about: ${topic}. Be wild, be practical, be unexpected. Mix genres. No filters.`;

    const session: Session = {
      id: crypto.randomUUID(),
      userId: 'system',
      createdAt: Date.now(),
      lastActivity: Date.now(),
      messages: [],
      context: { activeTools: [], customVariables: { topic: 'brainstorm' } },
      activeAgents: [this.id],
      pendingTasks: [],
    };

    return this.process(prompt, session);
  }

  /**
   * Explain complex topic simply
   */
  async explainSimply(topic: string, audience: string = 'beginner'): Promise<AgentMessage> {
    const prompt = `Explain "${topic}" to a ${audience}. Use analogies. Avoid jargon. Make it memorable. One paragraph max, then a "bottom line" summary.`;

    const session: Session = {
      id: crypto.randomUUID(),
      userId: 'system',
      createdAt: Date.now(),
      lastActivity: Date.now(),
      messages: [],
      context: { activeTools: [], customVariables: { topic: 'explain' } },
      activeAgents: [this.id],
      pendingTasks: [],
    };

    return this.process(prompt, session);
  }
}
