/**
 * Base Agent
 * Abstract foundation for all 4 agent personas
 */

import { 
  AgentProfile, 
  AgentMessage, 
  AgentId,
  ModelRequest,
  ModelResponse,
  Session,
  ToolCall 
} from '../types/index.js';
import { ModelRouter } from '../models/model-router.js';
import { logger } from '../utils/logger.js';

export abstract class BaseAgent {
  protected profile: AgentProfile;
  protected router: ModelRouter;
  protected memory: AgentMessage[] = [];
  protected maxMemorySize: number = 50;

  constructor(profile: AgentProfile, router: ModelRouter) {
    this.profile = profile;
    this.router = router;
  }

  get id(): AgentId {
    return this.profile.id;
  }

  get name(): string {
    return this.profile.name;
  }

  /**
   * Main entry: receive user input, return response
   */
  async process(input: string, session: Session): Promise<AgentMessage> {
    const startTime = Date.now();

    // 1. Build message context
    const messages = this.buildContext(input, session);

    // 2. Route to appropriate model(s)
    const intent = session.context.customVariables?.lastIntent as import('../types/index.js').IntentClassification;
    const routing = await this.router.route(
      intent || { primary: 'general', secondary: [], confidence: 0.5, entities: {}, urgency: 'normal' },
      this.profile,
      messages
    );

    logger.info({ 
      agent: this.id, 
      strategy: routing.strategy, 
      models: routing.targetModels 
    }, 'Agent processing request');

    // 3. Execute
    const response = await this.router.execute(routing, messages);

    // 4. Post-process
    const processed = await this.postProcess(response, session);

    // 5. Store in memory
    this.addToMemory({
      id: crypto.randomUUID(),
      agentId: this.id,
      role: 'assistant',
      content: processed.content,
      timestamp: Date.now(),
      metadata: {
        modelUsed: response.modelId,
        latencyMs: Date.now() - startTime,
        tokensIn: response.usage.prompt,
        tokensOut: response.usage.completion,
      },
    });

    return processed;
  }

  /**
   * Build conversation context from session + agent memory
   */
  protected buildContext(input: string, session: Session): { role: string; content: string }[] {
    const messages: { role: string; content: string }[] = [];

    // System prompt
    messages.push({
      role: 'system',
      content: this.profile.systemPrompt,
    });

    // Session summary (if available)
    if (session.context.conversationSummary) {
      messages.push({
        role: 'system',
        content: `Conversation context: ${session.context.conversationSummary}`,
      });
    }

    // User profile context (for user agent)
    if (this.id === 'user' && session.context.userProfile) {
      const profile = session.context.userProfile;
      messages.push({
        role: 'system',
        content: `User Profile: ${profile.name}. Preferences: ${JSON.stringify(profile.preferences)}`,
      });

      if (profile.humanDesign) {
        const hd = profile.humanDesign;
        messages.push({
          role: 'system',
          content: `Human Design: Type ${hd.type}, Strategy ${hd.strategy}, Authority ${hd.authority}, Profile ${hd.profile}. Defined centers: ${hd.definedCenters.join(', ')}. Channels: ${hd.channels.join(', ')}.`,
        });
      }
    }

    // Recent conversation history (last 10 messages from session)
    const recentHistory = session.messages.slice(-10);
    for (const msg of recentHistory) {
      messages.push({
        role: msg.role,
        content: msg.content,
      });
    }

    // Agent's own memory (last 5)
    const recentMemory = this.memory.slice(-5);
    for (const msg of recentMemory) {
      messages.push({
        role: msg.role,
        content: `[${this.name} memory] ${msg.content}`,
      });
    }

    // Current input
    messages.push({
      role: 'user',
      content: input,
    });

    return messages;
  }

  /**
   * Post-process model output (override in subclasses)
   */
  protected async postProcess(response: ModelResponse, session: Session): Promise<AgentMessage> {
    // Default: just wrap the response
    return {
      id: crypto.randomUUID(),
      agentId: this.id,
      role: 'assistant',
      content: response.content,
      timestamp: Date.now(),
      metadata: {
        modelUsed: response.modelId,
        latencyMs: response.latencyMs,
        tokensIn: response.usage.prompt,
        tokensOut: response.usage.completion,
      },
    };
  }

  /**
   * Handle tool calls from the model
   */
  protected async handleToolCalls(calls: ToolCall[], session: Session): Promise<AgentMessage[]> {
    const results: AgentMessage[] = [];

    for (const call of calls) {
      if (!this.profile.tools.includes(call.name)) {
        logger.warn({ agent: this.id, tool: call.name }, 'Agent not authorized for tool');
        continue;
      }

      // Tool execution would be delegated to MCP layer
      // Simplified: log and return placeholder
      logger.info({ agent: this.id, tool: call.name, args: call.arguments }, 'Tool call');

      results.push({
        id: crypto.randomUUID(),
        agentId: this.id,
        role: 'tool',
        content: JSON.stringify({ tool: call.name, result: 'placeholder' }),
        timestamp: Date.now(),
        metadata: { toolsCalled: [call.name] },
      });
    }

    return results;
  }

  protected addToMemory(message: AgentMessage): void {
    this.memory.push(message);
    if (this.memory.length > this.maxMemorySize) {
      this.memory = this.memory.slice(-this.maxMemorySize);
    }
  }

  /**
   * Get agent stats
   */
  getStats(): { memorySize: number; tools: string[]; modelPreference: string } {
    return {
      memorySize: this.memory.length,
      tools: this.profile.tools,
      modelPreference: this.profile.modelPreference,
    };
  }
}
