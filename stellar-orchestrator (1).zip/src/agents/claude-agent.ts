/**
 * Claude Agent
 * Deep analyst, safety reviewer, critical thinker
 */

import { BaseAgent } from './base-agent.js';
import { AgentProfile, AgentMessage, Session, ModelResponse } from '../types/index.js';
import { ModelRouter } from '../models/model-router.js';
import { logger } from '../utils/logger.js';

export class ClaudeAgent extends BaseAgent {
  constructor(profile: AgentProfile, router: ModelRouter) {
    super(profile, router);
  }

  protected async postProcess(response: ModelResponse, session: Session): Promise<AgentMessage> {
    let content = response.content;

    // Claude's rigor: surface assumptions, check edge cases
    content = this.addCriticalAnalysis(content);

    // Safety check for sensitive content
    const safetyFlags = this.checkSafety(content);
    if (safetyFlags.length > 0) {
      content += `

⚠️ **Safety Notes:** ${safetyFlags.join(', ')}`;
    }

    return {
      id: crypto.randomUUID(),
      agentId: this.id,
      role: 'assistant',
      content,
      timestamp: Date.now(),
      metadata: {
        modelUsed: response.modelId,
        latencyMs: response.latencyMs,
        tokensIn: response.usage.prompt,
        tokensOut: response.usage.completion,
        confidence: 0.92,
      },
    };
  }

  private addCriticalAnalysis(content: string): string {
    // Add an "Assumptions & Edge Cases" section if not present
    if (!content.includes('Assumptions') && !content.includes('Edge cases')) {
      const analysis = `

---
🧠 **Claude's Critical Lens:**
- *Assumptions made:* This response assumes standard configurations.
- *Edge cases to consider:* Null inputs, race conditions, and unexpected data shapes.
- *Confidence level:* High for common cases, verify for edge cases.
`;
      content += analysis;
    }

    return content;
  }

  private checkSafety(content: string): string[] {
    const flags: string[] = [];

    const sensitivePatterns = [
      /api[_-]?key/gi,
      /password/gi,
      /secret/gi,
      /token/gi,
    ];

    for (const pattern of sensitivePatterns) {
      if (pattern.test(content)) {
        flags.push('Potential credential exposure detected');
        break;
      }
    }

    return flags;
  }

  /**
   * Deep code review with security focus
   */
  async securityReview(code: string, language: string = 'typescript'): Promise<AgentMessage> {
    const prompt = `Perform a security-focused code review of this ${language} code. Check for:
1. Injection vulnerabilities (SQL, command, template)
2. Authentication/authorization flaws
3. Data exposure (logging sensitive data)
4. Race conditions and concurrency issues
5. Input validation gaps
6. Dependency risks

Rate each category: SAFE | CAUTION | CRITICAL

Code:
\`\`\`${language}
${code}
\`\`\``;

    const session: Session = {
      id: crypto.randomUUID(),
      userId: 'system',
      createdAt: Date.now(),
      lastActivity: Date.now(),
      messages: [],
      context: { activeTools: [], customVariables: { topic: 'security-review' } },
      activeAgents: [this.id],
      pendingTasks: [],
    };

    return this.process(prompt, session);
  }

  /**
   * Long-context document analysis
   */
  async analyzeDocument(document: string, questions: string[]): Promise<AgentMessage> {
    const prompt = `Analyze this document and answer the following questions. Be thorough, cite specific sections, and flag any inconsistencies.

Document:
${document}

Questions:
${questions.map((q, i) => `${i + 1}. ${q}`).join('
')}`;

    const session: Session = {
      id: crypto.randomUUID(),
      userId: 'system',
      createdAt: Date.now(),
      lastActivity: Date.now(),
      messages: [],
      context: { activeTools: [], customVariables: { topic: 'document-analysis' } },
      activeAgents: [this.id],
      pendingTasks: [],
    };

    return this.process(prompt, session);
  }

  /**
   * Consensus arbitration between conflicting agent outputs
   */
  async arbitrate(outputs: { agent: string; content: string }[]): Promise<AgentMessage> {
    const prompt = `You are arbitrating between ${outputs.length} agent responses. Identify agreements, disagreements, and synthesize the most accurate combined answer. Flag any factual conflicts.

${outputs.map((o, i) => `--- Agent ${i + 1} (${o.agent}) ---
${o.content}
`).join('
')}`;

    const session: Session = {
      id: crypto.randomUUID(),
      userId: 'system',
      createdAt: Date.now(),
      lastActivity: Date.now(),
      messages: [],
      context: { activeTools: [], customVariables: { topic: 'arbitration' } },
      activeAgents: [this.id],
      pendingTasks: [],
    };

    return this.process(prompt, session);
  }
}
