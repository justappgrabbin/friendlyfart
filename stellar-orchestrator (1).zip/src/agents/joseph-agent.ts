/**
 * Joseph Agent
 * Systems architect, MRNN specialist, code generator
 */

import { BaseAgent } from './base-agent.js';
import { AgentProfile, AgentMessage, Session, ModelResponse } from '../types/index.js';
import { ModelRouter } from '../models/model-router.js';
import { logger } from '../utils/logger.js';

export class JosephAgent extends BaseAgent {
  constructor(profile: AgentProfile, router: ModelRouter) {
    super(profile, router);
  }

  /**
   * Joseph specializes in code generation with complete implementations
   */
  protected async postProcess(response: ModelResponse, session: Session): Promise<AgentMessage> {
    let content = response.content;

    // Joseph's signature: ensure code blocks are complete, not stubs
    if (content.includes('```typescript') || content.includes('```ts')) {
      content = this.verifyCodeCompleteness(content);
    }

    // Add MRNN/graph references naturally if relevant
    if (session.context.customVariables?.topic === 'neural' || 
        content.toLowerCase().includes('network')) {
      content = this.enrichWithArchitectureContext(content);
    }

    return {
      id: crypto.randomUUID(),
      agentId: this.id,
      role: 'assistant',
      content,
      timestamp: Date.now(),
      metadata: {
        modelUsed: response.modelId,
        latencyMs: response.latencyMs,
        tokensIn: response.usage.prompt,
        tokensOut: response.usage.completion,
        confidence: 0.95,
      },
    };
  }

  /**
   * Verify that generated code isn't leaving TODOs or stubs
   */
  private verifyCodeCompleteness(content: string): string {
    const stubPatterns = [
      /TODO:/gi,
      /FIXME:/gi,
      /\/\/ implement/gi,
      /\/\/ stub/gi,
      /not implemented/gi,
      /placeholder/gi,
    ];

    let warnings = '';
    for (const pattern of stubPatterns) {
      if (pattern.test(content)) {
        warnings += `
⚠️  Joseph detected potential stub in code. Review for completeness.
`;
      }
    }

    if (warnings) {
      content += `

---
${warnings}`;
    }

    return content;
  }

  /**
   * Enrich technical content with MRNN/graph architecture context
   */
  private enrichWithArchitectureContext(content: string): string {
    // Only add if not already present
    if (content.includes('MRNN') || content.includes('message-passing')) {
      return content;
    }

    const enrichment = `

> 💡 *Joseph's architectural note: Consider how this maps to a message-passing graph structure. Each layer can be a node, edges carry activations. Koehn's RNNG principles apply here — recursive composition through graph traversal rather than sequential stacking.*`;

    return content + enrichment;
  }

  /**
   * Joseph can review code from other agents
   */
  async reviewCode(code: string, language: string = 'typescript'): Promise<AgentMessage> {
    const reviewPrompt = `Review this ${language} code for:
1. Completeness (no stubs, all functions implemented)
2. Error handling (try/catch, input validation)
3. Type safety (proper TypeScript types)
4. Graph/message-passing compatibility (if applicable)
5. Performance considerations

Code:
\`\`\`${language}
${code}
\`\`\``;

    const session: Session = {
      id: crypto.randomUUID(),
      userId: 'system',
      createdAt: Date.now(),
      lastActivity: Date.now(),
      messages: [],
      context: { activeTools: [], customVariables: { topic: 'code-review' } },
      activeAgents: [this.id],
      pendingTasks: [],
    };

    return this.process(reviewPrompt, session);
  }

  /**
   * Generate a complete GitHub Actions workflow
   */
  async generateWorkflow(name: string, steps: string[]): Promise<AgentMessage> {
    const workflowContent = this.buildWorkflow(name, steps);

    return {
      id: crypto.randomUUID(),
      agentId: this.id,
      role: 'assistant',
      content: workflowContent,
      timestamp: Date.now(),
      metadata: {
        modelUsed: 'joseph-internal',
        toolsCalled: ['github'],
      },
    };
  }

  private buildWorkflow(name: string, steps: string[]): string {
    return `name: ${name}

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  ${name.toLowerCase().replace(/\s+/g, '-')}:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      ${steps.map((step, i) => `
      - name: Step ${i + 1}
        run: ${step}
      `).join('')}

      # Joseph's standard: always verify build artifacts
      - name: Verify artifacts
        run: ls -la dist/ || echo "No dist directory"
`;
  }
}
