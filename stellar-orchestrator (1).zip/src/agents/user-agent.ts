/**
 * User Agent (Personal Ally)
 * Knows your HD, astrology, life purpose. Grows WITH you.
 */

import { BaseAgent } from './base-agent.js';
import { AgentProfile, AgentMessage, Session, ModelResponse, HumanDesignProfile, AstrologicalProfile } from '../types/index.js';
import { ModelRouter } from '../models/model-router.js';
import { logger } from '../utils/logger.js';

export class UserAgent extends BaseAgent {
  private userProfile: { hd?: HumanDesignProfile; astro?: AstrologicalProfile } = {};
  private growthLog: { date: string; insight: string; applied: boolean }[] = [];

  constructor(profile: AgentProfile, router: ModelRouter) {
    super(profile, router);
  }

  setHumanDesign(hd: HumanDesignProfile): void {
    this.userProfile.hd = hd;
    logger.info({ type: hd.type, profile: hd.profile }, 'User HD profile loaded');
  }

  setAstrology(astro: AstrologicalProfile): void {
    this.userProfile.astro = astro;
    logger.info({ sun: astro.sunSign }, 'User astrological profile loaded');
  }

  protected async postProcess(response: ModelResponse, session: Session): Promise<AgentMessage> {
    let content = response.content;

    // Personalize with HD/astro references if available
    content = this.personalizeContent(content);

    // Align with user's life purpose
    content = this.alignWithPurpose(content, session);

    // Log growth insight
    this.logGrowthInsight(content);

    return {
      id: crypto.randomUUID(),
      agentId: this.id,
      role: 'assistant',
      content,
      timestamp: Date.now(),
      metadata: {
        modelUsed: response.modelId,
        latencyMs: response.latencyMs,
        tokensIn: response.usage.prompt,
        tokensOut: response.usage.completion,
        confidence: 0.88,
      },
    };
  }

  /**
   * Inject personal context naturally into responses
   */
  private personalizeContent(content: string): string {
    if (!this.userProfile.hd && !this.userProfile.astro) {
      return content;
    }

    // Only add if the content relates to decisions, energy, or timing
    const relevantTopics = ['decision', 'energy', 'timing', 'feel', 'strategy', 'wait', 'respond', 'initiate'];
    const isRelevant = relevantTopics.some(t => content.toLowerCase().includes(t));

    if (!isRelevant) return content;

    let personalNote = '';

    if (this.userProfile.hd) {
      const hd = this.userProfile.hd;
      if (content.toLowerCase().includes('decision') || content.toLowerCase().includes('strategy')) {
        personalNote += `

🧬 *Your HD reminder: As a ${hd.type} with ${hd.strategy} strategy and ${hd.authority} authority, your clarity comes ${hd.strategy === 'Wait to Respond' ? 'from waiting for life to show you the invitation' : 'through your unique process'}. Trust your body, not your mind.*`;
      }
    }

    if (this.userProfile.astro) {
      const astro = this.userProfile.astro;
      if (content.toLowerCase().includes('timing') || content.toLowerCase().includes('now')) {
        personalNote += `

🌙 *Astrological context: Your ${astro.sunSign} sun and ${astro.moonSign} moon create a rhythm of ${this.getRhythmDescription(astro)}. Current transits may be amplifying this.*`;
      }
    }

    return content + personalNote;
  }

  private getRhythmDescription(astro: AstrologicalProfile): string {
    const rhythms: Record<string, string> = {
      'Aries': 'initiation and bold action',
      'Taurus': 'steadiness and sensual grounding',
      'Gemini': 'curiosity and mental agility',
      'Cancer': 'emotional depth and nurturing',
      'Leo': 'creative expression and leadership',
      'Virgo': 'precision and service-oriented focus',
      'Libra': 'balance and relational harmony',
      'Scorpio': 'transformation and intensity',
      'Sagittarius': 'expansion and philosophical questing',
      'Capricorn': 'ambition and structural mastery',
      'Aquarius': 'innovation and collective vision',
      'Pisces': 'flow and spiritual permeability',
    };

    return rhythms[astro.sunSign] || 'unique cosmic timing';
  }

  /**
   * Align content with user's stated life purpose
   */
  private alignWithPurpose(content: string, session: Session): string {
    const purpose = session.context.customVariables?.lifePurpose as string;
    if (!purpose) return content;

    // Check if content is drifting from purpose
    const purposeKeywords = purpose.toLowerCase().split(/\s+/);
    const contentWords = content.toLowerCase().split(/\s+/);
    const alignment = purposeKeywords.filter(kw => contentWords.includes(kw)).length / purposeKeywords.length;

    if (alignment < 0.1 && content.length > 200) {
      content += `

🎯 *Purpose check: This response may not directly serve your purpose of "${purpose}". Want me to reframe this toward that direction?*`;
    }

    return content;
  }

  private logGrowthInsight(content: string): void {
    // Extract potential insights (sentences with "realize", "understand", "see that")
    const insightPatterns = [
      /realize that?\s+(.+?)[.!?]/gi,
      /understand that?\s+(.+?)[.!?]/gi,
      /see that?\s+(.+?)[.!?]/gi,
    ];

    for (const pattern of insightPatterns) {
      let match;
      while ((match = pattern.exec(content)) !== null) {
        this.growthLog.push({
          date: new Date().toISOString(),
          insight: match[1].trim(),
          applied: false,
        });
      }
    }
  }

  /**
   * Get growth summary for reflection
   */
  getGrowthSummary(): string {
    const recent = this.growthLog.slice(-10);
    return recent.map(g => `[${g.date}] ${g.insight} ${g.applied ? '✓' : '○'}`).join('
');
  }

  /**
   * Daily alignment check-in
   */
  async dailyCheckIn(): Promise<AgentMessage> {
    const hd = this.userProfile.hd;
    const astro = this.userProfile.astro;

    let prompt = 'Daily check-in: ';
    if (hd) {
      prompt += `As a ${hd.type} with ${hd.strategy}, what's one thing to remember today about your energy? `;
    }
    if (astro) {
      prompt += `With ${astro.sunSign} sun energy today, what quality to embody? `;
    }
    prompt += 'Keep it to one sentence. Make it actionable.';

    const session: Session = {
      id: crypto.randomUUID(),
      userId: 'system',
      createdAt: Date.now(),
      lastActivity: Date.now(),
      messages: [],
      context: { activeTools: [], customVariables: { topic: 'check-in' } },
      activeAgents: [this.id],
      pendingTasks: [],
    };

    return this.process(prompt, session);
  }
}
