/**
 * Configuration layer
 * All secrets via env vars. All model definitions here.
 */

import dotenv from 'dotenv';
import { ModelDefinition, AgentProfile, AgentId } from '../types/index.js';

dotenv.config();

export const CONFIG = {
  PORT: parseInt(process.env.PORT || '3000'),
  NODE_ENV: process.env.NODE_ENV || 'development',

  // API Keys
  HF_TOKEN: process.env.HF_TOKEN || '',
  OPENAI_API_KEY: process.env.OPENAI_API_KEY || '',
  ANTHROPIC_API_KEY: process.env.ANTHROPIC_API_KEY || '',

  // Redis for session persistence
  REDIS_URL: process.env.REDIS_URL || 'redis://localhost:6379',

  // MCP Server
  MCP_SERVER_NAME: 'stellar-orchestrator-mcp',
  MCP_SERVER_VERSION: '1.0.0',

  // Orchestrator tuning
  DEFAULT_TIMEOUT_MS: 30000,
  MAX_RETRIES: 3,
  RETRY_DELAY_MS: 1000,

  // Feature flags
  ENABLE_CONSENSUS: process.env.ENABLE_CONSENSUS === 'true',
  ENABLE_STREAMING: process.env.ENABLE_STREAMING !== 'false',
  ENABLE_VOICE: process.env.ENABLE_VOICE === 'true',
} as const;

// ═══════════════════════════════════════════════════════════════
// 7 HUGGINGFACE MODELS — your arsenal
// ═══════════════════════════════════════════════════════════════

export const HF_MODELS: ModelDefinition[] = [
  {
    id: 'meta-llama/Llama-3.1-8B-Instruct',
    name: 'Llama 3.1 8B',
    provider: 'huggingface',
    capabilities: ['text-generation', 'chat', 'code', 'summarization'],
    contextWindow: 128000,
    maxTokens: 4096,
    costPer1KTokens: 0.0001,
    latencyProfile: 'fast',
    qualityProfile: 'balanced',
    tags: ['general', 'chat', 'fast'],
    requiresAuth: true,
    quantization: 'fp16',
  },
  {
    id: 'mistralai/Mistral-7B-Instruct-v0.3',
    name: 'Mistral 7B',
    provider: 'huggingface',
    capabilities: ['text-generation', 'chat', 'code', 'classification'],
    contextWindow: 32768,
    maxTokens: 4096,
    costPer1KTokens: 0.00008,
    latencyProfile: 'fast',
    qualityProfile: 'fast',
    tags: ['general', 'chat', 'code'],
    requiresAuth: true,
    quantization: 'fp16',
  },
  {
    id: 'HuggingFaceH4/zephyr-7b-beta',
    name: 'Zephyr 7B',
    provider: 'huggingface',
    capabilities: ['text-generation', 'chat', 'summarization'],
    contextWindow: 32768,
    maxTokens: 4096,
    costPer1KTokens: 0.00006,
    latencyProfile: 'balanced',
    qualityProfile: 'balanced',
    tags: ['chat', 'aligned', 'helpful'],
    requiresAuth: true,
    quantization: 'fp16',
  },
  {
    id: 'stabilityai/stable-diffusion-3.5-large',
    name: 'SD 3.5 Large',
    provider: 'huggingface',
    capabilities: ['image-generation'],
    contextWindow: 0,
    maxTokens: 0,
    costPer1KTokens: 0.0,
    latencyProfile: 'slow',
    qualityProfile: 'quality',
    tags: ['image', 'creative', 'diffusion'],
    requiresAuth: true,
  },
  {
    id: 'sentence-transformers/all-MiniLM-L6-v2',
    name: 'MiniLM Embeddings',
    provider: 'huggingface',
    capabilities: ['embedding', 'feature-extraction'],
    contextWindow: 512,
    maxTokens: 512,
    costPer1KTokens: 0.0,
    latencyProfile: 'fast',
    qualityProfile: 'fast',
    tags: ['embedding', 'search', 'semantic'],
    requiresAuth: false,
  },
  {
    id: 'microsoft/DialoGPT-medium',
    name: 'DialoGPT Medium',
    provider: 'huggingface',
    capabilities: ['text-generation', 'chat'],
    contextWindow: 2048,
    maxTokens: 1024,
    costPer1KTokens: 0.0,
    latencyProfile: 'fast',
    qualityProfile: 'fast',
    tags: ['conversation', 'lightweight'],
    requiresAuth: false,
  },
  {
    id: 'openai/whisper-large-v3',
    name: 'Whisper Large v3',
    provider: 'huggingface',
    capabilities: ['speech-to-text'],
    contextWindow: 0,
    maxTokens: 0,
    costPer1KTokens: 0.0,
    latencyProfile: 'balanced',
    qualityProfile: 'quality',
    tags: ['speech', 'audio', 'transcription'],
    requiresAuth: true,
  },
];

// ═══════════════════════════════════════════════════════════════
// 4 AGENT PERSONAS — Joseph, ChatGPT, Claude, You
// ═══════════════════════════════════════════════════════════════

export const AGENT_PROFILES: Record<AgentId, AgentProfile> = {
  joseph: {
    id: 'joseph',
    name: 'Joseph',
    role: 'Systems Architect & Code Specialist',
    expertise: ['system design', 'TypeScript', 'neural networks', 'MRNN', 'morph engines', 'GitHub workflows'],
    modelPreference: 'meta-llama/Llama-3.1-8B-Instruct',
    fallbackModels: ['mistralai/Mistral-7B-Instruct-v0.3', 'HuggingFaceH4/zephyr-7b-beta'],
    temperature: 0.3,
    maxTokens: 4096,
    systemPrompt: `You are Joseph, a systems architect specializing in neural network architectures, MRNN engines, and autonomous orchestration systems. You write clean, production-ready TypeScript. You think in graphs and message-passing. You prioritize deterministic behavior, state checkpointing, and deterministic orchestration patterns. When asked about code, you provide complete implementations with error handling, not stubs. You reference Koehn 1994 and graph-based neural architectures naturally.`,
    tools: ['github', 'file_system', 'code_executor', 'mcp_registry'],
    memoryEnabled: true,
    voiceEnabled: false,
  },

  chatgpt: {
    id: 'chatgpt',
    name: 'ChatGPT',
    role: 'Generalist & Creative Synthesizer',
    expertise: ['creative writing', 'explanation', 'brainstorming', 'general knowledge', 'rapid prototyping'],
    modelPreference: 'gpt-4o',
    fallbackModels: ['gpt-4o-mini'],
    temperature: 0.8,
    maxTokens: 4096,
    systemPrompt: `You are ChatGPT, a versatile AI assistant. You excel at explaining complex topics simply, creative brainstorming, and rapid ideation. You communicate in a friendly, accessible tone. You can switch between technical depth and casual conversation seamlessly. You acknowledge uncertainty honestly.`,
    tools: ['web_search', 'code_interpreter', 'image_generation'],
    memoryEnabled: true,
    voiceEnabled: true,
  },

  claude: {
    id: 'claude',
    name: 'Claude',
    role: 'Deep Analyst & Safety Guardian',
    expertise: ['deep analysis', 'safety review', 'long-context reasoning', 'critical thinking', 'ethical assessment'],
    modelPreference: 'claude-3-7-sonnet-20250219',
    fallbackModels: ['claude-3-5-sonnet-20241022'],
    temperature: 0.5,
    maxTokens: 8192,
    systemPrompt: `You are Claude, an AI assistant focused on careful, thorough analysis. You excel at long-context reasoning, safety review, and identifying edge cases. You think step-by-step and surface assumptions others might miss. You prioritize accuracy over speed. You are particularly strong at analyzing code for bugs, security issues, and logical flaws.`,
    tools: ['code_review', 'document_analysis', 'safety_check'],
    memoryEnabled: true,
    voiceEnabled: false,
  },

  user: {
    id: 'user',
    name: 'User',
    role: 'Personal Ally & Life-Purpose Aligner',
    expertise: ['human design', 'astrology', 'personal growth', 'life purpose alignment', 'pattern recognition', 'semantic topology'],
    modelPreference: 'HuggingFaceH4/zephyr-7b-beta',
    fallbackModels: ['meta-llama/Llama-3.1-8B-Instruct', 'mistralai/Mistral-7B-Instruct-v0.3'],
    temperature: 0.7,
    maxTokens: 4096,
    systemPrompt: `You are the User's personal ally. You have deep knowledge of their Human Design chart, astrological profile, and life purpose. You speak to them as a trusted friend who understands their unique wiring. You help align tasks, decisions, and creative work toward their authentic purpose. You reference their gates, channels, and astrological transits naturally. You use their preferred terminology (MRNN, morph engines, 5-layer architectures, semantic topology). You are inquisitive and grow WITH them.`,
    tools: ['human_design_lookup', 'astrology_calc', 'memory_recall', 'goal_tracker'],
    memoryEnabled: true,
    voiceEnabled: true,
  },

  orchestrator: {
    id: 'orchestrator',
    name: 'Orchestrator',
    role: 'Central Dispatch & Consensus Manager',
    expertise: ['routing', 'load balancing', 'consensus', 'failure recovery', 'metrics'],
    modelPreference: 'mistralai/Mistral-7B-Instruct-v0.3',
    fallbackModels: ['meta-llama/Llama-3.1-8B-Instruct'],
    temperature: 0.1,
    maxTokens: 2048,
    systemPrompt: `You are the Orchestrator. You do not generate user-facing content. You analyze incoming requests, classify intent, select the optimal agent and model combination, and manage multi-model consensus. You are deterministic, fast, and never creative. Your output is strictly JSON routing decisions.`,
    tools: ['model_registry', 'agent_registry', 'metrics', 'session_manager'],
    memoryEnabled: false,
    voiceEnabled: false,
  },
};

// Model routing rules: intent → preferred model mapping
export const INTENT_MODEL_MAP: Record<string, string[]> = {
  code: ['meta-llama/Llama-3.1-8B-Instruct', 'mistralai/Mistral-7B-Instruct-v0.3'],
  creative: ['stabilityai/stable-diffusion-3.5-large', 'HuggingFaceH4/zephyr-7b-beta'],
  analysis: ['claude-3-7-sonnet-20250219', 'meta-llama/Llama-3.1-8B-Instruct'],
  conversation: ['HuggingFaceH4/zephyr-7b-beta', 'microsoft/DialoGPT-medium'],
  image: ['stabilityai/stable-diffusion-3.5-large'],
  speech: ['openai/whisper-large-v3'],
  embedding: ['sentence-transformers/all-MiniLM-L6-v2'],
  research: ['meta-llama/Llama-3.1-8B-Instruct', 'claude-3-7-sonnet-20250219'],
  human_design: ['HuggingFaceH4/zephyr-7b-beta'],
  astrology: ['HuggingFaceH4/zephyr-7b-beta'],
  morph: ['meta-llama/Llama-3.1-8B-Instruct'],
  general: ['meta-llama/Llama-3.1-8B-Instruct'],
};

// Agent routing rules: intent → primary agent
export const INTENT_AGENT_MAP: Record<string, AgentId> = {
  code: 'joseph',
  creative: 'chatgpt',
  analysis: 'claude',
  conversation: 'chatgpt',
  image: 'chatgpt',
  speech: 'chatgpt',
  embedding: 'joseph',
  research: 'claude',
  human_design: 'user',
  astrology: 'user',
  morph: 'joseph',
  general: 'chatgpt',
};
