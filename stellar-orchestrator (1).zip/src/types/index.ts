/**
 * Core types for the Stellar Orchestrator
 * Defines all domain entities, agent contracts, and model interfaces
 */

// ─── Agent System ───────────────────────────────────────────────

export type AgentId = 'joseph' | 'chatgpt' | 'claude' | 'user' | 'orchestrator';

export interface AgentProfile {
  id: AgentId;
  name: string;
  role: string;
  expertise: string[];
  modelPreference: string;        // preferred HF model ID
  fallbackModels: string[];       // cascade order
  temperature: number;
  maxTokens: number;
  systemPrompt: string;
  tools: string[];                // allowed MCP tools
  memoryEnabled: boolean;
  voiceEnabled: boolean;
}

export interface AgentMessage {
  id: string;
  agentId: AgentId;
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  timestamp: number;
  metadata?: MessageMetadata;
}

export interface MessageMetadata {
  modelUsed?: string;
  latencyMs?: number;
  tokensIn?: number;
  tokensOut?: number;
  confidence?: number;
  intent?: IntentClassification;
  toolsCalled?: string[];
}

// ─── Intent & Routing ───────────────────────────────────────────

export type IntentType = 
  | 'code' | 'creative' | 'analysis' | 'conversation'
  | 'image' | 'speech' | 'embedding' | 'research'
  | 'human_design' | 'astrology' | 'morph' | 'general';

export interface IntentClassification {
  primary: IntentType;
  secondary: IntentType[];
  confidence: number;
  entities: Record<string, string>;
  urgency: 'low' | 'normal' | 'high' | 'critical';
}

export interface RoutingDecision {
  targetAgent: AgentId;
  targetModels: string[];         // ordered by preference
  strategy: 'single' | 'ensemble' | 'consensus' | 'cascade';
  reasoning: string;
  estimatedLatency: number;
}

// ─── Model System ─────────────────────────────────────────────

export type ModelCapability = 
  | 'text-generation' | 'chat' | 'code' | 'summarization'
  | 'translation' | 'image-generation' | 'image-to-text'
  | 'text-to-speech' | 'speech-to-text' | 'embedding'
  | 'classification' | 'feature-extraction';

export interface ModelDefinition {
  id: string;                     // HF model ID like "meta-llama/Llama-3.1-8B"
  name: string;
  provider: 'huggingface' | 'openai' | 'anthropic' | 'local';
  capabilities: ModelCapability[];
  contextWindow: number;
  maxTokens: number;
  costPer1KTokens: number;
  latencyProfile: 'fast' | 'balanced' | 'slow';
  qualityProfile: 'fast' | 'balanced' | 'quality';
  tags: string[];
  endpoint?: string;              // custom endpoint if not HF hub
  requiresAuth: boolean;
  quantization?: 'fp16' | 'int8' | 'int4' | 'awq' | 'gptq';
}

export interface ModelRequest {
  modelId: string;
  messages: AgentMessage[];
  temperature?: number;
  maxTokens?: number;
  tools?: string[];
  stream?: boolean;
  parameters?: Record<string, unknown>;
}

export interface ModelResponse {
  modelId: string;
  content: string;
  usage: TokenUsage;
  latencyMs: number;
  finishReason: 'stop' | 'length' | 'tool_calls' | 'error';
  toolCalls?: ToolCall[];
  raw?: unknown;                  // provider-specific raw response
}

export interface TokenUsage {
  prompt: number;
  completion: number;
  total: number;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

// ─── Consensus & Ensemble ─────────────────────────────────────

export interface ConsensusResult {
  finalAnswer: string;
  contributors: { modelId: string; weight: number; answer: string }[];
  agreementScore: number;         // 0-1
  dissentNotes: string[];
  synthesisMethod: 'majority' | 'weighted' | 'best_quality' | 'arbitration';
}

// ─── Session & State ──────────────────────────────────────────

export interface Session {
  id: string;
  userId: string;
  createdAt: number;
  lastActivity: number;
  messages: AgentMessage[];
  context: SessionContext;
  activeAgents: AgentId[];
  pendingTasks: Task[];
}

export interface SessionContext {
  userProfile?: UserProfile;
  conversationSummary?: string;
  activeTools: string[];
  customVariables: Record<string, unknown>;
}

export interface UserProfile {
  id: string;
  name: string;
  preferences: Record<string, unknown>;
  humanDesign?: HumanDesignProfile;
  astrological?: AstrologicalProfile;
}

export interface HumanDesignProfile {
  type: string;
  strategy: string;
  authority: string;
  profile: string;
  definedCenters: string[];
  channels: string[];
  gates: number[];
}

export interface AstrologicalProfile {
  sunSign: string;
  moonSign: string;
  risingSign: string;
  siderealPositions: Record<string, number>;
}

export interface Task {
  id: string;
  type: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  assignedTo: AgentId;
  priority: number;
  payload: unknown;
  result?: unknown;
  error?: string;
}

// ─── Orchestrator Events ──────────────────────────────────────

export type OrchestratorEvent =
  | { type: 'request_received'; payload: { sessionId: string; content: string } }
  | { type: 'intent_classified'; payload: { sessionId: string; intent: IntentClassification } }
  | { type: 'agent_selected'; payload: { sessionId: string; agent: AgentId; reasoning: string } }
  | { type: 'model_dispatched'; payload: { sessionId: string; models: string[]; strategy: string } }
  | { type: 'response_generated'; payload: { sessionId: string; response: ModelResponse } }
  | { type: 'consensus_reached'; payload: { sessionId: string; result: ConsensusResult } }
  | { type: 'tool_invoked'; payload: { sessionId: string; tool: string; result: unknown } }
  | { type: 'error'; payload: { sessionId: string; error: string; recoverable: boolean } };

// ─── MCP ────────────────────────────────────────────────────────

export interface MCPTool {
  name: string;
  description: string;
  parameters: zod.ZodTypeAny;       // Zod schema for validation
  handler: (args: unknown) => Promise<unknown>;
}

export interface MCPResource {
  uri: string;
  name: string;
  mimeType: string;
  handler: () => Promise<unknown>;
}

import type { z } from 'zod';
export { z };
