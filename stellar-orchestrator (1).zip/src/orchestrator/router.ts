/**
 * Intent Router
 * Classifies incoming requests and determines routing strategy
 */

import { 
  IntentClassification, 
  IntentType,
  AgentId,
  AgentMessage 
} from '../types/index.js';
import { INTENT_AGENT_MAP } from '../config/index.js';
import { logger } from '../utils/logger.js';

// Keyword → intent mapping for fast classification
const INTENT_KEYWORDS: Record<IntentType, string[]> = {
  code: ['code', 'function', 'class', 'implement', 'typescript', 'javascript', 'build', 'repo', 'git', 'workflow', 'mrnn', 'neural', 'graph', 'morph'],
  creative: ['create', 'design', 'art', 'image', 'generate', 'draw', 'visual', 'aesthetic', 'burn'],
  analysis: ['analyze', 'review', 'check', 'audit', 'security', 'compare', 'evaluate', 'assess'],
  conversation: ['chat', 'talk', 'hello', 'hi', 'how are you', 'what do you think'],
  image: ['image', 'picture', 'photo', 'generate image', 'draw', 'visualize'],
  speech: ['voice', 'speak', 'audio', 'transcribe', 'listen'],
  embedding: ['embed', 'vector', 'semantic', 'similarity', 'search'],
  research: ['research', 'find', 'look up', 'search', 'information', 'paper', 'study'],
  human_design: ['human design', 'hd', 'gate', 'channel', 'center', 'type', 'authority', 'strategy', 'profile'],
  astrology: ['astrology', 'transit', 'planet', 'sign', 'sidereal', 'natal', 'chart', 'zodiac'],
  morph: ['morph', 'transform', 'evolve', 'shape', 'metamorphosis', 'change form'],
  general: [],
};

// Urgency indicators
const URGENCY_PATTERNS = {
  critical: ['urgent', 'emergency', 'broken', 'crash', 'error', 'fail', 'now', 'asap', 'critical'],
  high: ['important', 'soon', 'needed', 'priority', 'deadline'],
  low: ['whenever', 'later', 'someday', 'eventually', 'no rush'],
};

export class IntentRouter {
  /**
   * Classify user input into intent with confidence scores
   */
  classify(input: string): IntentClassification {
    const lowerInput = input.toLowerCase();
    const scores: Record<string, number> = {};

    // Score each intent based on keyword matches
    for (const [intent, keywords] of Object.entries(INTENT_KEYWORDS)) {
      scores[intent] = 0;
      for (const keyword of keywords) {
        if (lowerInput.includes(keyword)) {
          scores[intent] += 1;
          // Boost for exact phrase matches
          if (lowerInput.includes(` ${keyword} `) || lowerInput.startsWith(keyword + ' ')) {
            scores[intent] += 0.5;
          }
        }
      }
    }

    // Normalize scores
    const totalScore = Object.values(scores).reduce((a, b) => a + b, 0);
    const normalized = totalScore > 0 
      ? Object.fromEntries(Object.entries(scores).map(([k, v]) => [k, v / totalScore]))
      : { general: 1.0 };

    // Sort by score
    const sorted = Object.entries(normalized).sort((a, b) => b[1] - a[1]);
    const primary = sorted[0][0] as IntentType;
    const secondary = sorted.slice(1, 3).filter(([_, score]) => score > 0.1).map(([intent]) => intent as IntentType);
    const confidence = sorted[0][1];

    // Extract entities (simple regex-based)
    const entities = this.extractEntities(input);

    // Determine urgency
    const urgency = this.determineUrgency(lowerInput);

    logger.info({ primary, confidence, urgency }, 'Intent classified');

    return {
      primary,
      secondary,
      confidence,
      entities,
      urgency,
    };
  }

  /**
   * Determine which agent should handle this intent
   */
  selectAgent(intent: IntentClassification): AgentId {
    const mapped = INTENT_AGENT_MAP[intent.primary];
    if (mapped) return mapped;

    // Fallback: use confidence-weighted selection
    if (intent.secondary.length > 0) {
      for (const secIntent of intent.secondary) {
        const secMapped = INTENT_AGENT_MAP[secIntent];
        if (secMapped) return secMapped;
      }
    }

    return 'chatgpt'; // ultimate fallback
  }

  /**
   * Extract simple entities from input
   */
  private extractEntities(input: string): Record<string, string> {
    const entities: Record<string, string> = {};

    // Extract quoted strings
    const quotes = input.match(/"([^"]+)"/g);
    if (quotes) {
      entities.quotes = quotes.map(q => q.replace(/"/g, '')).join(', ');
    }

    // Extract URLs
    const urls = input.match(/https?:\/\/[^\s]+/g);
    if (urls) {
      entities.urls = urls.join(', ');
    }

    // Extract file references
    const files = input.match(/[\w-]+\.(ts|js|json|md|yml|yaml|py)/g);
    if (files) {
      entities.files = files.join(', ');
    }

    // Extract model references
    const models = input.match(/(?:meta-llama|mistralai|HuggingFaceH4|stabilityai|microsoft|openai)\/[\w-]+/g);
    if (models) {
      entities.models = models.join(', ');
    }

    return entities;
  }

  private determineUrgency(input: string): 'low' | 'normal' | 'high' | 'critical' {
    for (const [level, patterns] of Object.entries(URGENCY_PATTERNS)) {
      if (patterns.some(p => input.includes(p))) {
        return level as 'low' | 'normal' | 'high' | 'critical';
      }
    }
    return 'normal';
  }
}
