/**
 * Dispatcher
 * Coordinates agent execution and manages the request lifecycle
 */

import { 
  Session, 
  AgentMessage, 
  OrchestratorEvent,
  IntentClassification,
  RoutingDecision 
} from '../types/index.js';
import { BaseAgent } from '../agents/base-agent.js';
import { ModelRouter } from '../models/model-router.js';
import { logger } from '../utils/logger.js';

export class Dispatcher {
  private agents: Map<string, BaseAgent> = new Map();
  private router: ModelRouter;
  private eventHandlers: ((event: OrchestratorEvent) => void)[] = [];

  constructor(router: ModelRouter) {
    this.router = router;
  }

  registerAgent(agent: BaseAgent): void {
    this.agents.set(agent.id, agent);
    logger.info({ agent: agent.id, name: agent.name }, 'Agent registered');
  }

  onEvent(handler: (event: OrchestratorEvent) => void): void {
    this.eventHandlers.push(handler);
  }

  private emit(event: OrchestratorEvent): void {
    for (const handler of this.eventHandlers) {
      try {
        handler(event);
      } catch (error) {
        logger.error({ error }, 'Event handler failed');
      }
    }
  }

  /**
   * Main dispatch: receive input, route to agent, return response
   */
  async dispatch(
    session: Session,
    input: string,
    intent: IntentClassification,
    decision: RoutingDecision
  ): Promise<AgentMessage> {
    const agent = this.agents.get(decision.targetAgent);

    if (!agent) {
      logger.error({ agent: decision.targetAgent }, 'Agent not found');
      throw new Error(`Agent ${decision.targetAgent} not registered`);
    }

    this.emit({
      type: 'agent_selected',
      payload: { sessionId: session.id, agent: decision.targetAgent, reasoning: decision.reasoning },
    });

    this.emit({
      type: 'model_dispatched',
      payload: { sessionId: session.id, models: decision.targetModels, strategy: decision.strategy },
    });

    try {
      const response = await agent.process(input, session);

      this.emit({
        type: 'response_generated',
        payload: { sessionId: session.id, response: {
          modelId: response.metadata?.modelUsed || 'unknown',
          content: response.content,
          usage: { prompt: response.metadata?.tokensIn || 0, completion: response.metadata?.tokensOut || 0, total: (response.metadata?.tokensIn || 0) + (response.metadata?.tokensOut || 0) },
          latencyMs: response.metadata?.latencyMs || 0,
          finishReason: 'stop',
        }},
      });

      return response;
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);

      this.emit({
        type: 'error',
        payload: { sessionId: session.id, error: errorMsg, recoverable: true },
      });

      // Attempt recovery with fallback agent
      if (decision.targetModels.length > 1) {
        logger.info({ session: session.id }, 'Attempting recovery with fallback models');

        const fallbackDecision: RoutingDecision = {
          ...decision,
          targetModels: decision.targetModels.slice(1),
          strategy: 'cascade',
        };

        return this.dispatch(session, input, intent, fallbackDecision);
      }

      throw error;
    }
  }

  /**
   * Multi-agent collaboration: dispatch to multiple agents and synthesize
   */
  async collaborate(
    session: Session,
    input: string,
    intent: IntentClassification,
    agents: string[]
  ): Promise<AgentMessage[]> {
    const promises = agents.map(async agentId => {
      const agent = this.agents.get(agentId);
      if (!agent) return null;

      const decision = await this.router.route(intent, agent['profile'], []);
      return this.dispatch(session, input, intent, decision);
    });

    const results = await Promise.all(promises);
    return results.filter((r): r is AgentMessage => r !== null);
  }

  getAgentStats(): Record<string, { memorySize: number; tools: string[]; modelPreference: string }> {
    const stats: Record<string, any> = {};
    for (const [id, agent] of this.agents) {
      stats[id] = agent.getStats();
    }
    return stats;
  }
}
