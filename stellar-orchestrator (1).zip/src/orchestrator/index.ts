/**
 * Stellar Orchestrator — Main Entry Point
 * Coordinates all agents, models, and the request pipeline
 */

import Fastify from 'fastify';
import cors from '@fastify/cors';
import websocket from '@fastify/websocket';

import { CONFIG, AGENT_PROFILES } from '../config/index.js';
import { StateManager } from './state.js';
import { IntentRouter } from './router.js';
import { Dispatcher } from './dispatcher.js';
import { ConsensusEngine } from './consensus.js';
import { ModelRouter } from '../models/model-router.js';

import { JosephAgent } from '../agents/joseph-agent.js';
import { ChatGPTAgent } from '../agents/chatgpt-agent.js';
import { ClaudeAgent } from '../agents/claude-agent.js';
import { UserAgent } from '../agents/user-agent.js';

import { logger } from '../utils/logger.js';
import { metrics } from '../utils/metrics.js';

export class StellarOrchestrator {
  private app = Fastify({ logger: false });
  private stateManager: StateManager;
  private intentRouter: IntentRouter;
  private modelRouter: ModelRouter;
  private dispatcher: Dispatcher;
  private consensusEngine: ConsensusEngine;

  private agents = {
    joseph: null as JosephAgent | null,
    chatgpt: null as ChatGPTAgent | null,
    claude: null as ClaudeAgent | null,
    user: null as UserAgent | null,
  };

  constructor() {
    this.stateManager = new StateManager();
    this.intentRouter = new IntentRouter();
    this.modelRouter = new ModelRouter();
    this.dispatcher = new Dispatcher(this.modelRouter);
    this.consensusEngine = new ConsensusEngine();

    this.setupAgents();
    this.setupRoutes();
    this.setupWebSocket();
    this.setupEventHandlers();
  }

  private setupAgents(): void {
    // Initialize all 4 agents with their profiles
    this.agents.joseph = new JosephAgent(AGENT_PROFILES.joseph, this.modelRouter);
    this.agents.chatgpt = new ChatGPTAgent(AGENT_PROFILES.chatgpt, this.modelRouter);
    this.agents.claude = new ClaudeAgent(AGENT_PROFILES.claude, this.modelRouter);
    this.agents.user = new UserAgent(AGENT_PROFILES.user, this.modelRouter);

    // Register with dispatcher
    this.dispatcher.registerAgent(this.agents.joseph);
    this.dispatcher.registerAgent(this.agents.chatgpt);
    this.dispatcher.registerAgent(this.agents.claude);
    this.dispatcher.registerAgent(this.agents.user);

    logger.info('All 4 agents registered');
  }

  private setupRoutes(): void {
    this.app.register(cors, { origin: true });

    // Health check
    this.app.get('/health', async () => ({
      status: 'ok',
      timestamp: Date.now(),
      agents: Object.keys(this.agents),
      models: this.modelRouter['registry'].getAllModels().map(m => m.id),
    }));

    // Model health report
    this.app.get('/health/models', async () => ({
      models: this.modelRouter.getHealthReport(),
      stats: this.modelRouter.getRequestStats(),
    }));

    // Main chat endpoint
    this.app.post('/chat', async (request, reply) => {
      const { sessionId, message, userId, userProfile } = request.body as any;

      metrics.increment('requests_total');
      const startTime = Date.now();

      try {
        // Get or create session
        let session = sessionId 
          ? await this.stateManager.loadSession(sessionId)
          : null;

        if (!session) {
          session = await this.stateManager.createSession(userId || 'anonymous', userProfile);
        }

        // Store user message
        await this.stateManager.addMessage(session.id, {
          id: crypto.randomUUID(),
          agentId: 'user',
          role: 'user',
          content: message,
          timestamp: Date.now(),
        });

        // Classify intent
        const intent = this.intentRouter.classify(message);
        await this.stateManager.updateContext(session.id, { lastIntent: intent });

        // Select agent
        const agentId = this.intentRouter.selectAgent(intent);
        const agent = this.agents[agentId as keyof typeof this.agents];

        if (!agent) {
          throw new Error(`Agent ${agentId} not available`);
        }

        // Route to models
        const routing = await this.modelRouter.route(intent, agent['profile'], []);

        // Dispatch
        const response = await this.dispatcher.dispatch(session, message, intent, routing);

        // Store response
        await this.stateManager.addMessage(session.id, response);

        // Update metrics
        metrics.timing('request_duration_ms', Date.now() - startTime);

        return {
          sessionId: session.id,
          response: response.content,
          agent: agentId,
          model: response.metadata?.modelUsed,
          latency: response.metadata?.latencyMs,
          intent: intent.primary,
          confidence: intent.confidence,
        };
      } catch (error) {
        metrics.increment('errors_total');
        logger.error({ error: (error as Error).message }, 'Chat request failed');
        reply.status(500);
        return { error: (error as Error).message };
      }
    });

    // Multi-agent collaboration endpoint
    this.app.post('/collaborate', async (request) => {
      const { sessionId, message, agents: agentIds } = request.body as any;

      const session = await this.stateManager.loadSession(sessionId);
      if (!session) throw new Error('Session not found');

      const intent = this.intentRouter.classify(message);
      const responses = await this.dispatcher.collaborate(session, message, intent, agentIds);

      // If multiple responses, run consensus
      if (responses.length > 1 && CONFIG.ENABLE_CONSENSUS) {
        const consensus = await this.consensusEngine.reachConsensus(
          responses.map(r => ({
            modelId: r.metadata?.modelUsed || 'unknown',
            content: r.content,
            usage: { prompt: r.metadata?.tokensIn || 0, completion: r.metadata?.tokensOut || 0, total: 0 },
            latencyMs: r.metadata?.latencyMs || 0,
            finishReason: 'stop' as const,
          }))
        );

        return {
          sessionId,
          consensus: consensus.finalAnswer,
          contributors: consensus.contributors,
          agreement: consensus.agreementScore,
          raw: responses.map(r => ({ agent: r.agentId, content: r.content })),
        };
      }

      return {
        sessionId,
        responses: responses.map(r => ({ agent: r.agentId, content: r.content })),
      };
    });

    // Agent stats
    this.app.get('/agents/stats', async () => ({
      agents: this.dispatcher.getAgentStats(),
      models: this.modelRouter.getHealthReport(),
    }));

    // Session management
    this.app.get('/sessions/:id', async (request) => {
      const { id } = request.params as { id: string };
      return await this.stateManager.loadSession(id);
    });

    this.app.post('/sessions/:id/checkpoint', async (request) => {
      const { id } = request.params as { id: string };
      const { label } = request.body as { label: string };
      await this.stateManager.checkpoint(id, label);
      return { ok: true };
    });

    this.app.post('/sessions/:id/restore', async (request) => {
      const { id } = request.params as { id: string };
      const { label } = request.body as { label: string };
      const session = await this.stateManager.restoreCheckpoint(id, label);
      return { restored: !!session, session };
    });
  }

  private setupWebSocket(): void {
    this.app.register(websocket);

    this.app.get('/ws', { websocket: true }, (connection) => {
      logger.info('WebSocket connection established');

      connection.socket.on('message', async (message: Buffer) => {
        try {
          const data = JSON.parse(message.toString());

          if (data.type === 'chat') {
            // Handle streaming response
            const session = await this.stateManager.loadSession(data.sessionId);
            if (!session) {
              connection.socket.send(JSON.stringify({ error: 'Session not found' }));
              return;
            }

            const intent = this.intentRouter.classify(data.message);
            const agentId = this.intentRouter.selectAgent(intent);
            const agent = this.agents[agentId as keyof typeof this.agents];

            if (!agent) {
              connection.socket.send(JSON.stringify({ error: 'Agent not available' }));
              return;
            }

            const routing = await this.modelRouter.route(intent, agent['profile'], []);

            // Stream response if supported
            if (CONFIG.ENABLE_STREAMING && routing.targetModels[0]) {
              // Note: HF streaming would go here
              // For now, send full response
              const response = await this.dispatcher.dispatch(session, data.message, intent, routing);
              connection.socket.send(JSON.stringify({
                type: 'response',
                content: response.content,
                agent: agentId,
                done: true,
              }));
            }
          }
        } catch (error) {
          connection.socket.send(JSON.stringify({ 
            error: (error as Error).message 
          }));
        }
      });

      connection.socket.on('close', () => {
        logger.info('WebSocket connection closed');
      });
    });
  }

  private setupEventHandlers(): void {
    this.dispatcher.onEvent((event) => {
      logger.debug({ type: event.type, session: event.payload.sessionId }, 'Orchestrator event');

      // Could emit to WebSocket, metrics, etc.
      if (event.type === 'error') {
        metrics.increment('agent_errors');
      }
    });
  }

  async start(): Promise<void> {
    try {
      await this.app.listen({ port: CONFIG.PORT, host: '0.0.0.0' });
      logger.info(`🚀 Stellar Orchestrator running on port ${CONFIG.PORT}`);
      logger.info(`🤖 Agents: Joseph, ChatGPT, Claude, User`);
      logger.info(`🧠 Models: 7 HuggingFace models + OpenAI + Anthropic`);
      logger.info(`📡 MCP: Ready for tool integration`);
    } catch (error) {
      logger.error({ error: (error as Error).message }, 'Failed to start server');
      throw error;
    }
  }

  async stop(): Promise<void> {
    await this.stateManager.shutdown();
    await this.app.close();
    logger.info('Orchestrator stopped');
  }
}

// Start if run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const orchestrator = new StellarOrchestrator();
  orchestrator.start();

  process.on('SIGTERM', () => orchestrator.stop());
  process.on('SIGINT', () => orchestrator.stop());
}
