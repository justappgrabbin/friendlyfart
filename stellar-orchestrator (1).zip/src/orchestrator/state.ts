/**
 * Session State Manager
 * Redis-backed session persistence with checkpointing
 */

import Redis from 'ioredis';
import { Session, AgentMessage, Task, UserProfile } from '../types/index.js';
import { CONFIG } from '../config/index.js';
import { logger } from '../utils/logger.js';

export class StateManager {
  private redis: Redis;
  private localCache: Map<string, Session> = new Map();
  private readonly SESSION_TTL = 86400; // 24 hours

  constructor() {
    this.redis = new Redis(CONFIG.REDIS_URL, {
      retryStrategy: (times) => Math.min(times * 50, 2000),
      maxRetriesPerRequest: 3,
    });

    this.redis.on('error', (err) => {
      logger.error({ error: err.message }, 'Redis error');
    });
  }

  /**
   * Create a new session
   */
  async createSession(userId: string, userProfile?: UserProfile): Promise<Session> {
    const session: Session = {
      id: crypto.randomUUID(),
      userId,
      createdAt: Date.now(),
      lastActivity: Date.now(),
      messages: [],
      context: {
        userProfile,
        activeTools: [],
        customVariables: {},
      },
      activeAgents: [],
      pendingTasks: [],
    };

    await this.saveSession(session);
    logger.info({ sessionId: session.id, userId }, 'Session created');

    return session;
  }

  /**
   * Load session by ID
   */
  async loadSession(sessionId: string): Promise<Session | null> {
    // Check local cache first
    const cached = this.localCache.get(sessionId);
    if (cached) return cached;

    // Load from Redis
    const data = await this.redis.get(`session:${sessionId}`);
    if (!data) return null;

    try {
      const session = JSON.parse(data) as Session;
      this.localCache.set(sessionId, session);
      return session;
    } catch (error) {
      logger.error({ sessionId, error }, 'Failed to parse session');
      return null;
    }
  }

  /**
   * Save session to Redis + local cache
   */
  async saveSession(session: Session): Promise<void> {
    session.lastActivity = Date.now();

    const serialized = JSON.stringify(session);

    // Save to Redis with TTL
    await this.redis.setex(`session:${session.id}`, this.SESSION_TTL, serialized);

    // Update local cache
    this.localCache.set(session.id, session);

    // Also index by user
    await this.redis.sadd(`user:${session.userId}:sessions`, session.id);
  }

  /**
   * Add message to session
   */
  async addMessage(sessionId: string, message: AgentMessage): Promise<void> {
    const session = await this.loadSession(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);

    session.messages.push(message);

    // Trim if too large (keep last 100)
    if (session.messages.length > 100) {
      session.messages = session.messages.slice(-100);
    }

    await this.saveSession(session);
  }

  /**
   * Update session context
   */
  async updateContext(
    sessionId: string, 
    updates: Partial<Session['context']>
  ): Promise<void> {
    const session = await this.loadSession(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);

    session.context = { ...session.context, ...updates };
    await this.saveSession(session);
  }

  /**
   * Add task to session
   */
  async addTask(sessionId: string, task: Task): Promise<void> {
    const session = await this.loadSession(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);

    session.pendingTasks.push(task);
    await this.saveSession(session);
  }

  /**
   * Update task status
   */
  async updateTask(sessionId: string, taskId: string, status: Task['status'], result?: unknown): Promise<void> {
    const session = await this.loadSession(sessionId);
    if (!session) throw new Error(`Session ${sessionId} not found`);

    const task = session.pendingTasks.find(t => t.id === taskId);
    if (task) {
      task.status = status;
      if (result !== undefined) task.result = result;
    }

    await this.saveSession(session);
  }

  /**
   * Get active sessions for a user
   */
  async getUserSessions(userId: string): Promise<string[]> {
    return await this.redis.smembers(`user:${userId}:sessions`);
  }

  /**
   * Delete session
   */
  async deleteSession(sessionId: string): Promise<void> {
    const session = await this.loadSession(sessionId);
    if (session) {
      await this.redis.srem(`user:${session.userId}:sessions`, sessionId);
    }

    await this.redis.del(`session:${sessionId}`);
    this.localCache.delete(sessionId);

    logger.info({ sessionId }, 'Session deleted');
  }

  /**
   * Checkpoint: save current state for recovery
   */
  async checkpoint(sessionId: string, label: string): Promise<void> {
    const session = await this.loadSession(sessionId);
    if (!session) return;

    const checkpoint = {
      session,
      label,
      timestamp: Date.now(),
    };

    await this.redis.setex(
      `checkpoint:${sessionId}:${label}`,
      this.SESSION_TTL * 7, // 7 days
      JSON.stringify(checkpoint)
    );

    logger.info({ sessionId, label }, 'Checkpoint saved');
  }

  /**
   * Restore from checkpoint
   */
  async restoreCheckpoint(sessionId: string, label: string): Promise<Session | null> {
    const data = await this.redis.get(`checkpoint:${sessionId}:${label}`);
    if (!data) return null;

    try {
      const checkpoint = JSON.parse(data);
      const session = checkpoint.session as Session;
      await this.saveSession(session);

      logger.info({ sessionId, label }, 'Session restored from checkpoint');
      return session;
    } catch (error) {
      logger.error({ sessionId, label, error }, 'Failed to restore checkpoint');
      return null;
    }
  }

  /**
   * Get session summary for context compression
   */
  async getSessionSummary(sessionId: string): Promise<string> {
    const session = await this.loadSession(sessionId);
    if (!session) return '';

    const messageCount = session.messages.length;
    const agentInteractions = session.activeAgents;
    const pendingTasks = session.pendingTasks.filter(t => t.status === 'pending').length;

    return `Session ${sessionId}: ${messageCount} messages, agents: ${agentInteractions.join(', ')}, ${pendingTasks} pending tasks.`;
  }

  /**
   * Graceful shutdown
   */
  async shutdown(): Promise<void> {
    // Flush local cache to Redis
    for (const [sessionId, session] of this.localCache) {
      await this.saveSession(session);
    }

    await this.redis.quit();
    logger.info('State manager shut down');
  }
}
