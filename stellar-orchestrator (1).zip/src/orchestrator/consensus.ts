/**
 * Consensus Engine
 * Multi-model agreement synthesis with weighted voting
 */

import { 
  ConsensusResult, 
  ModelResponse, 
  AgentMessage 
} from '../types/index.js';
import { logger } from '../utils/logger.js';

interface ModelVote {
  modelId: string;
  answer: string;
  embedding: number[];
  qualityScore: number;
}

export class ConsensusEngine {
  /**
   * Build consensus from multiple model responses
   */
  async reachConsensus(responses: ModelResponse[]): Promise<ConsensusResult> {
    if (responses.length === 1) {
      return {
        finalAnswer: responses[0].content,
        contributors: [{ modelId: responses[0].modelId, weight: 1.0, answer: responses[0].content }],
        agreementScore: 1.0,
        dissentNotes: [],
        synthesisMethod: 'majority',
      };
    }

    // Filter out error responses
    const validResponses = responses.filter(r => r.finishReason !== 'error');
    if (validResponses.length === 0) {
      throw new Error('No valid responses for consensus');
    }

    // Score each response by quality heuristics
    const votes = validResponses.map(r => this.scoreResponse(r));

    // Calculate semantic similarity between responses (simplified: use length/content overlap)
    const similarities = this.calculateSimilarities(votes);

    // Weighted voting
    const weighted = votes.map((vote, i) => ({
      ...vote,
      weight: vote.qualityScore * similarities[i],
    }));

    // Find the best answer
    const best = weighted.reduce((best, current) => 
      current.weight > best.weight ? current : best
    );

    // Calculate agreement score
    const agreementScore = similarities.reduce((a, b) => a + b, 0) / similarities.length;

    // Identify dissent
    const dissentNotes = this.identifyDissent(weighted, best);

    // Synthesize final answer
    const finalAnswer = this.synthesizeAnswer(weighted, best);

    logger.info({ 
      contributors: weighted.length, 
      agreementScore, 
      bestModel: best.modelId 
    }, 'Consensus reached');

    return {
      finalAnswer,
      contributors: weighted.map(v => ({ modelId: v.modelId, weight: v.weight, answer: v.answer })),
      agreementScore,
      dissentNotes,
      synthesisMethod: 'weighted',
    };
  }

  /**
   * Score a response based on quality heuristics
   */
  private scoreResponse(response: ModelResponse): ModelVote {
    let qualityScore = 0.5;

    // Length heuristic: not too short, not too long
    const contentLength = response.content.length;
    if (contentLength > 50 && contentLength < 4000) qualityScore += 0.2;

    // Structure heuristic: has formatting
    if (response.content.includes('```') || response.content.includes('- ') || response.content.includes('1.')) {
      qualityScore += 0.1;
    }

    // Latency heuristic: faster is better (up to a point)
    if (response.latencyMs < 2000) qualityScore += 0.1;
    if (response.latencyMs > 10000) qualityScore -= 0.1;

    // Token efficiency
    const tokensPerChar = (response.usage.completion || 0) / Math.max(contentLength, 1);
    if (tokensPerChar > 0.2 && tokensPerChar < 0.5) qualityScore += 0.1;

    return {
      modelId: response.modelId,
      answer: response.content,
      embedding: [], // Would use actual embedding model
      qualityScore: Math.min(qualityScore, 1.0),
    };
  }

  /**
   * Calculate pairwise similarities (simplified Jaccard on words)
   */
  private calculateSimilarities(votes: ModelVote[]): number[] {
    if (votes.length === 1) return [1.0];

    const similarities: number[] = [];

    for (let i = 0; i < votes.length; i++) {
      let totalSim = 0;
      for (let j = 0; j < votes.length; j++) {
        if (i !== j) {
          totalSim += this.textSimilarity(votes[i].answer, votes[j].answer);
        }
      }
      similarities.push(totalSim / (votes.length - 1));
    }

    return similarities;
  }

  private textSimilarity(a: string, b: string): number {
    const wordsA = new Set(a.toLowerCase().split(/\s+/));
    const wordsB = new Set(b.toLowerCase().split(/\s+/));
    const intersection = new Set([...wordsA].filter(x => wordsB.has(x)));
    const union = new Set([...wordsA, ...wordsB]);
    return intersection.size / union.size;
  }

  /**
   * Identify where models disagree significantly
   */
  private identifyDissent(votes: ModelVote[], best: ModelVote): string[] {
    const notes: string[] = [];

    for (const vote of votes) {
      if (vote.modelId === best.modelId) continue;

      const sim = this.textSimilarity(vote.answer, best.answer);
      if (sim < 0.3) {
        notes.push(`${vote.modelId} provides a significantly different perspective (similarity: ${sim.toFixed(2)})`);
      }
    }

    return notes;
  }

  /**
   * Synthesize final answer from weighted votes
   */
  private synthesizeAnswer(votes: ModelVote[], best: ModelVote): string {
    // If strong agreement, just use best answer
    const avgWeight = votes.reduce((sum, v) => sum + v.weight, 0) / votes.length;
    if (best.weight > avgWeight * 1.5) {
      return best.answer;
    }

    // Otherwise, combine perspectives
    let combined = best.answer;

    const alternativeViews = votes
      .filter(v => v.modelId !== best.modelId && v.weight > 0.3)
      .slice(0, 2);

    if (alternativeViews.length > 0) {
      combined += `

---
📊 **Consensus Note:** ${votes.length} models contributed. `;
      combined += `Primary perspective from ${best.modelId}. `;

      if (alternativeViews.length > 0) {
        combined += `Alternative considerations from ${alternativeViews.map(v => v.modelId).join(', ')}.`;
      }
    }

    return combined;
  }
}
