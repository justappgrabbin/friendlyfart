# 🌟 Stellar Orchestrator

Multi-model orchestration system with 7 HuggingFace models + 4 agent personas.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    STELLAR ORCHESTRATOR                       │
├─────────────────────────────────────────────────────────────┤
│  Ingest → Analyze → Route → Dispatch → Execute → Respond     │
├─────────────────────────────────────────────────────────────┤
│  Agents: Joseph | ChatGPT | Claude | User (You)              │
├─────────────────────────────────────────────────────────────┤
│  Models: 7 HF + OpenAI + Anthropic                           │
│  ├─ Llama 3.1 8B (general/chat/code)                        │
│  ├─ Mistral 7B (general/chat)                               │
│  ├─ Zephyr 7B (chat/aligned)                                │
│  ├─ SD 3.5 Large (image generation)                         │
│  ├─ MiniLM (embeddings)                                     │
│  ├─ DialoGPT (conversation)                                 │
│  └─ Whisper v3 (speech-to-text)                             │
├─────────────────────────────────────────────────────────────┤
│  MCP Server | Redis Sessions | Health Checks | Consensus     │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# Install
npm install

# Set env vars
cp .env.example .env
# Edit .env with your HF_TOKEN, OPENAI_API_KEY, ANTHROPIC_API_KEY

# Dev mode
npm run dev

# Production
npm run build
npm start
```

## API

### Chat
```bash
curl -X POST http://localhost:3000/chat   -H "Content-Type: application/json"   -d '{
    "message": "Build me a TypeScript MRNN engine",
    "userId": "user-123"
  }'
```

### Multi-Agent Collaboration
```bash
curl -X POST http://localhost:3000/collaborate   -H "Content-Type: application/json"   -d '{
    "sessionId": "...",
    "message": "Review this architecture",
    "agents": ["joseph", "claude"]
  }'
```

### WebSocket
```javascript
const ws = new WebSocket('ws://localhost:3000/ws');
ws.send(JSON.stringify({
  type: 'chat',
  sessionId: '...',
  message: 'Hello'
}));
```

## Agents

| Agent | Role | Models | Specialization |
|-------|------|--------|----------------|
| **Joseph** | Systems Architect | Llama 3.1, Mistral 7B | Code, MRNN, Graph architectures |
| **ChatGPT** | Generalist | GPT-4o, GPT-4o-mini | Creative, explanation, brainstorming |
| **Claude** | Deep Analyst | Claude 3.7 Sonnet | Security review, long-context, arbitration |
| **User** | Personal Ally | Zephyr 7B | HD, astrology, life-purpose alignment |

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `HF_TOKEN` | Yes | HuggingFace API token |
| `OPENAI_API_KEY` | No | OpenAI API key |
| `ANTHROPIC_API_KEY` | No | Anthropic API key |
| `REDIS_URL` | No | Redis connection string |
| `PORT` | No | Server port (default: 3000) |

## License

MIT
