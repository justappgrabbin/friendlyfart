import { describe, it, expect, beforeAll } from 'vitest';
import { StellarOrchestrator } from '../src/orchestrator/index.js';
import { StateManager } from '../src/orchestrator/state.js';

describe('Integration', () => {
  let orchestrator: StellarOrchestrator;

  beforeAll(async () => {
    orchestrator = new StellarOrchestrator();
    // Don't start server, just test internals
  });

  it('orchestrator initializes with all agents', () => {
    // Access private field for testing
    const agents = (orchestrator as any).agents;
    expect(agents.joseph).toBeDefined();
    expect(agents.chatgpt).toBeDefined();
    expect(agents.claude).toBeDefined();
    expect(agents.user).toBeDefined();
  });

  it('state manager creates sessions', async () => {
    const state = new StateManager();
    const session = await state.createSession('test-user');
    expect(session.id).toBeDefined();
    expect(session.userId).toBe('test-user');
    await state.shutdown();
  });
});
