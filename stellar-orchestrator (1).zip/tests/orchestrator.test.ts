import { describe, it, expect } from 'vitest';
import { IntentRouter } from '../src/orchestrator/router.js';
import { ModelRegistry } from '../src/models/model-registry.js';

describe('Intent Router', () => {
  const router = new IntentRouter();

  it('classifies code intent', () => {
    const result = router.classify('Write a TypeScript function');
    expect(result.primary).toBe('code');
    expect(result.confidence).toBeGreaterThan(0);
  });

  it('classifies human design intent', () => {
    const result = router.classify('What is my gate 10 meaning');
    expect(result.primary).toBe('human_design');
  });

  it('selects correct agent', () => {
    const intent = router.classify('Build a neural network');
    const agent = router.selectAgent(intent);
    expect(agent).toBe('joseph');
  });
});

describe('Model Registry', () => {
  const registry = new ModelRegistry();

  it('has 7 models', () => {
    expect(registry.getAllModels().length).toBe(7);
  });

  it('finds models by capability', () => {
    const chatModels = registry.findByCapability('chat');
    expect(chatModels.length).toBeGreaterThan(0);
  });
});
