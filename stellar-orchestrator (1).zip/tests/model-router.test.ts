import { describe, it, expect } from 'vitest';
import { ModelRouter } from '../src/models/model-router.js';
import { IntentClassification } from '../src/types/index.js';

describe('Model Router', () => {
  const router = new ModelRouter();

  it('routes code intent to Joseph', async () => {
    const intent: IntentClassification = {
      primary: 'code',
      secondary: [],
      confidence: 0.9,
      entities: {},
      urgency: 'normal',
    };

    const agentProfile = {
      id: 'joseph' as const,
      name: 'Joseph',
      role: 'Architect',
      expertise: [],
      modelPreference: 'meta-llama/Llama-3.1-8B-Instruct',
      fallbackModels: [],
      temperature: 0.3,
      maxTokens: 4096,
      systemPrompt: 'test',
      tools: [],
      memoryEnabled: true,
      voiceEnabled: false,
    };

    const decision = await router.route(intent, agentProfile, []);
    expect(decision.targetAgent).toBe('joseph');
    expect(decision.targetModels.length).toBeGreaterThan(0);
  });
});
