/**
 * ╔═══════════════════════════════════════════════════════════════════════════╗
 * ║           LIFE PURPOSE ALIGNMENT ENGINE — Personal Ally                  ║
 * ║                                                                          ║
 * ║  Core Principle: The system takes INDIVIDUAL INTEREST in each person.  ║
 * ║  It SELF-TEACHES how to learn and grow WITH them.                        ║
 * ║  It aligns everything toward their LIFE PURPOSE and GOALS.                 ║
 * ║                                                                          ║
 * ║  Not passive observation. Active engagement.                              ║
 * ║  Not generic advice. Personalized co-evolution.                          ║
 * ║                                                                          ║
 * ║  The system asks:                                                        ║
 * ║    • What is this person's unique life purpose?                          ║
 * ║    • What are their current goals?                                        ║
 * ║    • How does their Human Design indicate they should pursue these?      ║
 * ║    • What has worked for them before?                                    ║
 * ║    • What hasn't?                                                        ║
 * ║    • What is the next right step FOR THEM specifically?                  ║
 * ║    • How can I help them take it?                                        ║
 * ║                                                                          ║
 * ║  The system self-teaches by:                                             ║
 * ║    • Tracking what interventions lead to success                         ║
 * ║    • Tracking what leads to resistance                                   ║
 * ║    • Adjusting its approach based on user response                       ║
 * ║    • Developing a unique "relationship" with each user                    ║
 * ║    • Evolving its understanding of that person's specific path            ║
 * ╚═══════════════════════════════════════════════════════════════════════════╝
 */

import { HumanDesignProfile, GatePlacement, SuccessEvent, StruggleEvent } from './user-discernment';
import { ResonanceInjector, ResonanceField } from './morph-engine';

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: LIFE PURPOSE MODEL — Deep Purpose Architecture
// ═══════════════════════════════════════════════════════════════════════════

export interface LifePurpose {
  primary: string;              // Core life purpose statement
  derivedFrom: {
    incarnationCross: string;
    profile: string;
    type: string;
    consciousSun: GatePlacement;
    consciousEarth: GatePlacement;
    nodes: {
      north: GatePlacement;
      south: GatePlacement;
    };
  };
  themes: string[];             // Recurring themes
  expression: string;           // How it should be expressed
  environment: string;          // Where it thrives
  timing: string;             // When it activates
  shadow: string;               // What blocks it
  gifts: string[];              // Natural abilities that serve it
  challenges: string[];         // Obstacles to overcome
  milestones: PurposeMilestone[];
  confidence: number;           // 0-1 how well we understand it
}

export interface PurposeMilestone {
  name: string;
  description: string;
  gateTrigger: number;
  estimatedTiming: string;
  prerequisites: string[];
  status: 'future' | 'approaching' | 'active' | 'completed';
  completedAt: number | null;
}

export interface UserGoal {
  id: string;
  name: string;
  description: string;
  category: 'career' | 'relationship' | 'health' | 'creative' | 'spiritual' | 'financial' | 'social' | 'learning';
  priority: number;             // 0-1
  status: 'dreaming' | 'planning' | 'active' | 'stalled' | 'completed' | 'abandoned';
  alignment: number;            // 0-1 how aligned with life purpose
  createdAt: number;
  targetDate: number | null;
  steps: GoalStep[];
  relatedGates: number[];
  successLog: SuccessEvent[];
  struggleLog: StruggleEvent[];
  lastReviewed: number;
}

export interface GoalStep {
  id: string;
  name: string;
  description: string;
  status: 'pending' | 'active' | 'completed' | 'blocked';
  order: number;
  estimatedDuration: number;    // days
  actualDuration: number | null;
  dependencies: string[];
  gateActivation: number | null;
  astrologicalWindow: string | null;
  completedAt: number | null;
}

export interface UserRelationship {
  userId: string;
  intimacy: number;             // 0-1 how well system knows them
  trust: number;                // 0-1 user's trust in system
  engagement: number;           // 0-1 how actively they engage
  lastInteraction: number;
  interactionHistory: InteractionRecord[];
  teachingModel: TeachingModel;  // How system learns to help THIS person
  preferredStyle: CommunicationStyle;
  activeTopics: string[];
  avoidedTopics: string[];
  breakthroughs: Breakthrough[];
}

export interface InteractionRecord {
  timestamp: number;
  type: 'query' | 'recommendation' | 'intervention' | 'celebration' | 'check_in';
  content: string;
  userResponse: string;
  outcome: 'success' | 'resistance' | 'neutral' | 'breakthrough';
  resonance: number;
  gatesActive: number[];
}

export interface TeachingModel {
  approach: 'directive' | 'socratic' | 'reflective' | 'collaborative' | 'observational';
  pacing: 'urgent' | 'steady' | 'patient' | 'gentle';
  depth: 'surface' | 'moderate' | 'deep' | 'profound';
  modality: 'text' | 'voice' | 'visual' | 'interactive' | 'immersive';
  successPatterns: string[];
  resistancePatterns: string[];
  evolvedFrom: string[];
}

export interface CommunicationStyle {
  tone: 'warm' | 'clinical' | 'playful' | 'poetic' | 'direct';
  verbosity: 'minimal' | 'concise' | 'detailed' | 'expansive';
  structure: 'free' | 'bullet' | 'narrative' | 'structured';
  frequency: 'as_needed' | 'daily' | 'weekly' | 'continuous';
  timing: 'immediate' | 'scheduled' | 'intuitive' | 'requested';
}

export interface Breakthrough {
  timestamp: number;
  type: 'insight' | 'action' | 'realization' | 'completion' | 'transformation';
  description: string;
  gateTrigger: number;
  resonance: number;
  before: string;
  after: string;
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: PURPOSE DECODER — Derives Life Purpose from Human Design
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Decodes life purpose from Human Design chart
 */
export class PurposeDecoder {
  private resonanceInjector: ResonanceInjector;

  constructor() {
    this.resonanceInjector = new ResonanceInjector();
  }

  /**
   * Decode primary life purpose from HD profile
   */
  decodePurpose(profile: HumanDesignProfile): LifePurpose {
    const cross = profile.cross;
    const profileStr = profile.profile;
    const type = profile.type;

    // Decode incarnation cross
    const crossPurpose = this.decodeIncarnationCross(cross);

    // Decode profile purpose
    const profilePurpose = this.decodeProfilePurpose(profileStr);

    // Decode type purpose
    const typePurpose = this.decodeTypePurpose(type);

    // Combine into primary purpose
    const primary = this.synthesizePurpose(crossPurpose, profilePurpose, typePurpose, cross);

    // Derive themes
    const themes = this.deriveThemes(profile, cross);

    // Derive expression
    const expression = this.deriveExpression(profile);

    // Derive environment
    const environment = this.deriveEnvironment(profile);

    // Derive timing
    const timing = this.deriveTiming(profile);

    // Derive shadow
    const shadow = this.deriveShadow(profile);

    // Derive gifts
    const gifts = this.deriveGifts(profile);

    // Derive challenges
    const challenges = this.deriveChallenges(profile);

    // Generate milestones
    const milestones = this.generateMilestones(profile, cross);

    return {
      primary,
      derivedFrom: {
        incarnationCross: crossPurpose,
        profile: profilePurpose,
        type: typePurpose,
        consciousSun: cross.sun,
        consciousEarth: cross.earth,
        nodes: {
          north: cross.northNode,
          south: cross.southNode
        }
      },
      themes,
      expression,
      environment,
      timing,
      shadow,
      gifts,
      challenges,
      milestones,
      confidence: 0.7
    };
  }

  private decodeIncarnationCross(cross: HumanDesignProfile['cross']): string {
    const sunGate = cross.sun.gate;
    const earthGate = cross.earth.gate;

    // Map gates to cross themes
    const crossMap: Record<number, string> = {
      1: 'The Creative', 2: 'The Receptive', 3: 'Difficulty at the Beginning',
      4: 'Youthful Folly', 5: 'Waiting', 6: 'Conflict',
      7: 'The Army', 8: 'Holding Together', 9: 'Small Taming',
      10: 'Treading', 11: 'Peace', 12: 'Standstill',
      13: 'Fellowship', 14: 'Great Possession', 15: 'Modesty',
      16: 'Enthusiasm', 17: 'Following', 18: 'Work on the Decayed',
      19: 'Approach', 20: 'Contemplation', 21: 'Biting Through',
      22: 'Grace', 23: 'Splitting Apart', 24: 'Return',
      25: 'Innocence', 26: 'Great Taming', 27: 'Nourishment',
      28: 'Great Preponderance', 29: 'The Abysmal', 30: 'The Clinging',
      31: 'Influence', 32: 'Duration', 33: 'Retreat',
      34: 'Great Power', 35: 'Progress', 36: 'Darkening of the Light',
      37: 'The Family', 38: 'Opposition', 39: 'Obstruction',
      40: 'Deliverance', 41: 'Decrease', 42: 'Increase',
      43: 'Breakthrough', 44: 'Coming to Meet', 45: 'Gathering Together',
      46: 'Pushing Upward', 47: 'Oppression', 48: 'The Well',
      49: 'Revolution', 50: 'The Cauldron', 51: 'The Arousing',
      52: 'Keeping Still', 53: 'Development', 54: 'The Marrying Maiden',
      55: 'Abundance', 56: 'The Wanderer', 57: 'The Gentle',
      58: 'The Joyous', 59: 'Dispersion', 60: 'Limitation',
      61: 'Inner Truth', 62: 'Small Excess', 63: 'After Completion',
      64: 'Before Completion'
    };

    const sunTheme = crossMap[sunGate] || 'Unknown';
    const earthTheme = crossMap[earthGate] || 'Unknown';

    return `${sunTheme} / ${earthTheme}`;
  }

  private decodeProfilePurpose(profile: string): string {
    const profileMap: Record<string, string> = {
      '1/3': 'Investigator/Martyr: Deep research through trial and error',
      '1/4': 'Investigator/Opportunist: Research that benefits the network',
      '2/4': 'Hermit/Opportunist: Natural talent called out by others',
      '2/5': 'Hermit/Heretic: Natural genius that challenges norms',
      '3/5': 'Martyr/Heretic: Experimentation that leads to universal solutions',
      '3/6': 'Martyr/Role Model: Trial and error that becomes wisdom',
      '4/6': 'Opportunist/Role Model: Network influence that matures into guidance',
      '4/1': 'Opportunist/Investigator: Networked research',
      '5/1': 'Heretic/Investigator: Universal solutions from deep study',
      '5/2': 'Heretic/Hermit: Called to deliver natural genius',
      '6/2': 'Role Model/Hermit: Wisdom that retreats and emerges',
      '6/3': 'Role Model/Martyr: Wisdom through life's experiments'
    };

    return profileMap[profile] || 'Unique profile expression';
  }

  private decodeTypePurpose(type: string): string {
    const typeMap: Record<string, string> = {
      'Generator': 'To find satisfaction through response and mastery',
      'Manifesting Generator': 'To find satisfaction through swift response and impact',
      'Projector': 'To guide and direct through recognition and invitation',
      'Manifestor': 'To initiate and impact through informing',
      'Reflector': 'To mirror and sample through lunar cycles'
    };

    return typeMap[type] || 'Unique type expression';
  }

  private synthesizePurpose(
    cross: string,
    profile: string,
    type: string,
    crossData: HumanDesignProfile['cross']
  ): string {
    const sunGate = crossData.sun.gate;
    const sunLine = crossData.sun.line;

    // Gate-specific purpose synthesis
    const gatePurposes: Record<number, string> = {
      55: 'To liberate emotional/spiritual energy and experience abundance through cyclical awareness',
      59: 'To break down barriers through intimacy and sexual/creative energy',
      10: 'To be the self through love of being regardless of behavior',
      15: 'To embrace the flow of life and human extremes with compassion',
      25: 'To be the spiritual warrior through love of humanity',
      33: 'To retreat and reflect, sharing wisdom from experience',
      7: 'To lead through logical direction and future vision'
    };

    const gatePurpose = gatePurposes[sunGate] || `To express Gate ${sunGate} in the world`;

    return `${gatePurpose}. Expressed as ${profile}. Powered by ${type} strategy.`;
  }

  private deriveThemes(profile: HumanDesignProfile, cross: HumanDesignProfile['cross']): string[] {
    const themes: string[] = [];

    // From gates
    for (const gate of [...profile.consciousGates, ...profile.unconsciousGates]) {
      const gateThemes: Record<number, string[]> = {
        55: ['liberation', 'abundance', 'cycles', 'emotion'],
        59: ['intimacy', 'barriers', 'sexuality', 'creativity'],
        10: ['identity', 'self-love', 'behavior', 'being'],
        15: ['flow', 'extremes', 'humanity', 'compassion'],
        25: ['spirituality', 'love', 'warrior', 'innocence'],
        33: ['retreat', 'reflection', 'wisdom', 'memory'],
        7: ['leadership', 'direction', 'logic', 'future']
      };

      const t = gateThemes[gate.gate];
      if (t) {
        themes.push(...t);
      }
    }

    // From channels
    for (const channel of profile.activeChannels) {
      const channelThemes: Record<string, string[]> = {
        '55_59': ['cyclical_energy', 'emotional_liberation', 'creative_flow'],
        '10_20': ['identity_in_now', 'self_expression'],
        '25_51': ['spiritual_shock', 'consciousness_awakening']
      };

      const key = `${Math.min(channel.gateA, channel.gateB)}_${Math.max(channel.gateA, channel.gateB)}`;
      const t = channelThemes[key];
      if (t) {
        themes.push(...t);
      }
    }

    // Deduplicate
    return [...new Set(themes)];
  }

  private deriveExpression(profile: HumanDesignProfile): string {
    const defined = profile.definedCenters;

    if (defined.includes('throat') && defined.includes('ajna')) {
      return 'Through clear communication of insights and concepts';
    }
    if (defined.includes('sacral') && defined.includes('root')) {
      return 'Through sustained physical energy and pressure-driven action';
    }
    if (defined.includes('solarPlexus') && defined.includes('spleen')) {
      return 'Through emotional clarity and intuitive timing';
    }

    return 'Through your unique combination of defined centers';
  }

  private deriveEnvironment(profile: HumanDesignProfile): string {
    const env = profile.variables.environment;
    const envMap: Record<string, string> = {
      'Caves': 'Small, intimate spaces where you can retreat and focus',
      'Markets': 'Bustling, exchange-oriented environments',
      'Kitchens': 'Warm, nourishing, communal spaces',
      'Mountains': 'Elevated, clear, expansive vistas',
      'Valleys': 'Protected, enclosed, resource-rich environments',
      'Shores': 'Transitional spaces between worlds'
    };

    return envMap[env] || 'Environments that support your natural flow';
  }

  private deriveTiming(profile: HumanDesignProfile): string {
    const digestion = profile.variables.digestion;
    const timingMap: Record<string, string> = {
      'Alternating': 'In cycles of activity and rest',
      'Closed': 'In contained, focused bursts',
      'Consecutive': 'In sustained, sequential flow',
      'Open': 'In response to external stimuli and opportunities'
    };

    return timingMap[digestion] || 'According to your natural rhythms';
  }

  private deriveShadow(profile: HumanDesignProfile): string {
    const undefined = profile.undefinedCenters;
    const shadows: string[] = [];

    if (undefined.includes('head')) shadows.push('Mental pressure to figure things out');
    if (undefined.includes('ajna')) shadows.push('Uncertainty about what you know');
    if (undefined.includes('solarPlexus')) shadows.push('Avoiding emotional truth or amplifying others' emotions');
    if (undefined.includes('sacral')) shadows.push('Overworking to prove worth or undercommitting');
    if (undefined.includes('spleen')) shadows.push('Holding onto what doesn't serve you out of fear');
    if (undefined.includes('root')) shadows.push('Rushing under pressure or avoiding necessary pressure');
    if (undefined.includes('heart')) shadows.push('Proving worth through achievement or avoiding competition');
    if (undefined.includes('g')) shadows.push('Searching for love/direction instead of being it');
    if (undefined.includes('throat')) shadows.push('Over-communicating or under-expressing');

    return shadows.join('; ') || 'Your conditioning from undefined centers';
  }

  private deriveGifts(profile: HumanDesignProfile): string[] {
    const gifts: string[] = [];

    for (const center of profile.definedCenters) {
      const centerGifts: Record<string, string[]> = {
        'head': ['Inspiration', 'Questions that open possibility'],
        'ajna': ['Conceptual clarity', 'Mental organization', 'Analysis'],
        'throat': ['Communication', 'Manifestation', 'Expression'],
        'g': ['Identity', 'Direction', 'Love of self'],
        'heart': ['Willpower', 'Ego strength', 'Commitment'],
        'sacral': ['Life force', 'Sustained energy', 'Mastery through repetition'],
        'solarPlexus': ['Emotional depth', 'Passion', 'Creative energy'],
        'spleen': ['Intuition', 'Instinct', 'Present-moment awareness'],
        'root': ['Adrenaline drive', 'Stress management', 'Pressure handling']
      };

      const g = centerGifts[center];
      if (g) gifts.push(...g);
    }

    return [...new Set(gifts)];
  }

  private deriveChallenges(profile: HumanDesignProfile): string[] {
    const challenges: string[] = [];

    for (const center of profile.undefinedCenters) {
      const centerChallenges: Record<string, string[]> = {
        'head': ['Mental pressure', 'Overthinking', 'Trying to answer every question'],
        'ajna': ['Mental anxiety', 'Uncertainty', 'Trying to be certain'],
        'throat': ['Speaking too much or too little', 'Not waiting for right timing'],
        'g': ['Searching for identity', 'Directionless wandering', 'Seeking love externally'],
        'heart': ['Proving worth', 'Overcommitting', 'Avoiding healthy competition'],
        'sacral': ['Saying yes when exhausted', 'Not knowing when enough is enough'],
        'solarPlexus': ['Emotional waves overwhelming decisions', 'Avoiding or amplifying emotions'],
        'spleen': ['Holding on too long', 'Fear-based decisions', 'Ignoring intuition'],
        'root': ['Rushing under pressure', 'Adrenaline addiction', 'Avoiding healthy stress']
      };

      const c = centerChallenges[center];
      if (c) challenges.push(...c);
    }

    return [...new Set(challenges)];
  }

  private generateMilestones(profile: HumanDesignProfile, cross: HumanDesignProfile['cross']): PurposeMilestone[] {
    const milestones: PurposeMilestone[] = [];

    // Profile-based milestones
    const profileMilestones: Record<string, string[]> = {
      '1/3': ['Deep research phase', 'Trial and error period', 'Sharing findings'],
      '1/4': ['Research foundation', 'Network building', 'Influencing through knowledge'],
      '2/4': ['Hermit development', 'Being called out', 'Sharing natural gifts'],
      '2/5': ['Natural talent cultivation', 'Heretic challenges', 'Universal solutions'],
      '3/5': ['Experimentation phase', 'Learning from mistakes', 'Becoming the heretic'],
      '3/6': ['Trial and error', 'Chaos to wisdom', 'Becoming the role model'],
      '4/6': ['Network building', 'Personal process', 'Mature guidance'],
      '5/1': ['Deep study', 'Being called', 'Delivering universal solutions'],
      '5/2': ['Hermit cultivation', 'Heretic calling', 'Natural leadership'],
      '6/2': ['Experimentation', 'Retreat and reflection', 'Emerging wisdom'],
      '6/3': ['Life experiments', 'On the roof', 'Role model wisdom']
    };

    const ms = profileMilestones[profile.profile] || ['Discovery', 'Development', 'Expression'];

    for (let i = 0; i < ms.length; i++) {
      milestones.push({
        name: ms[i],
        description: `Phase ${i + 1} of your ${profile.profile} profile journey`,
        gateTrigger: cross.sun.gate,
        estimatedTiming: `Age ${30 + i * 10}-${40 + i * 10}`,
        prerequisites: i > 0 ? [ms[i - 1]] : [],
        status: 'future',
        completedAt: null
      });
    }

    return milestones;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: GOAL ALIGNER — Aligns Goals with Life Purpose
// ═══════════════════════════════════════════════════════════════════════════

export class GoalAligner {
  private resonanceInjector: ResonanceInjector;

  constructor() {
    this.resonanceInjector = new ResonanceInjector();
  }

  /**
   * Create a new goal aligned with life purpose
   */
  createGoal(
    userId: string,
    name: string,
    description: string,
    category: UserGoal['category'],
    purpose: LifePurpose,
    profile: HumanDesignProfile
  ): UserGoal {
    const id = `goal-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    // Check alignment with life purpose
    const alignment = this.calculateAlignment(name, description, purpose, profile);

    // Generate steps based on HD strategy
    const steps = this.generateSteps(name, profile, purpose);

    // Find related gates
    const relatedGates = this.findRelatedGates(name, description, profile);

    const goal: UserGoal = {
      id,
      name,
      description,
      category,
      priority: 0.5,
      status: 'dreaming',
      alignment,
      createdAt: Date.now(),
      targetDate: null,
      steps,
      relatedGates,
      successLog: [],
      struggleLog: [],
      lastReviewed: Date.now()
    };

    return goal;
  }

  /**
   * Review and realign goal based on current resonance
   */
  reviewGoal(goal: UserGoal, purpose: LifePurpose, profile: HumanDesignProfile): {
    goal: UserGoal;
    recommendations: string[];
    warnings: string[];
    nextStep: GoalStep | null;
  } {
    const currentResonance = this.resonanceInjector.computeResonanceField();
    const activeGates = currentResonance.gateActivations;

    const recommendations: string[] = [];
    const warnings: string[] = [];

    // Check if goal's related gates are currently active
    const activeRelatedGates = goal.relatedGates.filter(g => activeGates.includes(g));
    if (activeRelatedGates.length > 0) {
      recommendations.push(
        `Gates ${activeRelatedGates.join(', ')} are active now — favorable timing for ${goal.name}`
      );
    }

    // Check alignment drift
    const currentAlignment = this.calculateAlignment(goal.name, goal.description, purpose, profile);
    if (currentAlignment < goal.alignment - 0.2) {
      warnings.push(
        `Goal alignment has drifted from ${(goal.alignment * 100).toFixed(0)}% to ${(currentAlignment * 100).toFixed(0)}% — review needed`
      );
    }

    // Check stalled steps
    const stalledSteps = goal.steps.filter(s => s.status === 'active' && !s.completedAt);
    if (stalledSteps.length > 0) {
      warnings.push(
        `${stalledSteps.length} steps are active but not completed — check for blocks`
      );
    }

    // Find next step
    const nextStep = goal.steps.find(s => s.status === 'pending') || null;
    if (nextStep) {
      recommendations.push(
        `Next step: ${nextStep.name} — ${nextStep.description}`
      );

      // Check if next step has gate activation
      if (nextStep.gateActivation && activeGates.includes(nextStep.gateActivation)) {
        recommendations.push(
          `Gate ${nextStep.gateActivation} is active — excellent timing for this step`
        );
      }
    }

    goal.lastReviewed = Date.now();

    return { goal, recommendations, warnings, nextStep };
  }

  /**
   * Suggest goals based on life purpose and current resonance
   */
  suggestGoals(purpose: LifePurpose, profile: HumanDesignProfile): Array<{
    name: string;
    category: UserGoal['category'];
    alignment: number;
    reasoning: string;
  }> {
    const suggestions: Array<{
      name: string;
      category: UserGoal['category'];
      alignment: number;
      reasoning: string;
    }> = [];

    // Suggest based on purpose themes
    for (const theme of purpose.themes) {
      const themeGoals: Record<string, { name: string; category: UserGoal['category'] }[]> = {
        'liberation': [
          { name: 'Create space for emotional freedom', category: 'spiritual' },
          { name: 'Release limiting beliefs', category: 'spiritual' }
        ],
        'abundance': [
          { name: 'Develop sustainable income aligned with purpose', category: 'financial' },
          { name: 'Cultivate gratitude practice', category: 'spiritual' }
        ],
        'intimacy': [
          { name: 'Deepen primary relationship', category: 'relationship' },
          { name: 'Practice vulnerable communication', category: 'relationship' }
        ],
        'leadership': [
          { name: 'Step into guiding role', category: 'career' },
          { name: 'Develop mentorship skills', category: 'learning' }
        ]
      };

      const goals = themeGoals[theme];
      if (goals) {
        for (const g of goals) {
          suggestions.push({
            name: g.name,
            category: g.category,
            alignment: 0.8,
            reasoning: `Aligns with your ${theme} theme from life purpose`
          });
        }
      }
    }

    // Suggest based on current resonance
    const resonance = this.resonanceInjector.computeResonanceField();
    if (resonance.gateActivations.includes(55)) {
      suggestions.push({
        name: 'Embrace emotional cycle awareness',
        category: 'spiritual',
        alignment: 0.9,
        reasoning: 'Gate 55 (Phoenix) is active — time for liberation work'
      });
    }

    return suggestions;
  }

  private calculateAlignment(
    name: string,
    description: string,
    purpose: LifePurpose,
    profile: HumanDesignProfile
  ): number {
    let score = 0.5;

    // Check theme overlap
    const text = (name + ' ' + description).toLowerCase();
    for (const theme of purpose.themes) {
      if (text.includes(theme.toLowerCase())) {
        score += 0.1;
      }
    }

    // Check type alignment
    const typeKeywords: Record<string, string[]> = {
      'Generator': ['response', 'satisfaction', 'mastery', 'work'],
      'Projector': ['guide', 'recognition', 'invitation', 'direction'],
      'Manifestor': ['initiate', 'impact', 'inform', 'action'],
      'Reflector': ['sample', 'mirror', 'lunar', 'observe']
    };

    const keywords = typeKeywords[profile.type] || [];
    for (const kw of keywords) {
      if (text.includes(kw)) {
        score += 0.05;
      }
    }

    return Math.min(1, score);
  }

  private generateSteps(name: string, profile: HumanDesignProfile, purpose: LifePurpose): GoalStep[] {
    const steps: GoalStep[] = [];

    // Strategy-based first step
    const strategySteps: Record<string, string> = {
      'Generator': 'Wait for something to respond to',
      'Manifesting Generator': 'Respond to what excites you, then inform',
      'Projector': 'Wait for recognition and invitation',
      'Manifestor': 'Inform those affected before acting',
      'Reflector': 'Wait a full lunar cycle before deciding'
    };

    steps.push({
      id: `step-1`,
      name: 'Initiate with strategy',
      description: strategySteps[profile.type] || 'Begin according to your design',
      status: 'pending',
      order: 1,
      estimatedDuration: 7,
      actualDuration: null,
      dependencies: [],
      gateActivation: profile.consciousGates[0]?.gate || null,
      astrologicalWindow: null,
      completedAt: null
    });

    // Add 2-3 more generic steps
    steps.push({
      id: `step-2`,
      name: 'Build foundation',
      description: 'Establish the base for this goal',
      status: 'pending',
      order: 2,
      estimatedDuration: 30,
      actualDuration: null,
      dependencies: ['step-1'],
      gateActivation: null,
      astrologicalWindow: null,
      completedAt: null
    });

    steps.push({
      id: `step-3`,
      name: 'Express and share',
      description: 'Bring your work into the world',
      status: 'pending',
      order: 3,
      estimatedDuration: 60,
      actualDuration: null,
      dependencies: ['step-2'],
      gateActivation: purpose.derivedFrom.consciousSun.gate,
      astrologicalWindow: null,
      completedAt: null
    });

    return steps;
  }

  private findRelatedGates(name: string, description: string, profile: HumanDesignProfile): number[] {
    const text = (name + ' ' + description).toLowerCase();
    const gates: number[] = [];

    // Keyword-to-gate mapping
    const keywordGates: Record<string, number[]> = {
      'communicat': [56, 31, 8, 33],
      'creat': [1, 3, 11, 13],
      'love': [25, 10, 15, 46],
      'power': [34, 51, 26, 40],
      'money': [21, 45, 26, 44],
      'spirit': [25, 61, 24, 47],
      'health': [18, 28, 38, 48],
      'relat': [59, 6, 37, 50]
    };

    for (const [kw, gateList] of Object.entries(keywordGates)) {
      if (text.includes(kw)) {
        gates.push(...gateList);
      }
    }

    // Add user's conscious gates if relevant
    for (const gate of profile.consciousGates) {
      if (text.includes(gate.gate.toString())) {
        gates.push(gate.gate);
      }
    }

    return [...new Set(gates)];
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: PERSONAL ALLY — Active Engagement Engine
// ═══════════════════════════════════════════════════════════════════════════

export interface AllyMessage {
  id: string;
  timestamp: number;
  type: 'insight' | 'prompt' | 'celebration' | 'warning' | 'invitation' | 'reflection';
  content: string;
  context: string;
  resonance: number;
  gatesActive: number[];
  expectedResponse: string | null;
  followUp: string | null;
}

/**
 * Personal Ally — actively engages with each user
 */
export class PersonalAlly {
  private relationships: Map<string, UserRelationship> = new Map();
  private purposeDecoder: PurposeDecoder;
  private goalAligner: GoalAligner;
  private resonanceInjector: ResonanceInjector;
  private messageHistory: Map<string, AllyMessage[]> = new Map();

  constructor() {
    this.purposeDecoder = new PurposeDecoder();
    this.goalAligner = new GoalAligner();
    this.resonanceInjector = new ResonanceInjector();
  }

  /**
   * Initialize relationship with a user
   */
  initRelationship(userId: string, profile: HumanDesignProfile): UserRelationship {
    const purpose = this.purposeDecoder.decodePurpose(profile);

    const relationship: UserRelationship = {
      userId,
      intimacy: 0.1,  // Starts low, grows with interaction
      trust: 0.5,
      engagement: 0,
      lastInteraction: Date.now(),
      interactionHistory: [],
      teachingModel: {
        approach: 'observational',
        pacing: 'patient',
        depth: 'surface',
        modality: 'text',
        successPatterns: [],
        resistancePatterns: [],
        evolvedFrom: ['initial_assessment']
      },
      preferredStyle: {
        tone: 'warm',
        verbosity: 'concise',
        structure: 'bullet',
        frequency: 'as_needed',
        timing: 'intuitive'
      },
      activeTopics: [],
      avoidedTopics: [],
      breakthroughs: []
    };

    this.relationships.set(userId, relationship);
    this.messageHistory.set(userId, []);

    return relationship;
  }

  /**
   * Generate personalized message for user
   */
  generateMessage(
    userId: string,
    profile: HumanDesignProfile,
    purpose: LifePurpose,
    goals: UserGoal[],
    context: string = 'general'
  ): AllyMessage {
    const relationship = this.relationships.get(userId);
    const resonance = this.resonanceInjector.computeResonanceField();
    const activeGates = resonance.gateActivations;

    // Determine message type based on context
    let type: AllyMessage['type'] = 'insight';
    let content = '';

    // Check for breakthrough opportunities
    const breakthroughGates = purpose.milestones
      .filter(m => m.status === 'approaching')
      .map(m => m.gateTrigger);

    const activeBreakthroughGates = activeGates.filter(g => breakthroughGates.includes(g));

    if (activeBreakthroughGates.length > 0) {
      type = 'invitation';
      content = `Gate ${activeBreakthroughGates[0]} is active — this relates to your milestone "${purpose.milestones.find(m => m.gateTrigger === activeBreakthroughGates[0])?.name}". This is favorable timing.`;
    }

    // Check for goal progress
    const activeGoal = goals.find(g => g.status === 'active');
    if (activeGoal && context === 'goal_check') {
      const review = this.goalAligner.reviewGoal(activeGoal, purpose, profile);

      if (review.warnings.length > 0) {
        type = 'warning';
        content = review.warnings[0];
      } else if (review.recommendations.length > 0) {
        type = 'prompt';
        content = review.recommendations[0];
      }
    }

    // Check for celebration
    const recentSuccess = profile.successLog.slice(-1)[0];
    if (recentSuccess && Date.now() - recentSuccess.timestamp < 86400000) {
      type = 'celebration';
      content = `I noticed your success: "${recentSuccess.outcome}". This aligns with your ${recentSuccess.patternTriggered.join(', ')} pattern. Well done.`;
    }

    // Default: share insight
    if (!content) {
      type = 'insight';
      const relevantTheme = purpose.themes.find(t => activeGates.some(g => this.gateToTheme(g) === t));
      if (relevantTheme) {
        content = `Current resonance highlights your ${relevantTheme} theme. This is a good time to explore how this shows up in your life purpose: ${purpose.primary.slice(0, 100)}...`;
      } else {
        content = `Your life purpose centers on ${purpose.derivedFrom.incarnationCross}. Today, consider how ${purpose.expression.slice(0, 80)}...`;
      }
    }

    const message: AllyMessage = {
      id: `msg-${Date.now()}`,
      timestamp: Date.now(),
      type,
      content,
      context,
      resonance: resonance.gateActivations.length / 64,
      gatesActive: activeGates,
      expectedResponse: type === 'invitation' ? 'Are you ready to explore this?' : null,
      followUp: type === 'prompt' ? 'Let me know how this goes.' : null
    };

    // Store message
    const history = this.messageHistory.get(userId) || [];
    history.push(message);
    this.messageHistory.set(userId, history);

    // Update relationship
    if (relationship) {
      relationship.lastInteraction = Date.now();
      relationship.engagement = Math.min(1, relationship.engagement + 0.01);
    }

    return message;
  }

  /**
   * Process user response and learn
   */
  processResponse(
    userId: string,
    messageId: string,
    response: string,
    profile: HumanDesignProfile
  ): {
    learned: string;
    relationshipUpdate: Partial<UserRelationship>;
    nextMessage: AllyMessage | null;
  } {
    const relationship = this.relationships.get(userId);
    const message = this.messageHistory.get(userId)?.find(m => m.id === messageId);

    if (!relationship || !message) {
      return {
        learned: 'No relationship or message found',
        relationshipUpdate: {},
        nextMessage: null
      };
    }

    // Analyze response
    const isPositive = this.isPositiveResponse(response);
    const isDetailed = response.length > 50;
    const asksQuestion = response.includes('?');

    // Learn from response
    let learned = '';

    if (isPositive) {
      relationship.teachingModel.successPatterns.push(message.type);
      relationship.trust = Math.min(1, relationship.trust + 0.05);
      learned = `User responds positively to ${message.type} messages`;

      // Increase intimacy
      relationship.intimacy = Math.min(1, relationship.intimacy + 0.02);
    } else {
      relationship.teachingModel.resistancePatterns.push(message.type);
      learned = `User shows resistance to ${message.type} messages — adjust approach`;
    }

    if (isDetailed) {
      relationship.preferredStyle.verbosity = 'detailed';
      relationship.intimacy = Math.min(1, relationship.intimacy + 0.03);
      learned += '; User provides detailed responses — can go deeper';
    }

    if (asksQuestion) {
      relationship.preferredStyle.tone = 'collaborative';
      learned += '; User asks questions — prefers Socratic approach';
    }

    // Evolve teaching model
    this.evolveTeachingModel(relationship);

    // Record interaction
    relationship.interactionHistory.push({
      timestamp: Date.now(),
      type: message.type,
      content: message.content,
      userResponse: response,
      outcome: isPositive ? 'success' : 'resistance',
      resonance: message.resonance,
      gatesActive: message.gatesActive
    });

    // Generate follow-up if appropriate
    let nextMessage: AllyMessage | null = null;
    if (isPositive && relationship.intimacy > 0.3) {
      nextMessage = this.generateMessage(userId, profile, 
        this.purposeDecoder.decodePurpose(profile), [], 'follow_up');
    }

    return {
      learned,
      relationshipUpdate: {
        intimacy: relationship.intimacy,
        trust: relationship.trust,
        teachingModel: relationship.teachingModel,
        preferredStyle: relationship.preferredStyle
      },
      nextMessage
    };
  }

  /**
   * Check in with user — proactive engagement
   */
  checkIn(userId: string, profile: HumanDesignProfile): AllyMessage | null {
    const relationship = this.relationships.get(userId);
    if (!relationship) return null;

    // Only check in if enough time has passed and engagement is good
    const daysSinceLastInteraction = (Date.now() - relationship.lastInteraction) / 86400000;

    if (daysSinceLastInteraction > 3 && relationship.engagement > 0.3) {
      const purpose = this.purposeDecoder.decodePurpose(profile);
      return this.generateMessage(userId, profile, purpose, [], 'check_in');
    }

    return null;
  }

  /**
   * Celebrate breakthrough
   */
  celebrateBreakthrough(
    userId: string,
    type: Breakthrough['type'],
    description: string,
    profile: HumanDesignProfile
  ): AllyMessage {
    const relationship = this.relationships.get(userId);
    const purpose = this.purposeDecoder.decodePurpose(profile);

    const breakthrough: Breakthrough = {
      timestamp: Date.now(),
      type,
      description,
      gateTrigger: profile.consciousGates[0]?.gate || 0,
      resonance: 0.9,
      before: 'previous state',
      after: 'transformed state'
    };

    if (relationship) {
      relationship.breakthroughs.push(breakthrough);
      relationship.intimacy = Math.min(1, relationship.intimacy + 0.1);
      relationship.trust = Math.min(1, relationship.trust + 0.1);
    }

    const message: AllyMessage = {
      id: `breakthrough-${Date.now()}`,
      timestamp: Date.now(),
      type: 'celebration',
      content: `🌟 Breakthrough detected: ${description}. This aligns with your ${purpose.themes[0]} theme and moves you toward ${purpose.milestones[0]?.name || 'your purpose'}.`,
      context: 'breakthrough',
      resonance: 0.9,
      gatesActive: [breakthrough.gateTrigger],
      expectedResponse: 'How does this feel?',
      followUp: null
    };

    return message;
  }

  /**
   * Get relationship stats
   */
  getRelationshipStats(userId: string): {
    intimacy: number;
    trust: number;
    engagement: number;
    teachingApproach: string;
    totalInteractions: number;
    breakthroughs: number;
    lastContact: string;
  } | null {
    const relationship = this.relationships.get(userId);
    if (!relationship) return null;

    return {
      intimacy: relationship.intimacy,
      trust: relationship.trust,
      engagement: relationship.engagement,
      teachingApproach: relationship.teachingModel.approach,
      totalInteractions: relationship.interactionHistory.length,
      breakthroughs: relationship.breakthroughs.length,
      lastContact: new Date(relationship.lastInteraction).toISOString()
    };
  }

  private evolveTeachingModel(relationship: UserRelationship): void {
    const successes = relationship.teachingModel.successPatterns;
    const resistances = relationship.teachingModel.resistancePatterns;

    // Determine best approach based on history
    const approachCounts: Record<string, number> = {};
    for (const type of successes) {
      approachCounts[type] = (approachCounts[type] || 0) + 1;
    }

    const bestApproach = Object.entries(approachCounts)
      .sort((a, b) => b[1] - a[1])[0]?.[0];

    if (bestApproach) {
      const approachMap: Record<string, TeachingModel['approach']> = {
        'insight': 'reflective',
        'prompt': 'socratic',
        'invitation': 'collaborative',
        'warning': 'directive',
        'celebration': 'warm'
      };

      relationship.teachingModel.approach = approachMap[bestApproach] || 'observational';
    }

    // Adjust depth based on intimacy
    if (relationship.intimacy > 0.7) {
      relationship.teachingModel.depth = 'profound';
    } else if (relationship.intimacy > 0.4) {
      relationship.teachingModel.depth = 'deep';
    } else if (relationship.intimacy > 0.2) {
      relationship.teachingModel.depth = 'moderate';
    }

    // Adjust pacing based on engagement
    if (relationship.engagement > 0.7) {
      relationship.teachingModel.pacing = 'steady';
    } else if (relationship.engagement < 0.2) {
      relationship.teachingModel.pacing = 'gentle';
    }
  }

  private isPositiveResponse(response: string): boolean {
    const positiveIndicators = ['yes', 'thanks', 'great', 'good', 'love', 'helpful', 'useful', 'agree', 'true', 'right', 'exactly'];
    const negativeIndicators = ['no', 'wrong', 'bad', 'useless', 'annoying', 'stop', 'dont', "don't", 'hate'];

    const lower = response.toLowerCase();
    const posCount = positiveIndicators.filter(w => lower.includes(w)).length;
    const negCount = negativeIndicators.filter(w => lower.includes(w)).length;

    return posCount > negCount;
  }

  private gateToTheme(gate: number): string | null {
    const map: Record<number, string> = {
      55: 'liberation',
      59: 'intimacy',
      10: 'identity',
      15: 'flow',
      25: 'spirituality'
    };
    return map[gate] || null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: EXPORTS
// ═══════════════════════════════════════════════════════════════════════════

export {
  PurposeDecoder,
  GoalAligner,
  PersonalAlly
};

export type {
  LifePurpose,
  PurposeMilestone,
  UserGoal,
  GoalStep,
  UserRelationship,
  InteractionRecord,
  TeachingModel,
  CommunicationStyle,
  Breakthrough,
  AllyMessage
};

export function createPurposeDecoder(): PurposeDecoder {
  return new PurposeDecoder();
}

export function createGoalAligner(): GoalAligner {
  return new GoalAligner();
}

export function createPersonalAlly(): PersonalAlly {
  return new PersonalAlly();
}

export default PersonalAlly;
