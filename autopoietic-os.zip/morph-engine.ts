/**
 * ╔═══════════════════════════════════════════════════════════════════════════╗
 * ║                    MORPH ENGINE — Complete Integration                     ║
 * ║                                                                          ║
 * ║  Bridges: HumanAgent (visual body) + GameGAN (world sim) +               ║
 * ║           UnifiedCognitiveEngine (consciousness) + Resonance (astrology) ║
 * ║           + ARCADIA Adapter (external cognition) + Supabase (persistence)║
 * ║                                                                          ║
 * ║  Architecture:                                                           ║
 * ║    Resonance Field → Cognitive State → Body Morphology → World Position  ║
 * ║         ↑____________________________________________________↓           ║
 * ║    (feedback loop: world state → perception → cognition update)         ║
 * ╚═══════════════════════════════════════════════════════════════════════════╝
 */

import { createHumanAgent, HumanAgentParams } from './HumanAgent';
import { bodyPresets } from './BodyPresets';
import { GameGANSimulator, GameState, GameAction } from './gamegan-simulator';
import { UnifiedCognitiveEngine, CognitiveState } from './unified-cognitive-engine';
import { HumanDesignState, ConsciousnessAction, processConsciousnessAction } from './human-design-gamegan';

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: RESONANCE INJECTOR — Real Astronomical Computation
// ═══════════════════════════════════════════════════════════════════════════

export interface PlanetaryPosition {
  planet: string;
  longitude: number;    // 0-360 degrees
  latitude: number;
  speed: number;
  house: number;          // 1-12
  sign: string;
}

export interface ResonanceField {
  timestamp: number;
  positions: PlanetaryPosition[];
  ascendant: number;
  mc: number;             // Midheaven
  lunarPhase: number;     // 0-1 (new to full)
  elementalResonance: {
    fire: number;
    earth: number;
    air: number;
    water: number;
  };
  gateActivations: number[];  // Which HD gates are active
  channelResonance: number;    // 0-1
  crossResonance: number;
}

/**
 * Simplified astronomical computation
 * In production, this would use Swiss Ephemeris or similar
 */
export class ResonanceInjector {
  private seed: number;

  constructor(seed: number = Date.now()) {
    this.seed = seed;
  }

  /**
   * Compute planetary positions for a given timestamp
   * Uses deterministic pseudo-astronomical calculation
   */
  computePositions(timestamp: number): PlanetaryPosition[] {
    const planets = [
      'Sun', 'Moon', 'Mercury', 'Venus', 'Mars',
      'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto',
      'North Node', 'Chiron'
    ];

    const orbitalPeriods = [
      365.25, 27.32, 87.97, 224.7, 686.98,
      4332.59, 10759.22, 30688.5, 60182, 90560,
      6793.4, 50000
    ];

    const daysSinceEpoch = (timestamp - 946684800000) / (1000 * 60 * 60 * 24);

    return planets.map((planet, idx) => {
      const period = orbitalPeriods[idx];
      const longitude = (daysSinceEpoch / period * 360 + (this.seed % 360)) % 360;
      const signIdx = Math.floor(longitude / 30);
      const signs = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo',
                     'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'];

      return {
        planet,
        longitude,
        latitude: Math.sin(daysSinceEpoch / period * Math.PI * 2) * 5,
        speed: 360 / period,
        house: ((signIdx + Math.floor(this.seed % 12)) % 12) + 1,
        sign: signs[signIdx]
      };
    });
  }

  /**
   * Compute elemental resonance from planetary positions
   */
  computeElementalResonance(positions: PlanetaryPosition[]): ResonanceField['elementalResonance'] {
    const signElements: Record<string, string> = {
      'Aries': 'fire', 'Leo': 'fire', 'Sagittarius': 'fire',
      'Taurus': 'earth', 'Virgo': 'earth', 'Capricorn': 'earth',
      'Gemini': 'air', 'Libra': 'air', 'Aquarius': 'air',
      'Cancer': 'water', 'Scorpio': 'water', 'Pisces': 'water'
    };

    const counts = { fire: 0, earth: 0, air: 0, water: 0 };

    positions.forEach(p => {
      const element = signElements[p.sign] || 'fire';
      counts[element as keyof typeof counts]++;
    });

    const total = positions.length;
    return {
      fire: counts.fire / total,
      earth: counts.earth / total,
      air: counts.air / total,
      water: counts.water / total
    };
  }

  /**
   * Compute which Human Design gates are activated by current planetary positions
   * Gates 1-64 map to degrees 0-360 (each gate = 5.625 degrees)
   */
  computeGateActivations(positions: PlanetaryPosition[]): number[] {
    const activeGates: number[] = [];

    positions.forEach(p => {
      const gate = Math.floor(p.longitude / 5.625) + 1;
      if (gate >= 1 && gate <= 64 && !activeGates.includes(gate)) {
        activeGates.push(gate);
      }
    });

    return activeGates.sort((a, b) => a - b);
  }

  /**
   * Compute full resonance field for a timestamp
   */
  computeResonanceField(timestamp: number = Date.now()): ResonanceField {
    const positions = this.computePositions(timestamp);
    const elementalResonance = this.computeElementalResonance(positions);
    const gateActivations = this.computeGateActivations(positions);

    // Compute lunar phase
    const moonPos = positions.find(p => p.planet === 'Moon');
    const sunPos = positions.find(p => p.planet === 'Sun');
    const lunarPhase = moonPos && sunPos 
      ? ((moonPos.longitude - sunPos.longitude + 360) % 360) / 360
      : 0.5;

    // Compute channel resonance (pairs of active gates)
    const channelPairs = this.findChannelPairs(gateActivations);

    return {
      timestamp,
      positions,
      ascendant: positions[0]?.longitude || 0,
      mc: (positions[0]?.longitude || 0) + 90,
      lunarPhase,
      elementalResonance,
      gateActivations,
      channelResonance: Math.min(1, channelPairs.length / 9),
      crossResonance: Math.min(1, gateActivations.length / 16)
    };
  }

  private findChannelPairs(gates: number[]): Array<[number, number]> {
    // Simplified channel mapping — in production would use full HD channel map
    const knownChannels: Array<[number, number]> = [
      [1, 8], [2, 14], [3, 60], [4, 63], [5, 15],
      [6, 59], [7, 31], [9, 52], [10, 34], [11, 56],
      [12, 22], [13, 33], [16, 48], [17, 62], [18, 58],
      [19, 49], [20, 34], [21, 45], [23, 43], [24, 61],
      [25, 51], [26, 44], [27, 50], [28, 38], [29, 46],
      [30, 41], [32, 54], [35, 36], [37, 40], [39, 55],
      [42, 53], [47, 64]
    ];

    const pairs: Array<[number, number]> = [];
    const gateSet = new Set(gates);

    knownChannels.forEach(([a, b]) => {
      if (gateSet.has(a) && gateSet.has(b)) {
        pairs.push([a, b]);
      }
    });

    return pairs;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: ARCADIA ADAPTER — External Cognition Interface
// ═══════════════════════════════════════════════════════════════════════════

export interface ArcadiaCognitiveInput {
  // Neo-Cortex levels
  reactiveState: number;      // 0-1 immediate threat response
  tacticalState: number;    // 0-1 short-term planning
  strategicState: number;   // 0-1 long-term goals
  abstractState: number;    // 0-1 creative reasoning

  // Emotional engine
  emotionalState: {
    joy: number;
    sadness: number;
    anger: number;
    fear: number;
    surprise: number;
    disgust: number;
    anticipation: number;
    trust: number;
    neutral: number;
  };

  // Self-awareness
  awarenessLevel: number;   // Dormant → Transcendent (0-1)
  selfReflection: string;

  // GOAP planning
  currentGoal: string;
  actionPlan: string[];
  planProgress: number;

  // Symbolic reasoning
  knowledgeGraph: Record<string, string[]>;
  inferredFacts: string[];
}

export interface ArcadiaAdapterConfig {
  endpoint?: string;          // ARCADIA API endpoint
  apiKey?: string;
  enableEmotionalEngine: boolean;
  enableGOAP: boolean;
  enableSymbolicReasoning: boolean;
  cognitiveWeights: {
    reactive: number;
    tactical: number;
    strategic: number;
    abstract: number;
  };
}

/**
 * ARCADIA Adapter — bridges external cognition into your unified engine
 */
export class ArcadiaAdapter {
  private config: ArcadiaAdapterConfig;
  private lastInput: ArcadiaCognitiveInput | null = null;

  constructor(config: Partial<ArcadiaAdapterConfig> = {}) {
    this.config = {
      enableEmotionalEngine: true,
      enableGOAP: true,
      enableSymbolicReasoning: true,
      cognitiveWeights: { reactive: 0.25, tactical: 0.25, strategic: 0.25, abstract: 0.25 },
      ...config
    };
  }

  /**
   * Convert ARCADIA cognitive state to your consciousness action
   */
  adaptToConsciousnessAction(input: ArcadiaCognitiveInput): ConsciousnessAction {
    const dominantLevel = this.getDominantCognitiveLevel(input);

    // Map ARCADIA cognitive levels to your consciousness actions
    switch (dominantLevel) {
      case 'reactive':
        return ConsciousnessAction.ACTIVATE_GATE;
      case 'tactical':
        return ConsciousnessAction.FORM_CHANNEL;
      case 'strategic':
        return ConsciousnessAction.EVOLVE_CONSCIOUSNESS;
      case 'abstract':
        return ConsciousnessAction.LIGHT_CROSS;
      default:
        return ConsciousnessAction.DEEPEN_AWARENESS;
    }
  }

  /**
   * Inject ARCADIA cognition into your unified engine
   */
  injectIntoEngine(
    engine: UnifiedCognitiveEngine,
    input: ArcadiaCognitiveInput
  ): CognitiveState {
    const currentState = engine.getCurrentState();

    // Map emotional state to consciousness fields
    const emotionalFields = this.mapEmotionsToFields(input.emotionalState);

    // Determine action based on cognitive state
    const action = this.adaptToConsciousnessAction(input);

    // Update human design state with ARCADIA input
    const newHDState = processConsciousnessAction(currentState.humanDesignState, action);

    // Blend ARCADIA awareness with your consciousness level
    const blendedConsciousness = (currentState.humanDesignState.consciousnessLevel * 0.6) 
                               + (input.awarenessLevel * 0.4);
    newHDState.consciousnessLevel = Math.min(1.0, blendedConsciousness);

    // Update archetype based on emotional dominance
    newHDState.currentArchetype = this.selectArchetypeFromEmotion(input.emotionalState);

    // Create modified cognitive state
    const modifiedState: CognitiveState = {
      ...currentState,
      humanDesignState: newHDState,
      consciousnessFields: emotionalFields,
      timestamp: Date.now(),
      evolutionStep: currentState.evolutionStep + 1
    };

    this.lastInput = input;
    return modifiedState;
  }

  private getDominantCognitiveLevel(input: ArcadiaCognitiveInput): string {
    const levels = {
      reactive: input.reactiveState * this.config.cognitiveWeights!.reactive,
      tactical: input.tacticalState * this.config.cognitiveWeights!.tactical,
      strategic: input.strategicState * this.config.cognitiveWeights!.strategic,
      abstract: input.abstractState * this.config.cognitiveWeights!.abstract
    };

    return Object.entries(levels).sort((a, b) => b[1] - a[1])[0][0];
  }

  private mapEmotionsToFields(emotions: ArcadiaCognitiveInput['emotionalState']): CognitiveState['consciousnessFields'] {
    return {
      head: emotions.joy * 0.8 + emotions.surprise * 0.2,
      ajna: emotions.trust * 0.7 + emotions.anticipation * 0.3,
      throat: emotions.anger * 0.5 + emotions.joy * 0.5,
      g: emotions.neutral * 0.6 + emotions.trust * 0.4,
      heart: emotions.joy * 0.7 + emotions.anticipation * 0.3,
      sacral: emotions.anticipation * 0.6 + emotions.joy * 0.4,
      solarPlexus: emotions.anger * 0.5 + emotions.fear * 0.3 + emotions.sadness * 0.2,
      spleen: emotions.fear * 0.6 + emotions.disgust * 0.4,
      root: emotions.anticipation * 0.5 + emotions.anger * 0.3 + emotions.joy * 0.2
    };
  }

  private selectArchetypeFromEmotion(emotions: ArcadiaCognitiveInput['emotionalState']): string {
    const dominant = Object.entries(emotions).sort((a, b) => b[1] - a[1])[0][0];

    const archetypeMap: Record<string, string> = {
      joy: 'The Light Bearer',
      sadness: 'The Shadow Guide',
      anger: 'The Fire Keeper',
      fear: 'The Void Walker',
      surprise: 'The Dream Weaver',
      disgust: 'The Mirror Holder',
      anticipation: 'The Bridge Builder',
      trust: 'The Unity Weaver',
      neutral: 'The Mystic Wanderer'
    };

    return archetypeMap[dominant] || 'The Mystic Wanderer';
  }

  /**
   * Generate ARCADIA-style cognitive input from your engine state
   */
  extractFromEngine(state: CognitiveState): ArcadiaCognitiveInput {
    return {
      reactiveState: state.consciousnessFields.spleen * 0.5 + state.consciousnessFields.root * 0.5,
      tacticalState: state.consciousnessFields.sacral * 0.6 + state.consciousnessFields.solarPlexus * 0.4,
      strategicState: state.consciousnessFields.ajna * 0.7 + state.consciousnessFields.head * 0.3,
      abstractState: state.consciousnessFields.g * 0.8 + state.consciousnessFields.throat * 0.2,
      emotionalState: this.extractEmotionsFromFields(state.consciousnessFields),
      awarenessLevel: state.humanDesignState.consciousnessLevel,
      selfReflection: `Current archetype: ${state.humanDesignState.currentArchetype}`,
      currentGoal: state.humanDesignState.incarnationCross,
      actionPlan: state.humanDesignState.actionSpace.map(a => a.toString()),
      planProgress: state.resonanceScore,
      knowledgeGraph: {
        'gates': state.humanDesignState.activeGates.map(String),
        'channels': state.humanDesignState.channels.map(c => `${c[0]}-${c[1]}`),
        'centers': state.humanDesignState.definedCenters
      },
      inferredFacts: [
        `Resonance: ${(state.resonanceScore * 100).toFixed(1)}%`,
        `Codon: ${state.codonState.hexagram}`,
        `Shape: ${state.geometricState.primaryShape}`
      ]
    };
  }

  private extractEmotionsFromFields(fields: CognitiveState['consciousnessFields']): ArcadiaCognitiveInput['emotionalState'] {
    return {
      joy: fields.heart * 0.7 + fields.sacral * 0.3,
      sadness: (1 - fields.g) * 0.5 + (1 - fields.head) * 0.3,
      anger: fields.throat * 0.4 + fields.root * 0.3,
      fear: fields.spleen * 0.8,
      surprise: fields.ajna * 0.6 + fields.head * 0.4,
      disgust: (1 - fields.spleen) * 0.3,
      anticipation: fields.sacral * 0.5 + fields.root * 0.5,
      trust: fields.g * 0.7 + fields.heart * 0.3,
      neutral: 0.5
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: BODY MORPH ENGINE — Cognitive State → Body Parameters
// ═══════════════════════════════════════════════════════════════════════════

export interface MorphMapping {
  resonanceToHeight: number;      // How much resonance affects height
  resonanceToCurve: number;       // How much resonance affects body curve
  consciousnessToSpeed: number;   // How consciousness affects movement speed
  emotionToBreath: number;        // How emotional state affects breathing
  gateToMass: number;             // How active gates affect body mass
}

export const defaultMorphMapping: MorphMapping = {
  resonanceToHeight: 0.15,
  resonanceToCurve: 0.4,
  consciousnessToSpeed: 0.5,
  emotionToBreath: 0.3,
  gateToMass: 0.02
};

/**
 * Morph Engine — transforms cognitive state into body parameters
 */
export class MorphEngine {
  private mapping: MorphMapping;
  private basePreset: HumanAgentParams;

  constructor(
    mapping: Partial<MorphMapping> = {},
    presetName: string = 'default'
  ) {
    this.mapping = { ...defaultMorphMapping, ...mapping };
    this.basePreset = bodyPresets[presetName] || bodyPresets.default;
  }

  /**
   * Compute body parameters from cognitive state
   */
  computeBodyParams(state: CognitiveState): HumanAgentParams {
    const params = { ...this.basePreset };

    // Resonance affects height (higher resonance = taller, more "present")
    params.height = this.basePreset.height 
      + (state.resonanceScore - 0.5) * this.mapping.resonanceToHeight;

    // Resonance affects curve (higher resonance = more flowing, embodied)
    params.curve = this.basePreset.curve 
      + (state.resonanceScore - 0.5) * this.mapping.resonanceToCurve;

    // Consciousness affects speed (higher consciousness = slower, more deliberate)
    params.speed = this.basePreset.speed 
      - (state.humanDesignState.consciousnessLevel - 0.5) * this.mapping.consciousnessToSpeed;

    // Emotional state (from consciousness fields) affects breathing
    const emotionalIntensity = (
      state.consciousnessFields.heart + 
      state.consciousnessFields.solarPlexus + 
      state.consciousnessFields.sacral
    ) / 3;
    params.breath = this.basePreset.breath 
      + (emotionalIntensity - 0.5) * this.mapping.emotionToBreath;

    // Active gates affect mass (more gates = more "density", presence)
    const gateDensity = state.humanDesignState.activeGates.length / 64;
    params.shoulders = this.basePreset.shoulders + gateDensity * this.mapping.gateToMass;
    params.chest = this.basePreset.chest + gateDensity * this.mapping.gateToMass * 0.5;
    params.hips = this.basePreset.hips + gateDensity * this.mapping.gateToMass;

    // Elemental balance affects proportions
    const fireDominance = state.elementalState.fire - 0.2;
    params.thigh = this.basePreset.thigh + fireDominance * 0.1;  // Fire = more leg power
    params.uArm = this.basePreset.uArm + fireDominance * 0.05;   // Fire = more arm presence

    const waterDominance = state.elementalState.water - 0.2;
    params.calf = this.basePreset.calf + waterDominance * 0.1;   // Water = more flow in lower body
    params.fArm = this.basePreset.fArm + waterDominance * 0.05;  // Water = more fluid arms

    // Clamp all values to reasonable ranges
    return this.clampParams(params);
  }

  /**
   * Compute body tilt from consciousness state
   * Higher consciousness = more upright (aligned)
   * Lower consciousness = more tilted (ungrounded)
   */
  computeTilt(state: CognitiveState): number {
    const alignment = state.humanDesignState.consciousnessLevel;
    const grounding = state.consciousnessFields.root;
    return (1 - alignment) * 0.2 - (1 - grounding) * 0.1;
  }

  private clampParams(params: HumanAgentParams): HumanAgentParams {
    return {
      height: Math.max(0.5, Math.min(2.0, params.height)),
      shoulders: Math.max(0.3, Math.min(3.0, params.shoulders)),
      chest: Math.max(0.3, Math.min(3.0, params.chest)),
      waist: Math.max(0.2, Math.min(2.0, params.waist)),
      hips: Math.max(0.3, Math.min(3.0, params.hips)),
      uArm: Math.max(0.3, Math.min(2.0, params.uArm)),
      fArm: Math.max(0.3, Math.min(2.0, params.fArm)),
      thigh: Math.max(0.3, Math.min(2.0, params.thigh)),
      calf: Math.max(0.3, Math.min(2.0, params.calf)),
      curve: Math.max(0.0, Math.min(1.0, params.curve)),
      tilt: Math.max(-0.5, Math.min(0.5, params.tilt)),
      speed: Math.max(0.1, Math.min(2.0, params.speed)),
      breath: Math.max(0.0, Math.min(1.0, params.breath))
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: WORLD EMBODIMENT — GameGAN + HumanAgent Integration
// ═══════════════════════════════════════════════════════════════════════════

export interface EmbodiedAgent {
  id: string;
  name: string;
  body: ReturnType<typeof createHumanAgent>;
  gameState: GameState;
  cognitiveState: CognitiveState;
  resonanceField: ResonanceField;
  position: { x: number; y: number; z: number };
  velocity: { x: number; y: number; z: number };
  facing: number;  // radians
  lastUpdate: number;
}

export interface WorldConfig {
  bounds: { x: number; y: number; z: number };
  gravity: number;
  friction: number;
  maxAgents: number;
  tickRate: number;
}

export const defaultWorldConfig: WorldConfig = {
  bounds: { x: 100, y: 50, z: 100 },
  gravity: 9.8,
  friction: 0.95,
  maxAgents: 50,
  tickRate: 60
};

/**
 * Embodied World — where agents exist with bodies in space
 */
export class EmbodiedWorld {
  private agents: Map<string, EmbodiedAgent> = new Map();
  private config: WorldConfig;
  private gameGAN: GameGANSimulator;
  private morphEngine: MorphEngine;
  private resonanceInjector: ResonanceInjector;
  private arcadiaAdapter: ArcadiaAdapter;
  private tickInterval: number | null = null;
  private onAgentUpdate: ((agent: EmbodiedAgent) => void) | null = null;

  constructor(
    config: Partial<WorldConfig> = {},
    morphMapping: Partial<MorphMapping> = {},
    arcadiaConfig: Partial<ArcadiaAdapterConfig> = {}
  ) {
    this.config = { ...defaultWorldConfig, ...config };
    this.gameGAN = new GameGANSimulator();
    this.morphEngine = new MorphEngine(morphMapping);
    this.resonanceInjector = new ResonanceInjector();
    this.arcadiaAdapter = new ArcadiaAdapter(arcadiaConfig);
  }

  /**
   * Spawn a new embodied agent
   */
  spawnAgent(
    id: string,
    name: string,
    presetName: string = 'default',
    position?: { x: number; y: number; z: number }
  ): EmbodiedAgent {
    const body = createHumanAgent();
    const cognitiveEngine = new UnifiedCognitiveEngine();
    const resonanceField = this.resonanceInjector.computeResonanceField();

    // Compute initial cognitive state with resonance
    const initialState = cognitiveEngine.getCurrentState();

    // Apply resonance to initial state
    initialState.resonanceScore = (
      resonanceField.elementalResonance.fire +
      resonanceField.elementalResonance.earth +
      resonanceField.elementalResonance.air +
      resonanceField.elementalResonance.water
    ) / 4;

    initialState.humanDesignState.activeGates = resonanceField.gateActivations.slice(0, 5);

    // Compute body from cognitive state
    const bodyParams = this.morphEngine.computeBodyParams(initialState);
    body.params = bodyParams;
    body.apply();

    const agent: EmbodiedAgent = {
      id,
      name,
      body,
      gameState: this.gameGAN.getState(),
      cognitiveState: initialState,
      resonanceField,
      position: position || {
        x: (Math.random() - 0.5) * this.config.bounds.x,
        y: 0,
        z: (Math.random() - 0.5) * this.config.bounds.z
      },
      velocity: { x: 0, y: 0, z: 0 },
      facing: Math.random() * Math.PI * 2,
      lastUpdate: Date.now()
    };

    this.agents.set(id, agent);
    return agent;
  }

  /**
   * Inject ARCADIA cognition into an agent
   */
  injectCognition(agentId: string, arcadiaInput: ArcadiaCognitiveInput): EmbodiedAgent | null {
    const agent = this.agents.get(agentId);
    if (!agent) return null;

    const engine = new UnifiedCognitiveEngine();
    // Set engine to agent's current state
    // (In production, would need state injection method on engine)

    const newState = this.arcadiaAdapter.injectIntoEngine(engine, arcadiaInput);
    agent.cognitiveState = newState;

    // Recompute body from new cognitive state
    const newParams = this.morphEngine.computeBodyParams(newState);
    agent.body.params = newParams;
    agent.body.apply();

    // Update game state based on new cognition
    const action: GameAction = {
      type: newState.resonanceScore > 0.7 ? 'create' : 
            newState.resonanceScore > 0.5 ? 'socialize' : 'move',
      direction: {
        x: Math.cos(agent.facing),
        y: 0,
        z: Math.sin(agent.facing)
      },
      intensity: newState.resonanceScore
    };

    agent.gameState = this.gameGAN.step(action);
    agent.lastUpdate = Date.now();

    if (this.onAgentUpdate) this.onAgentUpdate(agent);
    return agent;
  }

  /**
   * Update resonance field for all agents (astrological time progression)
   */
  updateResonance(timestamp?: number): void {
    const field = this.resonanceInjector.computeResonanceField(timestamp);

    this.agents.forEach(agent => {
      agent.resonanceField = field;

      // Update cognitive state with new resonance
      agent.cognitiveState.resonanceScore = (
        field.elementalResonance.fire +
        field.elementalResonance.earth +
        field.elementalResonance.air +
        field.elementalResonance.water
      ) / 4;

      // Update gate activations
      agent.cognitiveState.humanDesignState.activeGates = 
        field.gateActivations.slice(0, Math.floor(agent.cognitiveState.humanDesignState.consciousnessLevel * 10) + 3);

      // Recompute body
      const newParams = this.morphEngine.computeBodyParams(agent.cognitiveState);
      agent.body.params = newParams;
      agent.body.apply();
    });
  }

  /**
   * World tick — physics + cognition + rendering
   */
  tick(deltaTime: number = 1/60): void {
    const now = Date.now();

    this.agents.forEach(agent => {
      // Physics update
      agent.position.x += agent.velocity.x * deltaTime;
      agent.position.y += agent.velocity.y * deltaTime;
      agent.position.z += agent.velocity.z * deltaTime;

      // Boundary clamping
      agent.position.x = Math.max(-this.config.bounds.x/2, 
                                   Math.min(this.config.bounds.x/2, agent.position.x));
      agent.position.z = Math.max(-this.config.bounds.z/2, 
                                   Math.min(this.config.bounds.z/2, agent.position.z));

      // Ground collision
      if (agent.position.y < 0) {
        agent.position.y = 0;
        agent.velocity.y = 0;
      }

      // Friction
      agent.velocity.x *= this.config.friction;
      agent.velocity.z *= this.config.friction;

      // Body animation tick
      const t = now / 1000;
      agent.body.tick(t);

      // Update body position in world
      agent.body.object.position.set(
        agent.position.x,
        agent.position.y,
        agent.position.z
      );
      agent.body.object.rotation.y = agent.facing;

      // Drive-based behavior
      const drives = agent.gameState.drives;
      if (drives.hunger > 0.8) {
        // Seek — random movement
        agent.facing += (Math.random() - 0.5) * 0.5;
        agent.velocity.x = Math.cos(agent.facing) * agent.body.params.speed;
        agent.velocity.z = Math.sin(agent.facing) * agent.body.params.speed;
      } else if (drives.rest < 0.2) {
        // Rest — stop moving
        agent.velocity.x *= 0.5;
        agent.velocity.z *= 0.5;
      } else if (drives.social > 0.7) {
        // Socialize — move toward nearest agent
        const nearest = this.findNearestAgent(agent);
        if (nearest) {
          const dx = nearest.position.x - agent.position.x;
          const dz = nearest.position.z - agent.position.z;
          agent.facing = Math.atan2(dz, dx);
          agent.velocity.x = Math.cos(agent.facing) * agent.body.params.speed * 0.5;
          agent.velocity.z = Math.sin(agent.facing) * agent.body.params.speed * 0.5;
        }
      }

      agent.lastUpdate = now;
    });
  }

  private findNearestAgent(from: EmbodiedAgent): EmbodiedAgent | null {
    let nearest: EmbodiedAgent | null = null;
    let minDist = Infinity;

    this.agents.forEach(agent => {
      if (agent.id === from.id) return;
      const dx = agent.position.x - from.position.x;
      const dz = agent.position.z - from.position.z;
      const dist = Math.sqrt(dx*dx + dz*dz);
      if (dist < minDist) {
        minDist = dist;
        nearest = agent;
      }
    });

    return nearest;
  }

  /**
   * Start world simulation loop
   */
  start(): void {
    if (this.tickInterval) return;

    const intervalMs = 1000 / this.config.tickRate;
    this.tickInterval = window.setInterval(() => {
      this.tick(1 / this.config.tickRate);
    }, intervalMs);
  }

  /**
   * Stop world simulation loop
   */
  stop(): void {
    if (this.tickInterval) {
      clearInterval(this.tickInterval);
      this.tickInterval = null;
    }
  }

  /**
   * Get all agents
   */
  getAgents(): EmbodiedAgent[] {
    return Array.from(this.agents.values());
  }

  /**
   * Get agent by ID
   */
  getAgent(id: string): EmbodiedAgent | undefined {
    return this.agents.get(id);
  }

  /**
   * Remove agent
   */
  removeAgent(id: string): boolean {
    return this.agents.delete(id);
  }

  /**
   * Set agent update callback
   */
  onUpdate(callback: (agent: EmbodiedAgent) => void): void {
    this.onAgentUpdate = callback;
  }

  /**
   * Get world statistics
   */
  getStats(): {
    agentCount: number;
    averageResonance: number;
    averageConsciousness: number;
    activeChannels: number;
    dominantElement: string;
  } {
    const agents = this.getAgents();
    if (agents.length === 0) {
      return {
        agentCount: 0,
        averageResonance: 0,
        averageConsciousness: 0,
        activeChannels: 0,
        dominantElement: 'none'
      };
    }

    const avgResonance = agents.reduce((sum, a) => sum + a.cognitiveState.resonanceScore, 0) / agents.length;
    const avgConsciousness = agents.reduce((sum, a) => sum + a.cognitiveState.humanDesignState.consciousnessLevel, 0) / agents.length;
    const totalChannels = agents.reduce((sum, a) => sum + a.cognitiveState.humanDesignState.channels.length, 0);

    // Find dominant element across all agents
    const elementTotals = { fire: 0, earth: 0, air: 0, water: 0 };
    agents.forEach(a => {
      elementTotals.fire += a.cognitiveState.elementalState.fire;
      elementTotals.earth += a.cognitiveState.elementalState.earth;
      // Map metal to air, wood to earth for 4-element system
      elementTotals.air += a.cognitiveState.elementalState.metal;
      elementTotals.water += a.cognitiveState.elementalState.water;
    });

    const dominantElement = Object.entries(elementTotals)
      .sort((a, b) => b[1] - a[1])[0][0];

    return {
      agentCount: agents.length,
      averageResonance: avgResonance,
      averageConsciousness: avgConsciousness,
      activeChannels: totalChannels,
      dominantElement
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: SUPABASE PERSISTENCE — Cross-Session Memory
// ═══════════════════════════════════════════════════════════════════════════

export interface PersistenceConfig {
  supabaseUrl: string;
  supabaseKey: string;
  tableName: string;
  autoSaveInterval: number;  // ms
}

export class WorldPersistence {
  private config: PersistenceConfig;
  private autoSaveTimer: number | null = null;

  constructor(config: PersistenceConfig) {
    this.config = config;
  }

  /**
   * Serialize agent state for storage
   */
  serializeAgent(agent: EmbodiedAgent): object {
    return {
      id: agent.id,
      name: agent.name,
      position: agent.position,
      velocity: agent.velocity,
      facing: agent.facing,
      cognitive_state: {
        resonance_score: agent.cognitiveState.resonanceScore,
        consciousness_level: agent.cognitiveState.humanDesignState.consciousnessLevel,
        archetype: agent.cognitiveState.humanDesignState.currentArchetype,
        active_gates: agent.cognitiveState.humanDesignState.activeGates,
        channels: agent.cognitiveState.humanDesignState.channels,
        defined_centers: agent.cognitiveState.humanDesignState.definedCenters,
        incarnation_cross: agent.cognitiveState.humanDesignState.incarnationCross,
        codon_sequence: agent.cognitiveState.humanDesignState.codonSequence,
        elemental_state: agent.cognitiveState.elementalState,
        geometric_state: agent.cognitiveState.geometricState,
        evolution_step: agent.cognitiveState.evolutionStep
      },
      body_params: agent.body.params,
      resonance_field: {
        timestamp: agent.resonanceField.timestamp,
        gate_activations: agent.resonanceField.gateActivations,
        elemental_resonance: agent.resonanceField.elementalResonance,
        lunar_phase: agent.resonanceField.lunarPhase
      },
      game_state: {
        drives: agent.gameState.drives,
        position: agent.gameState.position
      },
      last_update: agent.lastUpdate,
      created_at: new Date().toISOString()
    };
  }

  /**
   * Save agent to Supabase
   */
  async saveAgent(agent: EmbodiedAgent): Promise<boolean> {
    try {
      const data = this.serializeAgent(agent);

      const response = await fetch(`${this.config.supabaseUrl}/rest/v1/${this.config.tableName}`, {
        method: 'POST',
        headers: {
          'apikey': this.config.supabaseKey,
          'Authorization': `Bearer ${this.config.supabaseKey}`,
          'Content-Type': 'application/json',
          'Prefer': 'resolution=merge-duplicates,return=minimal'
        },
        body: JSON.stringify(data)
      });

      return response.ok;
    } catch (error) {
      console.error('Failed to save agent:', error);
      return false;
    }
  }

  /**
   * Load agent from Supabase
   */
  async loadAgent(agentId: string): Promise<object | null> {
    try {
      const response = await fetch(
        `${this.config.supabaseUrl}/rest/v1/${this.config.tableName}?id=eq.${agentId}&order=created_at.desc&limit=1`,
        {
          headers: {
            'apikey': this.config.supabaseKey,
            'Authorization': `Bearer ${this.config.supabaseKey}`
          }
        }
      );

      if (!response.ok) return null;

      const data = await response.json();
      return data[0] || null;
    } catch (error) {
      console.error('Failed to load agent:', error);
      return null;
    }
  }

  /**
   * Save all agents from world
   */
  async saveWorld(world: EmbodiedWorld): Promise<{ saved: number; failed: number }> {
    const agents = world.getAgents();
    let saved = 0;
    let failed = 0;

    for (const agent of agents) {
      const success = await this.saveAgent(agent);
      if (success) saved++; else failed++;
    }

    return { saved, failed };
  }

  /**
   * Start auto-save
   */
  startAutoSave(world: EmbodiedWorld): void {
    if (this.autoSaveTimer) return;

    this.autoSaveTimer = window.setInterval(async () => {
      await this.saveWorld(world);
    }, this.config.autoSaveInterval);
  }

  /**
   * Stop auto-save
   */
  stopAutoSave(): void {
    if (this.autoSaveTimer) {
      clearInterval(this.autoSaveTimer);
      this.autoSaveTimer = null;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6: MAIN EXPORT — Complete System Integration
// ═══════════════════════════════════════════════════════════════════════════

export {
  createHumanAgent,
  HumanAgentParams,
  bodyPresets,
  GameGANSimulator,
  GameState,
  GameAction,
  UnifiedCognitiveEngine,
  CognitiveState,
  HumanDesignState,
  ConsciousnessAction,
  processConsciousnessAction
};

// Convenience factory function
export function createEmbodiedWorld(
  worldConfig?: Partial<WorldConfig>,
  morphMapping?: Partial<MorphMapping>,
  arcadiaConfig?: Partial<ArcadiaAdapterConfig>
): EmbodiedWorld {
  return new EmbodiedWorld(worldConfig, morphMapping, arcadiaConfig);
}

export function createResonanceInjector(seed?: number): ResonanceInjector {
  return new ResonanceInjector(seed);
}

export function createArcadiaAdapter(config?: Partial<ArcadiaAdapterConfig>): ArcadiaAdapter {
  return new ArcadiaAdapter(config);
}

export function createMorphEngine(
  mapping?: Partial<MorphMapping>,
  presetName?: string
): MorphEngine {
  return new MorphEngine(mapping, presetName);
}

export function createPersistence(config: PersistenceConfig): WorldPersistence {
  return new WorldPersistence(config);
}
