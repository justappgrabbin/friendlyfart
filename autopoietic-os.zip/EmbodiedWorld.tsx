/**
 * ╔═══════════════════════════════════════════════════════════════════════════╗
 * ║              EMBODIED WORLD — React Component                             ║
 * ║                                                                          ║
 * ║  Renders the complete embodied agent system in Three.js:                  ║
 * ║  - 3D humanoid bodies that morph based on cognitive state                  ║
 * ║  - World environment with resonance field visualization                    ║
 * ║  - Agent interaction, selection, inspection                                ║
 * ║  - Real-time cognitive state display                                         ║
 * ╚═══════════════════════════════════════════════════════════════════════════╝
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import {
  EmbodiedWorld,
  EmbodiedAgent,
  createEmbodiedWorld,
  createResonanceInjector,
  createArcadiaAdapter,
  createMorphEngine,
  createPersistence,
  ArcadiaCognitiveInput,
  ResonanceField
} from './morph-engine';

// ═══════════════════════════════════════════════════════════════════════════
// STYLES
// ═══════════════════════════════════════════════════════════════════════════

const styles: Record<string, React.CSSProperties> = {
  container: {
    width: '100vw',
    height: '100vh',
    position: 'relative',
    overflow: 'hidden',
    background: '#0a0a1a'
  },
  canvas: {
    width: '100%',
    height: '100%',
    display: 'block'
  },
  uiPanel: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 320,
    maxHeight: 'calc(100vh - 32px)',
    overflowY: 'auto',
    background: 'rgba(10, 10, 30, 0.92)',
    border: '1px solid rgba(100, 200, 255, 0.2)',
    borderRadius: 12,
    padding: 16,
    color: '#e0e0ff',
    fontFamily: "'Inter', 'SF Pro Display', -apple-system, sans-serif",
    fontSize: 13,
    backdropFilter: 'blur(12px)',
    zIndex: 100
  },
  title: {
    fontSize: 16,
    fontWeight: 700,
    color: '#64c8ff',
    marginBottom: 12,
    letterSpacing: '0.5px'
  },
  section: {
    marginBottom: 16,
    paddingBottom: 12,
    borderBottom: '1px solid rgba(100, 200, 255, 0.1)'
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: 600,
    color: '#8899aa',
    textTransform: 'uppercase',
    letterSpacing: '1px',
    marginBottom: 8
  },
  statRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: 4,
    fontSize: 12
  },
  statLabel: {
    color: '#8899aa'
  },
  statValue: {
    color: '#c0d0e0',
    fontWeight: 500
  },
  bar: {
    height: 4,
    background: 'rgba(100, 200, 255, 0.15)',
    borderRadius: 2,
    marginTop: 2,
    marginBottom: 8,
    overflow: 'hidden'
  },
  barFill: (color: string, pct: number): React.CSSProperties => ({
    height: '100%',
    width: `${pct * 100}%`,
    background: color,
    borderRadius: 2,
    transition: 'width 0.3s ease'
  }),
  button: {
    background: 'rgba(100, 200, 255, 0.15)',
    border: '1px solid rgba(100, 200, 255, 0.3)',
    color: '#64c8ff',
    padding: '8px 14px',
    borderRadius: 6,
    cursor: 'pointer',
    fontSize: 12,
    fontWeight: 500,
    transition: 'all 0.2s',
    marginRight: 8,
    marginBottom: 8
  },
  buttonHover: {
    background: 'rgba(100, 200, 255, 0.25)'
  },
  agentList: {
    maxHeight: 200,
    overflowY: 'auto'
  },
  agentItem: {
    padding: '8px 10px',
    borderRadius: 6,
    cursor: 'pointer',
    marginBottom: 4,
    transition: 'background 0.2s',
    border: '1px solid transparent'
  },
  agentItemSelected: {
    background: 'rgba(100, 200, 255, 0.15)',
    border: '1px solid rgba(100, 200, 255, 0.3)'
  },
  resonanceOrb: {
    position: 'absolute',
    bottom: 16,
    left: 16,
    width: 120,
    height: 120,
    borderRadius: '50%',
    background: 'radial-gradient(circle, rgba(100,200,255,0.3) 0%, transparent 70%)',
    border: '1px solid rgba(100, 200, 255, 0.2)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
    backdropFilter: 'blur(8px)',
    zIndex: 100
  },
  input: {
    background: 'rgba(0, 0, 0, 0.3)',
    border: '1px solid rgba(100, 200, 255, 0.2)',
    color: '#e0e0ff',
    padding: '6px 10px',
    borderRadius: 6,
    fontSize: 12,
    width: '100%',
    marginBottom: 8,
    outline: 'none'
  },
  gateGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(8, 1fr)',
    gap: 2,
    marginTop: 8
  },
  gate: (active: boolean): React.CSSProperties => ({
    width: 24,
    height: 24,
    borderRadius: 4,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 9,
    fontWeight: 600,
    background: active ? 'rgba(100, 200, 255, 0.4)' : 'rgba(100, 200, 255, 0.05)',
    color: active ? '#fff' : '#445566',
    border: active ? '1px solid rgba(100, 200, 255, 0.5)' : '1px solid transparent',
    transition: 'all 0.3s'
  })
};

// ═══════════════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════════════

interface EmbodiedWorldProps {
  supabaseUrl?: string;
  supabaseKey?: string;
  initialAgentCount?: number;
  enablePersistence?: boolean;
}

export const EmbodiedWorldComponent: React.FC<EmbodiedWorldProps> = ({
  supabaseUrl,
  supabaseKey,
  initialAgentCount = 3,
  enablePersistence = false
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const worldRef = useRef<EmbodiedWorld | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const frameRef = useRef<number>(0);

  const [selectedAgent, setSelectedAgent] = useState<EmbodiedAgent | null>(null);
  const [agents, setAgents] = useState<EmbodiedAgent[]>([]);
  const [worldStats, setWorldStats] = useState({
    agentCount: 0,
    averageResonance: 0,
    averageConsciousness: 0,
    activeChannels: 0,
    dominantElement: 'none'
  });
  const [resonanceField, setResonanceField] = useState<ResonanceField | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [injectText, setInjectText] = useState('');

  // Initialize Three.js scene
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const container = containerRef.current;
    const canvas = canvasRef.current;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a1a);
    scene.fog = new THREE.Fog(0x0a0a1a, 20, 100);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(
      60,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 5, 12);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    rendererRef.current = renderer;

    // Controls
    const controls = new OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 - 0.1;
    controls.minDistance = 3;
    controls.maxDistance = 50;
    controls.target.set(0, 1, 0);
    controlsRef.current = controls;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404080, 0.5);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x8899ff, 1);
    dirLight.position.set(10, 20, 10);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    scene.add(dirLight);

    const pointLight = new THREE.PointLight(0x64c8ff, 0.8, 50);
    pointLight.position.set(0, 5, 0);
    scene.add(pointLight);

    // Ground
    const groundGeo = new THREE.PlaneGeometry(200, 200);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0f0f2a,
      metalness: 0.1,
      roughness: 0.8
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Grid
    const gridHelper = new THREE.GridHelper(200, 100, 0x1a1a3a, 0x0f0f2a);
    scene.add(gridHelper);

    // Resonance field visualization (particles)
    const particleCount = 1000;
    const particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 100;
      positions[i * 3 + 1] = Math.random() * 20;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 100;

      colors[i * 3] = 0.4 + Math.random() * 0.4;
      colors[i * 3 + 1] = 0.6 + Math.random() * 0.4;
      colors[i * 3 + 2] = 1.0;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMat = new THREE.PointsMaterial({
      size: 0.15,
      vertexColors: true,
      transparent: true,
      opacity: 0.6,
      blending: THREE.AdditiveBlending
    });

    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Initialize world
    const world = createEmbodiedWorld({
      bounds: { x: 100, y: 50, z: 100 },
      maxAgents: 50,
      tickRate: 60
    });
    worldRef.current = world;

    // Spawn initial agents
    for (let i = 0; i < initialAgentCount; i++) {
      const agent = world.spawnAgent(
        `agent-${i}`,
        ['Adaya', 'Orion', 'Sage', 'Nova', 'Echo'][i % 5],
        i === 0 ? 'adaya' : 'default',
        {
          x: (Math.random() - 0.5) * 20,
          y: 0,
          z: (Math.random() - 0.5) * 20
        }
      );
      scene.add(agent.body.object);
    }

    // Setup persistence if configured
    if (enablePersistence && supabaseUrl && supabaseKey) {
      const persistence = createPersistence({
        supabaseUrl,
        supabaseKey,
        tableName: 'embodied_agents',
        autoSaveInterval: 30000
      });
      persistence.startAutoSave(world);
    }

    // Update UI periodically
    const uiInterval = setInterval(() => {
      const allAgents = world.getAgents();
      setAgents(allAgents);
      setWorldStats(world.getStats());

      if (allAgents.length > 0) {
        setResonanceField(allAgents[0].resonanceField);
      }
    }, 500);

    // Animation loop
    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);

      // Update world physics
      world.tick(1/60);

      // Animate particles
      const posArray = particles.geometry.attributes.position.array as Float32Array;
      for (let i = 0; i < particleCount; i++) {
        posArray[i * 3 + 1] += Math.sin(Date.now() * 0.001 + i) * 0.01;
      }
      particles.geometry.attributes.position.needsUpdate = true;

      // Update controls
      controls.update();

      // Render
      renderer.render(scene, camera);
    };

    animate();
    setIsRunning(true);

    // Handle resize
    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameRef.current);
      clearInterval(uiInterval);
      window.removeEventListener('resize', handleResize);
      world.stop();
      renderer.dispose();
    };
  }, [initialAgentCount, enablePersistence, supabaseUrl, supabaseKey]);

  // Spawn new agent
  const handleSpawn = useCallback(() => {
    const world = worldRef.current;
    if (!world) return;

    const id = `agent-${Date.now()}`;
    const names = ['Adaya', 'Orion', 'Sage', 'Nova', 'Echo', 'Lyra', 'Kai', 'Zara'];
    const name = names[Math.floor(Math.random() * names.length)];

    const agent = world.spawnAgent(id, name, 'default', {
      x: (Math.random() - 0.5) * 20,
      y: 0,
      z: (Math.random() - 0.5) * 20
    });

    if (sceneRef.current) {
      sceneRef.current.add(agent.body.object);
    }

    setAgents(world.getAgents());
  }, []);

  // Inject cognition
  const handleInject = useCallback(() => {
    if (!selectedAgent || !injectText.trim()) return;

    const world = worldRef.current;
    if (!world) return;

    // Create ARCADIA-style input from text
    const emotionalIntensity = Math.min(1, injectText.length / 100);
    const arcadiaInput: ArcadiaCognitiveInput = {
      reactiveState: emotionalIntensity * 0.3,
      tacticalState: emotionalIntensity * 0.5,
      strategicState: emotionalIntensity * 0.7,
      abstractState: emotionalIntensity * 0.4,
      emotionalState: {
        joy: injectText.includes('happy') || injectText.includes('joy') ? 0.8 : 0.3,
        sadness: injectText.includes('sad') || injectText.includes('loss') ? 0.7 : 0.2,
        anger: injectText.includes('angry') || injectText.includes('mad') ? 0.6 : 0.1,
        fear: injectText.includes('scared') || injectText.includes('afraid') ? 0.5 : 0.2,
        surprise: injectText.includes('wow') || injectText.includes('amazing') ? 0.7 : 0.3,
        disgust: 0.1,
        anticipation: injectText.includes('excited') || injectText.includes('wait') ? 0.8 : 0.4,
        trust: injectText.includes('trust') || injectText.includes('believe') ? 0.7 : 0.5,
        neutral: 0.3
      },
      awarenessLevel: 0.5 + emotionalIntensity * 0.3,
      selfReflection: injectText,
      currentGoal: 'Process: ' + injectText.slice(0, 30),
      actionPlan: ['perceive', 'analyze', 'respond'],
      planProgress: 0.3,
      knowledgeGraph: {
        'input': [injectText],
        'concepts': injectText.split(' ').slice(0, 5)
      },
      inferredFacts: [`Received input: ${injectText.slice(0, 50)}`]
    };

    world.injectCognition(selectedAgent.id, arcadiaInput);
    setAgents(world.getAgents());

    // Update selected agent
    const updated = world.getAgent(selectedAgent.id);
    if (updated) setSelectedAgent(updated);

    setInjectText('');
  }, [selectedAgent, injectText]);

  // Update resonance
  const handleUpdateResonance = useCallback(() => {
    const world = worldRef.current;
    if (!world) return;

    world.updateResonance();
    setAgents(world.getAgents());

    if (selectedAgent) {
      const updated = world.getAgent(selectedAgent.id);
      if (updated) setSelectedAgent(updated);
    }
  }, [selectedAgent]);

  // Render gate grid
  const renderGateGrid = (activeGates: number[]) => {
    const gates = [];
    for (let i = 1; i <= 64; i++) {
      const isActive = activeGates.includes(i);
      gates.push(
        <div key={i} style={styles.gate(isActive)}>
          {i}
        </div>
      );
    }
    return <div style={styles.gateGrid}>{gates}</div>;
  };

  return (
    <div ref={containerRef} style={styles.container}>
      <canvas ref={canvasRef} style={styles.canvas} />

      {/* Resonance Orb */}
      <div style={styles.resonanceOrb}>
        <div style={{ fontSize: 10, color: '#8899aa', marginBottom: 4 }}>RESONANCE</div>
        <div style={{ fontSize: 20, fontWeight: 700, color: '#64c8ff' }}>
          {Math.round(worldStats.averageResonance * 100)}%
        </div>
        <div style={{ fontSize: 9, color: '#556677', marginTop: 2 }}>
          {worldStats.dominantElement}
        </div>
      </div>

      {/* UI Panel */}
      <div style={styles.uiPanel}>
        <div style={styles.title}>⚡ EMBODIED WORLD</div>

        {/* World Stats */}
        <div style={styles.section}>
          <div style={styles.sectionTitle}>World State</div>
          <div style={styles.statRow}>
            <span style={styles.statLabel}>Agents</span>
            <span style={styles.statValue}>{worldStats.agentCount}</span>
          </div>
          <div style={styles.statRow}>
            <span style={styles.statLabel}>Avg Resonance</span>
            <span style={styles.statValue}>{(worldStats.averageResonance * 100).toFixed(1)}%</span>
          </div>
          <div style={styles.bar}>
            <div style={styles.barFill('#64c8ff', worldStats.averageResonance)} />
          </div>
          <div style={styles.statRow}>
            <span style={styles.statLabel}>Avg Consciousness</span>
            <span style={styles.statValue}>{(worldStats.averageConsciousness * 100).toFixed(1)}%</span>
          </div>
          <div style={styles.bar}>
            <div style={styles.barFill('#ff64c8', worldStats.averageConsciousness)} />
          </div>
          <div style={styles.statRow}>
            <span style={styles.statLabel}>Active Channels</span>
            <span style={styles.statValue}>{worldStats.activeChannels}</span>
          </div>
          <div style={styles.statRow}>
            <span style={styles.statLabel}>Dominant Element</span>
            <span style={styles.statValue}>{worldStats.dominantElement}</span>
          </div>
        </div>

        {/* Controls */}
        <div style={styles.section}>
          <div style={styles.sectionTitle}>Controls</div>
          <button
            style={styles.button}
            onClick={handleSpawn}
            onMouseEnter={e => e.currentTarget.style.background = styles.buttonHover.background!}
            onMouseLeave={e => e.currentTarget.style.background = styles.button.background!}
          >
            + Spawn Agent
          </button>
          <button
            style={styles.button}
            onClick={handleUpdateResonance}
            onMouseEnter={e => e.currentTarget.style.background = styles.buttonHover.background!}
            onMouseLeave={e => e.currentTarget.style.background = styles.button.background!}
          >
            🌙 Update Resonance
          </button>
        </div>

        {/* Agent List */}
        <div style={styles.section}>
          <div style={styles.sectionTitle}>Agents</div>
          <div style={styles.agentList}>
            {agents.map(agent => (
              <div
                key={agent.id}
                style={{
                  ...styles.agentItem,
                  ...(selectedAgent?.id === agent.id ? styles.agentItemSelected : {})
                }}
                onClick={() => setSelectedAgent(agent)}
              >
                <div style={{ fontWeight: 600, color: '#c0d0e0' }}>{agent.name}</div>
                <div style={{ fontSize: 10, color: '#667788' }}>
                  {agent.cognitiveState.humanDesignState.currentArchetype} · 
                  {Math.round(agent.cognitiveState.resonanceScore * 100)}%
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Agent Detail */}
        {selectedAgent && (
          <div style={styles.section}>
            <div style={styles.sectionTitle}>{selectedAgent.name}</div>

            <div style={styles.statRow}>
              <span style={styles.statLabel}>Archetype</span>
              <span style={styles.statValue}>{selectedAgent.cognitiveState.humanDesignState.currentArchetype}</span>
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Consciousness</span>
              <span style={styles.statValue}>{(selectedAgent.cognitiveState.humanDesignState.consciousnessLevel * 100).toFixed(0)}%</span>
            </div>
            <div style={styles.bar}>
              <div style={styles.barFill('#ff64c8', selectedAgent.cognitiveState.humanDesignState.consciousnessLevel)} />
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Resonance</span>
              <span style={styles.statValue}>{(selectedAgent.cognitiveState.resonanceScore * 100).toFixed(0)}%</span>
            </div>
            <div style={styles.bar}>
              <div style={styles.barFill('#64c8ff', selectedAgent.cognitiveState.resonanceScore)} />
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Position</span>
              <span style={styles.statValue}>
                {selectedAgent.position.x.toFixed(1)}, {selectedAgent.position.z.toFixed(1)}
              </span>
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Gates</span>
              <span style={styles.statValue}>{selectedAgent.cognitiveState.humanDesignState.activeGates.length}/64</span>
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Channels</span>
              <span style={styles.statValue}>{selectedAgent.cognitiveState.humanDesignState.channels.length}</span>
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Incarnation Cross</span>
              <span style={styles.statValue}>{selectedAgent.cognitiveState.humanDesignState.incarnationCross}</span>
            </div>

            {/* Gate Grid */}
            <div style={{ marginTop: 8 }}>
              <div style={{ fontSize: 10, color: '#667788', marginBottom: 4 }}>Active Gates</div>
              {renderGateGrid(selectedAgent.cognitiveState.humanDesignState.activeGates)}
            </div>

            {/* Cognition Injection */}
            <div style={{ marginTop: 12 }}>
              <div style={{ fontSize: 10, color: '#667788', marginBottom: 4 }}>Inject Cognition</div>
              <input
                style={styles.input}
                value={injectText}
                onChange={e => setInjectText(e.target.value)}
                placeholder="Enter thought, emotion, or directive..."
                onKeyDown={e => e.key === 'Enter' && handleInject()}
              />
              <button
                style={{ ...styles.button, width: '100%', marginRight: 0 }}
                onClick={handleInject}
                onMouseEnter={e => e.currentTarget.style.background = styles.buttonHover.background!}
                onMouseLeave={e => e.currentTarget.style.background = styles.button.background!}
              >
                🧠 Inject
              </button>
            </div>
          </div>
        )}

        {/* Resonance Field Info */}
        {resonanceField && (
          <div style={styles.section}>
            <div style={styles.sectionTitle}>Current Sky</div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Lunar Phase</span>
              <span style={styles.statValue}>{(resonanceField.lunarPhase * 100).toFixed(0)}%</span>
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Active Gates</span>
              <span style={styles.statValue}>{resonanceField.gateActivations.length}</span>
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Channel Res.</span>
              <span style={styles.statValue}>{(resonanceField.channelResonance * 100).toFixed(0)}%</span>
            </div>
            <div style={styles.statRow}>
              <span style={styles.statLabel}>Cross Res.</span>
              <span style={styles.statValue}>{(resonanceField.crossResonance * 100).toFixed(0)}%</span>
            </div>
            <div style={{ marginTop: 8, fontSize: 10, color: '#556677' }}>
              {resonanceField.positions.slice(0, 5).map(p => (
                <div key={p.planet}>{p.planet}: {p.sign} {p.longitude.toFixed(1)}°</div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmbodiedWorldComponent;
