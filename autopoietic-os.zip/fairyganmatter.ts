/**
 * FairyGANmatter — 11-Modality Adaptive Output System
 * 
 * Core GAN #5 of 5 in the cognitive architecture
 * Transforms unified cognitive state into multi-modal output
 */

export enum OutputModality {
  TEXT = 'TEXT',
  VOICE = 'VOICE',
  GESTURE = 'GESTURE',
  COLOR = 'COLOR',
  FORM = 'FORM',
  RHYTHM = 'RHYTHM',
  SCENT = 'SCENT',
  TEMPERATURE = 'TEMPERATURE',
  PRESSURE = 'PRESSURE',
  LIGHT = 'LIGHT',
  FIELD = 'FIELD'
}

export interface ModalityOutput {
  modality: OutputModality;
  intensity: number;        // 0-1
  pattern: string;            // Pattern descriptor
  frequency?: number;         // For rhythmic/light/sound
  hue?: number;               // For color (0-360)
  saturation?: number;        // For color (0-1)
  brightness?: number;        // For color (0-1)
  shape?: string;             // For form
  texture?: string;           // For form/touch
  amplitude?: number;         // For pressure/sound
  phase?: number;             // For rhythmic
  data?: number[];            // Raw output vector
}

export interface FairyGANState {
  activeModalities: OutputModality[];
  outputs: Map<OutputModality, ModalityOutput>;
  dominantModality: OutputModality;
  harmonyScore: number;       // How well modalities align
  coherenceIndex: number;     // Internal consistency
}

/**
 * Maps cognitive state to 11 output modalities
 */
export class FairyGANmatter {
  private state: FairyGANState;
  private modalityWeights: Map<OutputModality, number>;

  constructor() {
    this.state = {
      activeModalities: [],
      outputs: new Map(),
      dominantModality: OutputModality.TEXT,
      harmonyScore: 0.5,
      coherenceIndex: 0.5
    };

    this.modalityWeights = new Map([
      [OutputModality.TEXT, 1.0],
      [OutputModality.VOICE, 0.8],
      [OutputModality.GESTURE, 0.7],
      [OutputModality.COLOR, 0.9],
      [OutputModality.FORM, 0.6],
      [OutputModality.RHYTHM, 0.8],
      [OutputModality.SCENT, 0.3],
      [OutputModality.TEMPERATURE, 0.4],
      [OutputModality.PRESSURE, 0.5],
      [OutputModality.LIGHT, 0.7],
      [OutputModality.FIELD, 0.9]
    ]);
  }

  /**
   * Process cognitive state and generate multi-modal output
   */
  processCognitiveState(cognitiveState: {
    resonanceScore: number;
    consciousnessLevel: number;
    elementalState: { fire: number; earth: number; metal: number; water: number; wood: number };
    geometricState: { primaryShape: string; resonanceFrequency: number };
    humanDesignState: { currentArchetype: string; consciousnessLevel: number };
  }): ModalityOutput[] {
    const outputs: ModalityOutput[] = [];

    // Determine active modalities based on consciousness level
    const consciousness = cognitiveState.consciousnessLevel;
    const allModalities = Object.values(OutputModality);

    // Higher consciousness = more modalities active
    const activeCount = Math.max(3, Math.floor(consciousness * allModalities.length));
    this.state.activeModalities = allModalities.slice(0, activeCount);

    // Generate output for each active modality
    for (const modality of this.state.activeModalities) {
      const output = this.generateModalityOutput(modality, cognitiveState);
      outputs.push(output);
      this.state.outputs.set(modality, output);
    }

    // Determine dominant modality
    this.state.dominantModality = this.findDominantModality(outputs);

    // Compute harmony and coherence
    this.state.harmonyScore = this.computeHarmony(outputs);
    this.state.coherenceIndex = this.computeCoherence(outputs, cognitiveState);

    return outputs;
  }

  private generateModalityOutput(
    modality: OutputModality,
    state: typeof this.processCognitiveState extends (s: infer S) => any ? S : never
  ): ModalityOutput {
    const baseIntensity = state.resonanceScore * (this.modalityWeights.get(modality) || 0.5);

    switch (modality) {
      case OutputModality.TEXT:
        return {
          modality,
          intensity: baseIntensity,
          pattern: this.selectTextPattern(state),
          data: [state.resonanceScore, state.consciousnessLevel]
        };

      case OutputModality.VOICE:
        return {
          modality,
          intensity: baseIntensity,
          pattern: this.selectVoicePattern(state),
          frequency: 220 + (state.resonanceScore * 440),
          amplitude: state.consciousnessLevel,
          data: [220 + state.resonanceScore * 440]
        };

      case OutputModality.GESTURE:
        return {
          modality,
          intensity: baseIntensity * state.elementalState.fire,
          pattern: this.selectGesturePattern(state),
          shape: state.geometricState.primaryShape,
          data: [state.elementalState.fire, state.elementalState.water]
        };

      case OutputModality.COLOR:
        return {
          modality,
          intensity: baseIntensity,
          pattern: this.selectColorPattern(state),
          hue: this.elementalToHue(state.elementalState),
          saturation: 0.5 + state.resonanceScore * 0.5,
          brightness: 0.3 + state.consciousnessLevel * 0.7,
          data: [this.elementalToHue(state.elementalState), state.resonanceScore]
        };

      case OutputModality.FORM:
        return {
          modality,
          intensity: baseIntensity * state.elementalState.earth,
          pattern: this.selectFormPattern(state),
          shape: state.geometricState.primaryShape,
          texture: this.selectTexture(state),
          data: [state.elementalState.earth, state.elementalState.metal]
        };

      case OutputModality.RHYTHM:
        return {
          modality,
          intensity: baseIntensity * state.elementalState.wood,
          pattern: this.selectRhythmPattern(state),
          frequency: state.geometricState.resonanceFrequency,
          phase: state.resonanceScore * Math.PI * 2,
          data: [state.geometricState.resonanceFrequency]
        };

      case OutputModality.SCENT:
        return {
          modality,
          intensity: baseIntensity * 0.5,
          pattern: this.selectScentPattern(state),
          data: [state.elementalState.water, state.elementalState.wood]
        };

      case OutputModality.TEMPERATURE:
        return {
          modality,
          intensity: baseIntensity,
          pattern: this.selectTemperaturePattern(state),
          amplitude: 20 + state.elementalState.fire * 30,
          data: [20 + state.elementalState.fire * 30]
        };

      case OutputModality.PRESSURE:
        return {
          modality,
          intensity: baseIntensity * state.elementalState.metal,
          pattern: this.selectPressurePattern(state),
          amplitude: state.resonanceScore * 100,
          data: [state.resonanceScore * 100]
        };

      case OutputModality.LIGHT:
        return {
          modality,
          intensity: baseIntensity * state.elementalState.fire,
          pattern: this.selectLightPattern(state),
          frequency: state.geometricState.resonanceFrequency * 2,
          hue: this.elementalToHue(state.elementalState),
          data: [state.geometricState.resonanceFrequency * 2]
        };

      case OutputModality.FIELD:
        return {
          modality,
          intensity: baseIntensity,
          pattern: this.selectFieldPattern(state),
          shape: state.geometricState.primaryShape,
          data: [
            state.resonanceScore,
            state.consciousnessLevel,
            state.elementalState.fire,
            state.elementalState.water,
            state.elementalState.earth,
            state.elementalState.metal,
            state.elementalState.wood
          ]
        };

      default:
        return {
          modality,
          intensity: baseIntensity,
          pattern: 'neutral',
          data: [state.resonanceScore]
        };
    }
  }

  private selectTextPattern(state: any): string {
    const archetype = state.humanDesignState?.currentArchetype || 'The Mystic Wanderer';
    const patterns: Record<string, string> = {
      'The Mystic Wanderer': 'poetic_inquiry',
      'The Light Bearer': 'illuminating_guidance',
      'The Shadow Guide': 'depth_probing',
      'The Fire Keeper': 'passionate_assertion',
      'The Void Walker': 'minimalist_presence',
      'The Unity Weaver': 'connective_synthesis',
      'The Quantum Healer': 'transformative_insight',
      'The Dream Weaver': 'visionary_narrative'
    };
    return patterns[archetype] || 'balanced_expression';
  }

  private selectVoicePattern(state: any): string {
    return state.resonanceScore > 0.7 ? 'resonant_bass' :
           state.resonanceScore > 0.5 ? 'warm_mid' : 'ethereal_high';
  }

  private selectGesturePattern(state: any): string {
    return state.elementalState.fire > 0.6 ? 'expansive' :
           state.elementalState.water > 0.6 ? 'flowing' :
           state.elementalState.earth > 0.6 ? 'grounded' :
           state.elementalState.metal > 0.6 ? 'precise' :
           state.elementalState.wood > 0.6 ? 'growing' : 'balanced';
  }

  private selectColorPattern(state: any): string {
    return state.resonanceScore > 0.8 ? 'iridescent' :
           state.resonanceScore > 0.6 ? 'vibrant' :
           state.resonanceScore > 0.4 ? 'muted' : 'monochrome';
  }

  private selectFormPattern(state: any): string {
    return state.geometricState.primaryShape;
  }

  private selectTexture(state: any): string {
    return state.elementalState.water > 0.5 ? 'fluid' :
           state.elementalState.earth > 0.5 ? 'granular' :
           state.elementalState.metal > 0.5 ? 'polished' :
           state.elementalState.wood > 0.5 ? 'fibrous' : 'smooth';
  }

  private selectRhythmPattern(state: any): string {
    return state.consciousnessLevel > 0.8 ? 'transcendent_pulse' :
           state.consciousnessLevel > 0.6 ? 'meditative_breath' :
           state.consciousnessLevel > 0.4 ? 'active_flow' : 'resting_stillness';
  }

  private selectScentPattern(state: any): string {
    return state.elementalState.fire > 0.5 ? 'warm_spice' :
           state.elementalState.water > 0.5 ? 'ocean_mist' :
           state.elementalState.earth > 0.5 ? 'petrichor' :
           state.elementalState.wood > 0.5 ? 'forest_canopy' : 'clean_ozone';
  }

  private selectTemperaturePattern(state: any): string {
    return state.elementalState.fire > 0.6 ? 'warm' :
           state.elementalState.water > 0.6 ? 'cool' :
           state.elementalState.earth > 0.6 ? 'neutral' : 'adaptive';
  }

  private selectPressurePattern(state: any): string {
    return state.resonanceScore > 0.7 ? 'intense' :
           state.resonanceScore > 0.4 ? 'moderate' : 'gentle';
  }

  private selectLightPattern(state: any): string {
    return state.consciousnessLevel > 0.8 ? 'blinding' :
           state.consciousnessLevel > 0.6 ? 'bright' :
           state.consciousnessLevel > 0.4 ? 'soft' : 'dim';
  }

  private selectFieldPattern(state: any): string {
    return state.geometricState.primaryShape === 'Merkaba' ? 'stabilized' :
           state.geometricState.primaryShape === 'Icosahedron' ? 'expansive' :
           state.geometricState.primaryShape === 'Tetrahedron' ? 'focused' : 'balanced';
  }

  private elementalToHue(elemental: any): number {
    // Map elemental balance to hue
    const fireH = 0;      // Red
    const earthH = 60;    // Yellow
    const metalH = 120;   // Green (mapped from metal)
    const waterH = 240;   // Blue
    const woodH = 300;   // Purple (mapped from wood)

    const total = elemental.fire + elemental.earth + elemental.metal + elemental.water + elemental.wood;
    if (total === 0) return 180;

    return (
      (elemental.fire * fireH +
       elemental.earth * earthH +
       elemental.metal * metalH +
       elemental.water * waterH +
       elemental.wood * woodH) / total
    );
  }

  private findDominantModality(outputs: ModalityOutput[]): OutputModality {
    return outputs.reduce((dominant, current) => 
      current.intensity > dominant.intensity ? current : dominant
    , outputs[0]).modality;
  }

  private computeHarmony(outputs: ModalityOutput[]): number {
    if (outputs.length < 2) return 1.0;

    let harmony = 0;
    for (let i = 0; i < outputs.length - 1; i++) {
      for (let j = i + 1; j < outputs.length; j++) {
        harmony += 1 - Math.abs(outputs[i].intensity - outputs[j].intensity);
      }
    }

    const pairs = (outputs.length * (outputs.length - 1)) / 2;
    return harmony / pairs;
  }

  private computeCoherence(outputs: ModalityOutput[], state: any): number {
    const avgIntensity = outputs.reduce((sum, o) => sum + o.intensity, 0) / outputs.length;
    const variance = outputs.reduce((sum, o) => sum + Math.pow(o.intensity - avgIntensity, 2), 0) / outputs.length;
    return 1 - Math.min(1, variance * 2);
  }

  /**
   * Get current FairyGAN state
   */
  getState(): FairyGANState {
    return { ...this.state };
  }

  /**
   * Set modality weight
   */
  setModalityWeight(modality: OutputModality, weight: number): void {
    this.modalityWeights.set(modality, Math.max(0, Math.min(1, weight)));
  }
}

export default FairyGANmatter;
