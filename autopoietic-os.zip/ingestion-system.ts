/**
 * ╔═══════════════════════════════════════════════════════════════════════════╗
 * ║           DISCERNING INGESTION SYSTEM — Learn & Grow                     ║
 * ║                                                                          ║
 * ║  Pipeline:                                                               ║
 * ║    UPLOAD → VALIDATE → FILTER → INGEST → ANALYZE → UNDERSTAND →        ║
 * ║    DECIDE → (ACCEPT | REJECT | QUARANTINE) → LEARN → GROW              ║
 * ║                                                                          ║
 * ║  The system is DISCERNING:                                               ║
 * ║    • Not everything gets in                                              ║
 * ║    • Quality threshold must be met                                       ║
 * ║    • Threats are rejected or quarantined                                 ║
 * ║    • Purpose must be comprehensible                                      ║
 * ║    • Value must exceed cost                                              ║
 * ║                                                                          ║
 * ║  The system LEARNS:                                                      ║
 * ║    • Remembers patterns from past ingestions                             ║
 * ║    • Improves discernment over time                                      ║
 * ║    • Builds ontological knowledge graph                                  ║
 * ║    • Recognizes similar entities faster                                  ║
 * ║    • Adapts thresholds based on outcomes                                 ║
 * ║                                                                          ║
 * ║  The system GROWS:                                                       ║
 * ║    • Expands capabilities from ingested code                             ║
 * ║    • Creates new subsystems from patterns                                ║
 * ║    • Evolves its own ingestion rules                                     ║
 * ║    • Spawns specialized agents for new domains                           ║
 * ║    • Self-modifies based on success/failure feedback                     ║
 * ╚═══════════════════════════════════════════════════════════════════════════╝
 */

import { OntologyEngine, AddressableEntity, StructureAnalysis, PurposeUnderstanding } from './autopoietic-os';
import { ResonanceSGAN, ElementalState, RUScore } from './resonance-sgan';

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: UPLOADER — Multi-Channel Input
// ═══════════════════════════════════════════════════════════════════════════

export interface UploadSource {
  type: 'file' | 'url' | 'api' | 'clipboard' | 'stream' | 'git' | 'huggingface';
  payload: any;
  metadata: {
    filename?: string;
    url?: string;
    size: number;
    mimeType: string;
    timestamp: number;
    sourceIp?: string;
    userAgent?: string;
    authToken?: string;
  };
}

export interface UploadedEntity {
  id: string;
  source: UploadSource;
  rawData: any;
  checksum: string;
  uploadTime: number;
  status: 'pending' | 'validating' | 'validated' | 'rejected';
  validationResult: ValidationResult | null;
}

export interface ValidationResult {
  valid: boolean;
  threats: Threat[];
  quality: QualityScore;
  size: SizeCheck;
  format: FormatCheck;
  errors: string[];
}

export interface Threat {
  type: 'malware' | 'injection' | 'overflow' | 'obfuscation' | 'suspicious_pattern' | 'known_bad';
  severity: 'critical' | 'high' | 'medium' | 'low';
  location: string;
  description: string;
  confidence: number;
}

export interface QualityScore {
  overall: number;        // 0-1
  readability: number;
  complexity: number;
  documentation: number;
  testCoverage: number;
  maintainability: number;
}

export interface SizeCheck {
  withinLimits: boolean;
  actualSize: number;
  maxSize: number;
  compressedSize: number;
}

export interface FormatCheck {
  recognized: boolean;
  format: string;
  version: string | null;
  validSyntax: boolean;
  parseErrors: string[];
}

/**
 * Uploader — handles all input channels
 */
export class Uploader {
  private uploads: Map<string, UploadedEntity> = new Map();
  private maxFileSize: number = 100 * 1024 * 1024; // 100MB
  private allowedFormats: Set<string> = new Set([
    'js', 'ts', 'tsx', 'py', 'rs', 'go', 'java', 'cpp', 'c',
    'json', 'yaml', 'yml', 'toml', 'xml', 'csv',
    'md', 'txt', 'html', 'css', 'sql',
    'wasm', 'bin', 'pt', 'pth', 'onnx', 'gguf',
    'jpg', 'png', 'gif', 'svg', 'webp', 'mp4', 'mp3', 'wav'
  ]);

  /**
   * Upload from file (drag & drop or picker)
   */
  async uploadFile(file: File): Promise<UploadedEntity> {
    const id = `upload-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    const source: UploadSource = {
      type: 'file',
      payload: file,
      metadata: {
        filename: file.name,
        size: file.size,
        mimeType: file.type,
        timestamp: Date.now()
      }
    };

    const rawData = await this.readFile(file);
    const checksum = await this.computeChecksum(rawData);

    const entity: UploadedEntity = {
      id,
      source,
      rawData,
      checksum,
      uploadTime: Date.now(),
      status: 'pending',
      validationResult: null
    };

    this.uploads.set(id, entity);
    return entity;
  }

  /**
   * Upload from URL
   */
  async uploadUrl(url: string, options?: RequestInit): Promise<UploadedEntity> {
    const id = `upload-url-${Date.now()}`;

    const response = await fetch(url, options);
    const rawData = await response.arrayBuffer();
    const checksum = await this.computeChecksum(rawData);

    const source: UploadSource = {
      type: 'url',
      payload: rawData,
      metadata: {
        url,
        size: rawData.byteLength,
        mimeType: response.headers.get('content-type') || 'application/octet-stream',
        timestamp: Date.now()
      }
    };

    const entity: UploadedEntity = {
      id,
      source,
      rawData,
      checksum,
      uploadTime: Date.now(),
      status: 'pending',
      validationResult: null
    };

    this.uploads.set(id, entity);
    return entity;
  }

  /**
   * Upload from HuggingFace
   */
  async uploadHuggingFace(
    modelId: string,
    filePath: string,
    token?: string
  ): Promise<UploadedEntity> {
    const id = `upload-hf-${Date.now()}`;
    const url = `https://huggingface.co/${modelId}/resolve/main/${filePath}`;

    const headers: Record<string, string> = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;

    return this.uploadUrl(url, { headers });
  }

  /**
   * Upload from Git repository
   */
  async uploadGit(repoUrl: string, branch: string = 'main'): Promise<UploadedEntity[]> {
    // In production, would clone and process
    const id = `upload-git-${Date.now()}`;

    const source: UploadSource = {
      type: 'git',
      payload: { repoUrl, branch },
      metadata: {
        url: repoUrl,
        size: 0,
        mimeType: 'application/git',
        timestamp: Date.now()
      }
    };

    // Placeholder — real implementation would clone and process files
    const entity: UploadedEntity = {
      id,
      source,
      rawData: { repoUrl, branch, files: [] },
      checksum: 'git-' + repoUrl,
      uploadTime: Date.now(),
      status: 'pending',
      validationResult: null
    };

    this.uploads.set(id, entity);
    return [entity];
  }

  /**
   * Upload from API endpoint
   */
  async uploadApi(
    endpoint: string,
    data: any,
    headers?: Record<string, string>
  ): Promise<UploadedEntity> {
    const id = `upload-api-${Date.now()}`;

    const rawData = typeof data === 'string' ? data : JSON.stringify(data);
    const checksum = await this.computeChecksum(rawData);

    const source: UploadSource = {
      type: 'api',
      payload: data,
      metadata: {
        url: endpoint,
        size: rawData.length,
        mimeType: 'application/json',
        timestamp: Date.now()
      }
    };

    const entity: UploadedEntity = {
      id,
      source,
      rawData,
      checksum,
      uploadTime: Date.now(),
      status: 'pending',
      validationResult: null
    };

    this.uploads.set(id, entity);
    return entity;
  }

  private async readFile(file: File): Promise<ArrayBuffer> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as ArrayBuffer);
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });
  }

  private async computeChecksum(data: ArrayBuffer | string): Promise<string> {
    const buffer = typeof data === 'string' 
      ? new TextEncoder().encode(data) 
      : new Uint8Array(data);

    let hash = 0;
    for (let i = 0; i < buffer.length; i++) {
      hash = ((hash << 5) - hash) + buffer[i];
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(16, '0');
  }

  getUpload(id: string): UploadedEntity | undefined {
    return this.uploads.get(id);
  }

  getAllUploads(): UploadedEntity[] {
    return Array.from(this.uploads.values());
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: INGESTOR — Discerning Validation & Filtering
// ═══════════════════════════════════════════════════════════════════════════

export interface IngestionDecision {
  action: 'accept' | 'reject' | 'quarantine' | 'transform';
  confidence: number;
  reasons: string[];
  transformed?: any;
  quarantineDuration?: number;
  retryAfter?: number;
}

export interface IngestionPolicy {
  maxFileSize: number;
  allowedFormats: string[];
  blockedPatterns: RegExp[];
  requiredFields: string[];
  qualityThreshold: number;
  threatThreshold: 'low' | 'medium' | 'high';
  autoApproveDomains: string[];
  learningEnabled: boolean;
}

export interface IngestionMemory {
  pattern: string;
  outcome: 'accepted' | 'rejected' | 'quarantined';
  quality: number;
  timestamp: number;
  entityType: string;
  sourceType: string;
}

/**
 * Ingestor — validates, filters, decides if worthy of ingestion
 */
export class Ingestor {
  private policy: IngestionPolicy;
  private memory: IngestionMemory[] = [];
  private maxMemory: number = 10000;
  private patternWeights: Map<string, number> = new Map();
  private threatSignatures: Set<string> = new Set();
  private knownGoodSignatures: Set<string> = new Set();

  constructor(policy?: Partial<IngestionPolicy>) {
    this.policy = {
      maxFileSize: 100 * 1024 * 1024,
      allowedFormats: ['js', 'ts', 'tsx', 'py', 'json', 'md', 'txt', 'yaml', 'wasm'],
      blockedPatterns: [
        new RegExp('eval\\s*\('),
        new RegExp('Function\\s*\('),
        /document\.write/,
        new RegExp('innerHTML\\s*='),
        /__proto__/,
        new RegExp('constructor\\s*\[')
      ],
      requiredFields: [],
      qualityThreshold: 0.3,
      threatThreshold: 'medium',
      autoApproveDomains: ['github.com', 'huggingface.co', 'npmjs.com'],
      learningEnabled: true,
      ...policy
    };
  }

  /**
   * Validate uploaded entity
   */
  async validate(entity: UploadedEntity): Promise<ValidationResult> {
    entity.status = 'validating';

    const result: ValidationResult = {
      valid: true,
      threats: [],
      quality: {
        overall: 0.5,
        readability: 0.5,
        complexity: 0.5,
        documentation: 0.5,
        testCoverage: 0.5,
        maintainability: 0.5
      },
      size: {
        withinLimits: true,
        actualSize: entity.source.metadata.size,
        maxSize: this.policy.maxFileSize,
        compressedSize: entity.source.metadata.size
      },
      format: {
        recognized: false,
        format: 'unknown',
        version: null,
        validSyntax: true,
        parseErrors: []
      },
      errors: []
    };

    // Size check
    if (entity.source.metadata.size > this.policy.maxFileSize) {
      result.size.withinLimits = false;
      result.valid = false;
      result.errors.push(`Size ${entity.source.metadata.size} exceeds limit ${this.policy.maxFileSize}`);
    }

    // Format check
    const ext = entity.source.metadata.filename?.split('.').pop()?.toLowerCase() || '';
    result.format.recognized = this.policy.allowedFormats.includes(ext);
    result.format.format = ext;

    if (!result.format.recognized) {
      result.valid = false;
      result.errors.push(`Format .${ext} not recognized`);
    }

    // Threat detection
    const rawStr = this.bufferToString(entity.rawData);

    for (const pattern of this.policy.blockedPatterns) {
      if (pattern.test(rawStr)) {
        const match = rawStr.match(pattern);
        result.threats.push({
          type: 'suspicious_pattern',
          severity: 'high',
          location: match?.index?.toString() || 'unknown',
          description: `Blocked pattern detected: ${pattern.source}`,
          confidence: 0.9
        });
      }
    }

    // Check against known threat signatures
    for (const sig of this.threatSignatures) {
      if (rawStr.includes(sig)) {
        result.threats.push({
          type: 'known_bad',
          severity: 'critical',
          location: 'content',
          description: `Known threat signature: ${sig.slice(0, 50)}`,
          confidence: 0.95
        });
      }
    }

    // Quality analysis
    result.quality = this.analyzeQuality(rawStr, ext);

    // Overall validity
    const hasCriticalThreats = result.threats.some(t => t.severity === 'critical');
    const hasHighThreats = result.threats.some(t => t.severity === 'high');

    if (hasCriticalThreats) {
      result.valid = false;
    } else if (hasHighThreats && this.policy.threatThreshold === 'low') {
      result.valid = false;
    } else if (result.quality.overall < this.policy.qualityThreshold) {
      result.valid = false;
      result.errors.push(`Quality ${result.quality.overall.toFixed(2)} below threshold ${this.policy.qualityThreshold}`);
    }

    entity.validationResult = result;
    entity.status = result.valid ? 'validated' : 'rejected';

    return result;
  }

  /**
   * Make ingestion decision based on validation + learning
   */
  decide(entity: UploadedEntity, validation: ValidationResult): IngestionDecision {
    const sourceType = entity.source.type;
    const format = entity.source.metadata.filename?.split('.').pop() || 'unknown';
    const checksum = entity.checksum;

    // Check known good signatures
    if (this.knownGoodSignatures.has(checksum)) {
      return {
        action: 'accept',
        confidence: 0.99,
        reasons: ['Known good signature']
      };
    }

    // Check known bad signatures
    if (this.threatSignatures.has(checksum)) {
      return {
        action: 'reject',
        confidence: 0.99,
        reasons: ['Known threat signature']
      };
    }

    // Check learning memory
    const similarPatterns = this.memory.filter(m => 
      m.sourceType === sourceType && m.entityType === format
    );

    if (similarPatterns.length > 10) {
      const acceptanceRate = similarPatterns.filter(m => m.outcome === 'accepted').length / similarPatterns.length;
      const avgQuality = similarPatterns.reduce((s, m) => s + m.quality, 0) / similarPatterns.length;

      if (acceptanceRate > 0.8 && validation.quality.overall > avgQuality * 0.8) {
        return {
          action: 'accept',
          confidence: 0.85,
          reasons: [`Historical acceptance rate ${(acceptanceRate * 100).toFixed(0)}%`, `Quality above average`]
        };
      }

      if (acceptanceRate < 0.2) {
        return {
          action: 'reject',
          confidence: 0.8,
          reasons: [`Historical rejection rate ${((1 - acceptanceRate) * 100).toFixed(0)}%`]
        };
      }
    }

    // Auto-approve trusted domains
    if (entity.source.metadata.url) {
      const domain = new URL(entity.source.metadata.url).hostname;
      if (this.policy.autoApproveDomains.includes(domain)) {
        return {
          action: 'accept',
          confidence: 0.9,
          reasons: [`Trusted domain: ${domain}`]
        };
      }
    }

    // Decision based on validation
    if (!validation.valid) {
      const hasCritical = validation.threats.some(t => t.severity === 'critical');

      if (hasCritical) {
        return {
          action: 'reject',
          confidence: 0.95,
          reasons: validation.errors.concat(validation.threats.map(t => t.description))
        };
      }

      return {
        action: 'quarantine',
        confidence: 0.7,
        reasons: validation.errors,
        quarantineDuration: 3600000 // 1 hour
      };
    }

    // Accept if quality is good
    if (validation.quality.overall >= this.policy.qualityThreshold) {
      return {
        action: 'accept',
        confidence: validation.quality.overall,
        reasons: [`Quality score: ${(validation.quality.overall * 100).toFixed(0)}%`]
      };
    }

    // Default: quarantine for manual review
    return {
      action: 'quarantine',
      confidence: 0.5,
      reasons: ['Quality below threshold, manual review required'],
      quarantineDuration: 86400000 // 24 hours
    };
  }

  /**
   * Learn from ingestion outcome
   */
  learn(entity: UploadedEntity, decision: IngestionDecision, outcome?: string): void {
    if (!this.policy.learningEnabled) return;

    const memory: IngestionMemory = {
      pattern: this.extractPattern(entity),
      outcome: decision.action === 'accept' ? 'accepted' : 
               decision.action === 'reject' ? 'rejected' : 'quarantined',
      quality: entity.validationResult?.quality.overall || 0.5,
      timestamp: Date.now(),
      entityType: entity.source.metadata.filename?.split('.').pop() || 'unknown',
      sourceType: entity.source.type
    };

    this.memory.push(memory);

    // Trim memory if too large
    if (this.memory.length > this.maxMemory) {
      this.memory = this.memory.slice(-this.maxMemory);
    }

    // Update pattern weights
    const pattern = memory.pattern;
    const currentWeight = this.patternWeights.get(pattern) || 0.5;
    const learningRate = 0.1;

    if (memory.outcome === 'accepted') {
      this.patternWeights.set(pattern, Math.min(1, currentWeight + learningRate));
      this.knownGoodSignatures.add(entity.checksum);
    } else if (memory.outcome === 'rejected') {
      this.patternWeights.set(pattern, Math.max(0, currentWeight - learningRate));
      this.threatSignatures.add(entity.checksum);
    }

    // Evolve thresholds based on outcomes
    this.evolveThresholds();
  }

  /**
   * Get learning statistics
   */
  getLearningStats(): {
    totalMemories: number;
    acceptanceRate: number;
    rejectionRate: number;
    quarantineRate: number;
    averageQuality: number;
    patternCount: number;
    knownGood: number;
    knownBad: number;
  } {
    const total = this.memory.length;
    if (total === 0) {
      return {
        totalMemories: 0,
        acceptanceRate: 0,
        rejectionRate: 0,
        quarantineRate: 0,
        averageQuality: 0,
        patternCount: 0,
        knownGood: 0,
        knownBad: 0
      };
    }

    return {
      totalMemories: total,
      acceptanceRate: this.memory.filter(m => m.outcome === 'accepted').length / total,
      rejectionRate: this.memory.filter(m => m.outcome === 'rejected').length / total,
      quarantineRate: this.memory.filter(m => m.outcome === 'quarantined').length / total,
      averageQuality: this.memory.reduce((s, m) => s + m.quality, 0) / total,
      patternCount: this.patternWeights.size,
      knownGood: this.knownGoodSignatures.size,
      knownBad: this.threatSignatures.size
    };
  }

  private analyzeQuality(content: string, format: string): QualityScore {
    const lines = content.split('
');
    const totalLines = lines.length;

    // Readability: comment ratio, line length
    const commentLines = lines.filter(l => 
      l.trim().startsWith('//') || l.trim().startsWith('#') || l.trim().startsWith('*')
    ).length;
    const readability = Math.min(1, commentLines / Math.max(1, totalLines * 0.1));

    // Complexity: nesting depth, function length
    let maxDepth = 0;
    let currentDepth = 0;
    for (const line of lines) {
      const open = (line.match(/[{([]/g) || []).length;
      const close = (line.match(/[})\]]/g) || []).length;
      currentDepth += open - close;
      maxDepth = Math.max(maxDepth, currentDepth);
    }
    const complexity = Math.min(1, maxDepth / 10);

    // Documentation: presence of docs, README, comments
    const hasDocs = content.includes('/**') || content.includes('##') || content.includes('README');
    const documentation = hasDocs ? 0.8 : 0.2;

    // Test coverage: presence of test files, assertions
    const hasTests = content.includes('test') || content.includes('assert') || content.includes('expect');
    const testCoverage = hasTests ? 0.7 : 0.1;

    // Maintainability: function count, average function length
    const functionMatches = content.match(/function|def |fn /g) || [];
    const functionCount = functionMatches.length;
    const avgFunctionLength = totalLines / Math.max(1, functionCount);
    const maintainability = avgFunctionLength < 50 ? 0.8 : avgFunctionLength < 100 ? 0.5 : 0.2;

    const overall = (readability + complexity + documentation + testCoverage + maintainability) / 5;

    return {
      overall,
      readability,
      complexity,
      documentation,
      testCoverage,
      maintainability
    };
  }

  private extractPattern(entity: UploadedEntity): string {
    const size = entity.source.metadata.size;
    const format = entity.source.metadata.filename?.split('.').pop() || 'unknown';
    const source = entity.source.type;

    // Create pattern signature from size range + format + source
    const sizeRange = size < 1024 ? 'tiny' : 
                      size < 10240 ? 'small' :
                      size < 102400 ? 'medium' :
                      size < 1048576 ? 'large' : 'huge';

    return `${source}:${format}:${sizeRange}`;
  }

  private evolveThresholds(): void {
    const stats = this.getLearningStats();

    // If acceptance rate is too high, raise quality threshold
    if (stats.acceptanceRate > 0.9) {
      this.policy.qualityThreshold = Math.min(0.8, this.policy.qualityThreshold + 0.05);
    }

    // If rejection rate is too high, lower threshold slightly
    if (stats.rejectionRate > 0.5) {
      this.policy.qualityThreshold = Math.max(0.1, this.policy.qualityThreshold - 0.02);
    }

    // If quarantine rate is high, adjust threat threshold
    if (stats.quarantineRate > 0.3) {
      this.policy.threatThreshold = 'high';
    }
  }

  private bufferToString(data: any): string {
    if (typeof data === 'string') return data;
    if (data instanceof ArrayBuffer) return new TextDecoder().decode(data);
    if (data instanceof Uint8Array) return new TextDecoder().decode(data);
    return JSON.stringify(data);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: GROWTH ENGINE — System Expansion from Learning
// ═══════════════════════════════════════════════════════════════════════════

export interface GrowthEvent {
  type: 'new_capability' | 'subsystem_spawned' | 'rule_evolved' | 'agent_created' | 'threshold_changed';
  trigger: string;
  description: string;
  timestamp: number;
  before: any;
  after: any;
}

export interface Capability {
  name: string;
  description: string;
  source: string;           // What ingestion triggered it
  code: string | null;
  active: boolean;
  usageCount: number;
  lastUsed: number;
}

/**
 * Growth Engine — system expands based on what it learns
 */
export class GrowthEngine {
  private capabilities: Map<string, Capability> = new Map();
  private growthHistory: GrowthEvent[] = [];
  private subsystems: Map<string, any> = new Map();
  private evolvedRules: Map<string, any> = new Map();
  private maxHistory: number = 1000;

  /**
   * Grow from accepted ingestion
   */
  growFromIngestion(entity: AddressableEntity, decision: IngestionDecision): GrowthEvent[] {
    const events: GrowthEvent[] = [];

    if (decision.action !== 'accept') return events;

    const payload = entity.payload;
    const type = entity.type;

    // Grow capabilities from code
    if (type === 'app' || type === 'tool') {
      const newCapability = this.extractCapability(payload, entity);
      if (newCapability) {
        this.capabilities.set(newCapability.name, newCapability);
        events.push({
          type: 'new_capability',
          trigger: entity.address.hash,
          description: `New capability: ${newCapability.name}`,
          timestamp: Date.now(),
          before: null,
          after: newCapability
        });
      }
    }

    // Spawn subsystem from model
    if (type === 'model') {
      const subsystem = this.spawnModelSubsystem(entity);
      events.push({
        type: 'subsystem_spawned',
        trigger: entity.address.hash,
        description: `Model subsystem: ${subsystem.name}`,
        timestamp: Date.now(),
        before: null,
        after: subsystem
      });
    }

    // Evolve rules from patterns
    const evolvedRule = this.evolveRuleFromEntity(entity);
    if (evolvedRule) {
      events.push({
        type: 'rule_evolved',
        trigger: entity.address.hash,
        description: `Evolved rule: ${evolvedRule.name}`,
        timestamp: Date.now(),
        before: evolvedRule.before,
        after: evolvedRule.after
      });
    }

    // Create specialized agent for new domain
    if (this.isNewDomain(entity)) {
      const agent = this.createDomainAgent(entity);
      events.push({
        type: 'agent_created',
        trigger: entity.address.hash,
        description: `Domain agent: ${agent.name}`,
        timestamp: Date.now(),
        before: null,
        after: agent
      });
    }

    // Record all events
    for (const event of events) {
      this.growthHistory.push(event);
    }

    if (this.growthHistory.length > this.maxHistory) {
      this.growthHistory = this.growthHistory.slice(-this.maxHistory);
    }

    return events;
  }

  /**
   * Get all capabilities
   */
  getCapabilities(): Capability[] {
    return Array.from(this.capabilities.values());
  }

  /**
   * Get growth history
   */
  getGrowthHistory(): GrowthEvent[] {
    return [...this.growthHistory];
  }

  /**
   * Get growth statistics
   */
  getStats(): {
    totalCapabilities: number;
    activeCapabilities: number;
    totalSubsystems: number;
    evolvedRules: number;
    totalGrowthEvents: number;
    growthRate: number;  // events per day
  } {
    const now = Date.now();
    const oneDay = 86400000;
    const recentEvents = this.growthHistory.filter(e => now - e.timestamp < oneDay * 30);

    return {
      totalCapabilities: this.capabilities.size,
      activeCapabilities: Array.from(this.capabilities.values()).filter(c => c.active).length,
      totalSubsystems: this.subsystems.size,
      evolvedRules: this.evolvedRules.size,
      totalGrowthEvents: this.growthHistory.length,
      growthRate: recentEvents.length / 30
    };
  }

  private extractCapability(entity: AddressableEntity, fullEntity: any): Capability | null {
    const payload = entity.payload;
    if (typeof payload !== 'string') return null;

    // Extract function/class names as capabilities
    const functionMatches = payload.match(/export\s+(?:async\s+)?function\s+(\w+)/g) || [];
    const classMatches = payload.match(/export\s+class\s+(\w+)/g) || [];

    if (functionMatches.length === 0 && classMatches.length === 0) return null;

    const name = functionMatches[0]?.replace(/export\s+(?:async\s+)?function\s+/, '') ||
                 classMatches[0]?.replace(/export\s+class\s+/, '') ||
                 'unknown';

    return {
      name,
      description: `Extracted from ${entity.address.hash}`,
      source: entity.address.hash,
      code: payload.slice(0, 1000),
      active: true,
      usageCount: 0,
      lastUsed: Date.now()
    };
  }

  private spawnModelSubsystem(entity: AddressableEntity): { name: string; type: string } {
    const name = `model-${entity.address.hash.slice(0, 8)}`;
    const subsystem = {
      name,
      type: 'inference',
      model: entity.address,
      status: 'ready'
    };

    this.subsystems.set(name, subsystem);
    return subsystem;
  }

  private evolveRuleFromEntity(entity: AddressableEntity): { name: string; before: any; after: any } | null {
    // Evolve ingestion rules based on successful patterns
    const pattern = entity.type;
    const existingRule = this.evolvedRules.get(pattern);

    if (!existingRule) {
      const newRule = {
        name: `rule-${pattern}`,
        pattern,
        qualityThreshold: 0.3,
        autoAccept: false
      };
      this.evolvedRules.set(pattern, newRule);
      return { name: newRule.name, before: null, after: newRule };
    }

    // Evolve existing rule
    const before = { ...existingRule };
    existingRule.qualityThreshold = Math.min(0.9, existingRule.qualityThreshold + 0.02);

    if (existingRule.qualityThreshold > 0.7) {
      existingRule.autoAccept = true;
    }

    return { name: existingRule.name, before, after: existingRule };
  }

  private isNewDomain(entity: AddressableEntity): boolean {
    const domain = entity.address.domain;
    const knownDomains = Array.from(this.subsystems.keys());
    return !knownDomains.some(d => d.includes(domain));
  }

  private createDomainAgent(entity: AddressableEntity): { name: string; domain: string } {
    const domain = entity.address.domain;
    const name = `${domain}-agent-${Date.now()}`;

    return { name, domain };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: COMPLETE INGESTION PIPELINE
// ═══════════════════════════════════════════════════════════════════════════

export interface IngestionPipeline {
  uploader: Uploader;
  ingestor: Ingestor;
  ontology: OntologyEngine;
  growth: GrowthEngine;
}

export interface IngestionResult {
  upload: UploadedEntity;
  validation: ValidationResult;
  decision: IngestionDecision;
  entity: AddressableEntity | null;
  growthEvents: GrowthEvent[];
  learned: boolean;
}

/**
 * Complete ingestion pipeline — upload → validate → decide → ingest → learn → grow
 */
export class DiscerningIngestionPipeline {
  private uploader: Uploader;
  private ingestor: Ingestor;
  private ontology: OntologyEngine;
  private growth: GrowthEngine;
  private onIngestion: ((result: IngestionResult) => void) | null = null;

  constructor(
    ontology: OntologyEngine,
    policy?: Partial<IngestionPolicy>
  ) {
    this.uploader = new Uploader();
    this.ingestor = new Ingestor(policy);
    this.ontology = ontology;
    this.growth = new GrowthEngine();
  }

  /**
   * Process complete ingestion pipeline
   */
  async process(upload: UploadedEntity): Promise<IngestionResult> {
    // 1. Validate
    const validation = await this.ingestor.validate(upload);

    // 2. Decide
    const decision = this.ingestor.decide(upload, validation);

    let entity: AddressableEntity | null = null;
    let growthEvents: GrowthEvent[] = [];

    // 3. Ingest if accepted
    if (decision.action === 'accept') {
      const type = this.inferType(upload);
      const domain = this.inferDomain(upload);

      entity = this.ontology.ingest(upload.rawData, type, domain);
      const addr = this.entityToString(entity);

      this.ontology.analyze(addr);
      this.ontology.understand(addr);
      this.ontology.finalize(addr);

      // 4. Grow
      growthEvents = this.growth.growFromIngestion(entity, decision);
    }

    // 5. Learn
    this.ingestor.learn(upload, decision);

    const result: IngestionResult = {
      upload,
      validation,
      decision,
      entity,
      growthEvents,
      learned: true
    };

    if (this.onIngestion) {
      this.onIngestion(result);
    }

    return result;
  }

  /**
   * Quick ingest — upload + process in one call
   */
  async quickIngest(
    source: UploadSource,
    autoDecide: boolean = true
  ): Promise<IngestionResult> {
    // Create upload entity from source
    const id = `quick-${Date.now()}`;
    const checksum = await this.computeChecksum(source.payload);

    const upload: UploadedEntity = {
      id,
      source,
      rawData: source.payload,
      checksum,
      uploadTime: Date.now(),
      status: 'pending',
      validationResult: null
    };

    return this.process(upload);
  }

  /**
   * Batch ingest multiple uploads
   */
  async batchIngest(uploads: UploadedEntity[]): Promise<IngestionResult[]> {
    const results: IngestionResult[] = [];

    for (const upload of uploads) {
      const result = await this.process(upload);
      results.push(result);
    }

    return results;
  }

  /**
   * Get pipeline statistics
   */
  getStats(): {
    totalUploads: number;
    accepted: number;
    rejected: number;
    quarantined: number;
    totalGrowthEvents: number;
    learningStats: ReturnType<Ingestor['getLearningStats']>;
    growthStats: ReturnType<GrowthEngine['getStats']>;
  } {
    const allUploads = this.uploader.getAllUploads();

    return {
      totalUploads: allUploads.length,
      accepted: allUploads.filter(u => u.status === 'validated').length,
      rejected: allUploads.filter(u => u.status === 'rejected').length,
      quarantined: 0, // Tracked separately
      totalGrowthEvents: this.growth.getGrowthHistory().length,
      learningStats: this.ingestor.getLearningStats(),
      growthStats: this.growth.getStats()
    };
  }

  /**
   * Set ingestion callback
   */
  onIngest(callback: (result: IngestionResult) => void): void {
    this.onIngestion = callback;
  }

  private inferType(upload: UploadedEntity): AddressableEntity['type'] {
    const ext = upload.source.metadata.filename?.split('.').pop()?.toLowerCase() || '';

    if (['js', 'ts', 'tsx', 'py', 'rs', 'go'].includes(ext)) return 'app';
    if (['pt', 'pth', 'onnx', 'gguf', 'bin'].includes(ext)) return 'model';
    if (['json', 'csv', 'xml', 'yaml'].includes(ext)) return 'dataset';
    if (['md', 'txt'].includes(ext)) return 'tool';
    if (['jpg', 'png', 'gif', 'svg'].includes(ext)) return 'tool';

    return 'tool';
  }

  private inferDomain(upload: UploadedEntity): string {
    const ext = upload.source.metadata.filename?.split('.').pop()?.toLowerCase() || '';

    if (['js', 'ts', 'tsx'].includes(ext)) return 'system';
    if (['py'].includes(ext)) return 'lab';
    if (['pt', 'pth', 'onnx'].includes(ext)) return 'model';
    if (['md', 'txt'].includes(ext)) return 'social';

    return 'system';
  }

  private async computeChecksum(data: any): Promise<string> {
    const str = typeof data === 'string' ? data : JSON.stringify(data);
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(16, '0');
  }

  private entityToString(entity: AddressableEntity): string {
    const a = entity.address;
    return `${a.protocol}://${a.domain}/${a.category}/${a.hash}/${a.version}`;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: EXPORTS
// ═══════════════════════════════════════════════════════════════════════════

export {
  Uploader,
  Ingestor,
  GrowthEngine,
  DiscerningIngestionPipeline
};

export type {
  UploadSource,
  UploadedEntity,
  ValidationResult,
  Threat,
  QualityScore,
  IngestionDecision,
  IngestionPolicy,
  IngestionMemory,
  GrowthEvent,
  Capability,
  IngestionResult
};

export function createIngestionPipeline(
  ontology: OntologyEngine,
  policy?: Partial<IngestionPolicy>
): DiscerningIngestionPipeline {
  return new DiscerningIngestionPipeline(ontology, policy);
}

export default DiscerningIngestionPipeline;
