/**
 * Resonance S-GAN — Elemental Algebra & RU Scoring
 * 
 * Core GAN #1 of 5 in the cognitive architecture
 * Computes resonance scores from elemental interactions
 */

export interface ElementalState {
  fire: number;      // 0-1
  earth: number;     // 0-1
  metal: number;     // 0-1 (maps to air in 4-element)
  water: number;     // 0-1
  wood: number;      // 0-1 (maps to earth/plant in 4-element)
}

export interface RUScore {
  resonance: number;     // Overall resonance 0-1
  unity: number;         // Unity score 0-1
  tension: number;       // Creative tension 0-1
  flow: number;          // Energy flow 0-1
  stability: number;     // Structural stability 0-1
  transformation: number; // Change potential 0-1
}

export interface ElementalInteraction {
  source: keyof ElementalState;
  target: keyof ElementalState;
  relationship: 'generates' | 'controls' | 'drains' | 'harmonizes' | 'conflicts';
  strength: number;      // 0-1
  direction: number;     // -1 to 1 (negative = destructive, positive = constructive)
}

/**
 * Elemental generation cycle:
 * Wood → Fire → Earth → Metal → Water → Wood
 * 
 * Elemental control cycle:
 * Wood controls Earth
 * Earth controls Water
 * Water controls Fire
 * Fire controls Metal
 * Metal controls Wood
 */
const GENERATION_CYCLE: Array<[keyof ElementalState, keyof ElementalState]> = [
  ['wood', 'fire'],
  ['fire', 'earth'],
  ['earth', 'metal'],
  ['metal', 'water'],
  ['water', 'wood']
];

const CONTROL_CYCLE: Array<[keyof ElementalState, keyof ElementalState]> = [
  ['wood', 'earth'],
  ['earth', 'water'],
  ['water', 'fire'],
  ['fire', 'metal'],
  ['metal', 'wood']
];

/**
 * Resonance S-GAN — computes resonance from elemental algebra
 */
export class ResonanceSGAN {
  private elementalWeights: ElementalState;
  private history: ElementalState[] = [];
  private maxHistory: number = 100;

  constructor(initialWeights?: Partial<ElementalState>) {
    this.elementalWeights = {
      fire: 0.2,
      earth: 0.2,
      metal: 0.2,
      water: 0.2,
      wood: 0.2,
      ...initialWeights
    };
  }

  /**
   * Compute all elemental interactions in current state
   */
  computeInteractions(state: ElementalState): ElementalInteraction[] {
    const interactions: ElementalInteraction[] = [];
    const elements = Object.keys(state) as Array<keyof ElementalState>;

    for (let i = 0; i < elements.length; i++) {
      for (let j = 0; j < elements.length; j++) {
        if (i === j) continue;

        const source = elements[i];
        const target = elements[j];
        const interaction = this.computeSingleInteraction(source, target, state);
        interactions.push(interaction);
      }
    }

    return interactions;
  }

  private computeSingleInteraction(
    source: keyof ElementalState,
    target: keyof ElementalState,
    state: ElementalState
  ): ElementalInteraction {
    const sourceVal = state[source];
    const targetVal = state[target];

    // Check generation relationship
    const generates = GENERATION_CYCLE.some(([s, t]) => s === source && t === target);
    const isGeneratedBy = GENERATION_CYCLE.some(([s, t]) => s === target && t === source);

    // Check control relationship
    const controls = CONTROL_CYCLE.some(([s, t]) => s === source && t === target);
    const isControlledBy = CONTROL_CYCLE.some(([s, t]) => s === target && t === source);

    let relationship: ElementalInteraction['relationship'];
    let direction: number;

    if (generates) {
      relationship = 'generates';
      direction = 1.0;
    } else if (controls) {
      relationship = 'controls';
      direction = 0.5;
    } else if (isGeneratedBy) {
      relationship = 'drains';
      direction = -0.5;
    } else if (isControlledBy) {
      relationship = 'conflicts';
      direction = -1.0;
    } else {
      // Same element or no direct relationship
      relationship = 'harmonizes';
      direction = 0.0;
    }

    const strength = sourceVal * targetVal * (1 + Math.abs(direction) * 0.5);

    return { source, target, relationship, strength, direction };
  }

  /**
   * Compute RU (Resonance-Unity) score from elemental state
   */
  computeRUScore(state: ElementalState): RUScore {
    const interactions = this.computeInteractions(state);

    // Resonance: how well elements harmonize
    const harmonyInteractions = interactions.filter(i => i.relationship === 'harmonizes');
    const resonance = harmonyInteractions.length > 0
      ? harmonyInteractions.reduce((sum, i) => sum + i.strength, 0) / harmonyInteractions.length
      : 0.5;

    // Unity: balance between all elements
    const values = Object.values(state);
    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((sum, v) => sum + Math.pow(v - avg, 2), 0) / values.length;
    const unity = 1 - Math.min(1, variance * 4);

    // Tension: creative conflict between elements
    const conflictInteractions = interactions.filter(i => 
      i.relationship === 'conflicts' || i.relationship === 'controls'
    );
    const tension = conflictInteractions.length > 0
      ? conflictInteractions.reduce((sum, i) => sum + i.strength, 0) / conflictInteractions.length
      : 0.3;

    // Flow: generation cycle strength
    const generationInteractions = interactions.filter(i => i.relationship === 'generates');
    const flow = generationInteractions.length > 0
      ? generationInteractions.reduce((sum, i) => sum + i.strength, 0) / generationInteractions.length
      : 0.5;

    // Stability: earth + metal dominance
    const stability = (state.earth + state.metal) / 2;

    // Transformation: fire + water interaction (steam, change)
    const transformation = state.fire * state.water * 2;

    return {
      resonance: Math.min(1, resonance),
      unity: Math.min(1, unity),
      tension: Math.min(1, tension),
      flow: Math.min(1, flow),
      stability: Math.min(1, stability),
      transformation: Math.min(1, transformation)
    };
  }

  /**
   * Update elemental state based on external input
   */
  updateElementalState(
    current: ElementalState,
    input: Partial<ElementalState>,
    intensity: number = 0.3
  ): ElementalState {
    const updated: ElementalState = { ...current };

    for (const [key, value] of Object.entries(input)) {
      if (value !== undefined && key in updated) {
        const k = key as keyof ElementalState;
        updated[k] = Math.max(0, Math.min(1, 
          current[k] * (1 - intensity) + value * intensity
        ));
      }
    }

    // Apply elemental interactions (feedback)
    const interactions = this.computeInteractions(updated);

    for (const interaction of interactions) {
      if (interaction.relationship === 'generates') {
        // Source generates target: target gets boost
        updated[interaction.target] = Math.min(1, 
          updated[interaction.target] + interaction.strength * 0.05
        );
      } else if (interaction.relationship === 'drains') {
        // Source is drained by target: source loses
        updated[interaction.source] = Math.max(0,
          updated[interaction.source] - interaction.strength * 0.03
        );
      } else if (interaction.relationship === 'conflicts') {
        // Conflict: both lose slightly
        updated[interaction.source] = Math.max(0,
          updated[interaction.source] - interaction.strength * 0.02
        );
        updated[interaction.target] = Math.max(0,
          updated[interaction.target] - interaction.strength * 0.02
        );
      }
    }

    // Normalize to prevent runaway growth
    const total = Object.values(updated).reduce((a, b) => a + b, 0);
    if (total > 0) {
      const scale = 2.5 / total;  // Target sum of ~2.5 (average 0.5 per element)
      for (const key of Object.keys(updated) as Array<keyof ElementalState>) {
        updated[key] = Math.min(1, updated[key] * scale);
      }
    }

    this.history.push({ ...updated });
    if (this.history.length > this.maxHistory) {
      this.history.shift();
    }

    return updated;
  }

  /**
   * Compute elemental state from astrological positions
   */
  computeFromAstrology(positions: Array<{ planet: string; sign: string; longitude: number }>): ElementalState {
    const signElements: Record<string, keyof ElementalState> = {
      'Aries': 'fire', 'Leo': 'fire', 'Sagittarius': 'fire',
      'Taurus': 'earth', 'Virgo': 'earth', 'Capricorn': 'earth',
      'Gemini': 'metal', 'Libra': 'metal', 'Aquarius': 'metal',
      'Cancer': 'water', 'Scorpio': 'water', 'Pisces': 'water'
    };

    // Wood is associated with spring signs (Aries start, but let's map differently)
    const signWood: Record<string, boolean> = {
      'Aries': true, 'Taurus': true, 'Gemini': true  // Spring
    };

    const counts = { fire: 0, earth: 0, metal: 0, water: 0, wood: 0 };

    positions.forEach(p => {
      const element = signElements[p.sign];
      if (element) {
        counts[element]++;
      }
      if (signWood[p.sign]) {
        counts.wood += 0.5;
      }
    });

    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    if (total === 0) return { fire: 0.2, earth: 0.2, metal: 0.2, water: 0.2, wood: 0.2 };

    return {
      fire: Math.min(1, counts.fire / total * 2),
      earth: Math.min(1, counts.earth / total * 2),
      metal: Math.min(1, counts.metal / total * 2),
      water: Math.min(1, counts.water / total * 2),
      wood: Math.min(1, counts.wood / total * 2)
    };
  }

  /**
   * Get elemental history
   */
  getHistory(): ElementalState[] {
    return [...this.history];
  }

  /**
   * Get elemental weights
   */
  getWeights(): ElementalState {
    return { ...this.elementalWeights };
  }

  /**
   * Set elemental weights
   */
  setWeights(weights: Partial<ElementalState>): void {
    this.elementalWeights = { ...this.elementalWeights, ...weights };
  }
}

export default ResonanceSGAN;
