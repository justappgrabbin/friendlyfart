/**
 * ╔═══════════════════════════════════════════════════════════════════════════╗
 * ║           USER DISCERNMENT ENGINE — Learns the Human                      ║
 * ║                                                                          ║
 * ║  Not about filtering files. About UNDERSTANDING PEOPLE.                    ║
 * ║                                                                          ║
 * ║  Core Principle: The OS thrives on user success.                         ║
 * ║  It pays attention to each person's individual design.                   ║
 * ║  It learns what works and what doesn't FOR THEM.                         ║
 * ║  It recognizes patterns across designs and deciphers differentiation.    ║
 * ║                                                                          ║
 * ║  Example:                                                                ║
 * ║    You: Gate 55.2 in the Mind (Ajna)                                     ║
 * ║    Joseph: Gate 55.2 in the Body (Sacral/Root/etc)                       ║
 * ║    Jessica: Phoenix (Gate 55) in the Body                                ║
 * ║    You: Phoenix (Gate 55) in the Mind                                    ║
 * ║                                                                          ║
 * ║    System learns: 55/59 channel behaves DIFFERENTLY depending on:        ║
 * ║      • Which center it's in                                              ║
 * ║      • Who's living it                                                   ║
 * ║      • What the surrounding design looks like                              ║
 * ║      • What the person's history and success patterns are                  ║
 * ║                                                                          ║
 * ║  The system GROWS by understanding more humans more deeply.              ║
 * ╚═══════════════════════════════════════════════════════════════════════════╝
 */

import { OntologyEngine, AddressableEntity } from './autopoietic-os';
import { ResonanceInjector, ResonanceField } from './morph-engine';

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: HUMAN DESIGN PROFILE — Deep User Model
// ═══════════════════════════════════════════════════════════════════════════

export interface HumanDesignProfile {
  // Core design
  type: string;             // Generator, Projector, Manifestor, Reflector
  strategy: string;
  authority: string;
  profile: string;          // e.g., "5/1", "6/2"

  // Definition
  definition: 'single' | 'split' | 'triple' | 'quadruple';
  definedCenters: string[];
  undefinedCenters: string[];

  // Gates & Channels
  consciousGates: GatePlacement[];    // Personality (red/black in traditional)
  unconsciousGates: GatePlacement[];  // Design
  activeChannels: Channel[];

  // Variables
  variables: {
    digestion: string;
    environment: string;
    awareness: string;
    perspective: string;
    motivation: string;
    mind: string;
  };

  // Incarnation Cross
  cross: {
    sun: GatePlacement;
    earth: GatePlacement;
    northNode: GatePlacement;
    southNode: GatePlacement;
  };

  // Computed patterns
  patterns: DetectedPattern[];

  // User history
  createdAt: number;
  updatedAt: number;
  interactionCount: number;
  successLog: SuccessEvent[];
  struggleLog: StruggleEvent[];
}

export interface GatePlacement {
  gate: number;
  line: number;
  center: string;           // Which center: head, ajna, throat, g, heart, sacral, solarPlexus, spleen, root
  color: number;            // 1-6
  tone: number;             // 1-6
  base: number;             // 1-5
  isConscious: boolean;     // Personality (red) vs Design (black)
}

export interface Channel {
  gateA: number;
  gateB: number;
  centerA: string;
  centerB: string;
  isConscious: boolean;
}

export interface DetectedPattern {
  pattern: string;          // e.g., "55/59_channel", "phoenix_archetype", "mind_definition"
  confidence: number;
  evidence: GatePlacement[];
  description: string;
}

export interface SuccessEvent {
  timestamp: number;
  context: string;            // What was happening
  action: string;           // What the user did
  outcome: string;          // What happened
  resonance: number;        // How aligned it felt 0-1
  patternTriggered: string[]; // Which HD patterns were active
}

export interface StruggleEvent {
  timestamp: number;
  context: string;
  action: string;
  outcome: string;
  friction: number;         // How much resistance 0-1
  patternTriggered: string[];
  lesson: string;           // What the system learned
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: PATTERN RECOGNITION — Deciphers Differentiation
// ═══════════════════════════════════════════════════════════════════════════

export interface PatternInstance {
  userId: string;
  pattern: string;
  placement: GatePlacement;
  context: string;            // center, type, profile, surrounding gates
  behavior: string;           // How this person expresses it
  successRate: number;
  resonanceHistory: number[];
}

export interface PatternDifferentiation {
  pattern: string;
  instances: PatternInstance[];
  differentiations: {
    byCenter: Record<string, PatternInstance[]>;
    byType: Record<string, PatternInstance[]>;
    byProfile: Record<string, PatternInstance[]>;
    byDefinition: Record<string, PatternInstance[]>;
  };
  insights: string[];
  confidence: number;
}

/**
 * Pattern Decipherer — learns how the same gate/channel behaves differently
 */
export class PatternDecipherer {
  private patterns: Map<string, PatternInstance[]> = new Map();
  private differentiations: Map<string, PatternDifferentiation> = new Map();
  private insights: Map<string, string[]> = new Map();

  /**
   * Register a user's pattern instance
   */
  registerPattern(userId: string, profile: HumanDesignProfile, placement: GatePlacement): void {
    const patternKey = `gate_${placement.gate}`;
    const channelKey = profile.activeChannels
      .find(c => c.gateA === placement.gate || c.gateB === placement.gate);

    const instance: PatternInstance = {
      userId,
      pattern: patternKey,
      placement,
      context: this.buildContext(profile, placement),
      behavior: 'unknown',  // Filled in through observation
      successRate: 0.5,
      resonanceHistory: []
    };

    const existing = this.patterns.get(patternKey) || [];
    existing.push(instance);
    this.patterns.set(patternKey, existing);

    // If part of a channel, register channel pattern
    if (channelKey) {
      const channelPattern = `channel_${Math.min(channelKey.gateA, channelKey.gateB)}_${Math.max(channelKey.gateA, channelKey.gateB)}`;
      const channelInstances = this.patterns.get(channelPattern) || [];
      channelInstances.push({
        ...instance,
        pattern: channelPattern
      });
      this.patterns.set(channelPattern, channelInstances);
    }
  }

  /**
   * Decipher how a pattern differentiates across users
   */
  decipherPattern(patternKey: string): PatternDifferentiation | null {
    const instances = this.patterns.get(patternKey);
    if (!instances || instances.length < 2) return null;

    const diff: PatternDifferentiation = {
      pattern: patternKey,
      instances,
      differentiations: {
        byCenter: {},
        byType: {},
        byProfile: {},
        byDefinition: {}
      },
      insights: [],
      confidence: 0
    };

    // Group by center
    for (const instance of instances) {
      const center = instance.placement.center;
      if (!diff.differentiations.byCenter[center]) {
        diff.differentiations.byCenter[center] = [];
      }
      diff.differentiations.byCenter[center].push(instance);
    }

    // Generate insights
    const centers = Object.keys(diff.differentiations.byCenter);
    if (centers.length > 1) {
      diff.insights.push(
        `${patternKey} expresses differently in ${centers.length} centers: ${centers.join(', ')}`
      );

      // Compare success rates by center
      for (const [center, centerInstances] of Object.entries(diff.differentiations.byCenter)) {
        const avgSuccess = centerInstances.reduce((s, i) => s + i.successRate, 0) / centerInstances.length;
        diff.insights.push(
          `In ${center}: avg success rate ${(avgSuccess * 100).toFixed(0)}% (${centerInstances.length} instances)`
        );
      }
    }

    // Check for Phoenix pattern (Gate 55)
    if (patternKey === 'gate_55') {
      const phoenixInstances = instances.filter(i => 
        i.placement.gate === 55
      );

      const mindPhoenix = phoenixInstances.filter(i => i.placement.center === 'ajna' || i.placement.center === 'head');
      const bodyPhoenix = phoenixInstances.filter(i => 
        ['sacral', 'root', 'spleen', 'solarPlexus', 'heart'].includes(i.placement.center)
      );

      if (mindPhoenix.length > 0 && bodyPhoenix.length > 0) {
        diff.insights.push(
          `Phoenix (Gate 55) differentiation: MIND (${mindPhoenix.length}) vs BODY (${bodyPhoenix.length})`
        );
        diff.insights.push(
          `Mind Phoenix: spiritual/abstraction/liberation through awareness`
        );
        diff.insights.push(
          `Body Phoenix: physical/somatic/liberation through action`
        );
      }
    }

    // Check for 55/59 channel
    if (patternKey === 'channel_55_59') {
      const channelInstances = instances.filter(i => i.pattern === 'channel_55_59');
      if (channelInstances.length > 0) {
        diff.insights.push(
          `55/59 (Cyclical Energy) channel: ${channelInstances.length} instances`
        );

        // Analyze what drives the cycle for each person
        for (const instance of channelInstances) {
          const userContext = instance.context;
          diff.insights.push(
            `User ${instance.userId}: 55/59 driven by ${userContext}`
          );
        }
      }
    }

    diff.confidence = Math.min(1, instances.length * 0.1 + 0.3);
    this.differentiations.set(patternKey, diff);

    return diff;
  }

  /**
   * Get all deciphered patterns
   */
  getAllDifferentiations(): PatternDifferentiation[] {
    return Array.from(this.differentiations.values());
  }

  /**
   * Get insights for a specific user
   */
  getUserInsights(userId: string): string[] {
    const insights: string[] = [];

    for (const [pattern, instances] of this.patterns) {
      const userInstances = instances.filter(i => i.userId === userId);
      if (userInstances.length > 0) {
        const diff = this.differentiations.get(pattern);
        if (diff) {
          insights.push(...diff.insights);
        }
      }
    }

    return insights;
  }

  /**
   * Compare two users' patterns
   */
  compareUsers(userA: string, userB: string): {
    sharedPatterns: string[];
    differentiatedPatterns: Array<{
      pattern: string;
      userA: PatternInstance;
      userB: PatternInstance;
      difference: string;
    }>;
    insights: string[];
  } {
    const sharedPatterns: string[] = [];
    const differentiatedPatterns: Array<{
      pattern: string;
      userA: PatternInstance;
      userB: PatternInstance;
      difference: string;
    }> = [];

    for (const [pattern, instances] of this.patterns) {
      const aInstances = instances.filter(i => i.userId === userA);
      const bInstances = instances.filter(i => i.userId === userB);

      if (aInstances.length > 0 && bInstances.length > 0) {
        sharedPatterns.push(pattern);

        // Compare placements
        for (const aInst of aInstances) {
          for (const bInst of bInstances) {
            if (aInst.placement.center !== bInst.placement.center) {
              differentiatedPatterns.push({
                pattern,
                userA: aInst,
                userB: bInst,
                difference: `${userA}: ${aInst.placement.center} vs ${userB}: ${bInst.placement.center}`
              });
            }
          }
        }
      }
    }

    const insights: string[] = [];
    if (differentiatedPatterns.length > 0) {
      insights.push(`${userA} and ${userB} share ${sharedPatterns.length} patterns but express them differently`);

      for (const diff of differentiatedPatterns) {
        insights.push(`${diff.pattern}: ${diff.difference}`);
      }
    }

    return { sharedPatterns, differentiatedPatterns, insights };
  }

  private buildContext(profile: HumanDesignProfile, placement: GatePlacement): string {
    const parts = [
      `type:${profile.type}`,
      `profile:${profile.profile}`,
      `center:${placement.center}`,
      `definition:${profile.definition}`,
      `authority:${profile.authority}`
    ];
    return parts.join('|');
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: USER DISCERNMENT ENGINE — Learns What Works for Each Person
// ═══════════════════════════════════════════════════════════════════════════

export interface UserSession {
  userId: string;
  profile: HumanDesignProfile;
  startTime: number;
  currentResonance: ResonanceField;
  activePatterns: string[];
  recommendedActions: string[];
  avoidedActions: string[];
  context: Record<string, any>;
}

export interface DiscernmentRule {
  id: string;
  pattern: string;          // e.g., "gate_55_in_mind"
  condition: string;        // e.g., "user.type === 'Projector'"
  recommendation: string;   // What to do
  confidence: number;       // 0-1
  successRate: number;      // Historical success
  usageCount: number;
  createdAt: number;
  evolvedAt: number;
}

/**
 * User Discernment Engine — learns each person deeply
 */
export class UserDiscernmentEngine {
  private profiles: Map<string, HumanDesignProfile> = new Map();
  private sessions: Map<string, UserSession> = new Map();
  private rules: Map<string, DiscernmentRule[]> = new Map();
  private patternDecipherer: PatternDecipherer;
  private resonanceInjector: ResonanceInjector;
  private learningRate: number = 0.1;

  constructor() {
    this.patternDecipherer = new PatternDecipherer();
    this.resonanceInjector = new ResonanceInjector();
  }

  /**
   * Register a new user with their Human Design
   */
  registerUser(userId: string, profile: HumanDesignProfile): HumanDesignProfile {
    // Detect patterns in their design
    profile.patterns = this.detectPatterns(profile);

    // Register all gates with pattern decipherer
    for (const gate of profile.consciousGates) {
      this.patternDecipherer.registerPattern(userId, profile, gate);
    }
    for (const gate of profile.unconsciousGates) {
      this.patternDecipherer.registerPattern(userId, profile, gate);
    }

    // Decipher key patterns
    this.patternDecipherer.decipherPattern('gate_55');
    this.patternDecipherer.decipherPattern('channel_55_59');

    // Initialize rules for this user
    this.rules.set(userId, this.generateInitialRules(profile));

    this.profiles.set(userId, profile);
    return profile;
  }

  /**
   * Start a session for a user
   */
  startSession(userId: string, context: Record<string, any> = {}): UserSession {
    const profile = this.profiles.get(userId);
    if (!profile) throw new Error(`User ${userId} not registered`);

    const session: UserSession = {
      userId,
      profile,
      startTime: Date.now(),
      currentResonance: this.resonanceInjector.computeResonanceField(),
      activePatterns: this.getActivePatterns(profile),
      recommendedActions: this.getRecommendations(userId),
      avoidedActions: this.getAvoidances(userId),
      context
    };

    this.sessions.set(userId, session);
    return session;
  }

  /**
   * Record a success event for a user
   */
  recordSuccess(
    userId: string,
    context: string,
    action: string,
    outcome: string,
    resonance: number
  ): void {
    const profile = this.profiles.get(userId);
    if (!profile) return;

    const event: SuccessEvent = {
      timestamp: Date.now(),
      context,
      action,
      outcome,
      resonance,
      patternTriggered: this.getActivePatterns(profile)
    };

    profile.successLog.push(event);
    profile.interactionCount++;
    profile.updatedAt = Date.now();

    // Learn from success
    this.learnFromSuccess(userId, event);
  }

  /**
   * Record a struggle event for a user
   */
  recordStruggle(
    userId: string,
    context: string,
    action: string,
    outcome: string,
    friction: number,
    lesson: string
  ): void {
    const profile = this.profiles.get(userId);
    if (!profile) return;

    const event: StruggleEvent = {
      timestamp: Date.now(),
      context,
      action,
      outcome,
      friction,
      patternTriggered: this.getActivePatterns(profile),
      lesson
    };

    profile.struggleLog.push(event);
    profile.interactionCount++;
    profile.updatedAt = Date.now();

    // Learn from struggle
    this.learnFromStruggle(userId, event);
  }

  /**
   * Get personalized recommendations for a user
   */
  getRecommendations(userId: string): string[] {
    const profile = this.profiles.get(userId);
    const rules = this.rules.get(userId);
    if (!profile || !rules) return [];

    const currentResonance = this.resonanceInjector.computeResonanceField();
    const activeGates = currentResonance.gateActivations;

    const recommendations: string[] = [];

    // Check which of user's gates are currently active
    for (const gate of profile.consciousGates) {
      if (activeGates.includes(gate.gate)) {
        // This gate is active today — recommend based on its placement
        const rule = rules.find(r => r.pattern === `gate_${gate.gate}_in_${gate.center}`);
        if (rule && rule.confidence > 0.6) {
          recommendations.push(rule.recommendation);
        }
      }
    }

    // Add pattern-based recommendations
    const diff = this.patternDecipherer.getAllDifferentiations();
    for (const d of diff) {
      const userInstances = d.instances.filter(i => i.userId === userId);
      if (userInstances.length > 0) {
        for (const insight of d.insights) {
          if (!recommendations.includes(insight)) {
            recommendations.push(insight);
          }
        }
      }
    }

    return recommendations;
  }

  /**
   * Get what to avoid for a user
   */
  getAvoidances(userId: string): string[] {
    const profile = this.profiles.get(userId);
    if (!profile) return [];

    const avoidances: string[] = [];

    // Based on struggle log
    for (const struggle of profile.struggleLog.slice(-10)) {
      if (struggle.friction > 0.7) {
        avoidances.push(`Avoid: ${struggle.action} in ${struggle.context} (high friction)`);
      }
    }

    // Based on undefined centers (where user is most vulnerable)
    for (const center of profile.undefinedCenters) {
      avoidances.push(`Be mindful in ${center}: you're open here, easily conditioned`);
    }

    return avoidances;
  }

  /**
   * Get insights comparing this user to others
   */
  getComparativeInsights(userId: string): string[] {
    const insights: string[] = [];
    const allUserIds = Array.from(this.profiles.keys());

    for (const otherId of allUserIds) {
      if (otherId === userId) continue;

      const comparison = this.patternDecipherer.compareUsers(userId, otherId);
      if (comparison.sharedPatterns.length > 0) {
        insights.push(...comparison.insights);
      }
    }

    return insights;
  }

  /**
   * Get user's discernment stats
   */
  getUserStats(userId: string): {
    profile: HumanDesignProfile | undefined;
    patterns: DetectedPattern[];
    recommendations: number;
    successRate: number;
    totalInteractions: number;
    lessonsLearned: number;
    comparativeInsights: number;
  } {
    const profile = this.profiles.get(userId);
    if (!profile) {
      return {
        profile: undefined,
        patterns: [],
        recommendations: 0,
        successRate: 0,
        totalInteractions: 0,
        lessonsLearned: 0,
        comparativeInsights: 0
      };
    }

    const successes = profile.successLog.length;
    const struggles = profile.struggleLog.length;
    const total = successes + struggles;

    return {
      profile,
      patterns: profile.patterns,
      recommendations: this.getRecommendations(userId).length,
      successRate: total > 0 ? successes / total : 0.5,
      totalInteractions: profile.interactionCount,
      lessonsLearned: profile.struggleLog.filter(s => s.lesson).length,
      comparativeInsights: this.getComparativeInsights(userId).length
    };
  }

  /**
   * Get system-wide discernment stats
   */
  getSystemStats(): {
    totalUsers: number;
    totalPatterns: number;
    totalDifferentiations: number;
    totalRules: number;
    averageSuccessRate: number;
    topPattern: string;
    mostActiveUser: string;
  } {
    const users = Array.from(this.profiles.values());
    const allRules = Array.from(this.rules.values()).flat();

    const patternCounts: Record<string, number> = {};
    for (const profile of users) {
      for (const pattern of profile.patterns) {
        patternCounts[pattern.pattern] = (patternCounts[pattern.pattern] || 0) + 1;
      }
    }

    const topPattern = Object.entries(patternCounts)
      .sort((a, b) => b[1] - a[1])[0]?.[0] || 'none';

    const mostActiveUser = Array.from(this.profiles.entries())
      .sort((a, b) => b[1].interactionCount - a[1].interactionCount)[0]?.[0] || 'none';

    return {
      totalUsers: users.length,
      totalPatterns: Object.keys(patternCounts).length,
      totalDifferentiations: this.patternDecipherer.getAllDifferentiations().length,
      totalRules: allRules.length,
      averageSuccessRate: users.reduce((s, u) => {
        const total = u.successLog.length + u.struggleLog.length;
        return s + (total > 0 ? u.successLog.length / total : 0.5);
      }, 0) / Math.max(1, users.length),
      topPattern,
      mostActiveUser
    };
  }

  private detectPatterns(profile: HumanDesignProfile): DetectedPattern[] {
    const patterns: DetectedPattern[] = [];

    // Detect Phoenix (Gate 55)
    const gate55 = [...profile.consciousGates, ...profile.unconsciousGates]
      .find(g => g.gate === 55);
    if (gate55) {
      patterns.push({
        pattern: 'phoenix_archetype',
        confidence: 1.0,
        evidence: [gate55],
        description: `Phoenix (Gate 55) in ${gate55.center}: liberation through ${gate55.isConscious ? 'conscious' : 'unconscious'} awareness`
      });
    }

    // Detect 55/59 channel
    const channel5559 = profile.activeChannels
      .find(c => (c.gateA === 55 && c.gateB === 59) || (c.gateA === 59 && c.gateB === 55));
    if (channel5559) {
      patterns.push({
        pattern: 'cyclical_energy',
        confidence: 1.0,
        evidence: [...profile.consciousGates.filter(g => g.gate === 55 || g.gate === 59)],
        description: '55/59 Cyclical Energy: emotional/mood-driven energy that flows in cycles'
      });
    }

    // Detect mind definition
    const mindGates = profile.consciousGates.filter(g => 
      ['head', 'ajna', 'throat'].includes(g.center)
    );
    if (mindGates.length >= 3) {
      patterns.push({
        pattern: 'mind_definition',
        confidence: mindGates.length / 9,
        evidence: mindGates,
        description: 'Strong mind definition: mental processes are consistent and reliable'
      });
    }

    // Detect body definition
    const bodyGates = profile.consciousGates.filter(g => 
      ['sacral', 'root', 'spleen', 'solarPlexus', 'heart'].includes(g.center)
    );
    if (bodyGates.length >= 3) {
      patterns.push({
        pattern: 'body_definition',
        confidence: bodyGates.length / 9,
        evidence: bodyGates,
        description: 'Strong body definition: physical/energy processes are consistent'
      });
    }

    return patterns;
  }

  private getActivePatterns(profile: HumanDesignProfile): string[] {
    const currentResonance = this.resonanceInjector.computeResonanceField();
    const activeGates = currentResonance.gateActivations;

    const patterns: string[] = [];

    for (const gate of [...profile.consciousGates, ...profile.unconsciousGates]) {
      if (activeGates.includes(gate.gate)) {
        patterns.push(`gate_${gate.gate}_in_${gate.center}`);
      }
    }

    return patterns;
  }

  private generateInitialRules(profile: HumanDesignProfile): DiscernmentRule[] {
    const rules: DiscernmentRule[] = [];

    // Rule based on type
    rules.push({
      id: `rule-type-${profile.type}`,
      pattern: `type_${profile.type}`,
      condition: `user.type === '${profile.type}'`,
      recommendation: `As a ${profile.type}, your strategy is: ${profile.strategy}`,
      confidence: 0.8,
      successRate: 0.7,
      usageCount: 0,
      createdAt: Date.now(),
      evolvedAt: Date.now()
    });

    // Rules based on defined centers
    for (const center of profile.definedCenters) {
      rules.push({
        id: `rule-center-${center}`,
        pattern: `defined_${center}`,
        condition: `user.definedCenters.includes('${center}')`,
        recommendation: `Your ${center} is defined: this is your consistent strength`,
        confidence: 0.9,
        successRate: 0.8,
        usageCount: 0,
        createdAt: Date.now(),
        evolvedAt: Date.now()
      });
    }

    // Rules based on undefined centers (vulnerabilities)
    for (const center of profile.undefinedCenters) {
      rules.push({
        id: `rule-undefined-${center}`,
        pattern: `undefined_${center}`,
        condition: `user.undefinedCenters.includes('${center}')`,
        recommendation: `Your ${center} is open: be aware of conditioning here`,
        confidence: 0.85,
        successRate: 0.6,
        usageCount: 0,
        createdAt: Date.now(),
        evolvedAt: Date.now()
      });
    }

    return rules;
  }

  private learnFromSuccess(userId: string, event: SuccessEvent): void {
    const rules = this.rules.get(userId);
    if (!rules) return;

    for (const pattern of event.patternTriggered) {
      const rule = rules.find(r => r.pattern === pattern);
      if (rule) {
        rule.successRate = Math.min(1, rule.successRate + this.learningRate);
        rule.confidence = Math.min(1, rule.confidence + this.learningRate * 0.5);
        rule.usageCount++;
        rule.evolvedAt = Date.now();
      }
    }
  }

  private learnFromStruggle(userId: string, event: StruggleEvent): void {
    const rules = this.rules.get(userId);
    if (!rules) return;

    for (const pattern of event.patternTriggered) {
      const rule = rules.find(r => r.pattern === pattern);
      if (rule) {
        rule.successRate = Math.max(0, rule.successRate - this.learningRate);
        rule.confidence = Math.max(0, rule.confidence - this.learningRate * 0.3);
        rule.usageCount++;
        rule.evolvedAt = Date.now();

        // Add new avoidance rule
        rules.push({
          id: `rule-avoid-${Date.now()}`,
          pattern: `avoid_${pattern}`,
          condition: `context === '${event.context}'`,
          recommendation: `Lesson: ${event.lesson}`,
          confidence: event.friction,
          successRate: 1 - event.friction,
          usageCount: 1,
          createdAt: Date.now(),
          evolvedAt: Date.now()
        });
      }
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: EXPORTS
// ═══════════════════════════════════════════════════════════════════════════

export {
  PatternDecipherer,
  UserDiscernmentEngine
};

export type {
  HumanDesignProfile,
  GatePlacement,
  Channel,
  DetectedPattern,
  SuccessEvent,
  StruggleEvent,
  PatternInstance,
  PatternDifferentiation,
  UserSession,
  DiscernmentRule
};

export function createUserDiscernmentEngine(): UserDiscernmentEngine {
  return new UserDiscernmentEngine();
}

export default UserDiscernmentEngine;
