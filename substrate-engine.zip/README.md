# Substrate Engine - Your 5D Orchestrator

## What This Is
This adapts Daniel Miessler's Substrate (semantic knowledge framework) to your 5-dimensional engine. It gives you:

- **Ingestor**: Reads Substrate repos, extracts gates (Problems, Solutions, Arguments, Data, etc.)
- **Pipeline**: Fetches live data from FRED, BLS, CDC, Census, EPA
- **API Server**: FastAPI backend your chat PWA calls
- **Supabase Bridge**: SQL schema + inserts for your database

## Files

| File | Purpose |
|------|---------|
| `substrate_ingestor.py` | Parses Substrate repo into dimensional gates |
| `substrate_pipeline.py` | Fetches live data from 5 authoritative sources |
| `main.py` | FastAPI server (your orchestrator API) |
| `supabase_schema.sql` | Database schema for Supabase |
| `requirements.txt` | Python dependencies |
| `render.yaml` | Render.com deployment config |

## Quick Start

### 1. Local Test
```bash
cd substrate-engine
pip install -r requirements.txt
python main.py
```

API runs at `http://localhost:8000`

### 2. API Endpoints Your PWA Uses

```
GET  /              → Engine status
GET  /gates         → List all gates (filter by ?type=Problem&search=economy)
GET  /gates/{id}    → Get specific gate
GET  /gates/{id}/network → Get gate + connected gates
POST /query         → Main chat query (returns relevant gates + data)
POST /ingest        → Ingest a Substrate repo
POST /data/refresh  → Run data pipelines
GET  /dimensions    → 5D structure overview
GET  /health        → Health check
```

### 3. Deploy to Render
```bash
git init
git add .
git commit -m "substrate engine v0.1"
git push  # to your Render-connected repo
```

### 4. Connect Your PWA
```javascript
// In your chat app
const API_URL = 'https://synthia-server.onrender.com';

async function askEngine(question) {
  const res = await fetch(`${API_URL}/query`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({question, include_data: true})
  });
  return res.json();
}
```

### 5. Get API Keys (Free)

| Source | URL | Rate Limit |
|--------|-----|------------|
| FRED | fred.stlouisfed.org/docs/api | 120/min |
| Census | api.census.gov/data/key_signup | 500/day |
| BLS | bls.gov/developers/home | 500/day |
| CDC | No key needed | Fair use |
| EPA | Email aqs.support@epa.gov | 10/min |

Set them in Render dashboard as env vars.

## The 5D Mapping

| Dimension | Substrate Gate | What It Means |
|-----------|---------------|---------------|
| 1 - Being | Problem | What's broken |
| 2 - Movement | Solution | How to fix it |
| 3 - Design | Argument | Why it works |
| 4 - Space | DataSource | Evidence from reality |
| 5 - Emergence | EmergentLink | AI-discovered connections |

## Next Steps

1. Deploy this to Render
2. Point your chat PWA at the API
3. When user asks a question, `/query` returns relevant gates
4. Add LLM layer to generate emergent links (5th dimension)
5. Write validated links back to Supabase
