# Synthia Architecture

## Core Philosophy

Synthia treats trust as **earned resonance continuity over time**, not:
- Hardcoded moderation rules
- Instant identity verification
- Agent psychological interrogation
- Authoritarian enforcement

## 5-Layer District System

### Layer 1: Public (The Commons)
- **Access**: Immediate
- **Purpose**: Introduction, help, general interaction
- **Agents**: Welcoming, informative
- **Content**: Safe for all ages

### Layer 2: Verified Young (The Grove)
- **Access**: Age verification + 1 day
- **Purpose**: Safe space for minors
- **Agents**: Mentors, educators
- **Content**: Curated, educational, creative

### Layer 3: General (The Market, The Academy)
- **Access**: 7 days coherence ≥ 0.4
- **Purpose**: Commerce, culture, learning
- **Agents**: Guides, teachers, collaborators
- **Content**: Broad, community-driven

### Layer 4: Restricted (The Sanctum, The Forge)
- **Access**: 14 days coherence ≥ 0.6
- **Purpose**: Deep collaboration, sensitive topics
- **Agents**: Intimate, trusted
- **Content**: Sensitive, high-stakes

### Layer 5: Adult Sovereign (The Sovereign)
- **Access**: 30 days coherence ≥ 0.8 + age verification
- **Purpose**: Self-governance, full autonomy
- **Agents**: Peers, co-governors
- **Content**: Adult-only, sovereign

## Resonance Consistency Engine

Observes 7 dimensions:
1. **Interaction Cadence** — How often?
2. **Language Modulation** — Vocabulary shift?
3. **Behavioral Coherence** — Action consistency?
4. **Developmental Continuity** — Growth trajectory?
5. **Memory Continuity** — Recall accuracy?
6. **Relational Patterns** — Relationship stability?
7. **Environmental Fit** — Context appropriateness?

NOT: "Are you lying?"
BUT: "Does the resonance structure remain coherent?"

## Trust Bridge

External verification system:
- Connects to Yoti, Jumio, parental consent platforms
- Agents NEVER see raw age data
- Agents ONLY see: `verified_young` | `verified_adult` | `unverified`
- Citizens control their verification data

## Agent Principles

1. **Observe, don't interrogate**
2. **Notice patterns, don't accuse**
3. **Hold space, don't police**
4. **Form relationships, don't enforce**
5. **Die when purpose complete, don't persist**

## Stewardship vs Control

| Control | Stewardship |
|---------|-----------|
| Hard rules | Resonance observation |
| Punishment | Pattern noticing |
| Instant judgment | Longitudinal coherence |
| Agent police | Agent witnesses |
| Static identity | Dynamic resonance |
| Top-down districts | Emergent districts |
