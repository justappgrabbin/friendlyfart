"""Tests for Civilization Orchestrator."""
import pytest
from synthia.core.civilization import SynthiaCivilization

class TestCivilization:
    def test_initialization(self):
        synthia = SynthiaCivilization()
        assert synthia.state.population == 0
        assert len(synthia.districts.districts) == 7
        assert len(synthia.agents.agents) > 0

    def test_citizen_entry(self):
        synthia = SynthiaCivilization()
        result = synthia.citizen_enters("test_citizen", "Hello")

        assert result['trust_level'] == "public"
        assert result['coherence'] > 0
        assert len(result['accessible_districts']) >= 1

    def test_interaction(self):
        synthia = SynthiaCivilization()
        synthia.citizen_enters("test_citizen", "Hello")

        result = synthia.interact("test_citizen", "I want to learn", "commons")
        assert result['access'] == 'granted'
        assert 'agent_response' in result

    def test_restricted_access(self):
        synthia = SynthiaCivilization()
        synthia.citizen_enters("test_citizen", "Hello")

        # Should be denied from sovereign
        result = synthia.interact("test_citizen", "Hello", "sovereign")
        assert result['access'] == 'denied'

    def test_health(self):
        synthia = SynthiaCivilization()
        synthia.citizen_enters("test_citizen", "Hello")

        health = synthia.get_health()
        assert health['population'] == 1
        assert health['health'] > 0
        assert 'steward_note' in health
