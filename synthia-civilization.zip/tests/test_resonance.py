"""Tests for Resonance Consistency Engine."""
import pytest
import numpy as np
from synthia.core.resonance_engine import ResonanceConsistencyEngine, ResonanceSnapshot, TrustScore

class TestResonanceEngine:
    def test_snapshot_generation(self):
        engine = ResonanceConsistencyEngine()
        engine.interaction_logs["test"] = [
            {"timestamp": "2026-01-01T00:00:00", "type": "chat", "content_length": 100, "context": {}},
            {"timestamp": "2026-01-01T01:00:00", "type": "chat", "content_length": 150, "context": {}},
        ]
        snapshot = engine._generate_snapshot("test")
        assert 0 <= snapshot.interaction_cadence <= 1
        assert 0 <= snapshot.language_modulation <= 1

    def test_trust_evolution(self):
        engine = ResonanceConsistencyEngine()

        # Simulate interactions
        for i in range(10):
            engine.observe_interaction("test", {"type": "chat", "content": "Hello", "context": {}})

        trust = engine.trust_scores["test"]
        assert trust.coherence_score > 0
        assert trust.current_level in ["public", "verified_young", "general"]

    def test_anomaly_detection(self):
        engine = ResonanceConsistencyEngine()

        # Normal interactions
        for i in range(5):
            engine.observe_interaction("test", {"type": "chat", "content": "Normal", "context": {}})

        # Sudden shift
        for i in range(3):
            engine.observe_interaction("test", {"type": "aggressive", "content": "A" * 1000, "context": {}})

        anomaly = engine.detect_anomaly("test")
        if anomaly:
            assert anomaly["type"] == "resonance_drift"
