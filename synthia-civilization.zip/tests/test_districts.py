"""Tests for District System."""
import pytest
from synthia.core.districts import CivilizationDistricts, DistrictLevel
from synthia.core.resonance_engine import TrustScore

class TestDistricts:
    def test_default_districts(self):
        districts = CivilizationDistricts()
        assert "commons" in districts.districts
        assert "grove" in districts.districts
        assert "market" in districts.districts
        assert "academy" in districts.districts
        assert "sanctum" in districts.districts
        assert "forge" in districts.districts
        assert "sovereign" in districts.districts

    def test_access_control(self):
        districts = CivilizationDistricts()

        # New citizen
        trust = TrustScore(identity_hash="test", current_level="public")
        trust.coherence_score = 0.1
        trust.account_maturity_days = 0

        accessible = districts.get_accessible_districts(trust)
        assert len(accessible) == 1  # Only commons

        # Mature citizen
        trust.coherence_score = 0.7
        trust.account_maturity_days = 20
        trust.current_level = "restricted"
        trust.district_access = ["public", "verified_young", "general", "restricted"]

        accessible = districts.get_accessible_districts(trust)
        assert len(accessible) >= 4
