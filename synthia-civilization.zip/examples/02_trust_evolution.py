#!/usr/bin/env python3
"""
Example 2: Trust Evolution
Watch how trust evolves through resonance continuity.
"""

from synthia.core.civilization import SynthiaCivilization
import time

def main():
    print("=" * 60)
    print("  EXAMPLE 2: Trust Evolution")
    print("=" * 60)

    synthia = SynthiaCivilization()
    identity = "citizen_trust_test"

    # Simulate 30 days of interactions
    print("\nSimulating 30 days of authentic interactions...")

    messages = [
        "Hello, I'm interested in learning",
        "Can you tell me about resonance?",
        "I've been thinking about trust systems",
        "What makes a civilization living?",
        "I appreciate the stewardship approach",
        "How do districts emerge?",
        "I want to contribute to The Forge",
        "Can we explore deeper topics?",
        "I've been consistent in my engagement",
        "Trust should be earned, not demanded",
    ]

    for day, message in enumerate(messages):
        # Simulate maturation
        trust = synthia.resonance.trust_scores.get(identity)
        if trust:
            trust.account_maturity_days = day + 1

        result = synthia.interact(identity, message, "commons")

        if trust:
            print(f"Day {day+1}: coherence={trust.coherence_score:.2f}, level={trust.current_level}")

    # Final state
    print("\n--- Final Trust State ---")
    trust = synthia.resonance.trust_scores.get(identity)
    if trust:
        print(f"Coherence: {trust.coherence_score:.2f}")
        print(f"Level: {trust.current_level}")
        print(f"Districts: {trust.district_access}")
        print(f"Maturity: {trust.account_maturity_days} days")

if __name__ == "__main__":
    main()
