#!/usr/bin/env python3
"""
Example 1: Enter Synthia
A citizen enters the civilization and explores districts.
"""

from synthia.core.civilization import SynthiaCivilization

def main():
    print("=" * 60)
    print("  EXAMPLE 1: Entering Synthia")
    print("=" * 60)

    # Create civilization
    synthia = SynthiaCivilization()

    # Citizen enters
    result = synthia.citizen_enters(
        identity_hash="citizen_001",
        message="Hello, I'm new here"
    )

    print(f"\nCitizen: citizen_001")
    print(f"Trust Level: {result['trust_level']}")
    print(f"Coherence: {result['coherence']:.2f}")
    print(f"Accessible Districts: {result['accessible_districts']}")

    if result.get('greeting'):
        print(f"\nAgent: {result['greeting']['response']}")

    # Try to enter a district
    print("\n--- Trying to enter The Academy ---")
    interact = synthia.interact(
        identity_hash="citizen_001",
        message="I want to learn about resonance",
        district="academy"
    )

    if interact['access'] == 'granted':
        print(f"✅ Access granted to Academy")
        print(f"Agent: {interact['agent_response']['response']}")
    else:
        print(f"❌ {interact.get('message', 'Access denied')}")

    # Check civilization health
    print("\n--- Civilization Health ---")
    health = synthia.get_health()
    print(f"Population: {health['population']}")
    print(f"Health Index: {health['health']:.2f}")
    print(f"Steward Note: {health['steward_note']}")

if __name__ == "__main__":
    main()
