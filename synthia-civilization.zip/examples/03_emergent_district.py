#!/usr/bin/env python3
"""
Example 3: Emergent District
Watch a new district form from citizen resonance.
"""

from synthia.core.civilization import SynthiaCivilization

def main():
    print("=" * 60)
    print("  EXAMPLE 3: Emergent District")
    print("=" * 60)

    synthia = SynthiaCivilization()

    # Create citizens who resonate together
    citizens = ["artist_001", "artist_002", "artist_003"]

    print("\nCitizens engaging in creative collaboration...")
    for citizen in citizens:
        for day in range(10):
            trust = synthia.resonance.trust_scores.get(citizen)
            if trust:
                trust.account_maturity_days = day + 1

            synthia.interact(citizen, f"Creative collaboration day {day+1}", "market")

    # Spawn emergent district
    print("\n--- Spawning Emergent District ---")
    result = synthia.spawn_emergent_district(
        name="atelier",
        level="general",
        description="A space for creative collaboration that emerged from citizen resonance",
        min_coherence=0.5,
        min_maturity_days=10,
        citizens=citizens
    )

    print(f"District: {result['district']}")
    print(f"Agents: {result['agents']}")
    print(f"Message: {result['message']}")

    # Check health
    health = synthia.get_health()
    print(f"\nCivilization now has {health['active_districts']} districts")
    print(f"Emergent events: {health['emergent_events']}")

if __name__ == "__main__":
    main()
