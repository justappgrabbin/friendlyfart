"""
Synthia CLI
Command-line interface for the living civilization.
"""

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from typing import Optional, List
from pathlib import Path

from synthia.core.civilization import SynthiaCivilization
from synthia.core.resonance_engine import ResonanceConsistencyEngine
from synthia.core.districts import DistrictLevel

app = typer.Typer(help="Synthia — Living Civilization Platform")
console = Console()

# Global civilization instance
synthia = SynthiaCivilization()

@app.command()
def enter(
    identity: str = typer.Argument(..., help="Your identity hash"),
    message: str = typer.Option("Hello Synthia", "--message", "-m", help="First message"),
):
    """Enter the Synthia civilization."""
    result = synthia.citizen_enters(identity, message)

    console.print(Panel.fit(
        f"[bold cyan]Welcome to Synthia[/bold cyan]\n"
        f"Identity: [bold]{identity}[/bold]\n"
        f"Trust Level: [green]{result['trust_level']}[/green]\n"
        f"Coherence: [yellow]{result['coherence']:.2f}[/yellow]",
        title="🌊 Civilization Entry",
        border_style="blue"
    ))

    # Show accessible districts
    tree = Tree("[bold]Accessible Districts[/bold]")
    for district in result['accessible_districts']:
        tree.add(f"🏛️ {district}")
    console.print(tree)

    if result.get('greeting'):
        console.print(f"\n[italic]{result['greeting']['response']}[/italic]")

@app.command()
def speak(
    identity: str = typer.Argument(..., help="Your identity hash"),
    message: str = typer.Argument(..., help="What you want to say"),
    district: str = typer.Option("commons", "--district", "-d", help="Target district"),
):
    """Speak in a district."""
    result = synthia.interact(identity, message, district)

    if result.get('access') == 'denied':
        console.print(Panel.fit(
            f"[bold red]Access Denied[/bold red]\n"
            f"{result.get('message', 'Insufficient trust')}",
            border_style="red"
        ))
        return

    console.print(Panel.fit(
        f"[bold]{district}[/bold] | Trust: [green]{result['trust_level']}[/green]",
        border_style="green"
    ))

    if result.get('agent_response'):
        console.print(f"\n🤖 {result['agent_response']['response']}")

    if result.get('anomaly'):
        console.print(f"\n[dim]⚠️  {result['anomaly']['message']}[/dim]")

@app.command()
def verify(
    identity: str = typer.Argument(..., help="Your identity hash"),
    method: str = typer.Option("document", "--method", help="Verification method"),
):
    """Request age verification."""
    result = synthia.request_verification(identity, method)
    console.print(Panel.fit(
        f"[bold]Verification Requested[/bold]\n"
        f"Method: {result['method']}\n"
        f"{result['message']}\n"
        f"[dim]{result['note']}[/dim]",
        border_style="yellow"
    ))

@app.command()
def health():
    """Check civilization health."""
    report = synthia.get_health()

    table = Table(title="Synthia Civilization Health")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("Population", str(report['population']))
    table.add_row("Age (days)", str(report['age_days']))
    table.add_row("Average Coherence", f"{report['average_coherence']:.2f}")
    table.add_row("Health Index", f"{report['health']:.2f}")
    table.add_row("Active Agents", str(report['active_agents']))
    table.add_row("Active Districts", str(report['active_districts']))
    table.add_row("Emergent Events", str(report['emergent_events']))

    console.print(table)

    if report.get('collapse_signals'):
        console.print("\n[bold red]Collapse Signals:[/bold red]")
        for signal in report['collapse_signals']:
            console.print(f"  ⚠️  {signal}")

    console.print(f"\n[italic dim]{report['steward_note']}[/italic dim]")

@app.command()
def districts():
    """List all districts."""
    tree = Tree("[bold]Synthia Districts[/bold]")

    levels = {
        "public": tree.add("🌐 Public Layer"),
        "verified_young": tree.add("🌱 Verified Young"),
        "general": tree.add("🏛️ General Civilization"),
        "restricted": tree.add("🔒 Restricted"),
        "adult_sovereign": tree.add("👑 Adult Sovereign"),
    }

    for name, district in synthia.districts.districts.items():
        level_str = district.level.value
        if level_str in levels:
            levels[level_str].add(f"{name}: {district.description}")

    console.print(tree)

@app.command()
def resonance(
    identity: str = typer.Argument(..., help="Identity hash to check"),
):
    """Check your resonance profile."""
    if identity not in synthia.resonance.trust_scores:
        console.print("[red]Citizen not found[/red]")
        return

    trust = synthia.resonance.trust_scores[identity]

    table = Table(title=f"Resonance Profile: {identity}")
    table.add_column("Dimension", style="cyan")
    table.add_column("Score", style="green")

    table.add_row("Coherence", f"{trust.coherence_score:.2f}")
    table.add_row("Stability", f"{trust.longitudinal_stability:.2f}")
    table.add_row("Maturity (days)", str(trust.account_maturity_days))
    table.add_row("Current Level", trust.current_level)
    table.add_row("District Access", ", ".join(trust.district_access))
    table.add_row("Trusted Relationships", str(len(trust.trusted_relationships)))

    console.print(table)

def main():
    app()

if __name__ == "__main__":
    main()
