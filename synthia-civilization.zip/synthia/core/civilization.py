"""
Synthia Civilization Orchestrator

The steward of the living civilization.

NOT a controller. NOT a police force.
A steward that:
- Tends the resonance field
- Watches for predatory patterns (not people)
- Allows emergent districts to form
- Dissolves districts when resonance collapses
- Protects the vulnerable without interrogating them
- Trusts the system to self-correct

"A living civilization requires stewardship, not just invention."
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
import numpy as np

from synthia.core.resonance_engine import ResonanceConsistencyEngine, TrustScore
from synthia.core.districts import CivilizationDistricts, DistrictLevel
from synthia.core.agents import AgentNursery, SynthiaAgent, AgentResonance
from synthia.core.trust_bridge import TrustBridge, VerificationStatus

@dataclass
class CivilizationState:
    """The living state of the civilization."""
    birth_time: datetime = field(default_factory=datetime.now)
    population: int = 0
    active_districts: int = 0
    active_agents: int = 0
    average_coherence: float = 0.0
    health_index: float = 1.0  # 0-1, civilization vitality
    emergent_events: List[Dict] = field(default_factory=list)

    def age_days(self) -> int:
        return (datetime.now() - self.birth_time).days

class SynthiaCivilization:
    """
    The living civilization.

    Usage:
        synthia = SynthiaCivilization()

        # Citizen enters
        result = synthia.citizen_enters(identity_hash="abc123", message="Hello")

        # Citizen interacts
        result = synthia.interact(identity_hash="abc123", 
                                  message="I want to learn",
                                  district="academy")

        # Check civilization health
        health = synthia.get_health()
    """

    def __init__(self):
        self.resonance = ResonanceConsistencyEngine()
        self.districts = CivilizationDistricts()
        self.agents = AgentNursery()
        self.trust_bridge = TrustBridge()
        self.state = CivilizationState()

        # Spawn initial agents for each district
        self._seed_agents()

    def _seed_agents(self):
        """Seed initial agents into districts."""
        for district_name, district in self.districts.districts.items():
            # Spawn 2-3 agents per district
            for i in range(2):
                agent = self.agents.spawn(
                    district=district_name,
                    purpose=f"Guide and support in {district_name}",
                    name=f"{district.name}-Guide-{i+1}",
                    resonance=AgentResonance(
                        warmth=0.6 + np.random.random() * 0.3,
                        depth=0.4 + np.random.random() * 0.4,
                        pace=0.4 + np.random.random() * 0.4,
                        curiosity=0.5 + np.random.random() * 0.4,
                        boundary=0.5 + np.random.random() * 0.3
                    )
                )
                district.active_agents.append(agent.agent_id)

    def citizen_enters(self, identity_hash: str, message: str, 
                       context: Optional[Dict] = None) -> Dict:
        """
        A citizen enters the civilization.

        Returns:
            - Available districts
            - Trust status
            - Agent greeting
            - Resonance reading
        """
        context = context or {}

        # Observe interaction (builds resonance history)
        resonance_result = self.resonance.observe_interaction(
            identity_hash=identity_hash,
            interaction={"type": "enter", "content": message, "context": context}
        )

        # Get trust score
        trust = self.resonance.trust_scores.get(identity_hash)
        if not trust:
            return {"error": "Trust score not found"}

        # Get accessible districts
        accessible = self.districts.get_accessible_districts(trust)

        # Find agent in first accessible district
        greeting = None
        if accessible:
            district_agents = self.agents.get_district_agents(accessible[0].name)
            if district_agents:
                greeting = district_agents[0].perceive(
                    citizen_id=identity_hash,
                    message=message,
                    context={"district": accessible[0].name, **context}
                )

        # Update civilization state
        self.state.population = len(self.resonance.trust_scores)
        self.state.average_coherence = np.mean([
            t.coherence_score for t in self.resonance.trust_scores.values()
        ]) if self.resonance.trust_scores else 0.0

        return {
            "identity_hash": identity_hash,
            "trust_level": trust.current_level,
            "coherence": trust.coherence_score,
            "accessible_districts": [d.name for d in accessible],
            "greeting": greeting,
            "resonance": resonance_result,
            "civilization_health": self.state.health_index
        }

    def interact(self, identity_hash: str, message: str, 
                district: str, context: Optional[Dict] = None) -> Dict:
        """
        Citizen interacts within a district.
        """
        context = context or {}

        # Check district access
        trust = self.resonance.trust_scores.get(identity_hash)
        if not trust:
            return {"error": "Citizen not found", "access": "denied"}

        target_district = self.districts.get_district(district)
        if not target_district:
            return {"error": "District not found", "access": "denied"}

        if not target_district.can_enter(trust):
            return {
                "error": "Insufficient trust for this district",
                "access": "denied",
                "required_coherence": target_district.min_coherence,
                "your_coherence": trust.coherence_score,
                "message": "Trust is earned through resonance continuity. Continue engaging authentically."
            }

        # Observe interaction
        resonance_result = self.resonance.observe_interaction(
            identity_hash=identity_hash,
            interaction={"type": "interact", "content": message, "context": {**context, "district": district}}
        )

        # Get district agent
        district_agents = self.agents.get_district_agents(district)
        if not district_agents:
            # Spawn emergency agent
            agent = self.agents.spawn(district=district, purpose="Emergency support")
            district_agents = [agent]

        # Agent responds
        agent = district_agents[0]  # Simple routing — could be more sophisticated
        response = agent.perceive(
            citizen_id=identity_hash,
            message=message,
            context={"district": district, **context}
        )

        # Check for anomalies
        anomaly = self.resonance.detect_anomaly(identity_hash)
        if anomaly:
            # Log but don't act — stewardship, not policing
            self.state.emergent_events.append({
                "type": "anomaly_detected",
                "identity_hash": identity_hash,
                "details": anomaly,
                "action": "observing",
                "timestamp": datetime.now().isoformat()
            })

        return {
            "access": "granted",
            "district": district,
            "agent_response": response,
            "resonance": resonance_result,
            "anomaly": anomaly,
            "trust_level": trust.current_level
        }

    def request_verification(self, identity_hash: str, method: str = "document") -> Dict:
        """Request external age verification."""
        return self.trust_bridge.request_verification(identity_hash, method)

    def complete_verification(self, identity_hash: str, external_result: Dict) -> Dict:
        """Complete verification and update trust."""
        record = self.trust_bridge.complete_verification(identity_hash, external_result)

        # Update trust score with verification
        if identity_hash in self.resonance.trust_scores:
            trust = self.resonance.trust_scores[identity_hash]

            if record.status == VerificationStatus.VERIFIED_YOUNG:
                trust.district_access.append("verified_young")
                if "grove" not in trust.district_access:
                    trust.district_access.append("grove")
            elif record.status == VerificationStatus.VERIFIED_ADULT:
                trust.district_access.extend(["verified_young", "general", "restricted", "adult_sovereign"])

            # Re-evaluate promotion
            self.resonance._evaluate_promotion(trust)

        return {
            "status": record.status.value,
            "districts": self.resonance.trust_scores.get(identity_hash, TrustScore(identity_hash="")).district_access
        }

    def get_health(self) -> Dict:
        """Get civilization health report."""
        report = self.resonance.get_civilization_report()

        # Adjust health index
        self.state.health_index = report.get("health", 0.5)

        # Check for civilization collapse signals
        collapse_signals = []
        if report.get("coherence_variance", 0) > 0.5:
            collapse_signals.append("High coherence variance — trust fragmentation")
        if self.state.health_index < 0.3:
            collapse_signals.append("Critical health — civilization at risk")

        return {
            **report,
            "age_days": self.state.age_days(),
            "active_agents": len([a for a in self.agents.agents.values() if a.is_alive]),
            "active_districts": len(self.districts.districts),
            "emergent_events": len(self.state.emergent_events),
            "collapse_signals": collapse_signals,
            "steward_note": "A living civilization requires stewardship, not just invention."
        }

    def spawn_emergent_district(self, name: str, level: str, description: str,
                                min_coherence: float, min_maturity_days: int,
                                citizens: List[str]) -> Dict:
        """
        Spawn an emergent district when citizens resonate together.

        This is how the civilization grows — not top-down, but emergent.
        """
        level_enum = DistrictLevel(level)

        district = self.districts.create_district(
            name=name,
            level=level_enum,
            description=description,
            min_coherence=min_coherence,
            min_maturity_days=min_maturity_days
        )

        # Spawn agents for new district
        for i in range(2):
            agent = self.agents.spawn(
                district=name,
                purpose=f"Support emergent district: {name}",
                name=f"{name}-Emergent-{i+1}"
            )
            district.active_agents.append(agent.agent_id)

        self.state.emergent_events.append({
            "type": "district_emerged",
            "name": name,
            "citizens": citizens,
            "timestamp": datetime.now().isoformat()
        })

        return {
            "district": name,
            "level": level,
            "agents": district.active_agents,
            "message": f"A new district has emerged from resonance. Welcome to {name}."
        }
