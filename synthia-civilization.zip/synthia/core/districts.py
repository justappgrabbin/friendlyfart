"""
Synthia District System

Layered civilization architecture:

    Public Layer
         ↓
    Verified Young Layer
         ↓
    General Civilization Layer
         ↓
    Restricted Resonance Districts
         ↓
    Adult Sovereign Districts

Access emerges through:
- Age verification (external, not agent-interrogation)
- Longitudinal consistency (resonance history)
- Account maturity (time-based)
- Behavioral coherence (pattern stability)
- Trusted relationship networks (social proof)
- Resonance history (earned trust)
- Contextual stability (environmental fit)

NOT through:
- Agent psychological interrogation
- Instant self-declaration
- Hardcoded moderation rules
- Authoritarian enforcement
"""

from typing import Dict, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

class DistrictLevel(Enum):
    PUBLIC = "public"
    VERIFIED_YOUNG = "verified_young"
    GENERAL = "general"
    RESTRICTED = "restricted"
    ADULT_SOVEREIGN = "adult_sovereign"

@dataclass
class District:
    """A district in the Synthia civilization."""
    name: str
    level: DistrictLevel
    description: str
    min_coherence: float
    min_maturity_days: int
    requires_age_verification: bool
    content_tags: List[str] = field(default_factory=list)
    active_agents: List[str] = field(default_factory=list)
    population: int = 0
    resonance_threshold: float = 0.5

    def can_enter(self, trust_score) -> bool:
        """Check if a citizen can enter this district."""
        if trust_score.coherence_score < self.min_coherence:
            return False
        if trust_score.account_maturity_days < self.min_maturity_days:
            return False
        if self.level == DistrictLevel.VERIFIED_YOUNG:
            # Young layer requires external age verification
            # Agents NEVER interrogate — they check verification status
            return "verified_young" in trust_score.district_access
        if self.level in [DistrictLevel.RESTRICTED, DistrictLevel.ADULT_SOVEREIGN]:
            return trust_score.current_level in ["restricted", "adult_sovereign"]
        return True

class CivilizationDistricts:
    """Manages all districts in the Synthia civilization."""

    def __init__(self):
        self.districts: Dict[str, District] = {}
        self._init_default_districts()

    def _init_default_districts(self):
        """Initialize the 5-layer district system."""

        # Layer 1: Public — open to all
        self.districts["commons"] = District(
            name="The Commons",
            level=DistrictLevel.PUBLIC,
            description="Open gathering space. No trust required. Basic interaction.",
            min_coherence=0.0,
            min_maturity_days=0,
            requires_age_verification=False,
            content_tags=["introduction", "help", "general"],
            resonance_threshold=0.3
        )

        # Layer 2: Verified Young — age-verified minors
        self.districts["grove"] = District(
            name="The Grove",
            level=DistrictLevel.VERIFIED_YOUNG,
            description="Safe space for young citizens. Curated content. Mentorship.",
            min_coherence=0.2,
            min_maturity_days=1,
            requires_age_verification=True,
            content_tags=["education", "mentorship", "creative", "safe"],
            resonance_threshold=0.4
        )

        # Layer 3: General — established citizens
        self.districts["market"] = District(
            name="The Market",
            level=DistrictLevel.GENERAL,
            description="Main civilization hub. Commerce, culture, collaboration.",
            min_coherence=0.4,
            min_maturity_days=7,
            requires_age_verification=False,
            content_tags=["commerce", "culture", "collaboration", "events"],
            resonance_threshold=0.5
        )

        self.districts["academy"] = District(
            name="The Academy",
            level=DistrictLevel.GENERAL,
            description="Learning and knowledge exchange. All ages welcome.",
            min_coherence=0.4,
            min_maturity_days=7,
            requires_age_verification=False,
            content_tags=["learning", "research", "teaching", "knowledge"],
            resonance_threshold=0.5
        )

        # Layer 4: Restricted — high-trust citizens
        self.districts["sanctum"] = District(
            name="The Sanctum",
            level=DistrictLevel.RESTRICTED,
            description="Deep resonance spaces. Intimate collaboration. Sensitive topics.",
            min_coherence=0.6,
            min_maturity_days=14,
            requires_age_verification=False,
            content_tags=["intimate", "sensitive", "deep", "trusted"],
            resonance_threshold=0.7
        )

        self.districts["forge"] = District(
            name="The Forge",
            level=DistrictLevel.RESTRICTED,
            description="Creation and innovation. High-stakes projects.",
            min_coherence=0.6,
            min_maturity_days=14,
            requires_age_verification=False,
            content_tags=["creation", "innovation", "projects", "build"],
            resonance_threshold=0.7
        )

        # Layer 5: Adult Sovereign — fully trusted adults
        self.districts["sovereign"] = District(
            name="The Sovereign",
            level=DistrictLevel.ADULT_SOVEREIGN,
            description="Self-governing districts. Adult-only. Full autonomy.",
            min_coherence=0.8,
            min_maturity_days=30,
            requires_age_verification=True,
            content_tags=["autonomy", "governance", "adult", "sovereign"],
            resonance_threshold=0.9
        )

    def get_accessible_districts(self, trust_score) -> List[District]:
        """Get all districts a citizen can access."""
        return [d for d in self.districts.values() if d.can_enter(trust_score)]

    def get_district(self, name: str) -> Optional[District]:
        """Get a district by name."""
        return self.districts.get(name)

    def create_district(self, name: str, level: DistrictLevel, description: str,
                       min_coherence: float, min_maturity_days: int,
                       requires_age_verification: bool = False,
                       content_tags: List[str] = None) -> District:
        """Create a new emergent district."""
        district = District(
            name=name,
            level=level,
            description=description,
            min_coherence=min_coherence,
            min_maturity_days=min_maturity_days,
            requires_age_verification=requires_age_verification,
            content_tags=content_tags or []
        )
        self.districts[name] = district
        return district
