"""Core Synthia modules."""
