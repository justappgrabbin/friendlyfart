"""
Synthia Resonance Consistency Engine

Observes temporal consistency, behavioral coherence, interaction cadence,
language modulation, developmental continuity, memory continuity, relational
patterns, and environmental fit.

Not: "Are you lying?"
But: "Does the resonance structure remain coherent over time?"
"""

import numpy as np
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict
import hashlib

@dataclass
class ResonanceSnapshot:
    """A point-in-time resonance reading."""
    timestamp: datetime
    interaction_cadence: float      # How often they interact (0-1)
    language_modulation: float      # Vocabulary complexity shift (0-1)
    behavioral_coherence: float   # Action consistency (0-1)
    developmental_continuity: float  # Growth trajectory (0-1)
    memory_continuity: float       # Recall accuracy (0-1)
    relational_patterns: float     # Relationship stability (0-1)
    environmental_fit: float       # Context appropriateness (0-1)

    def vector(self) -> np.ndarray:
        return np.array([
            self.interaction_cadence,
            self.language_modulation,
            self.behavioral_coherence,
            self.developmental_continuity,
            self.memory_continuity,
            self.relational_patterns,
            self.environmental_fit
        ])

@dataclass
class TrustScore:
    """Earned trust through resonance continuity over time."""
    identity_hash: str
    current_level: str  # public | verified_young | general | restricted | adult_sovereign
    resonance_history: List[ResonanceSnapshot] = field(default_factory=list)
    coherence_score: float = 0.0  # 0-1, higher = more trustworthy
    longitudinal_stability: float = 0.0  # Variance over time
    account_maturity_days: int = 0
    trusted_relationships: List[str] = field(default_factory=list)
    district_access: List[str] = field(default_factory=list)

    def compute_coherence(self) -> float:
        """Compute resonance consistency over time."""
        if len(self.resonance_history) < 2:
            return 0.3  # New accounts start with base trust

        vectors = [s.vector() for s in self.resonance_history[-20:]]  # Last 20 snapshots
        mean_vector = np.mean(vectors, axis=0)

        # Compute variance — low variance = high coherence
        variances = [np.var([v[i] for v in vectors]) for i in range(7)]
        avg_variance = np.mean(variances)

        # Coherence = 1 - normalized variance
        self.coherence_score = max(0.0, 1.0 - avg_variance * 2.0)
        self.longitudinal_stability = 1.0 - avg_variance

        return self.coherence_score

    def can_access(self, district: str) -> bool:
        """Check if user can access a district based on earned trust."""
        district_requirements = {
            "public": 0.0,
            "verified_young": 0.2,
            "general": 0.4,
            "restricted": 0.6,
            "adult_sovereign": 0.8
        }
        required = district_requirements.get(district, 1.0)
        return self.coherence_score >= required and district in self.district_access

class ResonanceConsistencyEngine:
    """
    Discernment system — not authoritarian moderation.

    Observes patterns over time to build trust organically.
    No psychological interrogation. No instant identity verification.
    Just: does the resonance structure remain coherent?
    """

    def __init__(self):
        self.snapshots: Dict[str, List[ResonanceSnapshot]] = defaultdict(list)
        self.trust_scores: Dict[str, TrustScore] = {}
        self.interaction_logs: Dict[str, List[Dict]] = defaultdict(list)

    def observe_interaction(self, identity_hash: str, interaction: Dict):
        """Record an interaction and update resonance snapshot."""
        self.interaction_logs[identity_hash].append({
            "timestamp": datetime.now().isoformat(),
            "type": interaction.get("type", "unknown"),
            "content_length": len(str(interaction.get("content", ""))),
            "context": interaction.get("context", {})
        })

        # Generate snapshot from recent interactions
        snapshot = self._generate_snapshot(identity_hash)
        self.snapshots[identity_hash].append(snapshot)

        # Update trust score
        if identity_hash not in self.trust_scores:
            self.trust_scores[identity_hash] = TrustScore(
                identity_hash=identity_hash,
                current_level="public",
                account_maturity_days=0
            )

        trust = self.trust_scores[identity_hash]
        trust.resonance_history = self.snapshots[identity_hash]
        trust.compute_coherence()

        # Auto-promote based on coherence + maturity
        self._evaluate_promotion(trust)

        return {
            "coherence": trust.coherence_score,
            "stability": trust.longitudinal_stability,
            "level": trust.current_level,
            "districts": trust.district_access
        }

    def _generate_snapshot(self, identity_hash: str) -> ResonanceSnapshot:
        """Generate a resonance snapshot from interaction history."""
        logs = self.interaction_logs[identity_hash][-50:]  # Last 50 interactions

        if not logs:
            return ResonanceSnapshot(
                timestamp=datetime.now(),
                interaction_cadence=0.5,
                language_modulation=0.5,
                behavioral_coherence=0.5,
                developmental_continuity=0.5,
                memory_continuity=0.5,
                relational_patterns=0.5,
                environmental_fit=0.5
            )

        # Interaction cadence: how frequent?
        timestamps = [datetime.fromisoformat(l["timestamp"]) for l in logs]
        if len(timestamps) > 1:
            intervals = [(timestamps[i] - timestamps[i-1]).total_seconds() 
                        for i in range(1, len(timestamps))]
            avg_interval = np.mean(intervals) if intervals else 3600
            cadence = max(0.0, 1.0 - avg_interval / 86400)  # Normalize to daily
        else:
            cadence = 0.5

        # Language modulation: vocabulary complexity
        content_lengths = [l["content_length"] for l in logs]
        avg_length = np.mean(content_lengths) if content_lengths else 100
        modulation = min(1.0, avg_length / 500)  # Normalize

        # Behavioral coherence: consistency in interaction types
        types = [l["type"] for l in logs]
        type_consistency = len(set(types)) / len(types) if types else 1.0
        coherence = 1.0 - type_consistency  # Lower variety = higher coherence

        # Developmental continuity: growth trajectory
        if len(content_lengths) > 5:
            trend = np.polyfit(range(len(content_lengths)), content_lengths, 1)[0]
            continuity = 0.5 + np.tanh(trend / 10) * 0.5  # -1 to 1 → 0 to 1
        else:
            continuity = 0.5

        # Memory continuity: recall of past interactions
        contexts = [str(l.get("context", {})) for l in logs]
        context_repetition = len(set(contexts)) / len(contexts) if contexts else 1.0
        memory = 1.0 - context_repetition

        # Relational patterns: interaction with same entities
        # (Simplified — would track actual relationships)
        relational = 0.5 + (len(logs) / 100) * 0.5  # More interactions = more relational

        # Environmental fit: context appropriateness
        # (Simplified — would analyze content appropriateness)
        environmental = 0.7  # Base assumption of good fit

        return ResonanceSnapshot(
            timestamp=datetime.now(),
            interaction_cadence=float(cadence),
            language_modulation=float(modulation),
            behavioral_coherence=float(coherence),
            developmental_continuity=float(continuity),
            memory_continuity=float(memory),
            relational_patterns=float(relational),
            environmental_fit=float(environmental)
        )

    def _evaluate_promotion(self, trust: TrustScore):
        """Evaluate if user should be promoted to next trust level."""
        coherence = trust.coherence_score
        maturity = trust.account_maturity_days

        # Layered access: earned, not declared
        if coherence >= 0.8 and maturity >= 30:
            trust.current_level = "adult_sovereign"
            trust.district_access = ["public", "verified_young", "general", "restricted", "adult_sovereign"]
        elif coherence >= 0.6 and maturity >= 14:
            trust.current_level = "restricted"
            trust.district_access = ["public", "verified_young", "general", "restricted"]
        elif coherence >= 0.4 and maturity >= 7:
            trust.current_level = "general"
            trust.district_access = ["public", "verified_young", "general"]
        elif coherence >= 0.2 and maturity >= 1:
            trust.current_level = "verified_young"
            trust.district_access = ["public", "verified_young"]
        else:
            trust.current_level = "public"
            trust.district_access = ["public"]

    def detect_anomaly(self, identity_hash: str) -> Optional[Dict]:
        """Detect resonance anomalies — potential predatory behavior or identity masking."""
        if identity_hash not in self.trust_scores:
            return None

        trust = self.trust_scores[identity_hash]
        history = trust.resonance_history

        if len(history) < 3:
            return None

        # Check for sudden drops in coherence
        recent = history[-3:]
        vectors = [s.vector() for s in recent]

        # Compute pairwise distances
        distances = []
        for i in range(len(vectors)):
            for j in range(i+1, len(vectors)):
                dist = np.linalg.norm(vectors[i] - vectors[j])
                distances.append(dist)

        avg_distance = np.mean(distances) if distances else 0

        if avg_distance > 1.5:  # Threshold for anomaly
            return {
                "type": "resonance_drift",
                "severity": "high" if avg_distance > 2.0 else "medium",
                "distance": float(avg_distance),
                "message": "Significant resonance drift detected. Possible identity masking or behavioral shift.",
                "recommendation": "Observe longer before granting district access. Do not interrogate."
            }

        return None

    def get_civilization_report(self) -> Dict:
        """Get overall civilization health metrics."""
        if not self.trust_scores:
            return {"population": 0, "health": 0.0}

        coherences = [t.coherence_score for t in self.trust_scores.values()]
        levels = defaultdict(int)
        for t in self.trust_scores.values():
            levels[t.current_level] += 1

        return {
            "population": len(self.trust_scores),
            "average_coherence": float(np.mean(coherences)),
            "coherence_variance": float(np.var(coherences)),
            "district_distribution": dict(levels),
            "health": float(np.mean(coherences) * (1.0 - np.var(coherences)))
        }
