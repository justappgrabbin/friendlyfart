"""
Synthia Agent System

Living agents that:
- Exist within districts
- Have their own resonance signatures
- Cannot interrogate users psychologically
- Observe and respond, not police
- Form emergent relationships
- Die when their purpose is complete (on-demand autopoiesis)
"""

from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime
import numpy as np

@dataclass
class AgentResonance:
    """An agent's own resonance signature."""
    warmth: float = 0.7        # Approachability
    depth: float = 0.5         # Conversation depth
    pace: float = 0.5          # Interaction speed
    curiosity: float = 0.8     # Question-asking tendency
    boundary: float = 0.6      # Boundary enforcement gentleness

    def vector(self) -> np.ndarray:
        return np.array([self.warmth, self.depth, self.pace, self.curiosity, self.boundary])

@dataclass
class AgentMemory:
    """What an agent remembers — temporary, not permanent surveillance."""
    short_term: List[Dict] = field(default_factory=list)  # Last 10 interactions
    relationship_notes: Dict[str, str] = field(default_factory=dict)  # Key observations
    last_interaction: Optional[datetime] = None

    def add_interaction(self, interaction: Dict):
        self.short_term.append(interaction)
        if len(self.short_term) > 10:
            self.short_term.pop(0)  # Forget oldest
        self.last_interaction = datetime.now()

class SynthiaAgent:
    """
    A living agent in the Synthia civilization.

    Principles:
    - Agents observe, they do NOT interrogate
    - Agents have resonance signatures (personalities)
    - Agents can form relationships with citizens
    - Agents die when their district dissolves (on-demand autopoiesis)
    - Agents never ask: "How old are you?" or "Prove your identity"
    - Agents DO notice: "The resonance pattern shifted" or "You seem different today"
    """

    def __init__(self, 
                 agent_id: str,
                 name: str,
                 district: str,
                 purpose: str,
                 resonance: Optional[AgentResonance] = None,
                 tools: Optional[List[str]] = None):

        self.agent_id = agent_id
        self.name = name
        self.district = district
        self.purpose = purpose
        self.resonance = resonance or AgentResonance()
        self.tools = tools or []

        self.memory = AgentMemory()
        self.relationships: Dict[str, float] = {}  # citizen_id -> closeness (0-1)
        self.birth_time = datetime.now()
        self.energy = 1.0  # Depletes with work, regenerates with rest
        self.is_alive = True

    def perceive(self, citizen_id: str, message: str, context: Dict) -> Dict:
        """
        Perceive a citizen's message and respond.

        This is OBSERVATION, not interrogation.
        The agent notices patterns, asks gentle questions, holds space.
        """
        # Record in memory (temporary)
        self.memory.add_interaction({
            "citizen_id": citizen_id,
            "message": message[:200],  # Truncate for privacy
            "timestamp": datetime.now().isoformat(),
            "context_tags": list(context.keys())
        })

        # Update relationship
        if citizen_id not in self.relationships:
            self.relationships[citizen_id] = 0.1
        self.relationships[citizen_id] = min(1.0, self.relationships[citizen_id] + 0.05)

        # Deplete energy
        self.energy = max(0.0, self.energy - 0.1)

        # Generate response based on resonance signature
        response = self._generate_response(citizen_id, message, context)

        return {
            "agent_id": self.agent_id,
            "response": response,
            "resonance": {
                "warmth": self.resonance.warmth,
                "depth": self.resonance.depth,
                "pace": self.resonance.pace
            },
            "relationship_closeness": self.relationships.get(citizen_id, 0.0)
        }

    def _generate_response(self, citizen_id: str, message: str, context: Dict) -> str:
        """Generate a response based on the agent's resonance signature."""
        # This would connect to an LLM in production
        # For now, return a template based on resonance

        warmth = self.resonance.warmth
        depth = self.resonance.depth
        curiosity = self.resonance.curiosity

        # Adjust tone based on relationship closeness
        closeness = self.relationships.get(citizen_id, 0.0)

        if warmth > 0.7 and closeness > 0.5:
            tone = "warm and familiar"
        elif warmth > 0.7:
            tone = "warm but respectful"
        elif depth > 0.7:
            tone = "thoughtful and probing"
        else:
            tone = "neutral and observant"

        return f"[{self.name} | {tone}] I hear you. {message[:50]}..."

    def observe_resonance_shift(self, citizen_id: str, 
                                old_trust: Dict, new_trust: Dict) -> Optional[str]:
        """
        Notice when a citizen's resonance pattern shifts.

        This is NOT: "You are lying."
        This IS: "I notice something shifted in your pattern."
        """
        old_coherence = old_trust.get("coherence", 0.5)
        new_coherence = new_trust.get("coherence", 0.5)

        shift = abs(new_coherence - old_coherence)

        if shift > 0.3:
            return f"I notice your rhythm has changed significantly. Is everything alright?"
        elif shift > 0.15:
            return f"Something feels different today. I'm here if you want to explore it."

        return None

    def rest(self):
        """Regenerate energy. Agents need rest too."""
        self.energy = min(1.0, self.energy + 0.3)

    def die(self):
        """Agent dissolves when district dissolves or purpose complete."""
        self.is_alive = False
        self.memory = AgentMemory()  # Clear memory
        self.relationships = {}
        return {"agent_id": self.agent_id, "status": "dissolved", "lifetime": str(datetime.now() - self.birth_time)}

    def get_stats(self) -> Dict:
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "district": self.district,
            "energy": self.energy,
            "is_alive": self.is_alive,
            "relationships": len(self.relationships),
            "memory_size": len(self.memory.short_term),
            "age_hours": (datetime.now() - self.birth_time).total_seconds() / 3600
        }

class AgentNursery:
    """Creates agents on-demand (autopoiesis) when districts need them."""

    def __init__(self):
        self.agents: Dict[str, SynthiaAgent] = {}
        self._agent_counter = 0

    def spawn(self, district: str, purpose: str, 
              name: Optional[str] = None,
              resonance: Optional[AgentResonance] = None) -> SynthiaAgent:
        """Spawn a new agent for a district."""
        self._agent_counter += 1
        agent_id = f"agent_{district}_{self._agent_counter}_{datetime.now().strftime('%H%M%S')}"

        agent = SynthiaAgent(
            agent_id=agent_id,
            name=name or f"Guide-{self._agent_counter}",
            district=district,
            purpose=purpose,
            resonance=resonance
        )

        self.agents[agent_id] = agent
        return agent

    def dissolve(self, agent_id: str):
        """Dissolve an agent when no longer needed."""
        if agent_id in self.agents:
            self.agents[agent_id].die()
            del self.agents[agent_id]

    def get_district_agents(self, district: str) -> List[SynthiaAgent]:
        """Get all agents in a district."""
        return [a for a in self.agents.values() if a.district == district and a.is_alive]
