"""
Synthia — Living Civilization Platform

A platform for contextual trust emergence, not hardcoded moderation.

Principles:
- Resonance consistency analysis over identity verification
- Discernment systems over authoritarian systems
- Earned trust through longitudinal coherence
- Layered districts: Public → Verified Young → General → Restricted → Adult Sovereign
- Stewardship > invention for living systems
"""

__version__ = "0.1.0"
__author__ = "Synthia Builders"

from synthia.core.civilization import SynthiaCivilization
from synthia.core.resonance_engine import ResonanceConsistencyEngine, TrustScore
from synthia.core.districts import CivilizationDistricts, District, DistrictLevel
from synthia.core.agents import SynthiaAgent, AgentNursery, AgentResonance
from synthia.core.trust_bridge import TrustBridge, VerificationStatus

__all__ = [
    "SynthiaCivilization",
    "ResonanceConsistencyEngine",
    "TrustScore",
    "CivilizationDistricts",
    "District",
    "DistrictLevel",
    "SynthiaAgent",
    "AgentNursery",
    "AgentResonance",
    "TrustBridge",
    "VerificationStatus",
]
