# 🌊 Synthia — Living Civilization Platform

> *"A living civilization requires stewardship, not just invention."*

**Synthia** is a platform for **contextual trust emergence** — not hardcoded moderation.

## Philosophy

| Instead of... | Synthia uses... |
|---------------|----------------|
| Hardcoded moderation | Resonance consistency analysis |
| Authoritarian enforcement | Discernment systems |
| Instant identity verification | Earned trust through longitudinal coherence |
| Agent psychological interrogation | Pattern observation over time |
| Static identity labels | Dynamic resonance profiles |

## Architecture

### 5-Layer District System

```
🌐 Public Layer (The Commons)
    ↓ — earned through: presence
🌱 Verified Young Layer (The Grove)
    ↓ — earned through: age verification + 1 day maturity
🏛️ General Civilization (The Market, The Academy)
    ↓ — earned through: 7 days coherence ≥ 0.4
🔒 Restricted Districts (The Sanctum, The Forge)
    ↓ — earned through: 14 days coherence ≥ 0.6
👑 Adult Sovereign (The Sovereign)
    ↓ — earned through: 30 days coherence ≥ 0.8
```

### Core Systems

- **Resonance Consistency Engine** — Observes temporal consistency, behavioral coherence, interaction cadence, language modulation, developmental continuity, memory continuity, relational patterns, environmental fit
- **Trust Bridge** — External age verification (agents NEVER interrogate)
- **Agent Nursery** — On-demand autopoietic agent spawning
- **Civilization Orchestrator** — Stewardship, not control

## Quick Start

```bash
# Install
pip install -e ".[dev]"

# Enter the civilization
synthia enter your-identity-hash --message "Hello Synthia"

# Speak in a district
synthia speak your-identity-hash "I want to learn" --district academy

# Check civilization health
synthia health

# List districts
synthia districts

# Check your resonance
synthia resonance your-identity-hash
```

## Principles

1. **Agents observe, they do NOT interrogate**
2. **Trust is earned through resonance continuity over time**
3. **Verification happens externally — agents only see status tokens**
4. **Emergent districts form from citizen resonance, not top-down design**
5. **Stewardship > invention for living systems**
6. **Minors are protected through layered access, not invasive questioning**

## License

MIT — Build civilizations, not prisons.
